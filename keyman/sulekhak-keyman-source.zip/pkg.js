const fs = require('fs'), path = require('path');
const OUT = process.argv[2] || 'proj';
const LANGS = [['sulekhak_odia', 'Sulekhak Odia', 'or', 'Odia'], ['sulekhak_devanagari', 'Sulekhak Devanagari', 'hi', 'Hindi (Devanagari)'],
               ['sulekhak_assamese', 'Sulekhak Assamese', 'as', 'Assamese'], ['sulekhak_bangla', 'Sulekhak Bangla', 'bn', 'Bangla']];
fs.writeFileSync(path.join(OUT, 'sulekhak.kpj'), `<?xml version="1.0" encoding="utf-8"?>
<KeymanDeveloperProject>
  <Options>
    <Version>2.0</Version>
    <CompilerWarningsAsErrors>False</CompilerWarningsAsErrors>
    <CheckFilenameConventions>True</CheckFilenameConventions>
  </Options>
</KeymanDeveloperProject>
`);
function kps(list, name, desc) {
  const files = list.map(([id]) => `    <File>
      <Name>..\\build\\${id}.kmx</Name>
    </File>
    <File>
      <Name>..\\build\\${id}.js</Name>
    </File>`).join('\n');
  const kbs = list.map(([id, nm, bcp, ln]) => `    <Keyboard>
      <Name>${nm}</Name>
      <ID>${id}</ID>
      <Version>1.0</Version>
      <Languages>
        <Language ID="${bcp}">${ln}</Language>
      </Languages>
    </Keyboard>`).join('\n');
  return `<?xml version="1.0" encoding="utf-8"?>
<Package>
  <System>
    <KeymanDeveloperVersion>18.0.253</KeymanDeveloperVersion>
    <FileVersion>7.0</FileVersion>
  </System>
  <Options>
    <ReadMeFile>readme.htm</ReadMeFile>
    <LicenseFile>..\\LICENSE.md</LicenseFile>
    <WelcomeFile>welcome.htm</WelcomeFile>
    <FollowKeyboardVersion/>
  </Options>
  <Info>
    <Name URL="https://github.com/Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard">${name}</Name>
    <Copyright URL="">© 2026 Sai Sudeep Das</Copyright>
    <Author URL="">Sai Sudeep Das</Author>
    <Description URL="">${desc}</Description>
  </Info>
  <Files>
${files}
    <File>
      <Name>welcome.htm</Name>
    </File>
    <File>
      <Name>readme.htm</Name>
    </File>
    <File>
      <Name>..\\LICENSE.md</Name>
    </File>
  </Files>
  <Keyboards>
${kbs}
  </Keyboards>
</Package>
`;
}
fs.writeFileSync(path.join(OUT, 'source', 'sulekhak_all.kps'), kps(LANGS, 'Sulekhak (Odia, Devanagari, Assamese, Bangla)', 'Sulekhak phonetic keyboards: type Odia, Devanagari, Assamese and Bangla with English letters.'));
for (const L of LANGS) fs.writeFileSync(path.join(OUT, 'source', L[0] + '.kps'), kps([L], L[1], 'Sulekhak phonetic keyboard: type ' + L[3] + ' with English letters.'));
const page = (title, body) => `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${title}</title>
<style type="text/css">p,li,td { font: 10pt Tahoma; } h1 { font: bold 16pt Tahoma; color: #17475e; } h2 { font: bold 12pt Tahoma; color: #17475e; } code { font-size: 11pt; } td { padding: 2px 10px 2px 0; }</style></head><body>${body}</body></html>
`;
const scheme = `<h2>How to type</h2>
<p>Type the sounds with English letters. The keyboard puts the letters in as you type, so spell out long vowels.</p>
<table>
<tr><td><code>k kh g gh c ch j jh</code></td><td>consonants (<code>ch</code> is the aspirated one, <code>c</code> the plain one)</td></tr>
<tr><td><code>T Th D Dh N</code></td><td>retroflex consonants, <code>R</code> and <code>Rh</code> the flapped ones</td></tr>
<tr><td><code>t th d dh n p ph b bh m</code></td><td>dental and labial consonants</td></tr>
<tr><td><code>y r l L w v s sh S h x</code></td><td>the rest; <code>x</code> is the conjunct ksha, <code>gy</code> and <code>jn</code> the conjunct gya</td></tr>
<tr><td><code>a i u e o</code></td><td>vowels; after a consonant <code>a</code> is only the sound a, so <code>ka</code> is the plain consonant, <code>kaa</code> the long one</td></tr>
<tr><td><code>aa ii uu ee oo ai au</code></td><td>long vowels and diphthongs; <code>A I U</code> are shortcuts for the long ones</td></tr>
<tr><td><code>rri</code></td><td>the vowel ri</td></tr>
<tr><td>consonant + consonant</td><td>joins into a conjunct by itself: <code>stra</code>, <code>ksh</code>, <code>ntr</code>. Type <code>a</code> between them to keep them apart: <code>kah</code></td></tr>
<tr><td><code>\`</code></td><td>halant</td></tr>
<tr><td><code>z</code> and <code>Z</code></td><td>zero-width non-joiner, and halant with a non-joiner</td></tr>
<tr><td><code>M</code> <code>H</code> <code>~</code> <code>&gt;</code></td><td>anusvara, visarga, chandrabindu, nukta</td></tr>
<tr><td><code>|</code></td><td>danda</td></tr>
</table>
<p>The Sulekhak apps (Mac, Windows, Android, iPad, web) also suggest whole words and learn your choices; a Keyman keyboard types by rules only, so it has no candidate list.</p>`;
fs.writeFileSync(path.join(OUT, 'source', 'welcome.htm'), page('Start using Sulekhak', `<h1>Start using Sulekhak</h1><p>Four phonetic keyboards in one package: Odia, Devanagari, Assamese and Bangla. Add the language you want in Keyman, then switch to it.</p>${scheme}<p>Sai Sudeep Das, 2026. <a href="https://github.com/Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard">github.com/Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard</a></p>`));
fs.writeFileSync(path.join(OUT, 'source', 'readme.htm'), page('Sulekhak keyboards for Keyman', `<h1>Sulekhak keyboards for Keyman</h1>${scheme}`));
fs.copyFileSync('/home/claude/newrepo/LICENSE', path.join(OUT, 'LICENSE.md'));
console.log('package files written');
