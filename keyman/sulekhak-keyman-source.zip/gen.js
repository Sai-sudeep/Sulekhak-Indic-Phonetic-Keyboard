/* Generates the Sulekhak Keyman keyboards (Odia, Devanagari, Assamese, Bangla) from the same tables as the Sulekhak engine.
   node gen.js <outdir>      writes source/*.kmn, *.keyman-touch-layout, and rules-<lang>.json (for the self test) */
const fs = require('fs'), path = require('path');
const E = require('/tmp/appsrc/shared/engine.js');
const OUT = process.argv[2] || 'proj';

const LANGS = [
  { id: 'sulekhak_odia',       name: 'Sulekhak Odia',       native: 'ଓଡ଼ିଆ',  sc: 0, bcp: 'or', lname: 'Odia' },
  { id: 'sulekhak_devanagari', name: 'Sulekhak Devanagari', native: 'देवनागरी', sc: 1, bcp: 'hi', lname: 'Hindi (Devanagari)' },
  { id: 'sulekhak_assamese',   name: 'Sulekhak Assamese',   native: 'অসমীয়া', sc: 5, bcp: 'as', lname: 'Assamese' },
  { id: 'sulekhak_bangla',     name: 'Sulekhak Bangla',     native: 'বাংলা',   sc: 2, bcp: 'bn', lname: 'Bangla' }
];

const hex = c => c.codePointAt(0).toString(16).toUpperCase().padStart(4, '0');
const U = s => [...s].map(c => 'U+' + hex(c)).join(' ');

function build(L) {
  const T = s => (L.sc === 0 ? s : E.toScript(s, L.sc, 0));
  const HAL = T('୍'), ZWNJ = '‌';
  /* single keys and their consonant (Odia) */
  const CK = { k: 'କ', g: 'ଗ', c: 'ଚ', j: 'ଜ', T: 'ଟ', D: 'ଡ', N: 'ଣ', t: 'ତ', d: 'ଦ', n: 'ନ', p: 'ପ', f: 'ଫ', b: 'ବ', m: 'ମ',
               y: (L.sc === 2 || L.sc === 5) ? 'ୟ' : 'ଯ', Y: (L.sc === 2 || L.sc === 5) ? 'ଯ' : 'ୟ', r: 'ର', l: 'ଲ', L: 'ଳ', w: 'ୱ', S: 'ଷ', s: 'ସ', h: 'ହ', R: '\u0B5C', V: 'ଵ', v: 'ବ', q: 'କ', x: 'କ୍ଷ' };
  const DIG = [['k', 'h', 'ଖ'], ['g', 'h', 'ଘ'], ['j', 'h', 'ଝ'], ['T', 'h', 'ଠ'], ['D', 'h', 'ଢ'], ['t', 'h', 'ଥ'], ['d', 'h', 'ଧ'],
               ['p', 'h', 'ଫ'], ['b', 'h', 'ଭ'], ['s', 'h', 'ଶ'], ['R', 'h', '\u0B5D'], ['S', 'h', 'ଷ']];
  /* the consonant end characters: every character a consonant can end with, in this script */
  const consSet = new Set();
  const addCons = o => { const t = T(o); consSet.add([...t].pop()); };
  for (const o of Object.values(CK)) addCons(o);
  for (const [, , o] of DIG) addCons(o);
  'କଖଗଘଙଚଛଜଝଞଟଠଡଢଣତଥଦଧନପଫବଭମଯରଲଳଵଶଷସହୟୱ'.split('').forEach(addCons);
  const consList = [...consSet];
  const isConsOut = o => consSet.has([...T(o)][0]);

  const R = [];            // {ctx:[...], key, out:[...]}  items: {c:'x'} | {any:'cons'} | {dk:'a'} | {cx:1}
  const ch = s => [...s].map(c => ({ c }));
  const rule = (ctx, key, out) => R.push({ ctx, key, out });

  /* specials */
  rule([], '`', ch(HAL));
  rule([], 'z', ch(ZWNJ));
  rule([], 'Z', ch(HAL + ZWNJ));
  rule([], '>', ch(T('଼')));
  rule([], 'M', ch(T('ଂ')));
  rule([], 'H', ch(T('ଃ')));
  rule([], '~', ch(T('ଁ')));
  rule([], '|', ch(T('।')));

  /* conjunct specials (longest context first) */
  rule(ch(T('କ୍ସ')), 'h', ch(T('କ୍ଷ')));                                          // ksh
  rule(ch(T('ଗ')), 'y', ch(T('ଜ୍ଞ')));                                             // gy
  rule(ch(T('ଜ')), 'n', ch(T('ଜ୍ଞ')));                                             // jn
  /* a nasal before k, g (ṅ) or c, j (ñ) takes the nasal of its own class: anka, ganga, pancha, ranjan */
  rule(ch(T('ନ')), 'k', ch(T('ଙ୍କ')));
  rule(ch(T('ନ')), 'g', ch(T('ଙ୍ଗ')));
  rule(ch(T('ନ')), 'c', ch(T('ଞ୍ଚ')));
  rule(ch(T('ନ')), 'j', ch(T('ଞ୍ଜ')));
  /* rri: independent and after a consonant (r + r gives the cluster first) */
  rule([{ any: 'cons' }, ...ch(T('୍ର୍ର'))], 'i', [{ cx: 1 }, ...ch(T('ୃ'))]);
  rule(ch(T('ର୍ର')), 'i', ch(T('ଋ')));
  /* digraphs, then an extra h is swallowed after chh */
  for (const [a, b, o] of DIG) rule(ch(T(CK[a])), b, ch(T(o)));
  rule(ch(T('ଛ')), 'h', ch(T('ଛ')));
  rule(ch(T('ଚ')), 'h', [...ch(T('ଚ')), { dk: 'ch' }]);              // ch is the plain letter, chh the aspirated one
  rule([...ch(T('ଚ')), { dk: 'ch' }], 'h', ch(T('ଛ')));

  /* vowels after a consonant: matras. 'a' only marks "inherent a" (a dead key) so that  k a h  is  କହ  and  kaa  is  କା */
  rule([{ dk: 'a' }], 'a', ch(T('ା')));
  rule([{ dk: 'a' }], 'i', ch(T('ୈ')));
  rule([{ dk: 'a' }], 'u', ch(T('ୌ')));
  rule([{ any: 'cons' }], 'a', [{ cx: 1 }, { dk: 'a' }]);
  for (const [k, m] of [['i', 'ି'], ['u', 'ୁ'], ['e', 'େ'], ['o', 'ୋ'], ['A', 'ା'], ['I', 'ୀ'], ['U', 'ୂ']]) rule([{ any: 'cons' }], k, [{ cx: 1 }, ...ch(T(m))]);
  rule(ch(T('ି')), 'i', ch(T('ୀ')));
  rule(ch(T('ୁ')), 'u', ch(T('ୂ')));
  rule(ch(T('େ')), 'e', ch(T('ୀ')));
  rule(ch(T('ୋ')), 'o', ch(T('ୂ')));
  rule(ch(T('ୋ')), 'u', ch(T('ୌ')));
  /* independent vowels */
  rule(ch(T('ଅ')), 'a', ch(T('ଆ')));
  rule(ch(T('ଅ')), 'i', ch(T('ଐ')));
  rule(ch(T('ଅ')), 'u', ch(T('ଔ')));
  rule(ch(T('ଇ')), 'i', ch(T('ଈ')));
  rule(ch(T('ଉ')), 'u', ch(T('ଊ')));
  rule(ch(T('ଏ')), 'e', ch(T('ଈ')));
  rule(ch(T('ଓ')), 'o', ch(T('ଊ')));
  rule(ch(T('ଓ')), 'u', ch(T('ଔ')));
  for (const [k, v] of [['a', 'ଅ'], ['i', 'ଇ'], ['u', 'ଉ'], ['e', 'ଏ'], ['o', 'ଓ'], ['A', 'ଆ'], ['I', 'ଈ'], ['U', 'ଊ']]) rule([], k, ch(T(v)));

  /* consonants: after a consonant they join with a halant, otherwise they stand alone */
  for (const [k, o] of Object.entries(CK)) {
    let o2 = o;
    if (k === 'y') o2 = 'ୟ';                      // ya-phala
    if (isConsOut(o2)) rule([{ any: 'cons' }], k, [{ cx: 1 }, ...ch(HAL + T(o2))]);
  }
  for (const [k, o] of Object.entries(CK)) rule([], k, ch(T(o)));

  const extra = [];
  for (const r of R) {
    if (r.ctx.length === 1 && r.ctx[0].any === 'cons' && r.key !== 'h') {
      extra.push({ ctx: [...ch(T('ଚ')), { dk: 'ch' }], key: r.key, out: r.out.map(o => o.cx ? { c: T('ଚ') } : o) });
    }
  }
  /* the variants go in right after the plain rule of the same key, before the no-context rules */
  const firstPlain = key => R.findIndex(x => x.key === key && x.ctx.length === 0);
  for (const e of extra) { const i = firstPlain(e.key); if (i >= 0) R.splice(i, 0, e); else R.push(e); }
  return { R, consList, HAL, T };
}

/* ---- write .kmn ---- */
function itemStr(it, side) {
  if (it.c !== undefined) return U(it.c);
  if (it.any) return 'any(' + it.any + ')';
  if (it.dk) return 'dk(' + it.dk + ')';
  if (it.cx) return 'context(' + it.cx + ')';
  throw new Error('bad item');
}
function kmn(L, B) {
  const lines = [];
  lines.push('c Sulekhak ' + L.lname + ' phonetic keyboard for Keyman. Generated from the Sulekhak engine tables (gen.js). Do not edit by hand.');
  lines.push(`store(&NAME) '${L.name}'`);
  lines.push(`store(&COPYRIGHT) '© 2026 Sai Sudeep Das'`);
  lines.push(`store(&VERSION) '10.0'`);
  lines.push(`store(&KEYBOARDVERSION) '1.0'`);
  lines.push(`store(&TARGETS) 'any'`);
  lines.push(`store(&MNEMONICLAYOUT) '1'`);
  lines.push(`store(&LAYOUTFILE) '${L.id}.keyman-touch-layout'`);
  lines.push('');
  lines.push('store(cons) ' + B.consList.map(c => U(c)).join(' '));
  lines.push('');
  lines.push('begin Unicode > use(main)');
  lines.push('');
  lines.push('group(main) using keys');
  lines.push('');
  for (const r of B.R) {
    const ctx = r.ctx.map(itemStr).join(' ');
    const out = r.out.map(itemStr).join(' ');
    lines.push((ctx ? ctx + ' ' : '') + `+ '${r.key === "'" ? "\\'" : r.key}' > ${out}`);
  }
  return lines.join('\n') + '\n';
}

/* ---- touch layout ---- */
function layout(L, B) {
  const T = B.T;
  const hintFor = (k, shifted) => {
    // the independent / stand-alone value of the key (what it gives at the start of a word)
    const r = B.R.filter(x => x.key === k && x.ctx.length === 0).pop();
    if (!r) return '';
    const s = r.out.filter(o => o.c !== undefined).map(o => o.c).join('');
    return s;
  };
  const key = (id, text, extra) => Object.assign({ id, text }, extra || {});
  const letter = (c, up) => { const t = up ? c.toUpperCase() : c; const h = hintFor(t); const o = key('K_' + c.toUpperCase(), t); if (h && h !== t && !/^[‌]+$/.test(h)) o.hint = h; return o; };
  const mkLayer = up => ({
    id: up ? 'shift' : 'default',
    row: [
      { id: 1, key: 'qwertyuiop'.split('').map(c => letter(c, up)) },
      { id: 2, key: [key('', '', { sp: '10', width: '5' }), ...'asdfghjkl'.split('').map(c => letter(c, up)), key('', '', { sp: '10', width: '5' })].map(k => k.id === '' ? { text: '', width: k.width, sp: k.sp } : k) },
      { id: 3, key: [up ? key('K_SHIFT', '*Shift*', { sp: '2', nextlayer: 'default', width: '130' }) : key('K_SHIFT', '*Shift*', { sp: '1', nextlayer: 'shift', width: '130' }),
                     ...'zxcvbnm'.split('').map(c => letter(c, up)), key('K_BKSP', '*BkSp*', { sp: '1', width: '130' })] },
      { id: 4, key: [key('K_NUMLOCK', '*123*', { sp: '1', width: '130', nextlayer: 'numeric' }), key('K_LOPT', '*Menu*', { sp: '1', width: '110' }),
                     key('U_0060', '`', { hint: L.sc === 0 ? '◌୍' : '◌' + T('୍') }), key('K_SPACE', '', { sp: '0', width: '430' }),
                     key(up ? 'U_003E' : 'U_002E', up ? '>' : '.'), key('K_ENTER', '*Enter*', { sp: '1', width: '130' })] }
    ]
  });
  const tpl = JSON.parse(fs.readFileSync('/tmp/kmtest/node_modules/@keymanapp/kmc-generate/build/src/template/kmn-keyboard/source/keyboard.keyman-touch-layout', 'utf8'));
  const numeric = tpl.phone.layer.find(l => l.id === 'numeric');
  const plat = { font: 'Arial', layer: [mkLayer(false), mkLayer(true), numeric] };
  return JSON.stringify({ phone: plat, tablet: JSON.parse(JSON.stringify(plat)) }, null, 2);
}

fs.mkdirSync(path.join(OUT, 'source'), { recursive: true });
const built = {};
for (const L of LANGS) {
  const B = build(L); built[L.id] = B;
  fs.writeFileSync(path.join(OUT, 'source', L.id + '.kmn'), '﻿' + kmn(L, B));
  fs.writeFileSync(path.join(OUT, 'source', L.id + '.keyman-touch-layout'), layout(L, B));
  fs.writeFileSync(path.join(OUT, 'rules-' + L.id + '.json'), JSON.stringify({ R: B.R, cons: B.consList }));
}
console.log('written', LANGS.map(l => l.id).join(' '));
