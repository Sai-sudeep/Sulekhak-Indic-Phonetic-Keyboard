/* Generates the Sulekhak Keyman keyboards (Odia, Devanagari, Assamese, Bangla) from the same tables as the Sulekhak engine.
   node gen.js <outdir>      writes source/*.kmn, *.keyman-touch-layout, and rules-<lang>.json (for the self test) */
const fs = require('fs'), path = require('path');
const E = require('/tmp/appsrc/shared/engine.js');
const OUT = process.argv[2] || 'proj';
const ALTSRC = '/home/claude/work/src/android/app/src/main/java/com/saisudeep/sulekhak/KeyboardView.java';

const LANGS = [
  { id: 'sulekhak_odia',       name: 'Sulekhak Odia',       native: 'ଓଡ଼ିଆ',  sc: 0, bcp: 'or', lname: 'Odia' },
  { id: 'sulekhak_devanagari', name: 'Sulekhak Devanagari', native: 'देवनागरी', sc: 1, bcp: 'hi', lname: 'Hindi (Devanagari)' },
  { id: 'sulekhak_assamese',   name: 'Sulekhak Assamese',   native: 'অসমীয়া', sc: 5, bcp: 'as', lname: 'Assamese' },
  { id: 'sulekhak_bangla',     name: 'Sulekhak Bangla',     native: 'বাংলা',   sc: 2, bcp: 'bn', lname: 'Bangla' }
];

const hex = c => c.codePointAt(0).toString(16).toUpperCase().padStart(4, '0');
const U = s => [...s].map(c => 'U+' + hex(c)).join(' ');

function build(L) {
  const T = s => (L.sc === 0 ? s : E.toScript(s, L.sc, 0));
  const HAL = T('୍'), ZWNJ = '‌';
  /* single keys and their consonant (Odia) */
  const CK = { k: 'କ', g: 'ଗ', c: 'ଚ', j: 'ଜ', T: 'ଟ', D: 'ଡ', N: 'ଣ', t: 'ତ', d: 'ଦ', n: 'ନ', p: 'ପ', f: 'ଫ', b: 'ବ', m: 'ମ',
               y: (L.sc === 2 || L.sc === 5) ? 'ୟ' : 'ଯ', Y: (L.sc === 2 || L.sc === 5) ? 'ଯ' : 'ୟ', r: 'ର', l: 'ଲ', L: 'ଳ', w: 'ୱ', S: 'ଷ', s: 'ସ', h: 'ହ', R: '\u0B5C', V: 'ଵ', v: 'ବ', q: 'କ', x: 'କ୍ଷ' };
  const DIG = [['k', 'h', 'ଖ'], ['g', 'h', 'ଘ'], ['j', 'h', 'ଝ'], ['T', 'h', 'ଠ'], ['D', 'h', 'ଢ'], ['t', 'h', 'ଥ'], ['d', 'h', 'ଧ'],
               ['p', 'h', 'ଫ'], ['b', 'h', 'ଭ'], ['s', 'h', 'ଶ'], ['R', 'h', '\u0B5D'], ['S', 'h', 'ଷ']];
  /* the consonant end characters: every character a consonant can end with, in this script */
  const consSet = new Set();
  const addCons = o => { const t = T(o); consSet.add([...t].pop()); };
  for (const o of Object.values(CK)) addCons(o);
  for (const [, , o] of DIG) addCons(o);
  'କଖଗଘଙଚଛଜଝଞଟଠଡଢଣତଥଦଧନପଫବଭମଯରଲଳଵଶଷସହୟୱ'.split('').forEach(addCons);
  const consList = [...consSet];
  const isConsOut = o => consSet.has([...T(o)][0]);

  const R = [];            // {ctx:[...], key, out:[...]}  items: {c:'x'} | {any:'cons'} | {dk:'a'} | {cx:1}
  const ch = s => [...s].map(c => ({ c }));
  const rule = (ctx, key, out) => R.push({ ctx, key, out });

  /* specials */
  rule([], "'", [{ dk: 'sep' }]);          // an apostrophe separates: it stops the letters before it from joining the ones after it
  rule([], '`', ch(HAL));
  rule([], 'z', ch(ZWNJ));
  rule([], 'Z', ch(HAL + ZWNJ));
  rule([], '>', ch(T('଼')));
  rule([], 'M', ch(T('ଂ')));
  rule([], 'H', ch(T('ଃ')));
  rule([], '~', ch(T('ଁ')));
  rule([], '|', ch(T('।')));

  /* conjunct specials (longest context first) */
  rule(ch(T('କ୍ସ')), 'h', ch(T('କ୍ଷ')));                                          // ksh
  rule(ch(T('ଗ')), 'y', ch(T('ଜ୍ଞ')));                                             // gy
  rule(ch(T('ଜ')), 'n', ch(T('ଜ୍ଞ')));                                             // jn
  /* a nasal before k, g (ṅ) or c, j (ñ) takes the nasal of its own class: anka, ganga, pancha, ranjan */
  rule(ch(T('ନ')), 'k', ch(T('ଙ୍କ')));
  rule(ch(T('ନ')), 'g', ch(T('ଙ୍ଗ')));
  rule(ch(T('ନ')), 'c', ch(T('ଞ୍ଚ')));
  rule(ch(T('ନ')), 'j', ch(T('ଞ୍ଜ')));
  /* rri: independent and after a consonant (r + r gives the cluster first) */
  rule([{ any: 'cons' }, ...ch(T('୍ର୍ର'))], 'i', [{ cx: 1 }, ...ch(T('ୃ'))]);
  rule(ch(T('ର୍ର')), 'i', ch(T('ଋ')));
  /* digraphs, then an extra h is swallowed after chh */
  for (const [a, b, o] of DIG) rule(ch(T(CK[a])), b, ch(T(o)));
  rule(ch(T('ଛ')), 'h', ch(T('ଛ')));
  rule(ch(T('ଚ')), 'h', [...ch(T('ଚ')), { dk: 'ch' }]);              // ch is the plain letter, chh the aspirated one
  rule([...ch(T('ଚ')), { dk: 'ch' }], 'h', ch(T('ଛ')));

  /* vowels after a consonant: matras. 'a' only marks "inherent a" (a dead key) so that  k a h  is  କହ  and  kaa  is  କା */
  rule([{ dk: 'a' }], 'a', ch(T('ା')));
  rule([{ dk: 'a' }], 'i', ch(T('ୈ')));
  rule([{ dk: 'a' }], 'u', ch(T('ୌ')));
  rule([{ any: 'cons' }], 'a', [{ cx: 1 }, { dk: 'a' }]);
  for (const [k, m] of [['i', 'ି'], ['u', 'ୁ'], ['e', 'େ'], ['o', 'ୋ'], ['A', 'ା'], ['I', 'ୀ'], ['U', 'ୂ']]) rule([{ any: 'cons' }], k, [{ cx: 1 }, ...ch(T(m))]);
  rule(ch(T('ି')), 'i', ch(T('ୀ')));
  rule(ch(T('ୁ')), 'u', ch(T('ୂ')));
  rule(ch(T('େ')), 'e', ch(T('ୀ')));
  rule(ch(T('ୋ')), 'o', ch(T('ୂ')));
  rule(ch(T('ୋ')), 'u', ch(T('ୌ')));
  /* independent vowels */
  rule(ch(T('ଅ')), 'a', ch(T('ଆ')));
  rule(ch(T('ଅ')), 'i', ch(T('ଐ')));
  rule(ch(T('ଅ')), 'u', ch(T('ଔ')));
  rule(ch(T('ଇ')), 'i', ch(T('ଈ')));
  rule(ch(T('ଉ')), 'u', ch(T('ଊ')));
  rule(ch(T('ଏ')), 'e', ch(T('ଈ')));
  rule(ch(T('ଓ')), 'o', ch(T('ଊ')));
  rule(ch(T('ଓ')), 'u', ch(T('ଔ')));
  for (const [k, v] of [['a', 'ଅ'], ['i', 'ଇ'], ['u', 'ଉ'], ['e', 'ଏ'], ['o', 'ଓ'], ['A', 'ଆ'], ['I', 'ଈ'], ['U', 'ଊ']]) rule([], k, ch(T(v)));

  /* consonants: after a consonant they join with a halant, otherwise they stand alone */
  for (const [k, o] of Object.entries(CK)) {
    let o2 = o;
    if (k === 'y') o2 = 'ୟ';                      // ya-phala
    if (isConsOut(o2)) rule([{ any: 'cons' }], k, [{ cx: 1 }, ...ch(HAL + T(o2))]);
  }
  for (const [k, o] of Object.entries(CK)) rule([], k, ch(T(o)));

  const extra = [];
  for (const r of R) {
    if (r.ctx.length === 1 && r.ctx[0].any === 'cons' && r.key !== 'h') {
      extra.push({ ctx: [...ch(T('ଚ')), { dk: 'ch' }], key: r.key, out: r.out.map(o => o.cx ? { c: T('ଚ') } : o) });
    }
  }
  /* the variants go in right after the plain rule of the same key, before the no-context rules */
  const firstPlain = key => R.findIndex(x => x.key === key && x.ctx.length === 0);
  for (const e of extra) { const i = firstPlain(e.key); if (i >= 0) R.splice(i, 0, e); else R.push(e); }
  /* a capital letter that has no meaning of its own types the same as the small letter, so Shift (or Caps Lock) never gives Latin letters by accident */
  const upperDone = new Set(R.filter(x => /[A-Z]/.test(x.key)).map(x => x.key));
  const dups = [];
  for (const r of R) {
    if (!/^[a-z]$/.test(r.key)) continue;
    const U = r.key.toUpperCase();
    if (upperDone.has(U)) continue;
    dups.push({ ctx: r.ctx, key: U, out: r.out });
  }
  R.push(...dups);
  /* ^ is a prefix: ^0 .. ^9 give the native digits, ^z a joiner, ^^ a caret, ^' a plain apostrophe. These go first, before the rules for the bare keys. */
  const digitBase = L.sc === 1 ? 0x0966 : (L.sc === 2 || L.sc === 5) ? 0x09E6 : 0x0B66;
  const nd = [{ ctx: [], key: '^', out: [{ dk: 'nd' }] }];
  const ndc = [{ dk: 'nd' }];
  for (let d = 0; d <= 9; d++) nd.push({ ctx: ndc, key: String(d), out: [{ c: String.fromCodePoint(digitBase + d) }] });
  nd.push({ ctx: ndc, key: 'z', out: [{ c: '\u200D' }] }, { ctx: ndc, key: '^', out: [{ c: '^' }] }, { ctx: ndc, key: "'", out: [{ c: "'" }] });
  R.unshift(...nd.slice(1), nd[0]);
  return { R, consList, HAL, T };
}


/* ================================================================== v2: everything below is new ================================================================== */
const KBVER = '2.0';

/* ---- the long-press lists of the Android keyboard (one table for every keyboard) ---- */
function readAlts() {
  const src = fs.readFileSync(ALTSRC, 'utf8');
  const out = {};
  const re = /put\("([^"]+)",\s*([^;]*)\);/g;
  let m;
  while ((m = re.exec(src))) {
    try { out[m[1]] = JSON.parse('[' + m[2] + ']'); } catch (e) { /* not a letter list */ }
  }
  return out;
}
const ALTS = readAlts();

/* ---- helpers ---- */
const isDependent = c => /[ऀ-ःऺ-ॏ॑-ॗॢॣঁ-ঃ়া-্ৗৢৣଁ-ଃ଼ା-୍୕-ୗୢୣ]/.test(c);
const assigned = s => [...s].every(c => !/\p{Cn}/u.test(c));
const KEYS = 'qwertyuiopasdfghjklzxcvbnm'.split('');

function kmn(L, B) {
  const lines = [];
  lines.push('c Sulekhak ' + L.lname + ' phonetic keyboard for Keyman, version ' + KBVER + '. Generated from the Sulekhak engine tables (gen2.js). Do not edit by hand.');
  lines.push(`store(&NAME) '${L.name}'`);
  lines.push(`store(&COPYRIGHT) '© 2026 Sai Sudeep Das'`);
  lines.push(`store(&VERSION) '10.0'`);
  lines.push(`store(&KEYBOARDVERSION) '${KBVER}'`);
  lines.push(`store(&TARGETS) 'any'`);
  lines.push(`store(&MNEMONICLAYOUT) '1'`);
  lines.push(`store(&BITMAP) 'sulekhak.ico'`);
  lines.push(`store(&VISUALKEYBOARD) '${L.id}.kvks'`);
  lines.push(`store(&LAYOUTFILE) '${L.id}.keyman-touch-layout'`);
  lines.push(`store(&KMW_EMBEDCSS) 'sulekhak.css'`);
  lines.push('');
  lines.push('store(cons) ' + B.consList.map(c => U(c)).join(' '));
  lines.push('');
  lines.push('begin Unicode > use(main)');
  lines.push('');
  lines.push('group(main) using keys');
  lines.push('');
  lines.push('c ---- the phonetic rules');
  for (const r of B.R) {
    const ctx = r.ctx.map(itemStr).join(' ');
    const out = r.out.map(itemStr).join(' ');
    const k = r.key === "'" ? `"'"` : `'${r.key}'`;
    lines.push((ctx ? ctx + ' ' : '') + `+ ${k} > ${out}`);
  }
  lines.push('');
  lines.push('c ---- the touch keys that type more than one character (conjuncts from the long-press lists)');
  for (const t of TOUCH_RULES[L.id]) lines.push(`+ [${t.id}] > ${[...t.out].map(c => U(c)).join(' ')}`);
  return lines.join('\n') + '\n';
}
function itemStr(it) {
  if (it.c !== undefined) return U(it.c);
  if (it.any) return 'any(' + it.any + ')';
  if (it.dk) return 'dk(' + it.dk + ')';
  if (it.cx) return 'context(' + it.cx + ')';
  throw new Error('bad item');
}

/* ---- touch layout ---- */
const TOUCH_RULES = {};
function layout(L, B) {
  const T = B.T;
  const stand = k => {                    // what the key gives on its own
    const r = B.R.filter(x => x.key === k && x.ctx.length === 0).pop();
    if (!r) return '';
    return r.out.filter(o => o.c !== undefined).map(o => o.c).join('');
  };
  const uid = c => 'U_' + hex(c);
  const SP = { normal: 0, special: 1, active: 2, custom: 3, customActive: 4, dead: 8, blank: 9, spacer: 10 };
  const rules = [];
  const tIds = {};                         // text -> T_ id (a key that types several characters)
  const subkeyFor = item => {
    if (item === '') return null;
    const chars = [...item];
    let text = item;
    if (item === '‌') text = 'ZWNJ'; else if (item === '‍') text = 'ZWJ';
    else if (chars.length === 2 && chars[0] === T('୍') && (chars[1] === '‌' || chars[1] === '‍')) text = '◌' + T('୍') + ' + ' + (chars[1] === '‌' ? '┊' : '[');
    else if (isDependent(chars[0])) text = '◌' + item;
    if (chars.length === 1) return { id: uid(item), text };
    if (!tIds[item]) { tIds[item] = 'T_SK' + (Object.keys(tIds).length + 1); rules.push({ id: tIds[item], out: item }); }
    return { id: tIds[item], text };
  };
  const altsFor = c => {
    const list = ALTS[c.toLowerCase()];
    if (!list) return null;
    const out = [], seen = new Set();
    for (const a0 of list) {
      const a = a0 === '' ? '' : T(a0);
      if (!a || !assigned(a) || seen.has(a)) continue;
      seen.add(a);
      const sk = subkeyFor(a);
      if (sk) out.push(sk);
    }
    return out.length ? out : null;
  };

  const spacer = w => ({ text: '', width: w, sp: SP.spacer });
  const letter = (c, up) => {
    const t = up ? c.toUpperCase() : c;
    const o = { id: 'K_' + c.toUpperCase(), text: t };
    const h = stand(t);
    if (h && h !== t && !/^[‌]+$/.test(h)) o.hint = h;
    if (c === 'z') { o.sp = SP.custom; delete o.hint; }
    const sk = altsFor(c);
    if (sk) o.sk = sk;
    return o;
  };
  const digit = d => {
    const nd = String.fromCodePoint((L.sc === 1 ? 0x0966 : (L.sc === 2 || L.sc === 5) ? 0x09E6 : 0x0B66) + d);
    return { id: 'K_' + d, text: String(d), hint: nd, sk: [{ id: uid(nd), text: nd }] };
  };
  const digitRow = () => ({ key: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map(digit) });
  const fnKey = (id, text, extra) => Object.assign({ id, text, sp: SP.special, width: 130 }, extra || {});
  const bottom = (layerName) => ({
    key: [
      layerName === 'default' || layerName === 'shift'
        ? fnKey('T_123', '*123*', { nextlayer: 'numeric', width: 125 })
        : fnKey('T_ABC', 'ABC', { nextlayer: 'default', width: 125 }),
      fnKey('T_SCRIPT', L.letter, { nextlayer: 'script', width: 100, font: 'Noto Sans Oriya, Nirmala UI, sans-serif' }),
      fnKey('K_LOPT', '*Menu*', { width: 100 }),
      { id: 'U_0060', text: '`', hint: '◌' + T('୍'), width: 90 },
      { id: 'U_003E', text: '>', hint: '◌' + T('଼'), width: 90 },
      { id: 'U_007E', text: '~', hint: '◌' + T('ଁ'), width: 90 },
      { id: 'K_SPACE', text: L.native, sp: SP.normal, width: 330 },
      { id: 'U_002E', text: '.', hint: "' " + T('।'), width: 95,
        sk: ['.', ',', '?', '!', "'", ':', ';', '-', '"', '(', ')', '/', '@', '#', '%', '&', '*', '+', '=', '_', T('।'), T('॥'), '…', '~'].filter(x => x && assigned(x))
          .map(x => ({ id: uid(x), text: x })) },
      fnKey('K_ENTER', '*Enter*', { width: 125 })
    ]
  });
  const shiftKey = up => up ? fnKey('K_SHIFT', '*Shift*', { sp: SP.active, nextlayer: 'default', width: 135 }) : fnKey('K_SHIFT', '*Shift*', { nextlayer: 'shift', width: 135 });
  const mkLayer = up => ({
    id: up ? 'shift' : 'default',
    row: [
      { id: 1, key: digitRow().key },
      { id: 2, key: 'qwertyuiop'.split('').map(c => letter(c, up)) },
      { id: 3, key: [spacer(50), ...'asdfghjkl'.split('').map(c => letter(c, up)), spacer(50)] },
      { id: 4, key: [shiftKey(up), ...'zxcvbnm'.split('').map(c => letter(c, up)), fnKey('K_BKSP', '*BkSp*', { width: 135 })] },
      Object.assign({ id: 5 }, bottom(up ? 'shift' : 'default'))
    ]
  });
  const plain = (ch, extra) => Object.assign({ id: uid(ch), text: ch }, extra || {});
  const symRow = list => ({ key: list.map(x => plain(x)) });
  const numeric = {
    id: 'numeric',
    row: [
      { id: 1, key: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map(digit) },
      { id: 2, key: ['@', '#', '₹', '$', '%', '&', '-', '+', '(', ')'].map(x => plain(x)) },
      { id: 3, key: [fnKey('T_SYMBOLS', '=\\<', { nextlayer: 'symbol', width: 140 }), ...['!', '?', '"', "'", ':', ';', '/'].map(x => plain(x)), fnKey('K_BKSP', '*BkSp*', { width: 140 })] },
      { id: 4, key: [T('।'), ',', '.', '…', '_', '*', '=', '^', '~', '|'].map(x => plain(x)) },
      Object.assign({ id: 5 }, bottom('numeric'))
    ]
  };
  const symbol = {
    id: 'symbol',
    row: [
      { id: 1, key: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map(digit) },
      Object.assign({ id: 2 }, symRow(['~', '`', '|', '•', '√', 'π', '÷', '×', '¶', '∆'])),
      { id: 3, key: [fnKey('T_NUMERIC', '?123', { nextlayer: 'numeric', width: 140 }), ...['£', '¢', '€', '¥', '°', '©', '®'].map(x => plain(x)), fnKey('K_BKSP', '*BkSp*', { width: 140 })] },
      Object.assign({ id: 4 }, symRow(['[', ']', '{', '}', '<', '>', '«', '»', '±', '§'])),
      Object.assign({ id: 5 }, bottom('symbol'))
    ]
  };
  /* the script layer: every independent vowel, vowel sign and mark of the script, typed directly */
  const sk = s => { const t = T(s); return assigned(t) && t ? t : ''; };
  const sc = (s, dep) => { const t = sk(s); if (!t) return null; return { id: uid(t), text: dep ? '◌' + t : t, sp: SP.normal, fontsize: '1.2em' }; };
  const rowOf = (list, dep) => list.map(x => sc(x, dep)).filter(Boolean);
  const scriptLayer = {
    id: 'script',
    row: [
      { id: 1, key: rowOf(['ଅ', 'ଆ', 'ଇ', 'ଈ', 'ଉ', 'ଊ', 'ଋ', 'ଏ', 'ଐ', 'ଓ'], false) },
      { id: 2, key: rowOf(['ା', 'ି', 'ୀ', 'ୁ', 'ୂ', 'ୃ', 'େ', 'ୈ', 'ୋ', 'ୌ'], true) },
      { id: 3, key: [...rowOf(['ଔ', 'ଌ', 'ୠ', 'ୡ', 'ଽ', '୰'], false), ...rowOf(['ୖ', 'ୗ'], true), fnKey('K_BKSP', '*BkSp*', { width: 140 })] },
      { id: 4, key: [...rowOf(['ୄ', 'ୢ', 'ୣ', 'ଁ', 'ଂ', 'ଃ', '଼', '୍'], true), { id: 'U_200C', text: 'ZWNJ', sp: SP.special, fontsize: '0.7em' }, { id: 'U_200D', text: 'ZWJ', sp: SP.special, fontsize: '0.7em' }] },
      Object.assign({ id: 5 }, bottom('script'))
    ]
  };
  const fix = ly => { ly.row = ly.row.filter(Boolean); return ly; };
  const plat = { font: 'Noto Sans Oriya, Nirmala UI, Arial, sans-serif', fontsize: '1.0em', defaultHint: 'dot', layer: [mkLayer(false), mkLayer(true), numeric, symbol, scriptLayer].map(fix) };
  TOUCH_RULES[L.id] = rules;
  const tablet = JSON.parse(JSON.stringify(plat));
  return JSON.stringify({ phone: plat, tablet }, null, 2);
}

/* ---- the on-screen keyboard that Keyman shows on a computer (letters on the left, what they give on the key) ---- */
function kvks(L, B) {
  const stand = k => {
    const r = B.R.filter(x => x.key === k && x.ctx.length === 0).pop();
    if (!r) return '';
    return r.out.filter(o => o.c !== undefined).map(o => o.c).join('');
  };
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const layer = up => {
    const ks = [];
    for (const c of KEYS) {
      const t = up ? c.toUpperCase() : c;
      let s = stand(t);
      s = s.replace(/‌/g, '').replace(/‍/g, '');
      if (c === 'z' && !up) s = 'ZWNJ'; else if (c === 'z' && up) s = T_HAL(L, B) + '+ZWNJ';
      if (!s) continue;
      if (isDependent([...s][0]) && s.length === 1) s = '◌' + s;
      ks.push(`      <key vkey="K_${c.toUpperCase()}">${esc(s)}</key>`);
    }
    if (!up) ks.push(`      <key vkey="K_BKQUOTE">◌${esc(B.T('୍'))}</key>`);
    else ks.push(`      <key vkey="K_BKQUOTE">◌${esc(B.T('ଁ'))}</key>`, `      <key vkey="K_BKSLASH">${esc(B.T('।'))}</key>`);
    return ks.join('\n');
  };
  return `<?xml version="1.0" encoding="utf-8"?>
<visualkeyboard>
  <header>
    <version>10.0</version>
    <kbdname>${L.id}</kbdname>
    <flags>
      <usealtgr/>
    </flags>
  </header>
  <encoding name="unicode" fontname="${L.sc === 0 ? 'Nirmala UI' : 'Nirmala UI'}" fontsize="-14">
    <layer shift="">
${layer(false)}
    </layer>
    <layer shift="S">
${layer(true)}
    </layer>
  </encoding>
</visualkeyboard>
`;
}
function T_HAL(L, B) { return '◌' + B.T('୍'); }

/* ---- the look of the keyboard on phones, tablets and the web ---- */
const CSS = `/* Sulekhak keyboard look. Embedded in the keyboard, so it applies in Keyman for Android and iOS and in KeymanWeb. */
.kmw-key {
  border-radius: 9px;
  box-shadow: 0 1.5px 0 rgba(20, 30, 60, 0.28), inset 0 0 0 1px rgba(255, 255, 255, 0.10);
  transition: background-color 0.08s ease, transform 0.05s ease;
}
.kmw-key:active, .kmw-key-pressed { transform: scale(0.96); }
.kmw-key-hint, .kmw-key-label { opacity: 0.78; }

/* the Z key: a different colour, a soft halo, and a band of light that sweeps across it from left to right */
@keyframes sk-sweep { 0% { background-position: -150% 0, 0 0; } 55%, 100% { background-position: 250% 0, 0 0; } }
@keyframes sk-halo { 0%, 100% { box-shadow: 0 0 6px 1px rgba(255, 176, 46, 0.45); } 50% { box-shadow: 0 0 13px 3px rgba(255, 176, 46, 0.80); } }
.kmw-key[id$="-K_Z"] {
  color: #1b1f2e !important;
  background-color: #ffb02e !important;
  background-image: linear-gradient(105deg, rgba(255, 255, 255, 0) 38%, rgba(255, 255, 255, 0.70) 50%, rgba(255, 255, 255, 0) 62%), linear-gradient(#ffb02e, #ffb02e) !important;
  background-size: 55% 100%, 100% 100% !important;
  background-repeat: no-repeat !important;
  animation: sk-sweep 2.6s linear infinite, sk-halo 2.2s ease-in-out infinite;
}
`;

/* ---- the lexical models (the suggestion strip above the keys) ---- */
function writeModels() {
  const zlib = require('zlib');
  const LEX = process.env.SK_LEX;                       // Odia lex.gz of the engine: word<TAB>count
  const odia = zlib.gunzipSync(fs.readFileSync(LEX)).toString('utf8').split('\n').map(l => l.split('\t')).filter(a => a[0] && a[1]).map(a => [a[0], +a[1]]);
  const hiRaw = JSON.parse(fs.readFileSync(process.env.SK_HI, 'utf8'));
  const bnRaw = JSON.parse(fs.readFileSync(process.env.SK_BN, 'utf8'));
  const inBlock = (re) => w => re.test(w);
  const odOK = inBlock(/^[ଁ-୷‌‍]+$/), hiOK = inBlock(/^[ऀ-ॣ०-ॿ‌‍]+$/), bnOK = inBlock(/^[ঁ-৿‌‍]+$/);
  const tsv = (list, ok, n, scale) => {
    const seen = new Set(), out = [];
    for (const [w, c] of list) {
      if (!ok(w) || w.length < 2 || seen.has(w)) continue;
      seen.add(w);
      out.push(w + '\t' + Math.max(1, Math.round(c * scale)));
      if (out.length >= n) break;
    }
    return out;
  };
  const N = 40000;
  const odTop = odia.slice().sort((a, b) => b[1] - a[1]);
  const tot = odTop.reduce((s, x) => s + x[1], 0);
  const odFreq = odTop.map(([w, c]) => [w, c / tot * 1e6]);                       // per million
  const hi = Object.entries(hiRaw).sort((a, b) => b[1] - a[1]).map(([w, f]) => [w, f * 1e6]);
  const bn = Object.entries(bnRaw).sort((a, b) => b[1] - a[1]).map(([w, f]) => [w, f * 1e6]);
  const lists = {
    sulekhak_odia: tsv(odFreq, odOK, N, 1),
    sulekhak_devanagari: tsv(hi, hiOK, N, 1),
    sulekhak_bangla: tsv(bn, bnOK, N, 1)
  };
  /* Assamese: Bangla words with the Assamese ra (ৰ), and the Odia words carried into the Assamese script */
  const asBn = bn.map(([w, c]) => [w.replace(/র/g, 'ৰ'), c]);
  const asOd = odFreq.slice(0, 30000).map(([w, c]) => { let t = ''; try { t = E.toScript(w, 5, 0); } catch (e) { } return [t, c * 0.6]; });
  const asAll = asBn.concat(asOd).sort((a, b) => b[1] - a[1]);
  lists.sulekhak_assamese = tsv(asAll, bnOK, N, 1);
  const stats = {};
  for (const L of LANGS) {
    const id = 'sai_sudeep.' + L.bcp + '.sulekhak';
    const dir = path.join(OUT, 'models', L.id);
    fs.mkdirSync(path.join(dir, 'source'), { recursive: true });
    fs.mkdirSync(path.join(dir, 'build'), { recursive: true });
    fs.writeFileSync(path.join(dir, 'source', 'wordlist.tsv'), '# Sulekhak ' + L.lname + ' word list: word<TAB>frequency per million. Built from ' + (L.sc === 0 ? 'the Sulekhak Odia word list (Purnachandra Bhashakosha and corpus counts)' : L.sc === 1 ? 'the wordfreq Hindi list' : L.sc === 2 ? 'the wordfreq Bengali list' : 'the Bengali list (with the Assamese ra) and the Odia words in the Assamese script') + '\n' + lists[L.id].join('\n') + '\n');
    fs.writeFileSync(path.join(dir, 'source', id + '.model.ts'), `/* Sulekhak ${L.lname} suggestions: finishes the word being typed and fixes small slips. */
const source: LexicalModelSource = {
  format: 'trie-1.0',
  wordBreaker: 'default',
  sources: ['wordlist.tsv'],
  /* a word is found whether or not it was typed with the joiners (ZWNJ, ZWJ) */
  searchTermToKey: function (term: string) { return term.normalize('NFC').replace(/[\\u200C\\u200D]/g, ''); },
  punctuation: {
    quotesForKeepSuggestion: { open: '\\u201C', close: '\\u201D' },
    insertAfterWord: ' ',
    isRTL: false
  }
};
export default source;
`);
    fs.writeFileSync(path.join(dir, 'model.kpj'), `<?xml version="1.0" encoding="utf-8"?>
<KeymanDeveloperProject>
  <Options>
    <Version>2.0</Version>
    <SkipMetadataFiles>True</SkipMetadataFiles>
    <ProjectType>lexicalmodel</ProjectType>
    <CompilerWarningsAsErrors>False</CompilerWarningsAsErrors>
    <CheckFilenameConventions>True</CheckFilenameConventions>
  </Options>
</KeymanDeveloperProject>
`);
    fs.writeFileSync(path.join(dir, 'source', id + '.model.kps'), `<?xml version="1.0" encoding="utf-8"?>
<Package>
  <System>
    <KeymanDeveloperVersion>18.0.253</KeymanDeveloperVersion>
    <FileVersion>12.0</FileVersion>
  </System>
  <Options>
    <ReadMeFile>readme.htm</ReadMeFile>
    <LicenseFile>..\\..\\..\\LICENSE.md</LicenseFile>
  </Options>
  <Info>
    <Name URL="">Sulekhak ${L.lname} suggestions</Name>
    <Copyright URL="">© 2026 Sai Sudeep Das</Copyright>
    <Author URL="">Sai Sudeep Das</Author>
    <Version URL="">${KBVER}</Version>
    <Description URL="">Word suggestions for the Sulekhak ${L.lname} keyboard: the strip above the keys finishes the word being typed.</Description>
  </Info>
  <Files>
    <File>
      <Name>..\\build\\${id}.model.js</Name>
    </File>
    <File>
      <Name>readme.htm</Name>
    </File>
    <File>
      <Name>..\\..\\..\\LICENSE.md</Name>
    </File>
  </Files>
  <Keyboards/>
  <LexicalModels>
    <LexicalModel>
      <Name>Sulekhak ${L.lname} suggestions</Name>
      <ID>${id}</ID>
      <Languages>
        <Language ID="${L.bcp}">${L.lname}</Language>
      </Languages>
    </LexicalModel>
  </LexicalModels>
  <RelatedPackages/>
</Package>
`);
    fs.writeFileSync(path.join(dir, 'source', 'readme.htm'), `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Sulekhak ${L.lname} suggestions</title><style>p,li{font:10pt Tahoma}h1{font:bold 16pt Tahoma;color:#17475e}</style></head><body><h1>Sulekhak ${L.lname} suggestions</h1><p>Install this next to the Sulekhak ${L.lname} keyboard. On a phone or tablet the strip above the keys then suggests words as you type; tap one to put it in.</p><p>${lists[L.id].length} words.</p><p>© 2026 Sai Sudeep Das</p></body></html>`);
    stats[L.id] = lists[L.id].length;
  }
  return stats;
}

/* ---- packages ---- */
function kpsKeyboard(list, name, desc) {
  const files = list.map(L => `    <File>
      <Name>..\\build\\${L.id}.kmx</Name>
    </File>
    <File>
      <Name>..\\build\\${L.id}.js</Name>
    </File>`).join('\n');
  const kbs = list.map(L => `    <Keyboard>
      <Name>${L.name}</Name>
      <ID>${L.id}</ID>
      <Version>${KBVER}</Version>
      <Languages>
        <Language ID="${L.bcp}">${L.lname}</Language>
      </Languages>
    </Keyboard>`).join('\n');
  return `<?xml version="1.0" encoding="utf-8"?>
<Package>
  <System>
    <KeymanDeveloperVersion>18.0.253</KeymanDeveloperVersion>
    <FileVersion>7.0</FileVersion>
  </System>
  <Options>
    <ReadMeFile>readme.htm</ReadMeFile>
    <LicenseFile>..\\LICENSE.md</LicenseFile>
    <WelcomeFile>welcome.htm</WelcomeFile>
    <FollowKeyboardVersion/>
  </Options>
  <Info>
    <Name URL="https://github.com/Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard">${name}</Name>
    <Copyright URL="">© 2026 Sai Sudeep Das</Copyright>
    <Author URL="">Sai Sudeep Das</Author>
    <Description URL="">${desc}</Description>
  </Info>
  <Files>
${files}
    <File>
      <Name>welcome.htm</Name>
    </File>
    <File>
      <Name>readme.htm</Name>
    </File>
    <File>
      <Name>..\\LICENSE.md</Name>
    </File>
  </Files>
  <Keyboards>
${kbs}
  </Keyboards>
</Package>
`;
}
const PAGE_CSS = 'p,li,td{font:10pt Tahoma;}h1{font:bold 16pt Tahoma;color:#17475e;}h2{font:bold 12pt Tahoma;color:#17475e;}code{font-size:11pt;}td{padding:2px 10px 2px 0;vertical-align:top;}';
const page = (title, body) => `<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${title}</title>\n<style type="text/css">${PAGE_CSS}</style></head><body>${body}</body></html>\n`;
const SCHEME = `<h2>How to type</h2>
<p>Type the sounds with English letters; the keyboard writes the letters as you type, so spell out long vowels.</p>
<table>
<tr><td><code>k kh g gh c ch j jh</code></td><td>consonants (<code>ch</code> is the aspirated one, <code>c</code> the plain one)</td></tr>
<tr><td><code>T Th D Dh N</code></td><td>retroflex consonants; <code>R</code> and <code>Rh</code> are the flapped ones</td></tr>
<tr><td><code>t th d dh n p ph b bh m</code></td><td>dental and labial consonants</td></tr>
<tr><td><code>y r l L w v s sh S h x</code></td><td>the rest; <code>x</code> is the conjunct ksha, <code>gy</code> and <code>jn</code> the conjunct gya</td></tr>
<tr><td><code>a i u e o</code></td><td>vowels; after a consonant <code>a</code> only means "the sound a", so <code>ka</code> stays the plain consonant, <code>kaa</code> is the long one</td></tr>
<tr><td><code>aa ii uu ee oo ai au</code></td><td>long vowels and diphthongs; <code>A I U</code> are shortcuts for the long ones</td></tr>
<tr><td><code>rri</code></td><td>the vowel ri</td></tr>
<tr><td>consonant + consonant</td><td>joins into a conjunct by itself: <code>stra</code>, <code>ksh</code>, <code>ntr</code>. Put an apostrophe between them to keep them apart: <code>k'k</code></td></tr>
<tr><td><code>\`</code></td><td>halant</td></tr>
<tr><td><code>z</code>, <code>Z</code></td><td>zero-width non-joiner, and halant with a non-joiner</td></tr>
<tr><td><code>M</code> <code>H</code> <code>~</code> <code>&gt;</code></td><td>anusvara, visarga, chandrabindu, nukta</td></tr>
<tr><td><code>|</code></td><td>danda</td></tr>
<tr><td>Shift or Caps Lock</td><td>capitals that have no meaning of their own type the same as the small letter</td></tr>
<tr><td><code>^0</code> ... <code>^9</code></td><td>native digits; <code>^z</code> is ZWJ, <code>^'</code> a plain apostrophe, <code>^^</code> a caret</td></tr>
</table>
<h2>On a phone or tablet</h2>
<ul>
<li>Press and hold a letter for the vowels, signs and common conjuncts that belong to it.</li>
<li>Press and hold the full stop for all punctuation (the apostrophe is there, and the danda).</li>
<li>The key with the script's first letter opens a page with every vowel, vowel sign and mark.</li>
<li>The glowing Z key gives ZWNJ (hold it for ZWJ and halant with a joiner).</li>
<li>Install the matching <b>suggestions</b> package (the file ending in .model.kmp) as well, and the strip above the keys suggests words while you type.</li>
</ul>
<p>The Sulekhak apps (Mac, Windows, Android, iPad, web) suggest whole words, learn your choices and cycle through candidates; a Keyman keyboard types by rules and suggests completions from its word list.</p>`;

/* ---- run ---- */
fs.mkdirSync(path.join(OUT, 'source'), { recursive: true });
fs.mkdirSync(path.join(OUT, 'build'), { recursive: true });
const built = {};
for (const L of LANGS) {
  L.letter = L.sc === 0 ? 'ଅ' : E.toScript('ଅ', L.sc, 0);
}
for (const L of LANGS) {
  const B = build(L); built[L.id] = B;
  fs.writeFileSync(path.join(OUT, 'source', L.id + '.keyman-touch-layout'), layout(L, B));      // first: the touch layout fills TOUCH_RULES
  fs.writeFileSync(path.join(OUT, 'source', L.id + '.kmn'), '﻿' + kmn(L, B));
  fs.writeFileSync(path.join(OUT, 'source', L.id + '.kvks'), kvks(L, B));
  fs.writeFileSync(path.join(OUT, 'rules-' + L.id + '.json'), JSON.stringify({ R: B.R, cons: B.consList }));
  fs.writeFileSync(path.join(OUT, 'source', L.id + '.kps'), kpsKeyboard([L], L.name, 'Sulekhak phonetic keyboard: type ' + L.lname + ' with English letters. Version ' + KBVER + ': long-press lists, a page of every vowel and sign, a glowing Z key, and an on-screen keyboard for computers.'));
}
fs.writeFileSync(path.join(OUT, 'source', 'sulekhak_all.kps'), kpsKeyboard(LANGS, 'Sulekhak (Odia, Devanagari, Assamese, Bangla)', 'Sulekhak phonetic keyboards: type Odia, Devanagari, Assamese and Bangla with English letters.'));
fs.writeFileSync(path.join(OUT, 'source', 'sulekhak.css'), CSS);
fs.writeFileSync(path.join(OUT, 'sulekhak.kpj'), `<?xml version="1.0" encoding="utf-8"?>
<KeymanDeveloperProject>
  <Options>
    <Version>2.0</Version>
    <CompilerWarningsAsErrors>False</CompilerWarningsAsErrors>
    <CheckFilenameConventions>True</CheckFilenameConventions>
  </Options>
</KeymanDeveloperProject>
`);
fs.writeFileSync(path.join(OUT, 'source', 'welcome.htm'), page('Start using Sulekhak', `<h1>Start using Sulekhak</h1><p>Four phonetic keyboards in one package: Odia, Devanagari, Assamese and Bangla. Add the language you want in Keyman, then switch to it.</p>${SCHEME}<p>Sai Sudeep Das, 2026. <a href="https://github.com/Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard">github.com/Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard</a></p>`));
fs.writeFileSync(path.join(OUT, 'source', 'readme.htm'), page('Sulekhak keyboards for Keyman', `<h1>Sulekhak keyboards for Keyman</h1>${SCHEME}`));
fs.copyFileSync('/home/claude/newrepo/LICENSE', path.join(OUT, 'LICENSE.md'));
if (process.env.SK_LEX) console.log('models', JSON.stringify(writeModels()));
console.log('written', LANGS.map(l => l.id).join(' '));
