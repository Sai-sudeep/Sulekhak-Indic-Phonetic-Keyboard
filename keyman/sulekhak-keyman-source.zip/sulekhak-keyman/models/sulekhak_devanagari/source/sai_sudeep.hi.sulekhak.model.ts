/* Sulekhak Hindi (Devanagari) suggestions: finishes the word being typed and fixes small slips. */
const source: LexicalModelSource = {
  format: 'trie-1.0',
  wordBreaker: 'default',
  sources: ['wordlist.tsv'],
  /* a word is found whether or not it was typed with the joiners (ZWNJ, ZWJ) */
  searchTermToKey: function (term: string) { return term.normalize('NFC').replace(/[\u200C\u200D]/g, ''); },
  punctuation: {
    quotesForKeepSuggestion: { open: '\u201C', close: '\u201D' },
    insertAfterWord: ' ',
    isRTL: false
  }
};
export default source;
