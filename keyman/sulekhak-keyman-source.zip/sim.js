/* A small Keyman-style rule interpreter for the generated rules, to test the design (not Keyman itself). */
const fs = require('fs');
function load(id) { const j = JSON.parse(fs.readFileSync('proj/rules-' + id + '.json', 'utf8')); return { R: j.R, cons: new Set(j.cons) }; }
function matches(rule, ctxArr, cons) {
  const n = rule.ctx.length; if (n > ctxArr.length) return null;
  const tail = ctxArr.slice(ctxArr.length - n);
  for (let i = 0; i < n; i++) {
    const r = rule.ctx[i], t = tail[i];
    if (r.c !== undefined) { if (t.c !== r.c) return null; }
    else if (r.any) { if (t.c === undefined || !cons.has(t.c)) return null; }
    else if (r.dk) { if (t.dk !== r.dk) return null; }
  }
  return tail;
}
function type(kb, str, order) {
  let ctx = [];
  for (const k of str) {
    let rules = kb.R.filter(r => r.key === k);
    if (order === 'len') rules = rules.map((r, i) => [r, i]).sort((a, b) => (b[0].ctx.length - a[0].ctx.length) || (a[1] - b[1])).map(x => x[0]);
    let done = false;
    for (const r of rules) {
      const tail = matches(r, ctx, kb.cons);
      if (!tail) continue;
      ctx = ctx.slice(0, ctx.length - r.ctx.length);
      for (const o of r.out) { if (o.c !== undefined) ctx.push({ c: o.c }); else if (o.dk) ctx.push({ dk: o.dk }); else if (o.cx) ctx.push(tail[o.cx - 1]); }
      done = true; break;
    }
    if (!done) ctx.push({ c: k });
  }
  return ctx.filter(x => x.c !== undefined).map(x => x.c).join('');
}
module.exports = { load, type };
if (require.main === module) {
  const tests = {
    sulekhak_odia: [['namaskaar', 'ନମସ୍କାର'], ['bhaarat', 'ଭାରତ'], ['oRiaa', '\u0B13\u0B5C\u0B3F\u0B06'], ['stree', 'ସ୍ତ୍ରୀ'], ['kshetra', 'କ୍ଷେତ୍ର'], ['xetra', 'କ୍ଷେତ୍ର'],
      ['gangaa', 'ଗଙ୍ଗା'], ['ankaa', 'ଅଙ୍କା'], ['panca', 'ପଞ୍ଚ'], ['panchaa', 'ପଞ୍ଚା'], ['chaa', 'ଚା'], ['chhaa', 'ଛା'], ['achha', 'ଅଛ'], ['kah', 'କହ'], ['kaa', 'କା'], ['kai', 'କୈ'], ['kau', 'କୌ'], ['ki', 'କି'], ['kii', 'କୀ'], ['kuu', 'କୂ'],
      ['ke', 'କେ'], ['kee', 'କୀ'], ['ko', 'କୋ'], ['kou', 'କୌ'], ['ai', 'ଐ'], ['au', 'ଔ'], ['aa', 'ଆ'], ['ii', 'ଈ'], ['rriSi', 'ଋଷି'], ['krriSNa', 'କୃଷ୍ଣ'], ['rrishi', 'ଋଶି'],
      ['baag`debii', 'ବାଗ୍ଦେବୀ'], ['baagZdebii', 'ବାଗ୍\u200Cଦେବୀ'], ['tatZsam', 'ତତ୍\u200Cସମ'], ['ghar', 'ଘର'], ['chhaata', 'ଛାତ'], ['thaa', 'ଥା'], ['byabahaar', 'ବ୍ୟବହାର'],
      ['pyaar', 'ପ୍ୟାର'], ['jnaan', 'ଜ୍ଞାନ'], ['gyaan', 'ଜ୍ଞାନ'], ['sharmaa', 'ଶର୍ମା'], ['saMmaan', 'ସଂମାନ'], ['duHkha', 'ଦୁଃଖ'], ['kaR', 'କ\u0B5C']],
    sulekhak_devanagari: [['namaskaar', 'नमस्कार'], ['bhaarat', 'भारत'], ['hindii', 'हिन्दी'], ['kshetra', 'क्षेत्र'], ['gangaa', 'गङ्गा'], ['jnaan', 'ज्ञान']],
    sulekhak_bangla: [['baaMlaa', 'বাংলা'], ['namaskaar', 'নমস্কার'], ['bhaarat', 'ভারত']],
    sulekhak_assamese: [['asamiiyaa', '\u0985\u09B8\u09AE\u09C0\u09DF\u09BE'], ['namaskaar', 'নমস্কাৰ']]
  };
  let bad = 0;
  for (const id of Object.keys(tests)) {
    const kb = load(id);
    for (const [r, e] of tests[id]) {
      const a = type(kb, r, 'src'), b = type(kb, r, 'len');
      const ok = a === e && b === e;
      if (!ok) { bad++; console.log('FAIL', id, r, 'expected', e, 'got(src)', a, 'got(len)', b); }
    }
  }
  console.log(bad ? bad + ' failed' : 'all rule tests passed');
}
