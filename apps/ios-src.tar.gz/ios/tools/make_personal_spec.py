#!/usr/bin/env python3
"""Writes project-personal.yml next to project.yml: the private build (Google sign-in in the app, the shared storage of the keyboard and the app).
   The public project.yml has English and local learning only. Run:  python3 tools/make_personal_spec.py   (needs PyYAML)"""
import os, yaml
here = os.path.dirname(os.path.abspath(__file__))
root = os.path.join(here, '..')
d = yaml.safe_load(open(os.path.join(root, 'project.yml'), encoding='utf8'))
GROUP = 'group.com.saisudeep.sulekhak'
d['name'] = 'Sulekhak'
d.setdefault('settings', {}).setdefault('base', {})['SWIFT_ACTIVE_COMPILATION_CONDITIONS'] = '$(inherited) SK_PERSONAL'
for t, ent in (('Sulekhak', 'SulekhakApp/Sulekhak.entitlements'), ('SulekhakKeyboard', 'SulekhakKeyboard/SulekhakKeyboard.entitlements')):
    tgt = d['targets'][t]
    tgt['info']['properties']['ALTAppGroups'] = [GROUP]            # AltStore and SideStore read this and register the App Group when they sign the app
    tgt['entitlements'] = {'path': ent, 'properties': {'com.apple.security.application-groups': [GROUP]}}
open(os.path.join(root, 'project-personal.yml'), 'w', encoding='utf8').write(yaml.safe_dump(d, sort_keys=False, default_flow_style=False, allow_unicode=True))
print('wrote project-personal.yml')
