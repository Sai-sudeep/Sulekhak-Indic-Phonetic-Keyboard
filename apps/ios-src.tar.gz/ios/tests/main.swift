import Foundation

// Runs the real iPhone/iPad English typing (EnglishTyper) and the real engine host (SKHost, JavaScriptCore) against a text kept in a string.
//   swiftc -o selftest Shared/SKHost.swift SulekhakKeyboard/EnglishTyper.swift tests/main.swift
//   SK_JS_DIR=Shared/js SK_EN_DIR=<lite English data> SK_STORAGE_DIR=<scratch> ./selftest
// Prints one line per check and exits 0 only when all pass. (CI does this; it is not a test on a real keyboard.)

final class StringDoc: EnglishDoc {
    var text = ""
    func insert(_ s: String) { text += s }
    func deleteBackward(_ n: Int) { text = String(text.dropLast(n)) }
    func before(_ n: Int) -> String { return String(text.suffix(n)) }
}

var bad = 0
func check(_ what: String, _ got: String, _ want: String) {
    let ok = got == want
    print("\(ok ? "ok  " : "FAIL")  \(what)  [\(got)]\(ok ? "" : "  expected [\(want)]")")
    if !ok { bad += 1 }
}
func checkTrue(_ what: String, _ v: Bool) {
    print("\(v ? "ok  " : "FAIL")  \(what)")
    if !v { bad += 1 }
}
func waitFor(_ secs: Double, _ cond: () -> Bool) -> Bool {
    let end = Date().addingTimeInterval(secs)
    while Date() < end { if cond() { return true }; Thread.sleep(forTimeInterval: 0.25) }
    return cond()
}

let host = SKHost.shared
host.start(role: .keyboard)
host.setMode(script: 0, english: true)
host.prepareEnglish()
checkTrue("English word lists loaded", waitFor(120) { host.englishReady })
if !host.englishReady { print("SELFTEST FAILED"); exit(1) }

let doc = StringDoc()
let en = EnglishTyper()
en.doc = doc
en.query = { typed, prev in host.englishQuery(typed, previous: prev) }
en.learn = { typed, word, prev, how, passed in host.englishCommit(typed: typed, word: word, previous: prev, how: how, passed: passed) }

func typeWord(_ s: String) {
    for ch in s {
        let c = String(ch)
        if c == " " { en.space() }
        else if EnglishTyper.isLetter(c) || (EnglishTyper.isApostrophe(c) && !en.buf.isEmpty) { en.type(c) }
        else { en.other(c) }
    }
}

typeWord("teh ");             check("teh + space is corrected", doc.text, "the ")
typeWord("recieve ");         check("recieve + space is corrected", doc.text, "the receive ")
checkTrue("backspace right after a correction is handled by the English typing", en.backspace())
check("... and puts the typed letters back", doc.text, "the recieve ")
typeWord("hello");            check("a correct word stays as typed while typing", doc.text, "the recieve hello")
typeWord(" ");                check("space after a correct word only adds the space", doc.text, "the recieve hello ")
typeWord("dont ");            check("dont becomes don't", doc.text, "the recieve hello don't ")
typeWord("thnak ");           check("thnak becomes thank", doc.text, "the recieve hello don't thank ")
typeWord("hi,");              check("a comma finishes the word", doc.text, "the recieve hello don't thank hi,")
typeWord(" ");
let before = doc.text
typeWord("helo");             checkTrue("a misspelling offers 'hello' in the list", en.cands.contains("hello"))
if let i = en.cands.firstIndex(of: "hello") { en.pick(i) }
check("tapping a suggestion puts it in with a space", doc.text, before + "hello ")
checkTrue("Backspace after a tapped suggestion deletes one character as usual", !en.backspace())
// a word moved from under us (the cursor was moved): nothing is deleted by mistake
typeWord("wrld");
doc.text = "something else"
en.space()
check("when the text under the cursor changed, only the space is added", doc.text, "something else ")

// what was learned is written to the language file a couple of seconds later
for _ in 0..<3 { host.englishCommit(typed: "zorbatrix", word: "zorbatrix", previous: "<s>", how: "typed", passed: "") }
let enFile = SKShared.langFile("en")
checkTrue("the learning file en.json was written", waitFor(20) { FileManager.default.fileExists(atPath: enFile.path) })
host.drain()
let q = host.englishQuery("zorbatrix", previous: "<s>")
check("a word typed three times is kept as the person's own", q?.list.first ?? "(none)", "zorbatrix")

// the Odia / Hindi history
host.setMode(script: 0, english: false)
host.pick(roman: "namaskar", word: "\u{0B28}\u{0B2E}\u{0B38}\u{0B4D}\u{0B15}\u{0B3E}\u{0B30}")
let orFile = SKShared.langFile("or")
checkTrue("the Odia learning file or.json was written", waitFor(20) { FileManager.default.fileExists(atPath: orFile.path) })
let orText = (try? String(contentsOf: orFile, encoding: .utf8)) ?? ""
checkTrue("it holds the picked word", orText.contains("namaskar"))
host.setMode(script: 1, english: false)
host.pick(roman: "bharat", word: "\u{092D}\u{093E}\u{0930}\u{0924}")
let hiFile = SKShared.langFile("hi")
checkTrue("the Devanagari learning file hi.json was written", waitFor(20) { FileManager.default.fileExists(atPath: hiFile.path) })

host.reload()
host.drain()
checkTrue("reload() runs without trouble", true)

print(bad == 0 ? "SELFTEST PASSED" : "SELFTEST FAILED (\(bad))")
exit(bad == 0 ? 0 : 1)
