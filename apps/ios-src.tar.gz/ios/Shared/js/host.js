/* Sulekhak for Mac: the part that the Objective-C side talks to (see SKPersonal.m). Runs after english.js, learning.js, drive.js and personal.js.
   English suggestions are synchronous here (the typing code waits for them), the learning and sync code is asynchronous and talks to the app through __post(json). */
var SKM = (function () {
  'use strict';
  var EN = null, ready = false;
  function lowerPrev(p) { return (p || '').toLowerCase(); }
  function enLearn() {                      /* what this person has taught it: their own words and the fixes they made */
    if (!EN || !window.SKP || SKP.lang !== 'en') return;
    try {
      SKP.learnedWords(2).forEach(function (x) { EN.addUser(x[0], 300 + Math.min(250, x[1] * 25)); });
      SKP.learnedCorrections(2).forEach(function (c) { EN.addFix(c[0], c[1]); });
    } catch (e) {}
  }
  window.imeEnLearn = enLearn;
  window.imeLearnAdd = function (pairs) { try { __learnAdd(JSON.stringify(pairs || [])); } catch (e) {} };      /* history from other devices: [[roman, odiaWord], ...] */
  function enRank(typed, prev, list, fixed) {
    if (!window.SKP || list.length <= fixed + 1) return list;
    try {
      var head = list.slice(0, fixed), rest = list.slice(fixed).map(function (w) { return [w.toLowerCase(), w]; });
      return head.concat(SKP.rerankRaw(typed.toLowerCase(), prev, rest).map(function (x) { return x[1]; }));
    } catch (e) { return list; }
  }
  var enSeen = {};
  return {
    enLoad: function (lex, ng, fix) {
      var e = window.SulekhakEnglish.create(); e.load({ lex: lex, ng: ng, fix: fix }); EN = e; enLearn(); return true;
    },
    enReady: function () { return !!EN; },
    /* -> JSON {list:[...], auto:0|1} ; list[0] is what the space key commits, auto:1 means list[1] is the text as typed */
    enQuery: function (typed, prev) {
      if (!EN) return null;
      prev = lowerPrev(prev); try { SKP.prev(prev); } catch (e) {}
      var r, xt = null;
      try { if (window.SKP && SKP.lang === 'en') xt = SKP.completionsFor(typed.toLowerCase(), 6); } catch (x) {}
      try { r = EN.suggest(typed, prev || null, { extra: xt }); } catch (x) { r = { list: [typed], auto: 0 }; }
      return JSON.stringify({ list: enRank(typed, prev, r.list, r.auto ? 2 : 1), auto: r.auto ? 1 : 0 });
    },
    /* the words that usually follow prev ("<s>" at a sentence start) -> JSON [..] */
    enNext: function (prev) {
      if (!EN) return null;
      prev = lowerPrev(prev) || '<s>';
      var out = [], seen = {};
      function add(w) { var k = w.toLowerCase(); if (w && !seen[k] && out.length < 6) { seen[k] = 1; out.push(w); } }
      try { if (window.SKP && SKP.lang === 'en') SKP.nextFor(prev, 3).forEach(function (x) { add(prev === '<s>' ? x[0].charAt(0).toUpperCase() + x[0].substr(1) : x[0]); }); } catch (x) {}
      try { EN.next(prev, 6).forEach(add); } catch (x) {}
      return JSON.stringify(out);
    },
    enCommit: function (typed, word, prev, how, passed) {      /* how: typed | auto | pick | revert */
      if (EN && word && how !== 'revert') try { EN.note(word, lowerPrev(prev)); } catch (e) {}     /* the next question about this word has two words of context */
      if (!window.SKP || !word) return;
      var tl = (typed || '').toLowerCase(), wl = word.toLowerCase(); prev = lowerPrev(prev);
      try {
        if (how === 'pick') {
          if (tl && wl.indexOf(tl) === 0) SKP.onPick(tl, wl, prev); else if (tl) { SKP.onCorrection(tl, wl); SKP.onWord(wl, prev); } else SKP.onWord(wl, prev);
          if (tl && passed && passed.toLowerCase() !== wl) SKP.onSkip(tl, passed.toLowerCase());
        } else if (how === 'revert') {
          SKP.onWord(wl, prev);
          if (passed && passed.toLowerCase() !== wl) SKP.onSkip(tl, passed.toLowerCase());
          if (EN && !EN.known(wl)) EN.addUser(word, 400);
        } else {
          SKP.onWord(wl, prev);
          if (how === 'typed' && EN && !EN.known(wl)) { enSeen[wl] = (enSeen[wl] || 0) + 1; if (enSeen[wl] >= 2) EN.addUser(word, 350); }
        }
      } catch (e) {}
    },
    setMode: function (script, opt, english) { if (window.SKP) try { SKP.setMode(script, opt, !!english); } catch (e) {} },
    pick: function (roman, word, prev) { try { SKP.onPick(roman, word, prev || ''); } catch (e) {} },
    init: function (did, name, allowedJson, platform) {
      SKP.initHost({ did: did, name: name, platform: platform || 'mac', allowed: JSON.parse(allowedJson || '[]'), post: function (m) { __post(JSON.stringify(m)); } });
      ready = true;
    },
    enUnload: function () { EN = null; return true; },          /* the iPhone keyboard gives the memory back when the system asks for it */
    word: function (w, prev) { try { SKP.onWord(w, prev || ''); } catch (e) {} },
    swipe: function (word, accepted, prev) { try { SKP.onSwipe(word, accepted !== false, prev || ''); } catch (e) {} },
    serialize: function (lang) { try { return SKP._internals().store.serialize(lang); } catch (e) { return ''; } },
    /* the app (iPhone / iPad): bring every language up to date with the cloud, one after the other; says sk-every-done when finished */
    syncEvery: function () {
      var modes = [[0, 0, false], [1, 0, false], [1, 1, false], [2, 0, false], [5, 0, false], [0, 0, true]];
      return modes.reduce(function (c, m) { return c.then(function () { SKP.setMode(m[0], m[1], m[2]); return SKP.syncNow(); }); }, Promise.resolve())
        .then(function () { __post(JSON.stringify({ t: 'sk-every-done', state: SKP.state, detail: SKP.detail })); },
              function () { __post(JSON.stringify({ t: 'sk-every-done', state: 'error', detail: 'sync failed' })); });
    },
    hostLoad: function (lang, text) { SKP.hostLoad(lang, text || ''); },
    setToken: function (a, secs, email) { SKP.setToken(a, secs, email); },
    signedOut: function () { SKP.signedOut(); },
    syncNow: function () { try { return SKP.syncNow(); } catch (e) {} },
    dictionary: function () { try { return JSON.stringify(SKP.dictionary()); } catch (e) { return '[]'; } },
    hasSKP: function () { return !!window.SKP; }
  };
})();
