/* Sulekhak for Mac: what the browser pages give english.js, learning.js, drive.js and personal.js, supplied by the app (JavaScriptCore has no window, timers or fetch of its own).
   The app defines  __log(text)  __timer(fn, ms, repeat) -> id  __untimer(id)  __fetch(method, url, headersJson, body, done(status, headersJson, text))  before this file runs. */
var window = this, self = this, global = this;
var console = { log: function () { __log(Array.prototype.join.call(arguments, ' ')); }, warn: function () { __log(Array.prototype.join.call(arguments, ' ')); }, error: function () { __log(Array.prototype.join.call(arguments, ' ')); } };
function setTimeout(f, ms) { return __timer(f, ms | 0, false); }
function setInterval(f, ms) { return __timer(f, ms | 0, true); }
function clearTimeout(id) { __untimer(id); }
function clearInterval(id) { __untimer(id); }
function fetch(url, opts) {
  opts = opts || {};
  return new Promise(function (resolve, reject) {
    var h = opts.headers || {};
    __fetch(String(opts.method || 'GET'), String(url), JSON.stringify(h), opts.body == null ? null : String(opts.body), function (status, headersJson, text) {
      if (!(status > 0)) { reject(new TypeError('network error')); return; }
      var hd = {}; try { hd = JSON.parse(headersJson || '{}'); } catch (e) {}
      resolve({
        ok: status >= 200 && status < 300, status: status,
        headers: { get: function (k) { k = String(k).toLowerCase(); for (var x in hd) if (x.toLowerCase() === k) return hd[x]; return null; } },
        text: function () { return Promise.resolve(text); },
        json: function () { return Promise.resolve().then(function () { return JSON.parse(text); }); }
      });
    });
  });
}
