import Foundation
import JavaScriptCore

/// Where the keyboard and the app keep what is learned. With an App Group (AltStore and SideStore give one when the Info.plist names it) both see the same folder;
/// without one each keeps its own copy, and typing still works, only the app cannot sync what the keyboard learned.
enum SKShared {
    static let groupId = "group.com.saisudeep.sulekhak"

    static let groupContainer: URL? = {
        var ids: [String] = []
        if let a = Bundle.main.object(forInfoDictionaryKey: "ALTAppGroups") as? [String] { ids += a }      // AltStore writes the identifiers it registered here
        ids.append(groupId)
        for id in ids {
            if let u = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: id) { return u }
        }
        return nil
    }()

    /// true when the keyboard and the app really share a folder
    static var isShared: Bool { return storageOverride == nil && groupContainer != nil }

    /// tests point this at a scratch folder
    static var storageOverride: URL? = {
        if let p = ProcessInfo.processInfo.environment["SK_STORAGE_DIR"], !p.isEmpty { return URL(fileURLWithPath: p, isDirectory: true) }
        return nil
    }()

    static let dir: URL = {
        let base: URL = storageOverride ?? groupContainer ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let d = base.appendingPathComponent("Sulekhak", isDirectory: true)
        try? FileManager.default.createDirectory(at: d.appendingPathComponent("learning", isDirectory: true), withIntermediateDirectories: true)
        return d
    }()

    static func langFile(_ lang: String) -> URL {
        return dir.appendingPathComponent("learning", isDirectory: true).appendingPathComponent(lang + ".json")
    }

    static let langs = ["or", "hi", "mr", "bn", "as", "en"]
}

/// The personal-learning and English engine (JavaScript in JavaScriptCore) that the Mac, Windows and Android apps also run:
/// english.js (word lists, spelling), learning.js (the history that merges between devices), personal.js, drive.js (the sync with Google Drive), host.js (the calls made from here).
/// All of it runs on one serial queue. The keyboard only learns and suggests (it has no network); the app does the sign-in and the sync.
final class SKHost {
    static let shared = SKHost()

    enum Role { case keyboard, app }

    private let q = DispatchQueue(label: "sulekhak.host")
    private let lock = NSLock()
    private var ctx: JSContext?
    private var role: Role = .keyboard
    private var started = false
    private var allowed: [String] = []
    private var timers: [Int: DispatchSourceTimer] = [:]
    private var timerFns: [Int: JSValue] = [:]
    private var timerSeq = 0
    private var known: [String: String] = [:]               // language -> the text of its file as this process last read or wrote it
    private var pendingMode: (Int, Int, Bool)?
    private var wantEnglish = false
    private var englishLoading = false
    private var _englishReady = false

    /// the keyboard sets this: history that came from another device, [[roman, word], ...] as JSON, goes into its engine
    static var learnSink: ((String) -> Void)?
    /// the app supplies this: it gives a fresh Google access token (or nil when signed out)
    var tokenProvider: ((@escaping (String?, Int, String?) -> Void) -> Void)?
    /// state ("signed-in", "syncing", "synced", "error", "signed-out", "refused") and detail, on the main thread
    var onStatus: ((String, String) -> Void)?
    var onEveryDone: ((String, String) -> Void)?
    var onSignOutRequested: (() -> Void)?
    private(set) var lastState = "off"
    private(set) var lastDetail = ""

    var englishReady: Bool { lock.lock(); defer { lock.unlock() }; return _englishReady }
    private func setEnglishReady(_ v: Bool) { lock.lock(); _englishReady = v; lock.unlock() }

    // MARK: files that come with the build (tests point the two folders somewhere else)

    private static func bundleURL(_ name: String, _ ext: String, _ sub: String, _ envKey: String) -> URL? {
        if let d = ProcessInfo.processInfo.environment[envKey], !d.isEmpty {
            let u = URL(fileURLWithPath: d, isDirectory: true).appendingPathComponent(name + "." + ext)
            return FileManager.default.fileExists(atPath: u.path) ? u : nil
        }
        return Bundle(for: SKHost.self).url(forResource: name, withExtension: ext, subdirectory: sub)
    }

    // MARK: start

    func start(role: Role, allowed: [String] = []) {
        q.async {
            if self.started { return }
            self.started = true
            self.role = role
            self.allowed = allowed
            self.boot()
        }
    }

    private func log(_ s: String) { NSLog("Sulekhak: %@", s) }

    private func deviceId() -> String {
        let f = SKShared.dir.appendingPathComponent("device.id")
        if let s = try? String(contentsOf: f, encoding: .utf8) {
            let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
            if t.count >= 3 { return t }
        }
        let id = "i" + String(UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased().prefix(8))
        try? id.write(to: f, atomically: true, encoding: .utf8)
        return id
    }

    private func boot() {
        let c = JSContext()!
        c.exceptionHandler = { [weak self] _, ex in self?.log("js: " + (ex?.toString() ?? "unknown")) }
        let logB: @convention(block) (String) -> Void = { [weak self] s in self?.log(s) }
        let timerB: @convention(block) (JSValue, Int32, Bool) -> NSNumber = { [weak self] fn, ms, rep in
            return NSNumber(value: self?.addTimer(fn, Int(ms), rep) ?? 0)
        }
        let untimerB: @convention(block) (NSNumber) -> Void = { [weak self] id in self?.removeTimer(id.intValue) }
        let fetchB: @convention(block) (String, String, String, JSValue, JSValue) -> Void = { [weak self] m, u, h, body, done in
            self?.fetch(m, u, h, body, done)
        }
        let postB: @convention(block) (String) -> Void = { [weak self] json in
            guard let me = self else { return }
            me.q.async { me.hostMessage(json) }
        }
        let learnB: @convention(block) (String) -> Void = { json in
            DispatchQueue.main.async { SKHost.learnSink?(json) }
        }
        c.setObject(logB, forKeyedSubscript: "__log" as NSString)
        c.setObject(timerB, forKeyedSubscript: "__timer" as NSString)
        c.setObject(untimerB, forKeyedSubscript: "__untimer" as NSString)
        c.setObject(fetchB, forKeyedSubscript: "__fetch" as NSString)
        c.setObject(postB, forKeyedSubscript: "__post" as NSString)
        c.setObject(learnB, forKeyedSubscript: "__learnAdd" as NSString)
        for name in ["prelude", "english", "learning", "drive", "personal", "host"] {
            guard let u = SKHost.bundleURL(name, "js", "js", "SK_JS_DIR"), let src = try? String(contentsOf: u, encoding: .utf8) else {
                log("missing " + name + ".js")
                return
            }
            c.evaluateScript(src, withSourceURL: u)
        }
        ctx = c
        let allowedJson = (try? JSONSerialization.data(withJSONObject: allowed)).flatMap { String(data: $0, encoding: .utf8) } ?? "[]"
        _ = skm("init", [deviceId(), role == .app ? "iPhone/iPad app" : "iPhone/iPad keyboard", allowedJson, "ios"])
        if let m = pendingMode { _ = skm("setMode", [m.0, m.1, m.2]) }
        if wantEnglish { loadEnglish() }
    }

    @discardableResult
    private func skm(_ fn: String, _ args: [Any]) -> JSValue? {
        guard let c = ctx, let o = c.objectForKeyedSubscript("SKM"), !o.isUndefined,
              let f = o.objectForKeyedSubscript(fn), !f.isUndefined else { return nil }
        return f.call(withArguments: args)
    }

    // MARK: what the JavaScript asks for

    private func addTimer(_ fn: JSValue, _ ms: Int, _ repeats: Bool) -> Int {
        timerSeq += 1
        let id = timerSeq
        let t = DispatchSource.makeTimerSource(queue: q)
        let ns = DispatchTimeInterval.milliseconds(max(ms, 1))
        t.schedule(deadline: .now() + ns, repeating: repeats ? ns : .never, leeway: .milliseconds(max(ms / 10, 1)))
        timers[id] = t
        timerFns[id] = fn
        t.setEventHandler { [weak self] in
            guard let me = self, let f = me.timerFns[id] else { return }
            if !repeats { me.removeTimer(id) }
            f.call(withArguments: [])
        }
        t.resume()
        return id
    }

    private func removeTimer(_ id: Int) {
        if let t = timers[id] { t.cancel(); timers[id] = nil }
        timerFns[id] = nil
    }

    private func fetch(_ method: String, _ urlS: String, _ hdrs: String, _ body: JSValue, _ done: JSValue) {
        func answer(_ st: Int, _ hj: String, _ text: String) { q.async { done.call(withArguments: [st, hj, text]) } }
        // only the app has a network, and the sync code only ever talks to Google's Drive API
        guard role == .app, let u = URL(string: urlS), u.scheme == "https", let host = u.host, host.hasSuffix("googleapis.com") else { answer(0, "{}", ""); return }
        var r = URLRequest(url: u, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60)
        r.httpMethod = method
        if let d = hdrs.data(using: .utf8), let h = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
            for (k, v) in h { r.setValue("\(v)", forHTTPHeaderField: k) }
        }
        if body.isString, let s = body.toString() { r.httpBody = s.data(using: .utf8) }
        URLSession.shared.dataTask(with: r) { data, resp, _ in
            let hr = resp as? HTTPURLResponse
            let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
            var hd: [String: String] = [:]
            for (k, v) in hr?.allHeaderFields ?? [:] { hd["\(k)"] = "\(v)" }
            let hj = (try? JSONSerialization.data(withJSONObject: hd)).flatMap { String(data: $0, encoding: .utf8) } ?? "{}"
            answer(hr?.statusCode ?? 0, hj, text)
        }.resume()
    }

    private func hostMessage(_ json: String) {
        guard let d = json.data(using: .utf8), let m = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let t = m["t"] as? String else { return }
        let lang = m["lang"] as? String ?? ""
        switch t {
        case "sk-need":
            let text = SKShared.langs.contains(lang) ? readFile(lang) : ""
            known[lang] = text
            skm("hostLoad", [lang, text])
        case "sk-save":
            if let text = m["text"] as? String { save(lang, text) }
        case "sk-token":
            guard let p = tokenProvider else { skm("signedOut", []); return }
            DispatchQueue.main.async {
                p { [weak self] access, secs, email in
                    self?.q.async {
                        if let a = access { self?.skm("setToken", [a, secs, email ?? ""]) } else { self?.skm("signedOut", []) }
                    }
                }
            }
        case "sk-state":
            let s = m["state"] as? String ?? "", dt = m["detail"] as? String ?? ""
            lastState = s; lastDetail = dt
            DispatchQueue.main.async { self.onStatus?(s, dt) }
        case "sk-signout":
            DispatchQueue.main.async { self.onSignOutRequested?() }
        case "sk-every-done":
            let s = m["state"] as? String ?? "", dt = m["detail"] as? String ?? ""
            DispatchQueue.main.async { self.onEveryDone?(s, dt) }
        default: break
        }
    }

    // MARK: the learning files (the keyboard and the app may both write them: whatever the other wrote is merged in first)

    private func readFile(_ lang: String) -> String {
        return (try? String(contentsOf: SKShared.langFile(lang), encoding: .utf8)) ?? ""
    }

    private func save(_ lang: String, _ text: String) {
        guard SKShared.langs.contains(lang), !text.isEmpty else { return }
        var out = text
        let existing = readFile(lang)
        if !existing.isEmpty && existing != known[lang] {                 // the other side wrote since this one read: take that in, then write the merged history
            skm("hostLoad", [lang, existing])
            if let merged = skm("serialize", [lang])?.toString(), merged.hasPrefix("{") { out = merged }
        }
        let f = SKShared.langFile(lang)
        let fm = FileManager.default
        if !existing.isEmpty {
            let bak = f.appendingPathExtension("bak")
            try? fm.removeItem(at: bak)
            try? fm.copyItem(at: f, to: bak)
        }
        do { try out.write(to: f, atomically: true, encoding: .utf8); known[lang] = out } catch { log("could not write " + lang + ".json: \(error)") }
    }

    /// The keyboard came back on screen: take in what the app merged from the cloud since.
    func reload() {
        q.async {
            guard self.ctx != nil else { return }
            for lang in SKShared.langs {
                let t = self.readFile(lang)
                if !t.isEmpty && t != self.known[lang] {
                    self.known[lang] = t
                    self.skm("hostLoad", [lang, t])
                }
            }
        }
    }

    // MARK: modes and learning (called from the keyboard)

    /// script: 0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese (4 IPA learns nothing); english: the English mode
    func setMode(script: Int, english: Bool) {
        q.async {
            if let m = self.pendingMode, m.0 == script, m.2 == english, self.ctx != nil { return }
            self.pendingMode = (script, 0, english)
            if english { self.wantEnglish = true }
            if self.ctx != nil {
                self.skm("setMode", [script, 0, english])
                if english { self.loadEnglish() }
            }
        }
    }

    func pick(roman: String, word: String) { q.async { self.skm("pick", [roman, word, ""]) } }
    func word(_ w: String) { q.async { self.skm("word", [w, ""]) } }
    func swipe(_ w: String, accepted: Bool = true) { q.async { self.skm("swipe", [w, accepted, ""]) } }

    // MARK: English

    private func loadEnglish() {                                          // on q
        guard ctx != nil, !englishReady, !englishLoading else { return }
        guard let lu = SKHost.bundleURL("en_lex", "txt", "en", "SK_EN_DIR"), let nu = SKHost.bundleURL("en_ng", "txt", "en", "SK_EN_DIR") else {
            log("English data missing"); return
        }
        englishLoading = true
        var ok = false
        autoreleasepool {
            if let lex = try? String(contentsOf: lu, encoding: .utf8), let ng = try? String(contentsOf: nu, encoding: .utf8) {
                let fix = SKHost.bundleURL("en_fix", "txt", "en", "SK_EN_DIR").flatMap { try? String(contentsOf: $0, encoding: .utf8) } ?? ""
                ok = skm("enLoad", [lex, ng, fix])?.toBool() ?? false
            }
        }
        englishLoading = false
        setEnglishReady(ok)
        log(ok ? "English ready" : "English failed to load")
    }

    func prepareEnglish() { q.async { self.wantEnglish = true; self.loadEnglish() } }

    /// the system wants memory back
    func unloadEnglish() {
        q.async {
            guard self.englishReady else { return }
            self.skm("enUnload", [])
            self.setEnglishReady(false)
        }
    }

    /// The suggestions for the letters typed so far (answered at once; nil while the word lists are still loading).
    /// list[0] is what Space puts in; auto means list[1] is the text as it was typed.
    func englishQuery(_ typed: String, previous: String) -> (list: [String], auto: Bool)? {
        guard englishReady else { prepareEnglish(); return nil }
        let res: String? = q.sync { skm("enQuery", [typed, previous])?.toString() }
        guard let s = res, let d = s.data(using: .utf8), let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
              let l = o["list"] as? [String], !l.isEmpty else { return nil }
        return (l, (o["auto"] as? Int ?? 0) == 1)
    }

    /// The words that usually follow `previous` ("<s>" at the start of a sentence); nil while the word lists load.
    func englishNext(_ previous: String) -> [String]? {
        guard englishReady else { return nil }
        let res: String? = q.sync { skm("enNext", [previous])?.toString() }
        guard let s = res, let d = s.data(using: .utf8), let l = try? JSONSerialization.jsonObject(with: d) as? [String] else { return nil }
        return l
    }

    /// how: typed | auto | pick | revert | next
    func englishCommit(typed: String, word: String, previous: String, how: String, passed: String) {
        q.async { self.skm("enCommit", [typed, word, previous, how, passed]) }
    }

    // MARK: the app: sign-in state and sync

    func setToken(_ access: String, seconds: Int, email: String) { q.async { self.skm("setToken", [access, seconds, email]) } }
    func signedOut() { q.async { self.skm("signedOut", []) } }
    /// bring every language up to date with the cloud (answers through onEveryDone)
    func syncEvery() { q.async { self.skm("syncEvery", []) } }

    /// tests: wait until everything queued so far has run
    func drain() { q.sync { } }
}
