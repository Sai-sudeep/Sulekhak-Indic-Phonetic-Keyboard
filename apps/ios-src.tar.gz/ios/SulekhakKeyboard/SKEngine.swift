import Foundation
import JavaScriptCore

/// The Sulekhak language engine (the same JavaScript as the web tool, Android and Windows apps) running in JavaScriptCore.
/// The rule engine and the user's own memory only: no network, no language-model files, so it stays well inside the memory limit of a keyboard extension.
final class SKEngine {
    static let shared = SKEngine()

    private let ctx: JSContext
    private var learned: [[String]] = []
    private let learnKey = "sulekhak.learned.v1"
    private let learnMax = 3000

    private init() {
        ctx = JSContext()!
        ctx.exceptionHandler = { _, ex in NSLog("Sulekhak JS error: %@", ex?.toString() ?? "unknown") }
        ctx.evaluateScript("var window = this; var global = this;")
        for name in ["engine", "ios_ime", "phon-data", "phon-core"] { load(name) }
        if let data = UserDefaults.standard.data(forKey: learnKey),
           let arr = try? JSONSerialization.jsonObject(with: data) as? [[String]] {
            learned = arr
            call("iosReplay", [String(data: data, encoding: .utf8) ?? "[]"])
        }
    }

    private func load(_ name: String) {
        let bundle = Bundle(for: SKEngine.self)
        guard let url = bundle.url(forResource: name, withExtension: "js"),
              let src = try? String(contentsOf: url, encoding: .utf8) else {
            NSLog("Sulekhak: missing %@.js", name)
            return
        }
        ctx.evaluateScript(src)
    }

    @discardableResult
    private func call(_ fn: String, _ args: [Any]) -> JSValue? {
        guard let f = ctx.objectForKeyedSubscript(fn), !f.isUndefined else { return nil }
        return f.call(withArguments: args)
    }

    private func strings(_ v: JSValue?) -> [String] {
        guard let s = v?.toString(), let d = s.data(using: .utf8),
              let a = try? JSONSerialization.jsonObject(with: d) as? [String] else { return [] }
        return a
    }

    /// sc: 0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese
    func setScript(_ sc: Int) { call("iosSetScript", [sc, 0]) }

    /// The candidates for the roman letters typed so far; the first is the best word, the second is always the typed text.
    func query(_ buf: String, smart: String? = nil) -> [String] {
        let r = strings(call("iosQuery", [buf, smart ?? ""]))
        return r.isEmpty ? [buf] : r
    }

    /// Does the language model engine understand these letters? (Z and z are ZWNJ in this scheme: those words are left to the rule engine.)
    func smartOK(_ buf: String) -> Bool {
        return call("iosSmartOK", [buf])?.toInt32() == 1
    }

    /// The words that usually follow, after the spelling rules and in the script of the keyboard.
    func nextList(_ json: String) -> [String] {
        return strings(call("iosNextList", [json]))
    }

    /// Swiped words (Odia, best first) after the spelling rules, in the script of the keyboard.
    func finishSwipe(_ odia: [String]) -> [String] {
        guard let d = try? JSONSerialization.data(withJSONObject: odia), let j = String(data: d, encoding: .utf8) else { return odia }
        let r = strings(call("iosSwipeFinish", [j]))
        return r.isEmpty ? odia : r
    }

    /// A word of the keyboard's script back in Odia (the word list of the swipe decoder is Odia).
    func toOdia(_ w: String) -> String {
        return call("iosToOdia", [w])?.toString() ?? w
    }

    /// The look-alike symbols for a key in the Phonetic (IPA) mode: the key itself first, then the others.
    func phonetic(_ key: String) -> [String] {
        return strings(call("iosPhon", [key]))
    }

    /// The user chose `word` for the letters `roman`: remember it (kept on this device only).
    func commit(roman: String, word: String) {
        call("iosCommit", [roman, word])
        learned.removeAll { $0.count == 2 && $0[0] == roman }
        learned.append([roman, word])
        if learned.count > learnMax { learned.removeFirst(learned.count - learnMax) }
        if let d = try? JSONSerialization.data(withJSONObject: learned) {
            UserDefaults.standard.set(d, forKey: learnKey)
        }
    }
}
