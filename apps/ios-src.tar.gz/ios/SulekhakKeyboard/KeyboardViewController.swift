import UIKit

// MARK: - Modes and layout

struct Mode {
    let name: String
    let native: String
    let sc: Int            // 0 Odia, 1 Devanagari, 5 Assamese, 2 Bangla, 4 IPA, -1 English
}

let MODES: [Mode] = [
    Mode(name: "Odia", native: "ଓଡ଼ିଆ", sc: 0),
    Mode(name: "Devanagari", native: "हिन्दी", sc: 1),
    Mode(name: "Assamese", native: "অসমীয়া", sc: 5),
    Mode(name: "Bangla", native: "বাংলা", sc: 2),
    Mode(name: "IPA", native: "IPA", sc: 4),
    Mode(name: "English", native: "EN", sc: -1)
]

enum KeyKind { case char, shift, caps, backspace, ret, globe, lang, space, hide, tab }

struct KeyDef {
    let kind: KeyKind
    let a: String          // the key
    let b: String          // with shift
    let w: CGFloat
    init(_ kind: KeyKind, _ a: String = "", _ b: String = "", w: CGFloat = 1) {
        self.kind = kind; self.a = a; self.b = b; self.w = w
    }
}

private func ch(_ a: String, _ b: String) -> KeyDef { return KeyDef(.char, a, b) }
private func letters(_ s: String) -> [KeyDef] { return s.map { ch(String($0), String($0).uppercased()) } }

let ROWS: [[KeyDef]] = [
    [ch("`", "~"), ch("1", "!"), ch("2", "@"), ch("3", "#"), ch("4", "$"), ch("5", "%"), ch("6", "^"),
     ch("7", "&"), ch("8", "*"), ch("9", "("), ch("0", ")"), ch("-", "_"), ch("=", "+"), KeyDef(.backspace, w: 1.7)],
    [KeyDef(.tab, w: 1.7)] + letters("qwertyuiop") + [ch("[", "{"), ch("]", "}"), ch("\\", "|")],
    [KeyDef(.caps, w: 1.8)] + letters("asdfghjkl") + [ch(";", ":"), ch("'", "\""), KeyDef(.ret, w: 1.9)],
    [KeyDef(.shift, w: 2.35)] + letters("zxcvbnm") + [ch(",", "<"), ch(".", ">"), ch("/", "?"), KeyDef(.shift, w: 2.35)],
    [KeyDef(.globe, w: 1.3), KeyDef(.lang, w: 2.0), KeyDef(.space, w: 10.1), KeyDef(.hide, w: 1.3)]
]

// MARK: - Colours

private func dyn(_ light: UIColor, _ dark: UIColor) -> UIColor {
    return UIColor { tc in tc.userInterfaceStyle == .dark ? dark : light }
}
private let kbBackground = dyn(UIColor(white: 0.82, alpha: 1), UIColor(white: 0.10, alpha: 1))
private let keyColor = dyn(UIColor.white, UIColor(white: 0.36, alpha: 1))
private let keyPressed = dyn(UIColor(white: 0.74, alpha: 1), UIColor(white: 0.55, alpha: 1))
private let specialColor = dyn(UIColor(white: 0.68, alpha: 1), UIColor(white: 0.24, alpha: 1))
private let accent = UIColor(red: 0.09, green: 0.28, blue: 0.37, alpha: 1)
private let textColor = dyn(UIColor.black, UIColor.white)
private let hintColor = dyn(UIColor(red: 0.75, green: 0.32, blue: 0.10, alpha: 1), UIColor(red: 1.0, green: 0.70, blue: 0.35, alpha: 1))

// MARK: - One key

final class KeyView: UIControl {
    let def: KeyDef
    let title = UILabel()
    let hint = UILabel()
    let icon = UIImageView()
    private var base: UIColor

    init(def: KeyDef) {
        self.def = def
        switch def.kind {
        case .char, .space: base = keyColor
        default: base = specialColor
        }
        super.init(frame: .zero)
        backgroundColor = base
        layer.cornerRadius = 7
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.25
        layer.shadowRadius = 0
        layer.shadowOffset = CGSize(width: 0, height: 1)

        title.textAlignment = .center
        title.textColor = textColor
        title.isUserInteractionEnabled = false
        addSubview(title)

        hint.textAlignment = .right
        hint.font = UIFont.systemFont(ofSize: 12, weight: .semibold)
        hint.textColor = hintColor
        hint.isUserInteractionEnabled = false
        addSubview(hint)

        icon.contentMode = .scaleAspectFit
        icon.tintColor = textColor
        icon.isUserInteractionEnabled = false
        addSubview(icon)
    }

    required init?(coder: NSCoder) { fatalError("not used") }

    override var isHighlighted: Bool {
        didSet { backgroundColor = isHighlighted ? keyPressed : base }
    }

    func setBase(_ c: UIColor) { base = c; backgroundColor = isHighlighted ? keyPressed : c }

    override func layoutSubviews() {
        super.layoutSubviews()
        title.frame = bounds
        hint.frame = CGRect(x: 4, y: 3, width: bounds.width - 9, height: 15)
        let s = min(bounds.height * 0.42, 26)
        icon.frame = CGRect(x: (bounds.width - s) / 2, y: (bounds.height - s) / 2, width: s, height: s)
    }
}

// MARK: - The grid of keys

final class KeyGrid: UIView {
    var keys: [[KeyView]] = []
    let gap: CGFloat = 6

    func build(_ target: Any?, down: Selector, up: Selector) {
        for row in ROWS {
            var r: [KeyView] = []
            for d in row {
                let k = KeyView(def: d)
                k.addTarget(target, action: down, for: .touchDown)
                k.addTarget(target, action: up, for: [.touchUpInside, .touchUpOutside, .touchCancel])
                addSubview(k)
                r.append(k)
            }
            keys.append(r)
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let n = CGFloat(keys.count)
        guard n > 0 else { return }
        let rowH = (bounds.height - gap * (n + 1)) / n
        for (ri, row) in keys.enumerated() {
            let total = row.reduce(CGFloat(0)) { $0 + $1.def.w }
            let usable = bounds.width - gap * (CGFloat(row.count) + 1)
            var x = gap
            let y = gap + CGFloat(ri) * (rowH + gap)
            for k in row {
                let w = usable * k.def.w / total
                k.frame = CGRect(x: x, y: y, width: w, height: rowH)
                x += w + gap
            }
        }
    }
}

// MARK: - The keyboard

final class KeyboardViewController: UIInputViewController {
    private let engine = SKEngine.shared
    private let grid = KeyGrid()
    private let bar = UIView()
    private let romanLabel = UILabel()
    private let surroundBtn = UIButton(type: .custom)          // Auto-surround on / off (the choice is kept between sessions)
    private var autoSurround: Bool {
        get { return UserDefaults.standard.object(forKey: "sulekhak.autosurround") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "sulekhak.autosurround") }
    }
    private static let surrOpen = "([{\"'`<", surrClose = ")]}\"'`>"
    private let scroll = UIScrollView()
    private let stack = UIView()
    private var heightC: NSLayoutConstraint?

    private var modeIdx = 0
    private var shiftState = 0            // 0 off, 1 one letter, 2 caps lock
    private var lastShiftTap = Date.distantPast
    private var buf = ""
    private var cands: [String] = []
    private var ipaLast: String?
    private var ipaAlts: [String] = []
    private var autoSpace = false
    private var repeatTimer: Timer?

    private var mode: Mode { return MODES[modeIdx] }

    /// English is used for the fields that need it (addresses, links, numbers).
    private var effectiveSC: Int {
        switch textDocumentProxy.keyboardType {
        case .some(.emailAddress), .some(.URL), .some(.numberPad), .some(.phonePad), .some(.decimalPad), .some(.twitter), .some(.webSearch), .some(.asciiCapable):
            return -1
        default:
            return mode.sc
        }
    }

    // MARK: setup

    override func viewDidLoad() {
        super.viewDidLoad()
        modeIdx = max(0, min(MODES.count - 1, UserDefaults.standard.integer(forKey: "sulekhak.mode")))
        view.backgroundColor = kbBackground

        bar.backgroundColor = dyn(UIColor(white: 0.90, alpha: 1), UIColor(white: 0.16, alpha: 1))
        view.addSubview(bar)

        romanLabel.font = UIFont.monospacedSystemFont(ofSize: 17, weight: .medium)
        romanLabel.textColor = accent
        romanLabel.textAlignment = .center
        bar.addSubview(romanLabel)

        surroundBtn.setTitle("( )", for: .normal)
        surroundBtn.titleLabel?.font = UIFont.monospacedSystemFont(ofSize: 15, weight: .semibold)
        surroundBtn.layer.cornerRadius = 8
        surroundBtn.accessibilityLabel = "Auto-surround: wrap selected text in brackets or quotes"
        surroundBtn.addTarget(self, action: #selector(surroundTapped), for: .touchUpInside)
        bar.addSubview(surroundBtn)
        styleSurroundBtn()

        scroll.showsHorizontalScrollIndicator = false
        bar.addSubview(scroll)
        scroll.addSubview(stack)

        view.addSubview(grid)
        grid.build(self, down: #selector(keyDown(_:)), up: #selector(keyUp(_:)))

        for row in grid.keys {
            for k in row where k.def.kind == .globe {
                k.removeTarget(self, action: #selector(keyDown(_:)), for: .touchDown)
                k.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)
            }
        }

        let h = view.heightAnchor.constraint(equalToConstant: keyboardHeight())
        h.priority = UILayoutPriority(999)
        h.isActive = true
        heightC = h

        applyMode()
    }

    private func rowHeight() -> CGFloat {
        return traitCollection.horizontalSizeClass == .regular ? 58 : 42
    }

    private func keyboardHeight() -> CGFloat {
        return 50 + 5 * rowHeight() + 6 * 6
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        heightC?.constant = keyboardHeight()
        let w = view.bounds.width, h = view.bounds.height
        bar.frame = CGRect(x: 0, y: 0, width: w, height: 50)
        romanLabel.frame = CGRect(x: 0, y: 0, width: 120, height: 50)
        surroundBtn.frame = CGRect(x: w - 48, y: 7, width: 42, height: 36)
        scroll.frame = CGRect(x: 120, y: 0, width: w - 172, height: 50)
        layoutStack()
        grid.frame = CGRect(x: 0, y: 50, width: w, height: h - 50)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        applyMode()
    }

    override func textDidChange(_ textInput: UITextInput?) {
        super.textDidChange(textInput)
        applyMode()
    }

    // MARK: modes

    private func applyMode() {
        let sc = effectiveSC
        if sc == 0 || sc == 1 || sc == 2 || sc == 5 { engine.setScript(sc) }
        refreshKeys()
        renderBar()
    }

    private func setMode(_ i: Int) {
        flush()
        modeIdx = i
        UserDefaults.standard.set(i, forKey: "sulekhak.mode")
        ipaLast = nil; ipaAlts = []
        applyMode()
    }

    private func refreshKeys() {
        let upper = shiftState > 0
        let sc = effectiveSC
        let indic = sc == 0 || sc == 1 || sc == 2 || sc == 5
        for row in grid.keys {
            for k in row {
                k.hint.text = ""
                k.icon.image = nil
                k.title.text = ""
                switch k.def.kind {
                case .char:
                    let isLetter = k.def.a.count == 1 && k.def.a.unicodeScalars.first!.properties.isAlphabetic
                    let t = upper ? k.def.b : k.def.a
                    k.title.text = t
                    k.title.font = UIFont.systemFont(ofSize: isLetter ? 22 : 19)
                    if indic && isLetter {
                        let first = engine.query(t).first ?? ""
                        if first != t { k.hint.text = first }
                    } else if indic && (t == "`" || t == ">" || t == "~") {
                        k.hint.text = (t == "`") ? "◌्" : (t == ">") ? "◌़" : "◌ँ"
                    }
                case .space:
                    k.title.text = sc == -1 ? "space" : mode.name
                    k.title.font = UIFont.systemFont(ofSize: 15)
                    k.title.textColor = UIColor.gray
                case .shift:
                    k.icon.image = UIImage(systemName: shiftState == 1 ? "shift.fill" : "shift")
                case .caps:
                    k.icon.image = UIImage(systemName: shiftState == 2 ? "capslock.fill" : "capslock")
                case .backspace:
                    k.icon.image = UIImage(systemName: "delete.left")
                case .ret:
                    k.title.text = "return"
                    k.title.font = UIFont.systemFont(ofSize: 16)
                case .tab:
                    k.icon.image = UIImage(systemName: "arrow.right.to.line")
                case .globe:
                    k.icon.image = UIImage(systemName: "globe")
                case .lang:
                    k.title.text = mode.native
                    k.title.font = UIFont.systemFont(ofSize: 17, weight: .semibold)
                    k.setBase(accent)
                    k.title.textColor = UIColor.white
                case .hide:
                    k.icon.image = UIImage(systemName: "keyboard.chevron.compact.down")
                }
                if k.def.kind != .char && k.def.kind != .space && k.def.kind != .lang { k.icon.tintColor = textColor }
                k.setNeedsLayout()
            }
        }
    }

    // MARK: the bar

    private func renderBar() {
        for v in stack.subviews { v.removeFromSuperview() }
        let sc = effectiveSC
        if sc == 4 && !ipaAlts.isEmpty {
            romanLabel.text = ipaLast ?? ""
            for (i, a) in ipaAlts.enumerated() { stack.addSubview(chip(a, tag: i, selected: false, action: #selector(ipaTapped(_:)))) }
        } else if !cands.isEmpty {
            romanLabel.text = buf
            for (i, c) in cands.enumerated() { stack.addSubview(chip(c, tag: i, selected: i == 0, action: #selector(candTapped(_:)))) }
        } else {
            romanLabel.text = sc == -1 ? "EN" : mode.name
        }
        layoutStack()
        scroll.setContentOffset(.zero, animated: false)
    }

    private func styleSurroundBtn() {
        let on = autoSurround
        surroundBtn.backgroundColor = on ? accent : dyn(UIColor.white, UIColor(white: 0.30, alpha: 1))
        surroundBtn.setTitleColor(on ? UIColor.white : textColor, for: .normal)
        surroundBtn.accessibilityValue = on ? "on" : "off"
    }

    @objc private func surroundTapped() {
        autoSurround.toggle()
        styleSurroundBtn()
    }

    /// With text selected, a typed ( [ { " ' ` or < wraps it instead of replacing it. Only the two marks are added: the text itself is handed back unchanged.
    private func surroundSelection(with c: String) -> Bool {
        guard autoSurround, buf.isEmpty, c.count == 1,
              let k = KeyboardViewController.surrOpen.firstIndex(of: Character(c)),
              let sel = textDocumentProxy.selectedText, !sel.isEmpty else { return false }
        let n = KeyboardViewController.surrOpen.distance(from: KeyboardViewController.surrOpen.startIndex, to: k)
        let close = KeyboardViewController.surrClose[KeyboardViewController.surrClose.index(KeyboardViewController.surrClose.startIndex, offsetBy: n)]
        textDocumentProxy.insertText(c + sel + String(close))
        autoSpace = false
        ipaAlts = []; ipaLast = nil
        renderBar()
        return true
    }

    private func chip(_ text: String, tag: Int, selected: Bool, action: Selector) -> UIButton {
        let b = UIButton(type: .custom)
        b.setTitle(text, for: .normal)
        b.titleLabel?.font = UIFont.systemFont(ofSize: 22)
        b.setTitleColor(selected ? UIColor.white : textColor, for: .normal)
        b.backgroundColor = selected ? accent : dyn(UIColor.white, UIColor(white: 0.30, alpha: 1))
        b.layer.cornerRadius = 8
        b.contentEdgeInsets = UIEdgeInsets(top: 4, left: 14, bottom: 4, right: 14)
        b.tag = tag
        b.addTarget(self, action: action, for: .touchUpInside)
        return b
    }

    private func layoutStack() {
        var x: CGFloat = 0
        for v in stack.subviews {
            let s = v.sizeThatFits(CGSize(width: 1000, height: 36))
            v.frame = CGRect(x: x, y: 7, width: max(44, s.width), height: 36)
            x += max(44, s.width) + 8
        }
        stack.frame = CGRect(x: 0, y: 0, width: x, height: 50)
        scroll.contentSize = CGSize(width: x, height: 50)
    }

    @objc private func candTapped(_ b: UIButton) { commit(b.tag, space: true) }

    @objc private func ipaTapped(_ b: UIButton) {
        guard b.tag < ipaAlts.count else { return }
        let alt = ipaAlts[b.tag]
        if let last = ipaLast { for _ in 0..<last.count { textDocumentProxy.deleteBackward() } }
        textDocumentProxy.insertText(alt)
        ipaLast = alt
    }

    // MARK: keys

    @objc private func keyDown(_ k: KeyView) {
        switch k.def.kind {
        case .char:
            let t = shiftState > 0 ? k.def.b : k.def.a
            typeChar(t)
            if shiftState == 1 { shiftState = 0; refreshKeys() }
        case .space: doSpace()
        case .backspace:
            doBackspace()
            repeatTimer?.invalidate()
            repeatTimer = Timer.scheduledTimer(withTimeInterval: 0.45, repeats: false) { [weak self] _ in
                self?.repeatTimer = Timer.scheduledTimer(withTimeInterval: 0.06, repeats: true) { _ in self?.doBackspace() }
            }
        case .ret: flush(); textDocumentProxy.insertText("\n"); autoSpace = false
        case .tab: flush(); textDocumentProxy.insertText("\t"); autoSpace = false
        case .shift:
            let now = Date()
            if shiftState == 1 && now.timeIntervalSince(lastShiftTap) < 0.4 { shiftState = 2 }
            else { shiftState = shiftState == 0 ? 1 : 0 }
            lastShiftTap = now
            refreshKeys()
        case .caps:
            shiftState = shiftState == 2 ? 0 : 2
            refreshKeys()
        case .lang: setMode((modeIdx + 1) % MODES.count)
        case .hide: flush(); dismissKeyboard()
        case .globe: break
        }
    }

    @objc private func keyUp(_ k: KeyView) {
        if k.def.kind == .backspace { repeatTimer?.invalidate(); repeatTimer = nil }
    }

    // MARK: typing

    private func isBufferChar(_ c: String) -> Bool {
        guard c.count == 1, let u = c.unicodeScalars.first else { return false }
        if (u.value >= 65 && u.value <= 90) || (u.value >= 97 && u.value <= 122) { return true }
        return c == "`" || c == ">" || c == "~" || c == "'" || c == "."
    }

    private func isDots(_ s: String) -> Bool {
        return !s.isEmpty && s.allSatisfy { $0 == "." }
    }

    private func typeChar(_ c: String) {
        if surroundSelection(with: c) { return }
        let sc = effectiveSC
        if sc == -1 { insert(c); return }
        if sc == 4 {
            insert(c)
            let all = engine.phonetic(c)
            ipaAlts = Array(all.dropFirst())
            ipaLast = c
            renderBar()
            return
        }
        // Indic modes: the roman letters collect in the bar, the word is put in on space
        if !isBufferChar(c) { flush(); insertPunct(c); return }
        if c == ">" && buf.isEmpty {
            insert(sc == 1 ? "\u{093C}" : (sc == 2 || sc == 5) ? "\u{09BC}" : "\u{0B3C}")
            return
        }
        if c == "." {
            if !isDots(buf) { flush() }
        } else if isDots(buf) {
            flush()
        }
        buf += c
        autoSpace = false
        refreshCandidates()
    }

    private func insertPunct(_ c: String) {
        if autoSpace && ",;:!?)]}".contains(c) {
            if let b = textDocumentProxy.documentContextBeforeInput, b.hasSuffix(" ") { textDocumentProxy.deleteBackward() }
        }
        insert(c)
    }

    private func insert(_ s: String) {
        textDocumentProxy.insertText(s)
        autoSpace = false
        ipaAlts = []; ipaLast = nil
        if effectiveSC != 4 { renderBar() }
    }

    private func refreshCandidates() {
        cands = buf.isEmpty ? [] : engine.query(buf)
        renderBar()
    }

    private func hasNonASCII(_ s: String) -> Bool {
        return s.unicodeScalars.contains { $0.value > 127 }
    }

    private func commit(_ idx: Int, space: Bool) {
        guard !buf.isEmpty else { return }
        let roman = buf
        let word = idx >= 0 && idx < cands.count ? cands[idx] : roman
        textDocumentProxy.insertText(word + (space ? " " : ""))
        autoSpace = space
        if idx != 1 && hasNonASCII(word) && !isDots(roman) {
            engine.commit(roman: roman, word: word)
        }
        buf = ""; cands = []
        renderBar()
    }

    private func flush() {
        if !buf.isEmpty { commit(0, space: false) }
    }

    private func doSpace() {
        if effectiveSC == 4 { insert(" "); return }
        if !buf.isEmpty { commit(0, space: true); return }
        insert(" ")
    }

    private func doBackspace() {
        autoSpace = false
        if !buf.isEmpty {
            buf.removeLast()
            if buf.isEmpty { cands = []; renderBar() } else { refreshCandidates() }
        } else {
            ipaAlts = []; ipaLast = nil
            textDocumentProxy.deleteBackward()
            if effectiveSC == 4 { renderBar() }
        }
    }
}
