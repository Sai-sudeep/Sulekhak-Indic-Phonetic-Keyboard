import Foundation

/// What the English typing needs from the text field.
protocol EnglishDoc: AnyObject {
    func insert(_ s: String)
    func deleteBackward(_ n: Int)
    /// up to n characters before the cursor
    func before(_ n: Int) -> String
}

/// English typing with suggestions: the letters go into the text as they are typed (so the person sees them), the suggestions are offered in the bar,
/// Space puts in the first one (this is how a misspelling like "teh" becomes "the"), and Backspace straight after such a correction gives back what was typed.
/// The same rules as the English typing of the Mac and Windows apps. Platform-free, so that CI can run it against a plain string.
final class EnglishTyper {
    weak var doc: EnglishDoc?
    /// typed letters, previous word -> the suggestion list (nil while the word lists load)
    var query: (String, String) -> (list: [String], auto: Bool)? = { _, _ in nil }
    /// typed, word, previous, how (typed | auto | pick | revert), the word that was passed over
    var learn: (String, String, String, String, String) -> Void = { _, _, _, _, _ in }
    var onChange: () -> Void = {}
    /// the words that usually follow a word ("<s>" at the start of a sentence), best first; nil or empty: none to offer
    var next: (String) -> [String]? = { _ in nil }
    /// switched on by the keyboard: offer the next word after a word and a space
    var offerNext = false
    /// the offered next words (shown as chips; cleared by the next key)
    private(set) var nextWords: [String] = []
    /// capital letter at the start of a sentence and for the word I; curly quotes and apostrophes, — for -- and … for ... (the keyboard switches them on; they are off here so that plain tests stay plain)
    var capitalise = false
    var smart = false

    private(set) var buf = ""               // the word being typed, as it stands in the text (letters and apostrophes)
    private(set) var cands: [String] = []   // the suggestions for it; cands[0] is what Space takes
    private(set) var prev = "<s>"           // the word before, lower case; "<s>" at the start of a sentence
    private struct Fix { let typed: String; let word: String; let tail: String; let prev: String }
    private var last: Fix?                  // a correction made by Space, which Backspace can take back

    private static func isApos(_ c: Character) -> Bool { return c == "'" || c == "\u{2019}" }
    static func isLetter(_ c: String) -> Bool {
        guard c.count == 1, let u = c.unicodeScalars.first else { return false }
        return (u.value >= 65 && u.value <= 90) || (u.value >= 97 && u.value <= 122)
    }
    static func isApostrophe(_ c: String) -> Bool { return c.count == 1 && isApos(c.first!) }

    private func split() -> (core: String, tail: String) {      // a closing quote at the end is not part of the word
        var core = buf
        var tail = ""
        while let l = core.last, EnglishTyper.isApos(l) { tail = String(l) + tail; core.removeLast() }
        return (core, tail)
    }

    private func refresh() {
        let (core, _) = split()
        if core.isEmpty { cands = [buf] } else if let r = query(core, prev), !r.list.isEmpty { cands = r.list } else { cands = [core] }
        onChange()
    }

    /// is the word we think is in the text really there? (the cursor may have been moved, or the field changed)
    private func inSync() -> Bool {
        if buf.isEmpty { return true }
        return doc?.before(buf.count) == buf
    }

    private func forget() { buf = ""; cands = []; last = nil }

    private func hideNext() { if !nextWords.isEmpty { nextWords = [] } }
    private func showNext() {
        nextWords = []
        guard offerNext, !prev.isEmpty, let l = next(prev), !l.isEmpty else { return }
        nextWords = Array(l.prefix(6))
    }
    /// a next word was tapped: it goes in with a space, and the words that follow it are offered
    func acceptNext(_ i: Int) {
        guard let d = doc, i >= 0, i < nextWords.count, buf.isEmpty else { return }
        var w = nextWords[i]
        if capitalise && prev == "<s>", let f = w.unicodeScalars.first, f.value >= 97 && f.value <= 122 { w = w.prefix(1).uppercased() + w.dropFirst() }
        if capitalise { w = EnglishTyper.capitalI(w) }
        if smart { w = w.replacingOccurrences(of: "'", with: "\u{2019}") }
        let before = prev
        d.insert(w + " ")
        let straight = w.replacingOccurrences(of: "\u{2019}", with: "'")
        learn(straight, straight, before, "next", "")
        prev = straight.lowercased()
        last = nil
        showNext()
        onChange()
    }

    // ---- capital letters and curly punctuation
    private static let abbreviations: Set<String> = ["mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "vs", "etc", "e.g", "i.e", "no", "fig", "eq", "approx", "dept", "est", "inc", "ltd", "co", "mt", "ft", "vol", "pp", "p", "a.m", "p.m", "u.s", "u.k"]
    private func endsWithAbbreviation(_ chars: [Character]) -> Bool {
        var b = chars.count
        while b > 0, chars[b - 1].isLetter || chars[b - 1] == "." { b -= 1 }
        return EnglishTyper.abbreviations.contains(String(chars[b...]).lowercased())
    }
    /// the next letter begins a sentence: the start of the text, a new line, or . ! ? … (closing quotes and brackets allowed) and a space
    private func sentenceStart() -> Bool {
        var chars = Array(doc?.before(60) ?? "")
        while let l = chars.last {                                   // an opening quote or bracket right before the letter does not hide the start behind it
            let openStraight = l == "\"" && (chars.count == 1 || chars[chars.count - 2] == " ")
            if l == "\u{201C}" || l == "\u{2018}" || l == "(" || l == "[" || openStraight { chars.removeLast() } else { break }
        }
        var n = chars.count
        if n == 0 { return true }
        var spaces = 0
        while n > 0, chars[n - 1].isWhitespace { if chars[n - 1].isNewline { return true }; n -= 1; spaces += 1 }
        if n == 0 { return true }
        if spaces == 0 { return false }
        while n > 0, "\"'\u{201D}\u{2019})]".contains(chars[n - 1]) { n -= 1 }
        if n == 0 { return false }
        let e = chars[n - 1]
        if e != "." && e != "!" && e != "?" && e != "\u{2026}" { return false }
        if e == "." && !(n >= 2 && chars[n - 2] == ".") && endsWithAbbreviation(Array(chars[0..<(n - 1)])) { return false }
        return true
    }
    private func openContext() -> Bool {
        guard let c = doc?.before(1).first else { return true }
        return c.isWhitespace || "([{\u{2014}\u{2013}\u{201C}\u{2018}/-".contains(c)
    }
    private static func capitalI(_ w: String) -> String {
        let l = w.replacingOccurrences(of: "\u{2019}", with: "'").lowercased()
        if l == "i" || l == "i'm" || l == "i'll" || l == "i've" || l == "i'd" { return "I" + String(w.dropFirst()) }
        return w
    }
    /// how a finished word and its closing apostrophes stand in the text
    private func finalForm(_ word: String, _ tail: String) -> (String, String) {
        var w = word, t = tail
        if capitalise { w = EnglishTyper.capitalI(w) }
        if smart { w = w.replacingOccurrences(of: "'", with: "\u{2019}"); t = t.replacingOccurrences(of: "'", with: "\u{2019}") }
        return (w, t)
    }

    /// a letter, or an apostrophe inside a word
    func type(_ c: String) {
        guard let d = doc else { return }
        last = nil
        hideNext()
        if !buf.isEmpty && !inSync() { buf = ""; cands = [] }
        var ch = c
        if buf.isEmpty && capitalise && ch.count == 1, let u = ch.unicodeScalars.first, u.value >= 97 && u.value <= 122, sentenceStart() { ch = ch.uppercased() }
        d.insert(ch)
        buf += ch
        refresh()
    }

    /// the word as it stands is final (a digit, a mark, Return, the keyboard going away): learn it, change nothing in the text
    func finish() {
        guard !buf.isEmpty else { return }
        let (core, tail) = split()
        if (capitalise || smart), let d = doc, !core.isEmpty {                       // a lone i becomes I, apostrophes become curly
            let (fw, ft) = finalForm(core, tail)
            if fw + ft != buf && inSync() { d.deleteBackward(buf.count); d.insert(fw + ft) }
        }
        if !core.isEmpty { learn(core, core, prev, "typed", "") }
        if !core.isEmpty { prev = core.lowercased() }
        forget()
        onChange()
    }

    /// any other character (a digit, a mark): the word first, then the character
    func other(_ c: String) {
        guard let d = doc else { return }
        hideNext()
        finish()
        last = nil
        if smart {
            if c == "\"" || c == "'" {
                let open = openContext()
                d.insert(c == "\"" ? (open ? "\u{201C}" : "\u{201D}") : (open ? "\u{2018}" : "\u{2019}"))
                if c == "\"" { prev = "" }
                onChange(); return
            }
            if c == "-" && d.before(1) == "-" { d.deleteBackward(1); d.insert("\u{2014}"); onChange(); return }
            if c == "." && d.before(2) == ".." { d.deleteBackward(2); d.insert("\u{2026}"); prev = "<s>"; onChange(); return }
        }
        d.insert(c)
        if c == "." || c == "!" || c == "?" { prev = "<s>" } else if !EnglishTyper.isApostrophe(c) { prev = "" }
        onChange()
    }

    /// Return: the word, then the line break (which the caller inserts)
    func enter() { hideNext(); finish(); last = nil; prev = "<s>"; onChange() }

    func space() {
        guard let d = doc else { return }
        hideNext()
        if buf.isEmpty { last = nil; d.insert(" "); if prev == "<s>" { showNext() }; onChange(); return }
        if !inSync() { forget(); d.insert(" "); onChange(); return }
        let (core, tail) = split()
        var word = core
        if !core.isEmpty, let first = cands.first { word = first }
        let corrected = word != core
        let prevBefore = prev
        let (fw, ft) = finalForm(word, tail)
        if corrected || fw + ft != buf {
            d.deleteBackward(buf.count)
            d.insert(fw + ft + " ")
        } else {
            d.insert(" ")
        }
        if !core.isEmpty {
            let passed = (!cands.isEmpty && cands[0] != word && cands[0] != core) ? cands[0] : ""
            learn(core, word, prevBefore, corrected ? "auto" : "typed", passed)
            prev = word.lowercased()
        }
        last = corrected ? Fix(typed: core, word: fw, tail: ft + " ", prev: prevBefore) : nil
        buf = ""; cands = []
        showNext()
        onChange()
    }

    /// a suggestion was tapped: it replaces the word, a space follows
    func pick(_ i: Int) {
        guard let d = doc, !buf.isEmpty, i >= 0, i < cands.count else { return }
        if !inSync() { forget(); onChange(); return }
        let (core, tail) = split()
        let word = cands[i]
        let passed = (!cands.isEmpty && cands[0] != word && cands[0] != core) ? cands[0] : ""
        let (fw, ft) = finalForm(word, tail)
        if word != core || !tail.isEmpty || fw + ft != buf {
            d.deleteBackward(buf.count)
            d.insert(fw + ft + " ")
        } else {
            d.insert(" ")
        }
        if !core.isEmpty { learn(core, word, prev, "pick", passed); prev = word.lowercased() }
        last = nil
        buf = ""; cands = []
        showNext()
        onChange()
    }

    /// Backspace. true: handled here (the caller does nothing more); false: the caller deletes one character as usual.
    func backspace() -> Bool {
        guard let d = doc else { return false }
        if !nextWords.isEmpty { nextWords = []; onChange() }
        if !buf.isEmpty {
            if !inSync() { forget(); return false }
            d.deleteBackward(1)
            buf.removeLast()
            last = nil
            if buf.isEmpty { cands = []; onChange() } else { refresh() }
            return true
        }
        if let l = last {
            let cur = l.word + l.tail
            if d.before(cur.count) == cur {
                d.deleteBackward(cur.count)
                d.insert(l.typed + l.tail)
                learn(l.typed, l.typed, l.prev, "revert", l.word)
                prev = l.typed.lowercased()
                last = nil
                onChange()
                return true
            }
        }
        last = nil
        return false
    }

    /// the text changed under us (the cursor was moved, another field): drop a word that is no longer where we think
    func validate() { if !buf.isEmpty && !inSync() { forget(); onChange() } }

    /// the keyboard is closed or the field changed: no word is being typed any more
    func reset() { forget(); nextWords = []; prev = "<s>"; onChange() }
}
