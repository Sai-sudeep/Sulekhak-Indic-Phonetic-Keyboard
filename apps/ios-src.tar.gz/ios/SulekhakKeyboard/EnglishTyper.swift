import Foundation

/// What the English typing needs from the text field.
protocol EnglishDoc: AnyObject {
    func insert(_ s: String)
    func deleteBackward(_ n: Int)
    /// up to n characters before the cursor
    func before(_ n: Int) -> String
}

/// English typing with suggestions: the letters go into the text as they are typed (so the person sees them), the suggestions are offered in the bar,
/// Space puts in the first one (this is how a misspelling like "teh" becomes "the"), and Backspace straight after such a correction gives back what was typed.
/// The same rules as the English typing of the Mac and Windows apps. Platform-free, so that CI can run it against a plain string.
final class EnglishTyper {
    weak var doc: EnglishDoc?
    /// typed letters, previous word -> the suggestion list (nil while the word lists load)
    var query: (String, String) -> (list: [String], auto: Bool)? = { _, _ in nil }
    /// typed, word, previous, how (typed | auto | pick | revert), the word that was passed over
    var learn: (String, String, String, String, String) -> Void = { _, _, _, _, _ in }
    var onChange: () -> Void = {}

    private(set) var buf = ""               // the word being typed, as it stands in the text (letters and apostrophes)
    private(set) var cands: [String] = []   // the suggestions for it; cands[0] is what Space takes
    private(set) var prev = "<s>"           // the word before, lower case; "<s>" at the start of a sentence
    private struct Fix { let typed: String; let word: String; let tail: String; let prev: String }
    private var last: Fix?                  // a correction made by Space, which Backspace can take back

    private static func isApos(_ c: Character) -> Bool { return c == "'" || c == "\u{2019}" }
    static func isLetter(_ c: String) -> Bool {
        guard c.count == 1, let u = c.unicodeScalars.first else { return false }
        return (u.value >= 65 && u.value <= 90) || (u.value >= 97 && u.value <= 122)
    }
    static func isApostrophe(_ c: String) -> Bool { return c.count == 1 && isApos(c.first!) }

    private func split() -> (core: String, tail: String) {      // a closing quote at the end is not part of the word
        var core = buf
        var tail = ""
        while let l = core.last, EnglishTyper.isApos(l) { tail = String(l) + tail; core.removeLast() }
        return (core, tail)
    }

    private func refresh() {
        let (core, _) = split()
        if core.isEmpty { cands = [buf] } else if let r = query(core, prev), !r.list.isEmpty { cands = r.list } else { cands = [core] }
        onChange()
    }

    /// is the word we think is in the text really there? (the cursor may have been moved, or the field changed)
    private func inSync() -> Bool {
        if buf.isEmpty { return true }
        return doc?.before(buf.count) == buf
    }

    private func forget() { buf = ""; cands = []; last = nil }

    /// a letter, or an apostrophe inside a word
    func type(_ c: String) {
        guard let d = doc else { return }
        last = nil
        if !buf.isEmpty && !inSync() { buf = ""; cands = [] }
        d.insert(c)
        buf += c
        refresh()
    }

    /// the word as it stands is final (a digit, a mark, Return, the keyboard going away): learn it, change nothing in the text
    func finish() {
        guard !buf.isEmpty else { return }
        let (core, _) = split()
        if !core.isEmpty { learn(core, core, prev, "typed", "") }
        if !core.isEmpty { prev = core.lowercased() }
        forget()
        onChange()
    }

    /// any other character (a digit, a mark): the word first, then the character
    func other(_ c: String) {
        guard let d = doc else { return }
        finish()
        last = nil
        d.insert(c)
        if c == "." || c == "!" || c == "?" { prev = "<s>" } else if !EnglishTyper.isApostrophe(c) { prev = "" }
        onChange()
    }

    /// Return: the word, then the line break (which the caller inserts)
    func enter() { finish(); last = nil; prev = "<s>"; onChange() }

    func space() {
        guard let d = doc else { return }
        if buf.isEmpty { last = nil; d.insert(" "); onChange(); return }
        if !inSync() { forget(); d.insert(" "); onChange(); return }
        let (core, tail) = split()
        var word = core
        if !core.isEmpty, let first = cands.first { word = first }
        let corrected = word != core
        let prevBefore = prev
        if corrected {
            d.deleteBackward(buf.count)
            d.insert(word + tail + " ")
        } else {
            d.insert(" ")
        }
        if !core.isEmpty {
            let passed = (!cands.isEmpty && cands[0] != word && cands[0] != core) ? cands[0] : ""
            learn(core, word, prevBefore, corrected ? "auto" : "typed", passed)
            prev = word.lowercased()
        }
        last = corrected ? Fix(typed: core, word: word, tail: tail + " ", prev: prevBefore) : nil
        buf = ""; cands = []
        onChange()
    }

    /// a suggestion was tapped: it replaces the word, a space follows
    func pick(_ i: Int) {
        guard let d = doc, !buf.isEmpty, i >= 0, i < cands.count else { return }
        if !inSync() { forget(); onChange(); return }
        let (core, tail) = split()
        let word = cands[i]
        let passed = (!cands.isEmpty && cands[0] != word && cands[0] != core) ? cands[0] : ""
        if word != core || !tail.isEmpty {
            d.deleteBackward(buf.count)
            d.insert(word + tail + " ")
        } else {
            d.insert(" ")
        }
        if !core.isEmpty { learn(core, word, prev, "pick", passed); prev = word.lowercased() }
        last = nil
        buf = ""; cands = []
        onChange()
    }

    /// Backspace. true: handled here (the caller does nothing more); false: the caller deletes one character as usual.
    func backspace() -> Bool {
        guard let d = doc else { return false }
        if !buf.isEmpty {
            if !inSync() { forget(); return false }
            d.deleteBackward(1)
            buf.removeLast()
            last = nil
            if buf.isEmpty { cands = []; onChange() } else { refresh() }
            return true
        }
        if let l = last {
            let cur = l.word + l.tail
            if d.before(cur.count) == cur {
                d.deleteBackward(cur.count)
                d.insert(l.typed + l.tail)
                learn(l.typed, l.typed, l.prev, "revert", l.word)
                prev = l.typed.lowercased()
                last = nil
                onChange()
                return true
            }
        }
        last = nil
        return false
    }

    /// the text changed under us (the cursor was moved, another field): drop a word that is no longer where we think
    func validate() { if !buf.isEmpty && !inSync() { forget(); onChange() } }

    /// the keyboard is closed or the field changed: no word is being typed any more
    func reset() { forget(); prev = "<s>"; onChange() }
}
