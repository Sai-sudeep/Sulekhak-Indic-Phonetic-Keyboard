import Foundation
import JavaScriptCore

/// The language-model engine, in its own JavaScriptCore context: the same JavaScript as the web typist and the Android and Windows apps
/// (the word list with its Roman spellings, the spelling rules, a bigram and trigram language model, swipe decoding).
///
/// A keyboard extension may use very little memory, so this is built to be safe:
///  * nothing is loaded until the first letter is typed, and the two big binary files are memory-mapped (the system can drop their pages again), not copied;
///  * it is dropped on a memory warning and read again when it is next needed;
///  * if the system ever stops the keyboard while this is loading (too little memory), the next start notices, switches it off and the keyboard goes on with the
///    rule engine alone. Touch and hold the swipe button on the bar to switch it on again.
final class SmartEngine {
    static let shared = SmartEngine()

    private let queue = DispatchQueue(label: "sulekhak.smart", qos: .userInitiated)
    private var ctx: JSContext?
    private var broken = false
    private var swipeWarm = false
    private let defaults = UserDefaults.standard
    private let loadingKey = "sulekhak.smart.loading"
    private let offKey = "sulekhak.smart.off"
    private let wordsKey = "sulekhak.smart.words.v1"
    private let wordsMax = 600

    private init() {}

    /// False when the model has been switched off (a failed start) or its files are not in the app.
    var available: Bool { return !defaults.bool(forKey: offKey) && !broken }

    /// Switch it on again (touch and hold the swipe button).
    func reenable() {
        defaults.set(false, forKey: offKey)
        defaults.set(false, forKey: loadingKey)
        queue.async { [weak self] in self?.broken = false }
    }

    // MARK: loading (on `queue` only)

    private func ensure() -> JSContext? {
        if let c = ctx { return c }
        if broken || defaults.bool(forKey: offKey) { return nil }
        if defaults.bool(forKey: loadingKey) {
            // the last start never finished: the system stopped the keyboard for memory. Do not try again by itself.
            defaults.set(true, forKey: offKey)
            defaults.set(false, forKey: loadingKey)
            return nil
        }
        defaults.set(true, forKey: loadingKey)
        defaults.synchronize()
        let c = build()
        defaults.set(false, forKey: loadingKey)
        if c == nil { broken = true }
        ctx = c
        return c
    }

    /// A JavaScript ArrayBuffer over a memory-mapped file: no copy, and clean file pages do not count against the keyboard's memory.
    private func arrayBuffer(_ d: NSData, _ c: JSContext) -> JSValue? {
        let keep = Unmanaged.passRetained(d)
        let release: JSTypedArrayBytesDeallocator = { _, info in
            if let i = info { Unmanaged<NSData>.fromOpaque(i).release() }
        }
        var exc: JSValueRef? = nil
        guard let ref = JSObjectMakeArrayBufferWithBytesNoCopy(c.jsGlobalContextRef, UnsafeMutableRawPointer(mutating: d.bytes), d.length,
                                                                release, keep.toOpaque(), &exc) else {
            keep.release()
            return nil
        }
        return JSValue(jsValueRef: ref, in: c)
    }

    private func build() -> JSContext? {
        let bundle = Bundle(for: SmartEngine.self)
        guard let c = JSContext() else { return nil }
        c.exceptionHandler = { _, ex in NSLog("Sulekhak smart JS error: %@", ex?.toString() ?? "unknown") }

        func text(_ name: String, _ ext: String) -> String? {
            guard let u = bundle.url(forResource: name, withExtension: ext) else { return nil }
            return try? String(contentsOf: u, encoding: .utf8)
        }
        func mapped(_ name: String) -> JSValue? {
            guard let u = bundle.url(forResource: name, withExtension: "bin"),
                  let d = try? NSData(contentsOf: u, options: .alwaysMapped) else { return nil }
            return arrayBuffer(d, c)
        }

        for js in ["sulekhak", "ios_smart"] {
            guard let src = text(js, "js") else { NSLog("Sulekhak: missing %@.js", js); return nil }
            c.evaluateScript(src)
        }
        guard let cfg = text("sk_cfg", "json"), let lex = text("sk_lex", "txt"), let rom = text("sk_rom", "txt"),
              let clus = text("sk_clus", "txt"), let syU = text("sk_syl_uni", "txt"), let syB = text("sk_syl_bi", "txt"),
              let syC = text("sk_syl_chan", "txt"), let ng = mapped("sk_ng"), let idx = mapped("sk_idx"),
              let P = JSValue(newObjectIn: c) else {
            NSLog("Sulekhak: the language model files are not in the app")
            return nil
        }
        P.setValue(cfg, forProperty: "cfg")
        P.setValue(lex, forProperty: "lex")
        P.setValue(rom, forProperty: "rom")
        P.setValue(clus, forProperty: "clus")
        P.setValue(syU, forProperty: "syl_uni")
        P.setValue(syB, forProperty: "syl_bi")
        P.setValue(syC, forProperty: "syl_chan")
        P.setValue([ng], forProperty: "ng")
        P.setValue(idx, forProperty: "idx")
        let n = c.objectForKeyedSubscript("smLoad")?.call(withArguments: [P])?.toInt32() ?? 0
        guard n > 0 else { NSLog("Sulekhak: the language model did not load"); return nil }
        // the words the user has taken before count again
        for w in defaults.stringArray(forKey: wordsKey) ?? [] {
            c.objectForKeyedSubscript("smCommit")?.call(withArguments: [w])
        }
        return c
    }

    // MARK: questions (the answers come back on the main queue)

    /// The words for the letters typed so far, as JSON: [[word, "lex" | "conv"], ...]. Empty when there is no answer.
    func suggest(_ roman: String, prev: String, done: @escaping (String) -> Void) {
        queue.async { [weak self] in
            var out = ""
            if let c = self?.ensure(), let s = c.objectForKeyedSubscript("smSuggest")?.call(withArguments: [roman, prev])?.toString() { out = s }
            DispatchQueue.main.async { done(out) }
        }
    }

    /// The words that usually follow `prev`, as JSON: [word, ...].
    func next(prev: String, done: @escaping (String) -> Void) {
        queue.async { [weak self] in
            var out = ""
            if !prev.isEmpty, let c = self?.ensure(), let s = c.objectForKeyedSubscript("smNext")?.call(withArguments: [prev, 6])?.toString() { out = s }
            DispatchQueue.main.async { done(out) }
        }
    }

    /// spec: {"k":{letter:[x,y]},"p":[[x,y,ms],...]} in key widths. The answer: Odia words, best first.
    func swipe(spec: String, prev: String, done: @escaping ([String]) -> Void) {
        queue.async { [weak self] in
            var words: [String] = []
            if let me = self {
                // the first swipe builds the swipe index, which takes memory for a moment: it is guarded like the start-up
                let first = !me.swipeWarm
                if first, me.ctx != nil { me.defaults.set(true, forKey: me.loadingKey); me.defaults.synchronize() }
                if let c = me.ensure(),
                   let s = c.objectForKeyedSubscript("smSwipe")?.call(withArguments: [spec, prev, 8])?.toString(),
                   let d = s.data(using: .utf8),
                   let a = try? JSONSerialization.jsonObject(with: d) as? [String] {
                    words = a
                    me.swipeWarm = true
                }
                if first { me.defaults.set(false, forKey: me.loadingKey) }
            }
            DispatchQueue.main.async { done(words) }
        }
    }

    /// A word the user took (Odia): it counts for the next words and ranks higher next time. Kept on this device only.
    func commit(_ odiaWord: String) {
        guard !odiaWord.isEmpty else { return }
        queue.async { [weak self] in
            self?.ctx?.objectForKeyedSubscript("smCommit")?.call(withArguments: [odiaWord])
        }
        var l = defaults.stringArray(forKey: wordsKey) ?? []
        l.append(odiaWord)
        if l.count > wordsMax { l.removeFirst(l.count - wordsMax) }
        defaults.set(l, forKey: wordsKey)
    }

    /// On a memory warning the model goes; the next question reads it again.
    func unload() {
        queue.async { [weak self] in
            self?.ctx?.objectForKeyedSubscript("smUnload")?.call(withArguments: [])
            self?.ctx = nil
            self?.swipeWarm = false
        }
    }
}
