import UIKit
import UIKit.UIGestureRecognizerSubclass

/// Follows one finger that starts on a letter key and drags across the keys (swipe typing).
/// It begins only after the finger has moved a little, so an ordinary tap or a press-and-hold is never taken for a swipe.
final class SwipeRecognizer: UIGestureRecognizer {
    /// Is there a letter key at this point of the view?
    var canStart: ((CGPoint) -> Bool)?
    /// The finger path in the view's coordinates; the time is in milliseconds from the first touch.
    private(set) var points: [(x: CGFloat, y: CGFloat, ms: Int)] = []
    private(set) var startPoint = CGPoint.zero
    private var t0: TimeInterval = 0
    static let threshold: CGFloat = 22

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        guard let t = touches.first, let v = view else { state = .failed; return }
        if touches.count > 1 || numberOfTouches > 1 {
            if state == .possible { state = .failed }
            return
        }
        let p = t.location(in: v)
        guard canStart?(p) == true else { state = .failed; return }
        startPoint = p
        t0 = t.timestamp
        points = [(p.x, p.y, 0)]
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        guard let t = touches.first, let v = view, !points.isEmpty else { return }
        if numberOfTouches > 1 && state == .possible { state = .failed; return }
        let list = event.coalescedTouches(for: t) ?? [t]
        for q in list {
            let p = q.location(in: v)
            points.append((p.x, p.y, Int((q.timestamp - t0) * 1000)))
        }
        let p = t.location(in: v)
        switch state {
        case .possible:
            if hypot(p.x - startPoint.x, p.y - startPoint.y) >= SwipeRecognizer.threshold { state = .began }
        case .began, .changed:
            state = .changed
        default:
            break
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        if let t = touches.first, let v = view, !points.isEmpty {
            let p = t.location(in: v)
            points.append((p.x, p.y, Int((t.timestamp - t0) * 1000)))
        }
        state = (state == .began || state == .changed) ? .ended : .failed
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        state = (state == .began || state == .changed) ? .cancelled : .failed
    }

    override func reset() {
        // the path is read by the action while the state is .ended; clearing it here, after the action, is safe
        points = []
        startPoint = .zero
    }
}
