/* Sulekhak iOS keyboard: the engine host for JavaScriptCore (no DOM, no Worker). It is the rule engine plus the user's own memory,
   the same candidate order as the other apps when their language model is not loaded. Derived from ime.js. */
var window = this;
(function () {
  'use strict';
  var E = OdiaEngine;
  E.loadBuiltin();
  var SC = 0, OPT = 0;
  window.imeSetScript = function (sc, opt) { SC = (sc === 1 || sc === 2 || sc === 5) ? sc : 0; OPT = opt | 0; };
  function show(w) { if (!SC || !w) return w; try { return E.toScript(w, SC, OPT); } catch (e) { return w; } }
  function showList(odia, buf) {                /* the candidates as they are typed in the chosen script (Assamese: ৱ for v / w, ৎ beside ত্) */
    if (!SC) return odia;
    var D = [], O = [], i;
    for (i = 0; i < odia.length; i++) { D.push(show(odia[i])); O.push(odia[i]); }
    if (SC === 5 && E.asRefine) { try { return E.asRefine(buf, D, O).disp; } catch (e) {} }
    var seen = {}, out = [];
    for (i = 0; i < D.length; i++) { if (i === 1 || !seen[D[i]]) { seen[D[i]] = 1; out.push(D[i]); } }   /* slot 2 stays the typed text */
    return out;
  }
  function back(w) {                            /* what the host commits is in the chosen script; the memory and the dictionary are Odia */
    if (!w || !SC) return w;
    w = w.replace(/\u09CE/g, '\u0B24\u0B4D');
    try { return E.toOdia(w); } catch (e) { return w; }
  }

  var LR = {};                                  /* what the user has chosen before: typed roman -> Odia word (most recent wins) */
  var LRN = 0;
  function learn(roman, word) {
    if (!roman || !word) return;
    if (!(roman in LR)) LRN++;
    LR[roman] = word;
    if (LRN > 1500) { var n = 0; for (var k in LR) { delete LR[k]; LRN--; if (++n >= 300) break; } }
  }
  /* The smart engine reads Z as j and z as a plain letter, but in this scheme z is ZWNJ and Z is halant + ZWNJ,
     so a word that carries them is left to the rule engine. */
  function smartOK(buf) { return /^[A-Za-z]+$/.test(buf) && !/[zZ]/.test(buf); }

  function merge(od, r, buf) {                  /* slot 1 = a word chosen before, else the best smart word; slot 2 = the typed text */
    var O = [], seen = {}, i, L = LR[buf];
    function push(o) { if (o && !seen[o]) { seen[o] = 1; O.push(o); } }
    if (L) push(L);
    if (/[zZ]/.test(buf)) return od.slice();     /* z / Z: the engine's own order (the ZWNJ spelling, the typed text, the same without ZWNJ, with ZWJ, the rest) */
    if (r && r.length) { if (od.length && od[0].indexOf('\u200C') >= 0 && od[0].replace(/\u200C/g, '') === r[0][0].replace(/\u200C/g, '')) push(od[0]); push(r[0][0]); }     /* the dictionary's ZWNJ spelling beats the same word without ZWNJ */
    else if (od.length) push(od[0]);
    if (od.length > 1) { if (!seen[od[1]]) { O.push(od[1]); seen[od[1]] = 1; } }
    if (buf.length >= 2) {                      /* longer words the user typed before that start with these letters */
      var pre = [];
      for (var k in LR) if (k.length > buf.length && k.indexOf(buf) === 0) pre.push(k);
      pre.sort(function (x, y) { return x.length - y.length; });
      for (i = 0; i < pre.length && i < 2; i++) push(LR[pre[i]]);
    }
    if (r) for (i = 1; i < r.length; i++) push(r[i][0]);
    for (i = 0; i < od.length; i++) if (i !== 1) push(od[i]);
    var ty = od.length > 1 ? od[1] : null, ti = ty ? O.indexOf(ty) : -1;       /* the typed text always sits in slot 2 */
    if (ti > 1) { O.splice(ti, 1); O.splice(1, 0, ty); }
    return O;
  }

  this.iosSetScript = function (sc, opt) { SC = (sc === 1 || sc === 2 || sc === 5) ? sc : 0; OPT = opt | 0; };
  this.iosQuery = function (buf) {
    var old;
    try { old = E.candidatesIn(buf, SC, OPT).odia; } catch (e) { old = [buf]; }
    var out;
    try { out = showList(merge(old, null, buf), buf); } catch (e) { out = [buf]; }
    return JSON.stringify(out);
  };
  this.iosCommit = function (roman, word) {
    word = back(word);
    if (!word) return;
    try { if (roman) { E.lexAdd(roman, word, 3); learn(roman, word); } } catch (e) {}
  };
  this.iosReplay = function (json) {
    var arr = []; try { arr = JSON.parse(json); } catch (e) {}
    for (var i = 0; i < arr.length; i++) { try { var w = back(arr[i][1]); E.lexAdd(arr[i][0], w, 3); learn(arr[i][0], w); } catch (e) {} }
  };
  this.iosPhon = function (k) { try { return JSON.stringify(phCands(k)); } catch (e) { return JSON.stringify([k]); } };
}).call(this);
