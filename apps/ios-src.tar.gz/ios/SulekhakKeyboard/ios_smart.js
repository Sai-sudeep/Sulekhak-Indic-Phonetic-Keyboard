/* Sulekhak iPad / iPhone: the language-model engine in its own JavaScriptCore context (the same sulekhak.js as the web typist, Android and Windows):
   the word list with Roman spellings, the spelling rules, a bigram and trigram language model, and swipe (gesture) decoding.
   The host (SmartEngine.swift) calls smLoad once with the data (the two binary files are memory-mapped, not copied), then the other functions. */
var SMW = null;
function smLoad(P) {
  SMW = Sulekhak.create();
  SMW.engine.swipeWords = 70000;                      /* the swipe index covers the commonest 70,000 words (it is built on the first swipe) */
  SMW.load(P);
  return SMW.size;
}
function smSuggest(buf, prev) { return JSON.stringify(SMW ? SMW.suggest(buf, prev || '<s>', 4, 2) : []); }
function smSwipe(spec, prev, n) {
  var r = [];
  try { r = SMW ? SMW.swipe(JSON.parse(spec), prev || '<s>', n || 8) : []; } catch (e) { r = []; }
  return JSON.stringify(r.map(function (x) { return x[0]; }));
}
function smNext(prev, n) { return JSON.stringify(SMW && prev ? SMW.next(prev, n || 6) : []); }
function smCommit(w) { if (SMW && w) SMW.commit(w); }
function smUnload() { SMW = null; }
