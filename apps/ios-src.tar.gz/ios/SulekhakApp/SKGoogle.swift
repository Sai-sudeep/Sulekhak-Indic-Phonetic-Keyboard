#if SK_PERSONAL
import Foundation
import AuthenticationServices
import CryptoKit
import Security
import UIKit

/// Google sign-in for the private build (OAuth for iOS apps with PKCE; the iOS client has no secret) and the Drive sync of the learning history.
/// The keyboard has no network and no Full Access, so everything that talks to Google happens here, in the app, using the files the keyboard writes.
final class SKGoogle: NSObject, ObservableObject, ASWebAuthenticationPresentationContextProviding {
    static let shared = SKGoogle()

    @Published var email: String?
    @Published var busy = false
    @Published var message = ""
    @Published var syncLine = ""

    private var clientId = ""
    private(set) var allowed: [String] = []
    private var access: String?
    private var accessExp = Date.distantPast
    private var session: ASWebAuthenticationSession?
    private let service = "com.saisudeep.sulekhak.google"

    var configured: Bool { return !clientId.isEmpty }
    var signedIn: Bool { return email != nil && refreshToken() != nil }

    override init() {
        super.init()
        if let u = Bundle.main.url(forResource: "personal-config", withExtension: "json"),
           let d = try? Data(contentsOf: u),
           let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
            clientId = o["clientId"] as? String ?? ""
            allowed = (o["allowed"] as? [String] ?? []).map { $0.trimmingCharacters(in: .whitespaces).lowercased() }
        }
        email = readKeychain("email")
    }

    /// the host (JavaScript sync code) asks for a token, the app answers
    func start() {
        guard configured else { return }
        SKHost.shared.start(role: .app, allowed: allowed)
        SKHost.shared.tokenProvider = { [weak self] done in
            guard let me = self else { done(nil, 0, nil); return }
            me.accessToken { a, secs in done(a, secs, me.email) }
        }
        SKHost.shared.onStatus = { [weak self] state, detail in self?.show(state, detail) }
        SKHost.shared.onEveryDone = { [weak self] state, detail in self?.show(state, detail); self?.busy = false }
        SKHost.shared.onSignOutRequested = { [weak self] in self?.signOut() }
        if signedIn { syncNow() }
    }

    private func show(_ state: String, _ detail: String) {
        switch state {
        case "syncing": syncLine = "Syncing…"
        case "synced": syncLine = "Synced" + (detail.isEmpty ? "" : " at " + detail)
        case "error": syncLine = "Sync problem" + (detail.isEmpty ? "" : ": " + detail)
        case "refused": syncLine = "This account is not allowed."
        case "signed-out": syncLine = signedIn ? "Signed in" : ""
        case "signed-in": syncLine = "Signed in"
        default: break
        }
    }

    func syncNow() {
        guard signedIn else { return }
        busy = true
        accessToken { [weak self] a, secs in
            guard let me = self else { return }
            if let a = a {
                SKHost.shared.setToken(a, seconds: secs, email: me.email ?? "")
                SKHost.shared.syncEvery()
            } else {
                DispatchQueue.main.async { me.busy = false; me.message = "Signed out: please sign in again." }
            }
        }
    }

    // MARK: sign in

    private var redirectScheme: String { return "com.googleusercontent.apps." + clientId.replacingOccurrences(of: ".apps.googleusercontent.com", with: "") }
    private var redirectURI: String { return redirectScheme + ":/oauth2redirect" }

    private static func b64url(_ d: Data) -> String {
        return d.base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "")
    }
    private static func random(_ n: Int) -> Data {
        var b = [UInt8](repeating: 0, count: n)
        _ = SecRandomCopyBytes(kSecRandomDefault, n, &b)
        return Data(b)
    }
    private func enc(_ s: String) -> String {
        var ok = CharacterSet.alphanumerics
        ok.insert(charactersIn: "-._~")
        return s.addingPercentEncoding(withAllowedCharacters: ok) ?? ""
    }
    private func form(_ d: [String: String]) -> Data? {
        return d.map { enc($0.key) + "=" + enc($0.value) }.joined(separator: "&").data(using: .utf8)
    }

    func signIn() {
        guard configured, !busy else { return }
        busy = true; message = ""
        let verifier = SKGoogle.b64url(SKGoogle.random(48))
        let state = SKGoogle.b64url(SKGoogle.random(16))
        let challenge = SKGoogle.b64url(Data(SHA256.hash(data: Data(verifier.utf8))))
        let scope = "openid email https://www.googleapis.com/auth/drive.appdata"
        let url = "https://accounts.google.com/o/oauth2/v2/auth?client_id=\(enc(clientId))&redirect_uri=\(enc(redirectURI))&response_type=code&scope=\(enc(scope))&code_challenge=\(challenge)&code_challenge_method=S256&state=\(state)&access_type=offline&prompt=select_account%20consent"
        guard let u = URL(string: url) else { busy = false; return }
        let s = ASWebAuthenticationSession(url: u, callbackURLScheme: redirectScheme) { [weak self] cb, err in
            guard let me = self else { return }
            DispatchQueue.main.async {
                me.session = nil
                if let err = err {
                    me.busy = false
                    if (err as? ASWebAuthenticationSessionError)?.code != .canceledLogin { me.message = "Could not sign in: \(err.localizedDescription)" }
                    return
                }
                let items = cb.flatMap { URLComponents(url: $0, resolvingAgainstBaseURL: false)?.queryItems } ?? []
                func q(_ n: String) -> String? { return items.first { $0.name == n }?.value }
                guard q("state") == state else { me.busy = false; me.message = "The answer did not match the request."; return }
                if let e = q("error") { me.busy = false; me.message = "Google: " + e; return }
                guard let code = q("code") else { me.busy = false; me.message = "Google gave no code."; return }
                me.exchange(code: code, verifier: verifier)
            }
        }
        s.presentationContextProvider = self
        s.prefersEphemeralWebBrowserSession = false
        session = s
        if !s.start() { busy = false; message = "The sign-in page could not be opened." }
    }

    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        return scenes.flatMap { $0.windows }.first { $0.isKeyWindow } ?? ASPresentationAnchor()
    }

    private func tokenRequest(_ f: [String: String], done: @escaping ([String: Any]?, String) -> Void) {
        var r = URLRequest(url: URL(string: "https://oauth2.googleapis.com/token")!, timeoutInterval: 30)
        r.httpMethod = "POST"
        r.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        r.httpBody = form(f)
        URLSession.shared.dataTask(with: r) { d, resp, err in
            let st = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let o = d.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
            if st == 200, let o = o, o["access_token"] != nil { done(o, "") }
            else { done(nil, err?.localizedDescription ?? d.flatMap { String(data: $0, encoding: .utf8) } ?? "no answer") }
        }.resume()
    }

    private func emailFromIdToken(_ jwt: String) -> String? {
        let p = jwt.split(separator: ".")
        guard p.count >= 2 else { return nil }
        var s = String(p[1]).replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        while s.count % 4 != 0 { s += "=" }
        guard let d = Data(base64Encoded: s), let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return nil }
        if let v = o["email_verified"] as? Bool, !v { return nil }
        return (o["email"] as? String)?.lowercased()
    }

    private func exchange(code: String, verifier: String) {
        tokenRequest(["code": code, "client_id": clientId, "redirect_uri": redirectURI, "grant_type": "authorization_code", "code_verifier": verifier]) { [weak self] tok, err in
            DispatchQueue.main.async {
                guard let me = self else { return }
                guard let tok = tok else { me.busy = false; me.message = "Google did not accept the sign-in. " + err; return }
                let mail = (tok["id_token"] as? String).flatMap { me.emailFromIdToken($0) }
                guard let m = mail, me.allowed.contains(m) else {
                    if let a = tok["access_token"] as? String { me.revoke(a) }
                    me.busy = false
                    me.message = (mail ?? "That account") + " is not an authorised account for this app."
                    return
                }
                guard let r = tok["refresh_token"] as? String, !r.isEmpty else {
                    me.busy = false
                    me.message = "Google did not give a long-lived sign-in. Remove Sulekhak from your Google account's third-party access and try again."
                    return
                }
                me.writeKeychain("refresh", r); me.writeKeychain("email", m)
                me.email = m
                me.access = tok["access_token"] as? String
                me.accessExp = Date().addingTimeInterval(TimeInterval((tok["expires_in"] as? Int) ?? 3000))
                me.busy = false
                me.syncNow()
            }
        }
    }

    /// a valid access token (refreshing when it runs out): done(token, seconds) or done(nil, 0) when signed out
    func accessToken(_ done: @escaping (String?, Int) -> Void) {
        guard let r = refreshToken() else { done(nil, 0); return }
        if let a = access, accessExp.timeIntervalSinceNow > 120 { done(a, Int(accessExp.timeIntervalSinceNow)); return }
        tokenRequest(["client_id": clientId, "refresh_token": r, "grant_type": "refresh_token"]) { [weak self] tok, err in
            DispatchQueue.main.async {
                guard let me = self else { return }
                guard let tok = tok, let a = tok["access_token"] as? String else {
                    if err.contains("invalid_grant") { me.forget() }          // expired (Google ends test-mode sign-ins after 7 days) or revoked
                    done(nil, 0); return
                }
                let secs = (tok["expires_in"] as? Int) ?? 3000
                me.access = a; me.accessExp = Date().addingTimeInterval(TimeInterval(secs))
                done(a, secs)
            }
        }
    }

    private func revoke(_ token: String) {
        var r = URLRequest(url: URL(string: "https://oauth2.googleapis.com/revoke")!)
        r.httpMethod = "POST"
        r.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        r.httpBody = form(["token": token])
        URLSession.shared.dataTask(with: r) { _, _, _ in }.resume()
    }

    private func forget() {
        access = nil; accessExp = .distantPast
        deleteKeychain("refresh"); deleteKeychain("email")
        email = nil
        syncLine = ""
        SKHost.shared.signedOut()
    }

    func signOut() {
        if let r = refreshToken() { revoke(r) }
        forget()
    }

    // MARK: Keychain (the refresh token never leaves this app)

    private func query(_ key: String) -> [String: Any] {
        return [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: key]
    }
    private func readKeychain(_ key: String) -> String? {
        var q = query(key)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess, let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }
    private func writeKeychain(_ key: String, _ value: String) {
        deleteKeychain(key)
        var q = query(key)
        q[kSecValueData as String] = Data(value.utf8)
        q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(q as CFDictionary, nil)
    }
    private func deleteKeychain(_ key: String) { SecItemDelete(query(key) as CFDictionary) }
    private func refreshToken() -> String? { return readKeychain("refresh") }
}
#endif
