import SwiftUI

@main
struct SulekhakApp: App {
    @Environment(\.scenePhase) private var scenePhase

    init() {
        #if SK_PERSONAL
        SKGoogle.shared.start()
        #endif
    }

    var body: some Scene {
        WindowGroup { ContentView() }
            .onChange(of: scenePhase) { phase in
                #if SK_PERSONAL
                if phase == .active { SKGoogle.shared.syncNow() }        // the keyboard has no network: whatever it learned is synced when the app is opened
                #endif
            }
    }
}

#if SK_PERSONAL
/// Sign in with Google and keep the learned words in step with the other devices.
struct AccountBox: View {
    @ObservedObject private var g = SKGoogle.shared

    var body: some View {
        GroupBox(label: Text("Sign in and sync")) {
            VStack(alignment: .leading, spacing: 8) {
                if !g.configured {
                    Text("Sign-in is not set up in this build.").font(.footnote).foregroundColor(.secondary)
                } else if let mail = g.email {
                    Text("Signed in as \(mail)")
                    if !g.syncLine.isEmpty { Text(g.syncLine).font(.footnote).foregroundColor(.secondary) }
                    HStack {
                        Button("Sync now") { g.syncNow() }.buttonStyle(.bordered).disabled(g.busy)
                        Button("Sign out") { g.signOut() }.buttonStyle(.bordered)
                    }
                } else {
                    Text("Your chosen words (Odia, Hindi, Marathi, Bangla, Assamese and English) are kept in your own Google Drive and shared with your other devices.")
                        .font(.footnote).foregroundColor(.secondary)
                    Button(action: { g.signIn() }) {
                        Text("Sign in with Google").frame(maxWidth: .infinity).padding(.vertical, 8)
                    }
                    .buttonStyle(.borderedProminent).disabled(g.busy)
                }
                if !g.message.isEmpty { Text(g.message).font(.footnote).foregroundColor(.red) }
                Text(SKShared.isShared
                     ? "The keyboard and this app share their storage: what you type is synced."
                     : "The keyboard and this app cannot share storage in this install (App Groups are off), so what the keyboard learns stays on the keyboard and is not synced.")
                    .font(.footnote).foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, 6)
        }
    }
}
#endif

struct ContentView: View {
    @State private var text = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("Sulekhak")
                    .font(.system(size: 38, weight: .bold))
                Text("Phonetic keyboard for Odia, Devanagari, Assamese, Bangla and IPA, and an English keyboard with suggestions and spelling correction. Type with English letters, get the word in your script, in every app.")
                    .foregroundColor(.secondary)

                GroupBox(label: Text("Turn the keyboard on")) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Open Settings > General > Keyboard > Keyboards.")
                        Text("2. Tap Add New Keyboard and choose Sulekhak.")
                        Text("3. In any app, touch and hold the globe key and pick Sulekhak.")
                        Text("It does not ask for Full Access. It never sends what you type anywhere.")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 6)
                }

                Button(action: openSettings) {
                    Text("Open Settings")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)

                #if SK_PERSONAL
                AccountBox()
                #endif

                GroupBox(label: Text("Try it here")) {
                    TextEditor(text: $text)
                        .frame(minHeight: 170)
                }

                GroupBox(label: Text("How it types")) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Type namaskar, then press space: the first word is put in. Tap another word in the bar to choose it. The keyboard remembers the words you choose.")
                        Text("z is the zero-width non-joiner, Z is halant and a non-joiner, the backtick is the halant, > is the nukta, ~ is the chandrabindu.")
                        Text("The key at the bottom left switches the language: Odia, Devanagari, Assamese, Bangla, IPA, English.")
                        Text("English: the word you are typing stays in the text, the bar offers completions and corrections. Space takes the first one (teh becomes the); Backspace right after puts back what you typed. Words you choose or type often are remembered.")
                        Text("Auto-surround: select some text and type ( [ { \" ' ` or < to wrap it, for example (hello). The ( ) button at the right of the bar switches it on or off.")
                    }
                    .font(.footnote)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 6)
                }
            }
            .padding(20)
        }
    }

    private func openSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
}
