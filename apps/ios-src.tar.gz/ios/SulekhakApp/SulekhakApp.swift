import SwiftUI

@main
struct SulekhakApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct ContentView: View {
    @State private var text = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("Sulekhak")
                    .font(.system(size: 38, weight: .bold))
                Text("Phonetic keyboard for Odia, Devanagari, Assamese, Bangla and IPA. Type with English letters, get the word in your script, in every app.")
                    .foregroundColor(.secondary)

                GroupBox(label: Text("Turn the keyboard on")) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Open Settings > General > Keyboard > Keyboards.")
                        Text("2. Tap Add New Keyboard and choose Sulekhak.")
                        Text("3. In any app, touch and hold the globe key and pick Sulekhak.")
                        Text("It does not ask for Full Access. It never sends what you type anywhere.")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 6)
                }

                Button(action: openSettings) {
                    Text("Open Settings")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)

                GroupBox(label: Text("Try it here")) {
                    TextEditor(text: $text)
                        .frame(minHeight: 170)
                }

                GroupBox(label: Text("How it types")) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Type namaskar, then press space: the first word is put in. Tap another word in the bar to choose it. The keyboard remembers the words you choose.")
                        Text("z is the zero-width non-joiner, Z is halant and a non-joiner, the backtick is the halant, > is the nukta, ~ is the chandrabindu.")
                        Text("The key at the bottom left switches the language: Odia, Devanagari, Assamese, Bangla, IPA, English.")
                    }
                    .font(.footnote)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 6)
                }
            }
            .padding(20)
        }
    }

    private func openSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
}
