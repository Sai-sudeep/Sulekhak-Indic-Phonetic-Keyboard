/* Sulekhak candidate engine - JavaScript twin of sulekhak_engine.py (works in browsers, node and JavaScriptCore).
   var S = Sulekhak.create(); S.load({cfg, lex, rom, big, clus, syl_uni, syl_bi, syl_chan});   // each a string (cfg a string too)
   S.suggest('prajak', prevWord, nLex, nConv) -> [[word,'lex'|'conv'], ...]       S.commit(word)        S.dumpCache() / S.loadCache(obj) */
var Sulekhak=(function(){
'use strict';
var HAL='\u0B4D';
var CLRE=new RegExp('[\u0B15-\u0B39\u0B5C\u0B5D\u0B5F\u0B71](?:'+HAL+'[\u0B15-\u0B39\u0B5C\u0B5D\u0B5F\u0B71])+','g');
function clusters(w){return w.match(CLRE)||[]}
/* ---- fuzzy Roman keys (same rules as the Python reference) ---- */
var TR={c:'k',q:'k',f:'p',v:'b',w:'b',z:'j'};
var CONS_H={b:1,c:1,d:1,f:1,g:1,j:1,k:1,l:1,m:1,n:1,p:1,r:1,s:1,t:1,v:1,w:1,x:1,y:1,z:1,'\u010d':1};
var NASAL_BEFORE={b:1,p:1,k:1,g:1,j:1,t:1,d:1,'\u010d':1};
function k1(s){
  s=s.toLowerCase();
  var n=s.length,i,c,o=[],j;
  /* ch / chh -> c-caron ; ee -> i ; oo -> u */
  for(i=0;i<n;i++){
    c=s.charAt(i);
    if(c==='c'&&s.charAt(i+1)==='h'){o.push('\u010d');i+=(s.charAt(i+2)==='h')?2:1}
    else o.push(c);
  }
  var p=[];
  for(i=0;i<o.length;i++){
    c=o[i];
    if((c==='e'||c==='o')&&o[i+1]===c){p.push(c==='e'?'i':'u');i++}
    else p.push(c);
  }
  /* collapse runs of the same letter */
  var q=[];
  for(i=0;i<p.length;i++){c=p[i];if(i>0&&c===p[i-1]&&((c>='a'&&c<='z')||c==='\u010d'))continue;q.push(c)}
  /* drop h after a consonant (tested on the string before dropping) */
  var r=[];
  for(i=0;i<q.length;i++){c=q[i];if(c==='h'&&i>0&&CONS_H[q[i-1]]===1)continue;r.push(c)}
  /* m before a stop -> n ; c q f v w z mapped ; x -> ks */
  var out='';
  for(i=0;i<r.length;i++){
    c=r[i];
    if(c==='m'&&NASAL_BEFORE[r[i+1]]===1)out+='n';
    else if(c==='c'||c==='q')out+='k';
    else if(c==='f')out+='p';
    else if(c==='v'||c==='w')out+='b';
    else if(c==='z')out+='j';
    else if(c==='x')out+='ks';
    else out+=c;
  }
  return out;
}
function k1_regex(s){
  s=s.toLowerCase().replace(/chh/g,'\u010d').replace(/ch/g,'\u010d');
  s=s.replace(/ee/g,'i').replace(/oo/g,'u');
  s=s.replace(/([a-z\u010d])\1+/g,'$1');
  s=s.replace(/([bcdfgjklmnprstvwxyz\u010d])h/g,'$1');
  s=s.replace(/m(?=[bpkgjtd\u010d])/g,'n');
  s=s.replace(/[cqfvwz]/g,function(c){return TR[c]}).replace(/x/g,'ks');
  return s;
}
function k2from(k){return k.charAt(0)+k.slice(1).replace(/a/g,'')}
function k2(s){return k2from(k1(s))}
function tkeys(t,f){
  var out=[f(t)],e;
  if(/c$/.test(t)){e=f(t.slice(0,-1)+'ch');if(out.indexOf(e)<0)out.push(e)}
  if(/e$/.test(t)){e=f(t.slice(0,-1)+'ee');if(out.indexOf(e)<0)out.push(e)}
  if(/o$/.test(t)){e=f(t.slice(0,-1)+'oo');if(out.indexOf(e)<0)out.push(e)}
  return out;
}
function alpha(r){return r.toLowerCase().replace(/[^a-z]/g,'')}
function startsWith(s,p){return s.length>=p.length&&s.lastIndexOf(p,0)===0}
function lines(s,keep){var a=s.length?s.split('\n'):[];if(!keep&&a.length&&a[a.length-1]==='')a.pop();return a}
var ALPHA='abcdefghijklmnopqrstuvwxyz';
function edit1(t){
  var v={},i,c,L=t.length;
  for(i=0;i<L;i++){
    v[t.slice(0,i)+t.slice(i+1)]=1;
    if(i+1<L&&t.charAt(i)!==t.charAt(i+1))v[t.slice(0,i)+t.charAt(i+1)+t.charAt(i)+t.slice(i+2)]=1;
    for(c=0;c<26;c++)if(ALPHA.charAt(c)!==t.charAt(i))v[t.slice(0,i)+ALPHA.charAt(c)+t.slice(i+1)]=1;
  }
  for(i=0;i<=L;i++)for(c=0;c<26;c++)v[t.slice(0,i)+ALPHA.charAt(c)+t.slice(i)]=1;
  delete v[t];delete v[''];
  return Object.keys(v);
}
function ed1(a,b){                      /* Damerau-Levenshtein distance <= 1 (insert, delete, substitute, adjacent swap) */
  var la=a.length,lb=b.length;
  if(Math.abs(la-lb)>1)return false;
  var i=0;while(i<la&&i<lb&&a.charAt(i)===b.charAt(i))i++;
  if(i===la||i===lb)return true;
  if(la===lb){
    if(a.slice(i+1)===b.slice(i+1))return true;
    if(i+1<la&&a.charAt(i)===b.charAt(i+1)&&a.charAt(i+1)===b.charAt(i)&&a.slice(i+2)===b.slice(i+2))return true;
    return false;
  }
  if(la<lb)return a.slice(i)===b.slice(i+1);
  return a.slice(i+1)===b.slice(i);
}
/* ---- the user's memory: recency-decayed counts of committed words ---- */
function Cache(tau){this.tau=tau||100;this.t=0;this.M=0;this.v={};this.last={}}
Cache.prototype.p=function(w){var x=this.v[w];return !x?0:x*Math.exp(-(this.t-this.last[w])/this.tau)/Math.max(this.M,1e-9)};
Cache.prototype.commit=function(w){
  this.t++;this.M=this.M*Math.exp(-1/this.tau)+1;
  var x=this.v.hasOwnProperty(w)?this.v[w]*Math.exp(-(this.t-1-this.last[w])/this.tau):0;
  this.v[w]=x+1;this.last[w]=this.t;
};
Cache.prototype.dump=function(){return {tau:this.tau,t:this.t,M:this.M,v:this.v,last:this.last}};
Cache.load=function(o){var c=new Cache(o.tau);c.t=o.t;c.M=o.M;c.v=o.v;c.last=o.last;return c};

function create(){
  var S={ready:false}, cfg, words, u, N, wid, romLines, romC, T, clv, bigText, bigIdx, bigC, foll, cache;
  var clp={}, k1c={}, k2c={}, suni, sU, sbi, stot, EX, FZ, maxL, cl, R2=false;
  /* The romanisation table writes a chandrabindu as '~' (keu~ = କେଉଁ), but typists write it as n / m / ng (keun, keum) or leave it out.
     The matching channel must accept what people actually type, so every spelling with '~' also stands for the same spelling with
     n, m, ng or nothing in that place. (Before this, 'keun' could not reach କେଉଁ at all and drifted to unrelated words.) */
  function roms(i){var r=romC[i];if(r===undefined){var l=romLines[i];r=l?l.split(' '):[];
      if(l&&l.indexOf('~')>=0){var seen={},o=[],j,v;for(j=0;j<r.length;j++)seen[r[j]]=1;
        for(j=0;j<r.length;j++){o.push(r[j]);if(r[j].indexOf('~')>=0){var vs=[r[j].replace(/~/g,'n'),r[j].replace(/~/g,'m'),r[j].replace(/~/g,'ng'),r[j].replace(/~/g,'')];
          for(v=0;v<vs.length;v++)if(!seen[vs[v]]){seen[vs[v]]=1;o.push(vs[v])}}}
        r=o}
      romC[i]=r}return r}
  function keys(i,f,store){var r=store[i];if(r===undefined){var seen={},o=[],rs=roms(i);for(var j=0;j<rs.length;j++){var x=f(rs[j]);if(!seen[x]){seen[x]=1;o.push(x)}}r=store[i]=o}return r}
  function buildTables(){
    var cap=cfg.cap;T={g0:[null,new Map(),new Map(),new Map(),new Map()],g1:[null,new Map(),new Map(),new Map(),new Map()],g2:[null,new Map(),new Map(),new Map(),new Map()]};
    function add(tab,keys){
      for(var j=0;j<keys.length;j++){
        var r=keys[j],lim=Math.min(4,r.length);
        for(var k=1;k<=lim;k++){
          var q=r.substr(0,k),M=tab[k],L=M.get(q);
          if(L===undefined){M.set(q,[cur])}
          else if(L[L.length-1]!==cur&&L.length<cap)L.push(cur);
        }
      }
    }
    var cur=0;
    for(var i=0;i<words.length;i++){
      var rs=roms(i);if(!rs.length)continue;cur=i;
      add(T.g0,rs);
      var a1=[],a2=[],s1={},s2={};
      for(var j=0;j<rs.length;j++){
        var x=k1(rs[j]);if(!s1[x]){s1[x]=1;a1.push(x)}
        var y=k2from(x);if(!s2[y]){s2[y]=1;a2.push(y)}
      }
      add(T.g1,a1);add(T.g2,a2);
    }
  }
  function indexBig(){
    bigText=lines(S._big);bigIdx={};
    for(var j=0;j<bigText.length;j++){var l=bigText[j],p=l.indexOf('\t');bigIdx[l.substr(0,p)]=j}
    bigC={};foll={};
  }
  function bigOf(prev){                     /* prev word (string) or '<s>' -> {tot, m: id->count, order: ids by count} or null */
    var pid=prev==='<s>'?-1:wid[prev];if(pid===undefined)return null;
    var r=bigC[pid];if(r!==undefined)return r;
    var j=bigIdx[pid];if(j===undefined)return bigC[pid]=null;
    var f=bigText[j].split('\t'),m={},order=[];
    if(f[2]){var ps=f[2].split(',');for(var q=0;q<ps.length;q++){var c=ps[q].indexOf(':'),id=+ps[q].substr(0,c);m[id]=+ps[q].substr(c+1);order.push(id)}}
    return bigC[pid]={tot:+f[1],m:m,order:order};
  }
  function clusterCounts(i){
    var r=clp[i];
    if(r===undefined){
      var n1=0,n2=0,cs=clusters(words[i]);
      for(var j=0;j<cs.length;j++){var k=cl.hasOwnProperty(cs[j])?cl[cs[j]]:2;if(k===1)n1++;else if(k===2)n2++}
      r=clp[i]=[n1,n2];
    }
    return r;
  }
  S.load=function(P){
    cfg=typeof P.cfg==='string'?JSON.parse(P.cfg):P.cfg;
    var L=lines(P.lex);words=new Array(L.length);u=new Float64Array(L.length);wid={};
    for(var i=0;i<L.length;i++){var t=L[i].indexOf('\t');words[i]=L[i].substr(0,t);var c=+L[i].substr(t+1);u[i]=c>0?c:0.3;wid[words[i]]=i}
    N=cfg.N;romLines=lines(P.rom,true);romC={};
    cl={};var C=lines(P.clus);for(i=0;i<C.length;i++){var f=C[i].split('\t');cl[f[0]]=+f[1]}
    S._big=P.big;indexBig();
    buildTables();
    /* converter */
    suni={};sU=0;var U=lines(P.syl_uni);for(i=0;i<U.length;i++){f=U[i].split('\t');suni[f[0]]=+f[1];sU+=+f[1]}
    sbi={};stot={};var B=lines(P.syl_bi);for(i=0;i<B.length;i++){f=B[i].split('\t');var cnt=+f[2];sbi[f[0]+'\t'+f[1]]=cnt;stot[f[0]]=(stot[f[0]]||0)+cnt}
    EX={};var fz={};maxL=0;var H=lines(P.syl_chan);
    for(i=0;i<H.length;i++){
      f=H[i].split('\t');var pen=+f[2];(EX[f[0]]||(EX[f[0]]=[])).push([f[1],pen]);
      if(f[0].length>maxL)maxL=f[0].length;
      var kk=k1(f[0]);if(kk){var m=fz[kk]||(fz[kk]={});if(!(f[1] in m)||m[f[1]]>pen)m[f[1]]=pen}
    }
    FZ={};for(var key in fz){var a=[];for(var o in fz[key])a.push([o,fz[key][o]]);FZ[key]=a}
    if(!cache)cache=new Cache(cfg.tau);
    S.ready=true;return S;
  };
  /* ---------------- lexicon side ---------------- */
  function nearEdit(t,i){
    var rs=roms(i),L=t.length;
    for(var j=0;j<rs.length;j++){var r=rs[j];for(var m=L-1;m<=L+1;m++){if(m>0&&r.substr(0,m)!==t.substr(0,m)&&ed1(t,r.substr(0,m)))return true}}
    return false;
  }
  S.lexicon=function(typed,prev,n,opt){
    var c=cfg,t=alpha(typed);if(!t)return [];
    var useEd=!(opt&&opt.noEdit)&&c.ed;
    var k=Math.min(t.length,4),pool={},p0=(T.g0[k].get(t.substr(0,k))||[]),i,j,key,kk,L;
    for(j=0;j<p0.length;j++)pool[p0[j]]=1;
    var tk1=tkeys(t,k1),tk2=tkeys(t,k2);
    for(j=0;j<tk1.length;j++){key=tk1[j];kk=Math.min(key.length,4);if(kk){L=(T.g1[kk].get(key.substr(0,kk))||[]);for(i=0;i<L.length;i++)pool[L[i]]=1}}
    for(j=0;j<tk2.length;j++){key=tk2[j];kk=Math.min(key.length,4);if(kk){L=(T.g2[kk].get(key.substr(0,kk))||[]);for(i=0;i<L.length;i++)pool[L[i]]=1}}
    var bg=bigOf(prev);
    if(bg){var fc=Math.min(bg.order.length,c.follower_cap);for(j=0;j<fc;j++)pool[bg.order[j]]=1}
    var edset=null;
    if(useEd&&t.length>=c.ed.minlen){
      var nex=0;
      for(j=0;j<p0.length&&nex<c.ed.gate;j++){var rs0=roms(p0[j]);for(var q=0;q<rs0.length;q++)if(startsWith(rs0[q],t)){nex++;break}}
      if(nex<c.ed.gate){
        var cand={};for(j=0;j<p0.length;j++)cand[p0[j]]=1;
        var base=t.length>4?t.substr(0,5):t,vs=edit1(base);
        for(j=0;j<vs.length;j++){
          var vv=t.length>4?vs[j]+t.substr(5):vs[j];kk=Math.min(vv.length,4);
          L=(T.g0[kk].get(vv.substr(0,kk))||[]);var m=Math.min(L.length,c.ed.cap);
          for(i=0;i<m;i++)cand[L[i]]=1;
        }
        edset={};for(var id in cand)if(nearEdit(t,+id)){edset[id]=1;pool[id]=1}
      }
    }
    var scored=[],bn=bg?Math.max(bg.tot,1e-9):1e-9;
    /* Ranking v2 (R2, switched on by the phone keyboard): the score is  log P(word | context) + log P(typed | word)  where
       - P(typed | word) is 1 for a spelling of the word that was typed in full, and falls by `rc` for every letter of the word that
         was NOT typed yet (a word is a completion of the typed letters, not a match of them), up to `rcap`; the fuzzy-key channels
         keep their own fixed costs on top;
       - P(word | context) mixes the word-after-word table and the plain frequency with a weight that grows with how many times
         the previous word was seen (Witten-Bell style), so a rarely seen previous word cannot overrule the frequency. */
    var R=R2?(c.rank2||{}):null, rc=R?(R.c!=null?R.c:0.7):0, rcap=R?(R.cap!=null?R.cap:4):0, rK=R?(R.K!=null?R.K:30):0;
    var lamB=bg?(R2?Math.min(c.a,bg.tot/(bg.tot+rK)):c.a):0;
    for(var sid in pool){
      i=+sid;var rs=roms(i),chan=null,x,y,miss=0;
      for(j=0;j<rs.length;j++)if(startsWith(rs[j],t)){var ms=rs[j].length-t.length;if(chan===null||ms<miss)miss=ms;chan=0;if(!R2)break}
      if(chan===null){var K1=keys(i,k1,k1c);for(x=0;x<K1.length;x++)for(y=0;y<tk1.length;y++)if(startsWith(K1[x],tk1[y])){var m1=K1[x].length-tk1[y].length;if(chan===null||m1<miss)miss=m1;chan=-c.w1}}
      if(chan===null){var K2=keys(i,k2,k2c);for(x=0;x<K2.length;x++)for(y=0;y<tk2.length;y++)if(startsWith(K2[x],tk2[y])){var m2=K2[x].length-tk2[y].length;if(chan===null||m2<miss)miss=m2;chan=-c.w2}}
      if(chan===null&&edset&&edset[i]){chan=-c.ed.w3;miss=0}
      if(chan===null)continue;
      var w=words[i],pb=bg&&bg.m[i]?bg.m[i]/bn:0;
      var lm=R2?(lamB*pb+(1-lamB)*u[i]/N):(c.a*pb+(1-c.a)*u[i]/N);
      lm=(1-c.lc)*lm+c.lc*cache.p(w);
      var cc=clusterCounts(i);
      var capPen=0;
      if(opt&&(opt.capD||opt.capDh)){var wd=words[i],a1=(wd.match(/[\u0B21\u0B5C]/g)||[]).length,a2=(wd.match(/[\u0B22\u0B5D]/g)||[]).length;
        capPen=5*(Math.max(0,(opt.capD||0)-a1)+Math.max(0,(opt.capDh||0)-a2))}
      scored.push([Math.log(lm+1e-12)+chan-c.p1*cc[0]-c.p2*cc[1]-(R2?Math.min(rcap,rc*miss):0)-capPen,i]);
    }
    scored.sort(function(A,B){return B[0]!==A[0]?B[0]-A[0]:B[1]-A[1]});
    scored=scored.slice(0,n);
    return scored.map(function(s){return {w:words[s[1]],i:s[1],s:s[0]}});
  };
  /* ---------------- converter ---------------- */
  function slm(prev,o,c){
    var b=stot[prev]?(sbi[prev+'\t'+o]||0)/stot[prev]:0;
    var uu=o!=='$'?(suni[o]||0)/sU:1e-4;
    return Math.log(c.mix*b+(1-c.mix)*uu+1e-9);
  }
  function cmpBeam(a,b){return a[0]!==b[0]?b[0]-a[0]:(a[1]<b[1]?1:a[1]>b[1]?-1:(a[2]<b[2]?1:a[2]>b[2]?-1:0))}
  S.converter=function(typed,n){
    var c=cfg.converter,t=alpha(typed),L=t.length;if(!L)return [];
    var beams=new Array(L+1),i,ln,j,o;for(i=0;i<=L;i++)beams[i]=[];beams[0]=[[0,'','^']];
    for(i=0;i<L;i++){
      var hs=beams[i];if(!hs.length)continue;
      if(hs.length>c.beam){hs=hs.slice().sort(cmpBeam).slice(0,c.beam)}
      for(ln=1;ln<=Math.min(maxL,L-i);ln++){
        var seg=t.substr(i,ln),opts={},any=false,e=EX[seg],f;
        if(e)for(j=0;j<e.length;j++){opts[e[j][0]]=e[j][1];any=true}
        f=FZ[k1(seg)];
        if(f)for(j=0;j<f.length;j++){var v=f[j][1]+c.fz;if(!(f[j][0] in opts)||opts[f[j][0]]>v){opts[f[j][0]]=v;any=true}}
        if(!any)continue;
        for(var h=0;h<hs.length;h++){var H=hs[h];for(o in opts)beams[i+ln].push([H[0]+c.lam*slm(H[2],o,c)-opts[o],H[1]+o,o])}
      }
    }
    var seen={};
    for(j=0;j<beams[L].length;j++){
      var B=beams[L][j],sc2=B[0]+c.lam*slm(B[2],'$',c),cs=clusters(B[1]);
      for(var q=0;q<cs.length;q++){var kk=cl.hasOwnProperty(cs[q])?cl[cs[q]]:2;if(kk===1)sc2-=c.p1;else if(kk===2)sc2-=c.p2}
      if(!(B[1] in seen)||seen[B[1]]<sc2)seen[B[1]]=sc2;
    }
    var items=[];for(var w in seen)items.push([w,seen[w]]);
    items.sort(function(a,b){return b[1]-a[1]});items=items.slice(0,c.nbest);
    items=items.map(function(it){var id=wid[it[0]];return [it[0],it[1]+(id!==undefined?c.beta+c.gamma*Math.log(1+u[id]):0)]});
    items.sort(function(a,b){return b[1]-a[1]});
    return items.slice(0,n).map(function(a){return a[0]});
  };
  /* ---------------- public ---------------- */
  S.suggest=function(typed,prev,nLex,nConv,opt){
    prev=prev||'<s>';var d=cfg.display;if(nLex==null)nLex=d.lexicon;if(nConv==null)nConv=d.converter;
    var t=alpha(typed);if(!t)return [];
    /* capital D / Dh is the retroflex ଡ / ଢ in this typing scheme; the fuzzy keys fold case, so the count is taken here, from the raw letters */
    var o2=opt;var nD=(String(typed).match(/D(?!h)/g)||[]).length,nDh=(String(typed).match(/Dh/g)||[]).length;
    if(nD||nDh){o2={};if(opt)for(var kx in opt)o2[kx]=opt[kx];o2.capD=nD;o2.capDh=nDh}
    var lex=S.lexicon(t,prev,nLex,o2),conv=nConv?S.converter(t,nConv):[];
    var near=!lex.length;
    if(!near){var rs=roms(lex[0].i),m=99;for(var j=0;j<rs.length;j++)if(startsWith(rs[j],t)&&rs[j].length<m)m=rs[j].length;near=m<=t.length+1}
    if(near&&lex.length&&cache.p(lex[0].w)>0.02)near=false;      /* a word the user has chosen before keeps the first place */
    /* Who goes first, the letter-by-letter conversion or the dictionary word that was typed in full?  Evidence decides, not habit:
       when the conversion is not a word of the dictionary at all (keun -> କେଉନ୍) and the dictionary has a word that these very letters
       spell (keun = କେଉଁ, 20 000 times in the corpus), the dictionary word is the better reading. A conversion that IS a dictionary word
       (or a word nobody has in the dictionary, with no dictionary spelling of these letters) keeps its place. */
    if(near&&R2&&lex.length&&conv.length&&wid[conv[0]]===undefined&&wid[lex[0].w]!==undefined&&u[lex[0].i]>=((cfg.rank2&&cfg.rank2.arb!=null)?cfg.rank2.arb:20))near=false;
    var out=[],seen={},a=conv.map(function(w){return [w,'conv']}),b=lex.map(function(x){return [x.w,'lex']});
    var all=near?a.concat(b):b.concat(a);
    for(var q=0;q<all.length;q++)if(!seen[all[q][0]]){seen[all[q][0]]=1;out.push(all[q])}
    return out;
  };

  /* ---------------- swipe typing (shape + location + stops + language model) ----------------
     S.swipe(spec, prev, n)  spec = {k:{a:[x,y],...}, p:[[x,y,ms],...]}  with every coordinate in key-widths (the letter keys' centres and the finger path).
     Method (the one used by the best-known gesture keyboards, SHARK2 and its successors):
       1. every dictionary spelling is turned into its ideal path through the key centres; only spellings that start and end near where the
          finger started and ended are compared;
       2. the finger path and the ideal path are resampled to the same number of points and compared twice: position-for-position
          (location channel) and after centring both (shape channel);
       3. every key of the ideal path must lie near the finger path (a skipped key is a miss), and every place where the finger stopped
          or turned sharply must lie on a key of the ideal path (a stop that no letter explains is a miss); keys the finger only passed
          over cost nothing when they are on the path;
       4. the total distance is turned into a log-likelihood and added to the language model: log P(word | previous word),
          with the same cluster penalties as typed letters. The best sum wins. */
  var SW=null;
  function swIndex(){
    if(SW)return SW;
    var B={},i,j,rs,r,key,e;
    for(i=0;i<words.length;i++){
      rs=roms(i);
      for(j=0;j<rs.length;j++){
        r=rs[j];if(r.length<2||!/^[a-z]+$/.test(r))continue;
        r=r.replace(/(.)\1+/g,'$1');if(r.length<2)continue;
        key=r.charAt(0)+r.charAt(r.length-1);e=B[key];
        if(!e)e=B[key]={w:[],r:[]};
        e.w.push(i);e.r.push(r);
      }
    }
    return SW=B;
  }
  function hyp(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return Math.sqrt(dx*dx+dy*dy)}
  function resample(P,M){                        /* P: [[x,y],...] -> M points evenly spaced along the path */
    var n=P.length,i,L=0,cum=[0];
    for(i=1;i<n;i++){L+=hyp(P[i][0],P[i][1],P[i-1][0],P[i-1][1]);cum.push(L)}
    var out=[];if(L<=1e-9){for(i=0;i<M;i++)out.push([P[0][0],P[0][1]]);return {pts:out,len:0}}
    var seg=1;
    for(i=0;i<M;i++){
      var d=L*i/(M-1);
      while(seg<n-1&&cum[seg]<d)seg++;
      var a=P[seg-1],b=P[seg],sl=cum[seg]-cum[seg-1],f=sl>1e-9?(d-cum[seg-1])/sl:0;
      out.push([a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f]);
    }
    return {pts:out,len:L};
  }
  function swStops(p){                           /* the places the finger stopped or turned: [[x,y,weight],...] */
    var n=p.length,i,st=[],sp=[],med;
    st.push([p[0][0],p[0][1],1]);
    /* speed of each step (key-widths per second) */
    for(i=1;i<n;i++){var dt=Math.max(1,p[i][2]-p[i-1][2]);sp.push(hyp(p[i][0],p[i][1],p[i-1][0],p[i-1][1])/dt*1000)}
    var sorted=sp.slice().sort(function(a,b){return a-b});med=sorted.length?sorted[Math.floor(sorted.length*0.6)]:0;
    /* dwell: a run of slow steps lasting at least 70 ms */
    var run=null;
    for(i=1;i<n;i++){
      var slow=med>0&&sp[i-1]<0.35*med;
      if(slow){if(!run)run={a:i-1,b:i};else run.b=i}
      if((!slow||i===n-1)&&run){
        var dur=p[run.b][2]-p[run.a][2];
        if(dur>=70){
          var sx=0,sy=0,c=0,k;for(k=run.a;k<=run.b;k++){sx+=p[k][0];sy+=p[k][1];c++}
          st.push([sx/c,sy/c,Math.min(1,dur/220)]);
        }
        run=null;
      }
    }
    /* sharp turns: the direction before and after a point 0.7 key-widths away on each side */
    var cum=[0];for(i=1;i<n;i++)cum.push(cum[i-1]+hyp(p[i][0],p[i][1],p[i-1][0],p[i-1][1]));
    var win=0.7,best=0,bi=-1,lo=0,hi=0;
    for(i=1;i<n-1;i++){
      while(lo<i&&cum[i]-cum[lo]>win)lo++;
      hi=Math.max(hi,i);while(hi<n-1&&cum[hi]-cum[i]<win)hi++;
      if(cum[i]-cum[lo]<win*0.6||cum[hi]-cum[i]<win*0.6){continue}
      var a1=Math.atan2(p[i][1]-p[lo][1],p[i][0]-p[lo][0]),a2=Math.atan2(p[hi][1]-p[i][1],p[hi][0]-p[i][0]),d=Math.abs(a2-a1);
      if(d>Math.PI)d=2*Math.PI-d;
      if(d>0.95){if(d>best){best=d;bi=i}}
      else if(bi>=0){st.push([p[bi][0],p[bi][1],Math.min(1,best/2.0)]);best=0;bi=-1}
    }
    if(bi>=0)st.push([p[bi][0],p[bi][1],Math.min(1,best/2.0)]);
    st.push([p[n-1][0],p[n-1][1],1]);
    /* merge stops that lie within half a key of each other (keep the heavier) */
    var out=[];
    for(i=0;i<st.length;i++){
      var m=-1,j;for(j=0;j<out.length;j++)if(hyp(out[j][0],out[j][1],st[i][0],st[i][1])<0.5){m=j;break}
      if(m<0)out.push(st[i]);else if(st[i][2]>out[m][2])out[m]=st[i];
    }
    return out;
  }
  S.swipe=function(spec,prev,n,opt){
    prev=prev||'<s>';n=n||8;
    var o=opt||{},M=o.M||32,RHO=o.rho!=null?o.rho:0.35,KAP=o.kap!=null?o.kap:16,LMW=o.lm!=null?o.lm:0.8,WS=o.ws!=null?o.ws:0.25,WC=o.wc!=null?o.wc:1.0,WK=o.wk!=null?o.wk:1.5;
    var K=spec.k,pts=spec.p;if(!pts||pts.length<3)return [];
    /* clean the path: drop repeated points */
    var P=[pts[0]],i,j;
    for(i=1;i<pts.length;i++)if(hyp(pts[i][0],pts[i][1],P[P.length-1][0],P[P.length-1][1])>0.02||i===pts.length-1)P.push(pts[i]);
    var g=resample(P,M);if(g.len<0.8)return [];
    var G=g.pts,Lg=g.len;
    var stops=swStops(P);
    var gcx=0,gcy=0;for(i=0;i<M;i++){gcx+=G[i][0];gcy+=G[i][1]}gcx/=M;gcy/=M;
    var Gc=G.map(function(q){return [q[0]-gcx,q[1]-gcy]});
    /* keys near the start and the end */
    var letters=Object.keys(K);
    function near(x,y,r){var l=letters.filter(function(c){return hyp(K[c][0],K[c][1],x,y)<=r});
      if(!l.length){var b=null,bd=1e9;letters.forEach(function(c){var d=hyp(K[c][0],K[c][1],x,y);if(d<bd){bd=d;b=c}});l=[b]}return l}
    var st0=near(P[0][0],P[0][1],1.15),st1=near(P[P.length-1][0],P[P.length-1][1],1.15);
    var idx=swIndex(),bg=bigOf(prev),lamB=bg?Math.min(cfg.a,bg.tot/(bg.tot+((cfg.rank2&&cfg.rank2.K)||30))):0,bn=bg?Math.max(bg.tot,1e-9):1e-9;
    var best={},cnt=0,a,b;
    for(a=0;a<st0.length;a++)for(b=0;b<st1.length;b++){
      var e=idx[st0[a]+st1[b]];if(!e)continue;
      for(var q=0;q<e.w.length;q++){
        var r=e.r[q],m=r.length,T=new Array(m),tl=0,ok=true;
        for(j=0;j<m;j++){var kc=K[r.charAt(j)];if(!kc){ok=false;break}T[j]=kc;if(j)tl+=hyp(kc[0],kc[1],T[j-1][0],T[j-1][1])}
        if(!ok)continue;
        if(tl<0.55*Lg||tl>1.9*Lg+0.8)continue;                          /* the ideal path is about as long as the finger path */
        /* location channel */
        var tp=resample(T,M).pts,loc=0,tcx=0,tcy=0;
        for(i=0;i<M;i++){var d=hyp(G[i][0],G[i][1],tp[i][0],tp[i][1])-RHO;if(d>0)loc+=d;tcx+=tp[i][0];tcy+=tp[i][1]}
        loc/=M;
        if(loc>1.2)continue;
        tcx/=M;tcy/=M;var shp=0;
        for(i=0;i<M;i++)shp+=hyp(Gc[i][0],Gc[i][1],tp[i][0]-tcx,tp[i][1]-tcy);
        shp/=M;
        /* every key of the word lies near the finger path */
        var cov=0;
        for(j=0;j<m;j++){
          var md=1e9;for(i=0;i<M;i++){var dd=hyp(G[i][0],G[i][1],T[j][0],T[j][1]);if(dd<md)md=dd}
          var ex=md-0.45;if(ex>0)cov+=(j===0||j===m-1)?2*ex:ex;
        }
        cov/=m;
        /* every stop of the finger lies on a key of the word */
        var sal=0,sw=0;
        for(i=0;i<stops.length;i++){
          var md2=1e9;for(j=0;j<m;j++){var dd2=hyp(stops[i][0],stops[i][1],T[j][0],T[j][1]);if(dd2<md2)md2=dd2}
          var ex2=md2-0.5;if(ex2>0)sal+=stops[i][2]*ex2;sw+=stops[i][2];
        }
        sal/=Math.max(sw,1);
        var J=loc+WS*shp*0.5+WC*cov+WK*sal;
        var wi=e.w[q];
        if(best[wi]===undefined||J<best[wi]){best[wi]=J;if(o.dbg)o.dbg[wi]=[loc,shp,cov,sal,r]}
        cnt++;
      }
    }
    var out=[];
    for(var sid in best){
      i=+sid;var w=words[i],pb=bg&&bg.m[i]?bg.m[i]/bn:0;
      var lm=lamB*pb+(1-lamB)*u[i]/N;lm=(1-cfg.lc)*lm+cfg.lc*cache.p(w);
      var cc=clusterCounts(i);
      out.push([-KAP*best[sid]+LMW*(Math.log(lm+1e-12)-cfg.p1*cc[0]-cfg.p2*cc[1]),i,best[sid]]);
    }
    out.sort(function(x,y){return y[0]-x[0]});
    return out.slice(0,n).map(function(x){return [words[x[1]],'lex',x[0],x[2]]});
  };

  S.setRank2=function(on){R2=!!on};
  S.commit=function(w){if(w)cache.commit(w)};
  S.dumpCache=function(){return cache.dump()};
  S.loadCache=function(o){cache=Cache.load(o)};
  S.has=function(w){return wid.hasOwnProperty(w)};
  /* the words that most often follow `prev` in the news and dictionary text (empty when the word is not known) */
  S.next=function(prev,n){
    if(!S.ready||!prev||prev==='<s>'||!wid.hasOwnProperty(prev)&&!wid.hasOwnProperty(prev.replace(/\u0B21\u0B3C/g,'\u0B5C').replace(/\u0B22\u0B3C/g,'\u0B5D').replace(/\u0B2F\u0B3C/g,'\u0B5F'))) return [];       /* the next word is offered only after a word the dictionary knows (a finished word, not a half-typed string) */
    var forms=[prev,prev.replace(/\u0B21\u0B3C/g,'\u0B5C').replace(/\u0B22\u0B3C/g,'\u0B5D').replace(/\u0B2F\u0B3C/g,'\u0B5F'),prev.replace(/\u0B5C/g,'\u0B21\u0B3C').replace(/\u0B5D/g,'\u0B22\u0B3C').replace(/\u0B5F/g,'\u0B2F\u0B3C')];
    for(var f=0;f<forms.length;f++){
      var r=bigOf(forms[f]); if(!r||!r.order.length) continue;
      var out=[];
      for(var i=0;i<r.order.length&&out.length<(n||6);i++){ var w=words[r.order[i]]; if(w&&/[\u0B05-\u0B39\u0B5C-\u0B61]/.test(w)) out.push(w) }
      if(out.length) return out;
    }
    return [];
  };
  S.k1=k1;S.k2=k2;S.ed1=ed1;
  return S;
}

/* ---- other languages: a word list in the script itself -> the Roman spellings people type for it ----
   The phone keyboard keeps one word list per language (Hindi, Marathi, Bangla, Assamese, English), never mixed. Each list is a text file of
   "word<TAB>count" lines, most frequent first. romanize() gives the spellings a typist or a swiper would use (the longer, fully spelled
   form first, then the form without the final inherent vowel); the same engine then matches typed letters and swipes against them. */
var DEV_C={0x15:'k',0x16:'kh',0x17:'g',0x18:'gh',0x19:'ng',0x1A:'ch',0x1B:'chh',0x1C:'j',0x1D:'jh',0x1E:'ny',0x1F:'t',0x20:'th',0x21:'d',0x22:'dh',0x23:'n',0x24:'t',0x25:'th',0x26:'d',0x27:'dh',0x28:'n',0x29:'n',0x2A:'p',0x2B:'ph',0x2C:'b',0x2D:'bh',0x2E:'m',0x2F:'y',0x30:'r',0x31:'r',0x32:'l',0x33:'l',0x34:'l',0x35:'v',0x36:'sh',0x37:'sh',0x38:'s',0x39:'h',0x58:'k',0x59:'kh',0x5A:'g',0x5B:'z',0x5C:'r',0x5D:'rh',0x5E:'f',0x5F:'y'};
var DEV_ALT={0x1B:'ch',0x35:'w',0x2B:'f',0x36:'s',0x37:'s',0x5B:'j',0x1E:'n'};
var DEV_V={0x05:'a',0x06:'aa',0x07:'i',0x08:'ee',0x09:'u',0x0A:'oo',0x0B:'ri',0x0C:'li',0x0D:'e',0x0F:'e',0x10:'ai',0x11:'o',0x13:'o',0x14:'au'};
var DEV_M={0x3E:'aa',0x3F:'i',0x40:'ee',0x41:'u',0x42:'oo',0x43:'ri',0x44:'ri',0x45:'e',0x46:'e',0x47:'e',0x48:'ai',0x49:'o',0x4A:'o',0x4B:'o',0x4C:'au'};
var DEV_MALT={0x40:'i',0x42:'u'};
function toDev(cp,lang){                        /* Bangla / Assamese code points -> their Devanagari twins; -1 when there is none */
  if(cp>=0x0900&&cp<=0x097F)return cp;
  if(cp>=0x0981&&cp<=0x09CD)return cp-0x80;
  if(cp===0x09CE)return 0x24;
  if(cp===0x09DC)return 0x095C;if(cp===0x09DD)return 0x095D;if(cp===0x09DF)return 0x095F;
  if(cp===0x09F0)return 0x0930;if(cp===0x09F1)return 0x0935;
  if(cp===0x09D7)return 0x094C;
  return -1;
}
/* lang: 'hi' | 'mr' | 'bn' | 'as'; returns up to four lower-case spellings */
function romanize(word,lang){
  var east=(lang==='bn'||lang==='as'),syl=[],i,cp,c,n=word.length,out=[];
  /* parse into syllables: {c: consonant roman or '', alt, v: vowel roman or null (inherent), valt, tail: signs} */
  var cur=null;
  function flush(){if(cur){syl.push(cur);cur=null}}
  for(i=0;i<n;i++){
    c=toDev(word.charCodeAt(i),lang);if(c<0)continue;
    cp=c>=0x0900?c-0x0900:c;                       /* offset inside the Devanagari block */
    if(c>=0x0958&&c<=0x095F)cp=c-0x0900;
    var key=cp;
    if(DEV_C[key]!==undefined&&!(c<0x0900&&cp>0x39&&cp<0x58)){
      flush();
      var r=DEV_C[key],ra=DEV_ALT[key];
      if(east){if(key===0x2F){r='j';ra='y'}else if(key===0x1B){r='chh';ra='ch'}else if(key===0x36||key===0x37||key===0x38){r='sh';ra='s'}}
      if(lang==='as'){if(key===0x36||key===0x37||key===0x38){r='x';ra='s'}else if(key===0x1A||key===0x1B){r='s';ra='ch'}else if(key===0x1C||key===0x1D){r='z';ra='j'}}
      if(lang==='mr'&&key===0x33)r='l';
      cur={c:r,alt:ra||r,v:null,valt:null,tail:'',end:false};
    }else if(DEV_V[key]!==undefined){
      flush();cur={c:'',alt:'',v:DEV_V[key],valt:DEV_V[key],tail:'',end:true};
    }else if(DEV_M[key]!==undefined){
      if(cur){cur.v=DEV_M[key];cur.valt=DEV_MALT[key]||DEV_M[key];cur.end=true}
    }else if(key===0x4D){                          /* halant: the consonant has no vowel */
      if(cur){cur.v='';cur.valt='';cur.end=true}
    }else if(key===0x02||key===0x01){              /* anusvara, chandrabindu */
      if(cur)cur.tail+='n';else{flush();cur={c:'n',alt:'n',v:'',valt:'',tail:'',end:true}}
    }else if(key===0x03){if(cur)cur.tail+='h'}
    else if(key===0x3C){                           /* nukta: a letter with a dot below */
      if(cur){var m2={0x1C:['z','j'],0x21:['r','d'],0x22:['rh','dh'],0x2B:['f','ph'],0x15:['k','k'],0x16:['kh','kh'],0x17:['g','g']}[0];}
    }
    /* anything else (ZWJ, ZWNJ, danda ...) is ignored */
  }
  flush();
  if(!syl.length)return [];
  var inh=east?['a','o']:['a'];
  function build(useAlt,inhV,dropFinal){
    var s='',k;
    for(k=0;k<syl.length;k++){
      var y=syl[k],last=(k===syl.length-1);
      s+=useAlt?y.alt:y.c;
      if(y.v===null){ if(y.c&&!(last&&dropFinal))s+=inhV; }
      else s+=useAlt?y.valt:y.v;
      s+=y.tail;
    }
    return s;
  }
  var seen={};
  function add(x){x=x.replace(/[^a-z]/g,'');if(x&&!seen[x]){seen[x]=1;out.push(x)}}
  for(i=0;i<inh.length;i++){add(build(false,inh[i],false));add(build(false,inh[i],true))}
  add(build(true,inh[0],true));add(build(true,inh[0],false));
  return out.slice(0,5);
}
/* a whole word list -> the data an engine instance needs (the same files the Odia engine reads) */
function listData(code,text,cfgText){
  var L=text.split('\n'),lex=[],rom=[],i,sum=0,cfg=JSON.parse(cfgText);
  for(i=0;i<L.length;i++){
    var t=L[i].indexOf('\t'),w=t>0?L[i].substr(0,t):'',c=t>0?+L[i].substr(t+1):0;
    if(!w||!(c>0))continue;
    var rs=code==='en'?[w.toLowerCase()]:romanize(w,code);
    if(!rs.length)continue;
    lex.push(w+'\t'+c);rom.push(rs.join(' '));sum+=c;
  }
  cfg.N=sum;cfg.words=lex.length;
  return {cfg:JSON.stringify(cfg),lex:lex.join('\n')+'\n',rom:rom.join('\n')+'\n',big:'',clus:'',syl_uni:'',syl_bi:'',syl_chan:''};
}

return {create:create,romanize:romanize,listData:listData,k1:k1,k1_regex:k1_regex,k2:k2,ed1:ed1,alpha:alpha};
})();
if(typeof module!=='undefined')module.exports=Sulekhak;
