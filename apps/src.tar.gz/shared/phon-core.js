/* The look-alike symbol lists of the Phonetic mode (IPA, extIPA, IAST), for the Mac and Windows keyboards.
   phon-data.js (the same database as the web typist) must be loaded first. phCands(k) returns the key itself first,
   then every symbol that looks like it, strongest first. */
(function(g){
var T={exact:0,high:1,medium:2,low:3}, cache={};
function phCands(k){
  if(cache[k]) return cache[k].slice();
  var D=g.SKPH, res=[k];
  if(D&&D.keyMap&&D.keyMap[k]){
    var seen={}, out=[];
    D.keyMap[k].forEach(function(r){
      var e=D.entries[r[0]], s=e[0], tier=(r[1]==='identity'||r[2]==='exact')?'exact':r[2], m=seen[s];
      if(!m){ m=seen[s]={s:s,score:r[3],tier:tier,i:out.length}; out.push(m) }
      else if(r[3]>m.score){ m.score=r[3]; m.tier=tier }
    });
    out.sort(function(a,b){ return ((T[a.tier]||0)-(T[b.tier]||0))||(b.score-a.score)||(a.i-b.i) });
    res=out.map(function(m){ return m.s }).filter(function(s){ return s!==k });
    res.unshift(k);
  }
  cache[k]=res; return res.slice();
}
/* the same look-alike list with the details the hover panel shows: [{s, tier, score, label, inv}] strongest first (the key itself is left out) */
function phInfo(k){
  var D=g.SKPH, out=[], seen={};
  if(!D||!D.keyMap||!D.keyMap[k]) return out;
  D.keyMap[k].forEach(function(r){
    var e=D.entries[r[0]], s=e[0], tier=(r[1]==='identity'||r[2]==='exact')?'exact':r[2], m=seen[s];
    if(!m){ m=seen[s]={s:s,score:r[3],tier:tier,label:e[3]||'',inv:(D.invLabel&&D.invLabel[D.inv[e[1]]])||D.inv[e[1]]||'',i:out.length}; out.push(m) }
    else if(r[3]>m.score){ m.score=r[3]; m.tier=tier }
  });
  out.sort(function(a,b){ return ((T[a.tier]||0)-(T[b.tier]||0))||(b.score-a.score)||(a.i-b.i) });
  return out.filter(function(m){ return m.s!==k });
}
g.phCands=phCands; g.phInfo=phInfo;
})(this);
