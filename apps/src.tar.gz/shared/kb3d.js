/* ସୁलेখk keyboard: a vector 3D mechanical keyboard (65% layout, or a phone layout) drawn as one SVG.
   No images. Every cap is a frustum (top face, front/left/right walls) projected with a real perspective camera,
   so it scales without loss, and legends sit on the cap tops under the same projection.
   SKKB.create({host, legend(k)->{a,b}, tip(k)->html, onKey(key,shifted,el,ev), alts(k)->[odia strings] + onText(str) for the long-press popup, layout:'full'|'phone'}) -> controller */
var SKKB=(function(){
'use strict';
var P=60;                                   /* key pitch in world units */
var SH={'`':'~','1':'!','2':'@','3':'#','4':'$','5':'%','6':'^','7':'&','8':'*','9':'(','0':')','-':'_','=':'+','[':'{',']':'}','\\':'|',';':':',"'":'"',',':'<','.':'>','/':'?'};
/* [id, width in u, kind, text on the cap] ; id '_' = empty gap */
var LAY={
 full:[
  [['Escape',1,'accent','esc'],['`',1],['1',1],['2',1],['3',1],['4',1],['5',1],['6',1],['7',1],['8',1],['9',1],['0',1],['-',1],['=',1],['Backspace',2,'mod',['back','\u232b delete']]],
  [['Tab',1.5,'mod','tab \u21e5'],['q',1],['w',1],['e',1],['r',1],['t',1],['y',1],['u',1],['i',1],['o',1],['p',1],['[',1],[']',1],['\\',1.5],['Delete',1,'mod',['del','\u2326']]],
  [['CapsLock',1.75,'mod','caps lock \u21ea'],['a',1],['s',1],['d',1],['f',1],['g',1],['h',1],['j',1],['k',1],['l',1],[';',1],["'",1],['Enter',2.25,'mod',['enter','\u21b5 return']],['PageUp',1,'mod',['pg up','\u21de']]],
  [['Shift',2.25,'mod','\u21e7 shift'],['z',1],['x',1],['c',1],['v',1],['b',1],['n',1],['m',1],[',',1],['.',1],['/',1],['Shift',1.75,'mod','shift \u21e7'],['ArrowUp',1,'accent','\u2191'],['PageDown',1,'mod',['pg dn','\u21df']]],
  [['Control',1.25,'mod',['ctrl','\u2303 control']],['Fn',1,'mod','fn'],['Meta',1.25,'mod',['\u229e start','\u2325 option']],['Alt',1.25,'mod',['alt','\u2318 cmd']],[' ',4.75,'mod',''],['Alt',1.25,'mod',['alt','\u2318 cmd']],['Control',1.25,'mod',['ctrl','\u2325 option']],['_',1],['ArrowLeft',1,'accent','\u2190'],['ArrowDown',1,'accent','\u2193'],['ArrowRight',1,'accent','\u2192']]
 ],
 phone:[
  [['1',1],['2',1],['3',1],['4',1],['5',1],['6',1],['7',1],['8',1],['9',1],['0',1]],
  [['q',1],['w',1],['e',1],['r',1],['t',1],['y',1],['u',1],['i',1],['o',1],['p',1]],
  [['_',.5],['a',1],['s',1],['d',1],['f',1],['g',1],['h',1],['j',1],['k',1],['l',1],['_',.5]],
  [['Shift',1.5,'mod','\u21e7'],['z',1],['x',1],['c',1],['v',1],['b',1],['n',1],['m',1],['Backspace',1.5,'mod','\u232b']],
  [['`',1.25],["'",1.25],[' ',4,'mod',''],['.',1.25],['Enter',2.25,'mod','\u21b5']]
 ]
};
var COL={
 /* anodised aluminium: silver alphas, space-grey modifiers, copper-orange accents. top = 4 gradient stops, f/l/r = wall stops */
 alpha:{top:['#f4f5f7','#d5d8dd','#b9bdc4','#dfe1e5'],f:['#c4c8cf','#8b9099'],l:['#d3d6dc','#a4a9b1'],r:['#9a9fa8','#6a6f78'],ink:'#06080c',ink2:'#06307f',hi:'#ffffff',hiO:.8,dx:.4,dy:.7},
 mod:{top:['#6a707a','#4b5059','#3a3e46','#555a63'],f:['#464a52','#25282e'],l:['#555a63','#34383f'],r:['#33373e','#1c1e23'],ink:'#ffffff',ink2:'#cfe0ff',hi:'#000000',hiO:.7,dx:.4,dy:.8},
 accent:{top:['#f2ab72','#dc8040','#c46a2a','#e69458'],f:['#b9632a','#7d3f14'],l:['#d4772f','#9a5320'],r:['#a8561f','#6e3510'],ink:'#140a02',ink2:'#140a02',hi:'#ffd9b5',hiO:.55,dx:.4,dy:.8}
};

/* ---------------- device styles: Mac, Windows, iPad / iPhone, Android ----------------
   Each style has its own case, key colours (always a strongly contrasting legend colour) and modifier labels. */
function K(top,f,l,r,ink,ink2,hi,hiO){ return {top:top,f:f,l:l,r:r,ink:ink,ink2:ink2,hi:hi,hiO:hiO,dx:.4,dy:.7} }
var THEMES={
 mac:{brush:0.05, label:'Mac', edge:'#8d939c', floor:'#aeb3bb', walls:['#c9cdd3','#b3b8bf','#a3a8b0'],
  cs:['#f1f2f5','#d9dce1','#bfc4cb','#a6abb3'], cf:['#f6f7f9','#dfe2e7','#c7ccd3','#aab0b8'], cr:['#fdfdfe','#e8eaee','#f3f4f6','#d3d7dc','#bcc1c8'],
  col:{
   alpha:K(['#ffffff','#f3f4f6','#e5e8ec','#f8f9fa'],['#d6d9de','#a9aeb6'],['#e2e5e9','#babfc6'],['#b6bbc3','#8b919b'],'#080a0f','#0a3d99','#ffffff',.9),
   mod:K(['#e9ebef','#d9dce1','#cbced5','#dfe2e7'],['#c1c5cc','#8f959e'],['#cfd3d9','#a2a8b0'],['#a5aab2','#7d838c'],'#0b0d14','#0a3d99','#ffffff',.9),
   accent:K(['#e8eefb','#d3def5','#c2d1ee','#dce6f8'],['#aebfe0','#7f93bd'],['#bfcdea','#92a5cc'],['#98abd2','#6d82ae'],'#0a1f55','#0a1f55','#ffffff',.9)}},
 win:{brush:0.2, label:'Windows', edge:'#050506', floor:'#0a0b0d', walls:['#2b2d33','#1d1e23','#16171b'],
  cs:['#44474e','#2a2c31','#18191c','#0c0d0f'], cf:['#4b4e55','#2e3035','#1a1b1e','#0b0c0d'], cr:['#6a6d75','#3f4248','#50535a','#2e3035','#1c1d21'],
  col:{
   alpha:K(['#53565e','#3b3e44','#2b2d32','#464950'],['#33353b','#16171b'],['#42454c','#212328'],['#24262b','#0e0f12'],'#ffffff','#ffd75e','#000000',.8),
   mod:K(['#33353b','#25272b','#1a1b1f','#2c2e33'],['#202226','#0c0d0f'],['#2a2c31','#15161a'],['#17181b','#08090a'],'#ffffff','#9fd0ff','#000000',.8),
   accent:K(['#62a8ff','#3a85ec','#2468cc','#549af5'],['#1f5cb8','#123a78'],['#2f72d6','#1b4b9c'],['#1b54a8','#0f3068'],'#ffffff','#ffffff','#0a2a5e',.5)}},
 ios:{brush:0.04, label:'iPad / iPhone', edge:'#aab1bd', floor:'#c4cad4', walls:['#d4d9e1','#c6ccd6','#b8bfca'],
  cs:['#eef1f6','#d5dae3','#bfc6d2','#a9b1bf'], cf:['#f3f5f9','#dde2ea','#c6ced9','#aeb6c3'], cr:['#fbfcfe','#e6eaf0','#f1f3f7','#d1d7e0','#bbc3cf'],
  col:{
   alpha:K(['#ffffff','#fafbfc','#f0f2f5','#ffffff'],['#d8dce3','#b5bbc6'],['#e6e9ee','#c4cad4'],['#bcc3ce','#98a0ae'],'#0a0a0e','#0057d8','#ffffff',.9),
   mod:K(['#b4bbc7','#a7aebb','#9ba3b1','#adb4c0'],['#8e96a4','#6c7482'],['#9aa2b0','#788090'],['#7d8593','#5b6370'],'#0a0a0e','#003c9a','#ffffff',.7),
   accent:K(['#3d97ff','#1a7cf5','#0a66dc','#2f8bf8'],['#0a5cc4','#06397a'],['#1272e6','#0a4aa6'],['#0a55b8','#06336e'],'#ffffff','#ffffff','#05285a',.5)}},
 android:{brush:0.2, label:'Android', edge:'#0c0d10', floor:'#121316', walls:['#2a2c30','#1d1e21','#17181b'],
  cs:['#3b3d42','#2a2b2f','#1d1e21','#121316'], cf:['#414348','#2d2e32','#1e1f22','#111214'], cr:['#55575d','#383a3f','#46484d','#2c2d31','#1d1e21'],
  col:{
   alpha:K(['#565a5f','#474a4f','#3a3d41','#4e5156'],['#33363a','#1a1b1e'],['#43464b','#25272a'],['#282a2d','#101113'],'#ffffff','#8ab4f8','#000000',.75),
   mod:K(['#3a3d41','#2e3033','#232528','#34363a'],['#27292c','#0f1012'],['#303236','#18191c'],['#1c1d20','#08090a'],'#ffffff','#a8c7fa','#000000',.75),
   accent:K(['#a8c7fa','#8ab4f8','#6f9fe8','#9dbff6'],['#5b88d2','#365d9e'],['#7aa6ec','#4b76bb'],['#4f7cc4','#2c4f8a'],'#0b1d3a','#0b1d3a','#ffffff',.6)}}
};
function detect(){
  var ua=navigator.userAgent||'', pl=(navigator.userAgentData&&navigator.userAgentData.platform)||navigator.platform||'', tp=navigator.maxTouchPoints||0;
  var ipad=/iPad/.test(ua)||(/Mac/.test(pl)&&tp>1), iphone=/iPhone|iPod/.test(ua), android=/Android/.test(ua);
  var os=(iphone||ipad)?'ios':android?'android':/Mac/.test(pl)?'mac':'win';
  var small=Math.min(screen.width||9999,screen.height||9999)<520;
  return {os:os, phone:!!(iphone||(android&&(/Mobile/.test(ua)||small))), tablet:!!(ipad||(android&&!/Mobile/.test(ua)&&!small)), touch:tp>0||('ontouchstart' in window)};
}
/* the 65% layout, with the modifier labels of the chosen device */
function fullRows(t){
  var mac=(t==='mac'||t==='ios');
  var bs=mac?['delete','⌫']:['backspace','⌫'], tab='tab ⇥', caps=mac?'caps lock ⇪':'caps lock ⇪', ent=mac?['return','↵']:['enter','↵'];
  var shL=mac?'⇧ shift':'⇧ shift', shR='shift ⇧', del=mac?['fwd del','⌦']:['del','⌦'];
  var bot=mac?
   [['Control',1.25,'mod',['⌃','control']],['Fn',1,'mod','fn'],['Alt',1.25,'mod',['⌥','option']],['Meta',1.25,'mod',['⌘','command']],[' ',4.75,'mod',''],['Meta',1.25,'mod',['⌘','command']],['Alt',1.25,'mod',['⌥','option']],['_',1],['ArrowLeft',1,'accent','←'],['ArrowDown',1,'accent','↓'],['ArrowRight',1,'accent','→']]:
   [['Control',1.25,'mod','ctrl'],['Fn',1,'mod','fn'],['Meta',1.25,'mod',['⊞','win']],['Alt',1.25,'mod','alt'],[' ',4.75,'mod',''],['Alt',1.25,'mod','alt gr'],['Control',1.25,'mod','ctrl'],['_',1],['ArrowLeft',1,'accent','←'],['ArrowDown',1,'accent','↓'],['ArrowRight',1,'accent','→']];
  return [
  [['Escape',1,'accent','esc'],['`',1],['1',1],['2',1],['3',1],['4',1],['5',1],['6',1],['7',1],['8',1],['9',1],['0',1],['-',1],['=',1],['Backspace',2,'mod',bs]],
  [['Tab',1.5,'mod',tab],['q',1],['w',1],['e',1],['r',1],['t',1],['y',1],['u',1],['i',1],['o',1],['p',1],['[',1],[']',1],['\\',1.5],['Delete',1,'mod',del]],
  [['CapsLock',1.75,'mod',caps],['a',1],['s',1],['d',1],['f',1],['g',1],['h',1],['j',1],['k',1],['l',1],[';',1],["'",1],['Enter',2.25,'mod',ent],['PageUp',1,'mod',['pg up','⇞']]],
  [['Shift',2.25,'mod',shL],['z',1],['x',1],['c',1],['v',1],['b',1],['n',1],['m',1],[',',1],['.',1],['/',1],['Shift',1.75,'mod',shR],['ArrowUp',1,'accent','↑'],['PageDown',1,'mod',['pg dn','⇟']]],
  bot];
}
function esc(s){ return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]}) }
function f1(n){ return Math.round(n*10)/10 }
function hull(pts){
  pts=pts.slice().sort(function(a,b){return a[0]-b[0]||a[1]-b[1]}); var n=pts.length; if(n<3) return pts;
  function cr(o,a,b){ return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]) }
  var lo=[],up=[],i;
  for(i=0;i<n;i++){ while(lo.length>=2&&cr(lo[lo.length-2],lo[lo.length-1],pts[i])<=0) lo.pop(); lo.push(pts[i]) }
  for(i=n-1;i>=0;i--){ while(up.length>=2&&cr(up[up.length-2],up[up.length-1],pts[i])<=0) up.pop(); up.push(pts[i]) }
  lo.pop(); up.pop(); return lo.concat(up);
}
function rr(cx,cy,w,d,r,steps){            /* rounded-rectangle outline, clockwise from the back-left */
  var o=[],a,i,corners=[[cx+w/2-r,cy-d/2+r,-90],[cx+w/2-r,cy+d/2-r,0],[cx-w/2+r,cy+d/2-r,90],[cx-w/2+r,cy-d/2+r,180]];
  corners.forEach(function(c){ for(i=0;i<=steps;i++){ a=(c[2]+90*i/steps)*Math.PI/180; o.push([c[0]+r*Math.cos(a),c[1]+r*Math.sin(a)]) } });
  return o;
}
function pathOf(pts){ return 'M'+pts.map(function(p){return f1(p[0])+' '+f1(p[1])}).join('L')+'Z' }

/* ---- the long-press popup (shared with the page's own touch keyboard as SKKB.pickPopup) ---- */
var lpEl=null, lpCells=[], lpSel=-1, lpOff=null;
function depCh(c){ var n=c.charCodeAt(0); return (n>=0x0B3E&&n<=0x0B4D)||n===0x0B3C||(n>=0x0B01&&n<=0x0B03)||n===0x0B44||n===0x0B56||n===0x0B57||n===0x0B62||n===0x0B63 }
function lpLabel(t){ if(t==='\u200c') return 'ZWNJ'; if(t==='\u200d') return 'ZWJ'; var m=/^(.*?)([\u0b4d\u094d\u09cd])([\u200c\u200d])$/.exec(t); if(m) return (m[1]||'\u25cc')+m[2]+' + '+(m[3]==='\u200c'?'\u250a':'['); return (depCh(t.charAt(0))?'\u25cc':'')+t }
function lpStyle(){
  if(document.getElementById('kb-lp-css')) return;
  var st=document.createElement('style'); st.id='kb-lp-css';
  st.textContent='.kb-lp{position:fixed;z-index:2147483000;display:grid;gap:3px;padding:6px;border-radius:12px;background:#2a3047;color:#f2f4fb;box-shadow:0 10px 30px rgba(0,0,0,.45),0 0 0 1px rgba(255,255,255,.12);font:600 22px/1 "Noto Sans Oriya","Nirmala UI","Kohinoor Odia","Odia Sangam MN",system-ui,sans-serif;touch-action:none;user-select:none;-webkit-user-select:none;pointer-events:none}'
   +'.kb-lp i{font-style:normal;min-width:40px;height:44px;padding:0 8px;display:flex;align-items:center;justify-content:center;border-radius:8px;white-space:nowrap}'
   +'.kb-lp i.on{background:#4f7be8;color:#fff}.kb-lp i.sm{font-size:14px}';
  document.head.appendChild(st);
}
function lpClose(){
  if(lpOff){ lpOff(); lpOff=null }
  if(lpEl&&lpEl.parentNode) lpEl.parentNode.removeChild(lpEl);
  lpEl=null; lpCells=[]; lpSel=-1;
}
function lpPick(x,y){
  var best=-1, bd=1e9, i, r, dx, dy, d;
  for(i=0;i<lpCells.length;i++){
    r=lpCells[i].getBoundingClientRect(); dx=Math.max(r.left-x,0,x-r.right); dy=Math.max(r.top-y,0,y-r.bottom); d=dx*dx+dy*dy;
    if(d<bd){ bd=d; best=i }
  }
  return bd<=60*60?best:-1;
}
function lpMark(i){ if(i===lpSel) return; if(lpSel>=0) lpCells[lpSel].classList.remove('on'); lpSel=i; if(i>=0) lpCells[i].classList.add('on') }
/* pickPopup(anchorEl, [texts], pointerEvent, done(text|null)): shows the list above the anchor while the pointer is still down;
   moving over a cell selects it, releasing calls done(text), leaving the list or cancelling calls done(null) */
function pickPopup(el,list,e0,done){
  lpClose(); lpStyle();
  var d=document.createElement('div'); d.className='kb-lp'; d.setAttribute('role','listbox');
  var vw0=document.documentElement.clientWidth||window.innerWidth||400, maxc=Math.max(4,Math.floor((vw0-24)/46));
  var per=list.length>7?Math.ceil(list.length/2):list.length; if(per>maxc) per=maxc;      /* never wider than the screen: wrap to more rows */
  d.style.gridTemplateColumns='repeat('+per+',auto)';
  lpCells=list.map(function(t){ var c=document.createElement('i'); c.textContent=lpLabel(t); if(t.length>3||t==='\u200c'||t==='\u200d'||/[\u200c\u200d]$/.test(t)) c.className='sm'; d.appendChild(c); return c });
  d.style.visibility='hidden'; document.body.appendChild(d); lpEl=d;
  var r=el.getBoundingClientRect(), w=d.offsetWidth, h=d.offsetHeight, vw=document.documentElement.clientWidth, vh=document.documentElement.clientHeight;
  var x=Math.max(4,Math.min(vw-w-4,r.left+r.width/2-w/2)), y=r.top-h-8; if(y<4) y=Math.min(4,vh-h-4);
  d.style.left=x+'px'; d.style.top=y+'px'; d.style.visibility='visible';
  var i0=lpPick(e0.clientX,e0.clientY); lpMark(i0>=0?i0:0);
  function mv(e){ e.preventDefault(); lpMark(lpPick(e.clientX,e.clientY)) }
  function up(e){ var i=lpSel, t=i>=0?list[i]:null; lpClose(); done(t) }       /* the cell that was last under the pointer */
  function cancel(){ lpClose(); done(null) }
  document.addEventListener('pointermove',mv,true); document.addEventListener('pointerup',up,true); document.addEventListener('pointercancel',cancel,true);
  lpOff=function(){ document.removeEventListener('pointermove',mv,true); document.removeEventListener('pointerup',up,true); document.removeEventListener('pointercancel',cancel,true) };
}

function create(opt){
  var host=opt.host, layoutName=opt.layout||'full', uid='kb'+Math.floor(Math.random()*1e6);
  var self={}, shiftMode=0, physShift=false, tipEl=null, svgEl=null, keys=[], lastFocus=null, tipTimer=0;
  var zoom=1, devPref=opt.device||'auto', themeName=resolve(devPref);
  function resolve(d){ return THEMES[d]?d:detect().os }

  /* ---------------- geometry ---------------- */
  function cfg(){
    var ph=layoutName==='phone';
    return ph?{E:80,dist:1500,GAP:7,INX:5,INY:5,H:[17,17,17,17,17],ZW:16,rc:9,rt:8,m:12,mFront:16,legend:1.0}:
              {E:76,dist:1600,GAP:6,INX:5.5,INY:5.5,H:[24,23,22,22,24],ZW:20,rc:8,rt:7,m:26,mFront:34,legend:1.0};
  }
  function build(){
    var TH=THEMES[themeName]; COL=TH.col;
    var c=cfg(), rows=layoutName==='full'?fullRows(themeName):LAY[layoutName], E=c.E*Math.PI/180, sE=Math.sin(E), cE=Math.cos(E);
    var W=0; rows.forEach(function(r){ var w=0; r.forEach(function(k){ w+=k[1] }); if(w>W) W=w });
    var Wp=W*P, Dp=rows.length*P, H=34, Hw=H-13;
    var T=[Wp/2,Dp/2,12], C=[T[0],T[1]+c.dist*cE,T[2]+c.dist*sE], F=c.dist;
    function pr(p){ var vx=p[0]-C[0], vy=p[1]-C[1], vz=p[2]-C[2]; var yc=-sE*vy+cE*vz, zc=-cE*vy-sE*vz; return [F*vx/zc,-F*yc/zc] }
    function pp(arr,z){ return arr.map(function(p){ return pr([p[0],p[1],z]) }) }
    var x0=-c.m, x1=Wp+c.m, y0=-c.m, y1=Dp+c.mFront;
    var out='', defs='', bb=[1e9,1e9,-1e9,-1e9];
    function grow(pts){ pts.forEach(function(p){ if(p[0]<bb[0])bb[0]=p[0]; if(p[1]<bb[1])bb[1]=p[1]; if(p[0]>bb[2])bb[2]=p[0]; if(p[1]>bb[3])bb[3]=p[1] }) }
    /* case */
    var rimOuter=rr((x0+x1)/2,(y0+y1)/2,x1-x0,y1-y0,22,6), rimIn=rr((x0+x1)/2+0,(y0+y1)/2,x1-x0-2*13,y1-y0-2*13,13,5);
    var gO=pp(rimOuter,H), gB=pp(rimOuter,0), floor=pp(rimIn,Hw), rimInTop=pp(rimIn,H);
    grow(gB); grow(gO);
    var caseSide=hull(gO.concat(gB));
    out+='<ellipse cx="'+f1(pr([Wp/2,Dp/2,0])[0])+'" cy="'+f1(pr([Wp/2,y1+40,0])[1])+'" rx="'+f1((gB[0]&&Math.abs(pr([x1,Dp/2,0])[0]-pr([x0,Dp/2,0])[0]))/2*1.02)+'" ry="26" fill="#000" opacity=".28" filter="url(#'+uid+'bl)"/>';
    out+='<path d="'+pathOf(caseSide)+'" fill="url(#'+uid+'cs)"/>';
    out+='<path d="'+pathOf(caseSide)+'" fill="url(#'+uid+'br)" opacity=".3" style="mix-blend-mode:soft-light"/>';
    out+='<path d="'+pathOf(gO)+'" fill="url(#'+uid+'cr)" stroke="'+TH.edge+'" stroke-width=".8"/>';
    out+='<path d="'+pathOf(gO)+'" fill="url(#'+uid+'br)" opacity=".4" style="mix-blend-mode:soft-light"/>';
    out+='<path d="'+pathOf(gO)+'" fill="none" stroke="url(#'+uid+'rim)" stroke-width="1.6" stroke-linejoin="round"/>';
    out+='<path d="'+pathOf(floor)+'" fill="'+TH.floor+'"/>';
    /* inner walls: back wall (lit), left and right (shaded) */
    function quad(a,b,fill){ out+='<path d="'+pathOf([pr(a[0]),pr(a[1]),pr(b[1]),pr(b[0])])+'" fill="'+fill+'"/>' }
    var ix0=x0+13,ix1=x1-13,iy0=y0+13,iy1=y1-13;
    quad([[ix0,iy0,H],[ix1,iy0,H]],[[ix0,iy0,Hw],[ix1,iy0,Hw]],TH.walls[0]);
    quad([[ix0,iy0,H],[ix0,iy1,H]],[[ix0,iy0,Hw],[ix0,iy1,Hw]],TH.walls[1]);
    quad([[ix1,iy0,H],[ix1,iy1,H]],[[ix1,iy0,Hw],[ix1,iy1,Hw]],TH.walls[2]);
    /* key shadows on the plate, one blurred group */
    var sh='';
    keys=[];
    var yRow=0, items=[];
    rows.forEach(function(row,ri){
      var xu=0; row.forEach(function(k,ci){
        var id=k[0], u=k[1], kind=k[2]||'alpha';
        if(id!=='_'){
          var cx=(xu+u/2)*P, cy=(ri+.5)*P, bw=u*P-c.GAP, bd=P-c.GAP, tw=bw-2*c.INX, td=bd-2*c.INY, tcy=cy-2.5, zb=Hw, zt=Hw+c.H[Math.min(ri,4)];
          items.push({id:id,u:u,kind:kind,text:k[3],ri:ri,ci:ci,cx:cx,cy:cy,bw:bw,bd:bd,tw:tw,td:td,tcy:tcy,zb:zb,zt:zt});
          sh+='<path d="'+pathOf(pp(rr(cx+2,cy+5,bw+2,bd+2,c.rc,3),zb))+'"/>';
        }
        xu+=u;
      });
    });
    out+='<g fill="#000" opacity=".5" filter="url(#'+uid+'bl2)">'+sh+'</g>';
    items.sort(function(a,b){ return a.ri-b.ri });
    var camx=Wp/2;
    items.forEach(function(it){
      var col=COL[it.kind], isSp=it.id===' ';
      var bR=rr(it.cx,it.cy,it.bw,it.bd,c.rc,3), tR=rr(it.cx,it.tcy,it.tw,it.td,c.rt,3);
      var pb=pp(bR,it.zb), pt=pp(tR,it.zt), hl=hull(pb.concat(pt));
      grow(pb); grow(pt);
      var bl=[it.cx-it.bw/2,it.cy-it.bd/2],br_=[it.cx+it.bw/2,it.cy-it.bd/2],fl=[it.cx-it.bw/2,it.cy+it.bd/2],fr=[it.cx+it.bw/2,it.cy+it.bd/2];
      var tl=[it.cx-it.tw/2,it.tcy-it.td/2],tr_=[it.cx+it.tw/2,it.tcy-it.td/2],tfl=[it.cx-it.tw/2,it.tcy+it.td/2],tfr=[it.cx+it.tw/2,it.tcy+it.td/2];
      function q(a,b,c2,d,z1,z2){ return pathOf([pr([a[0],a[1],z1]),pr([b[0],b[1],z1]),pr([c2[0],c2[1],z2]),pr([d[0],d[1],z2])]) }
      var g='<g class="kb-key'+(/^[a-z]$/.test(it.id)?' ltr':'')+'" data-k="'+esc(it.id)+'" data-i="'+keys.length+'" data-kind="'+it.kind+'" role="button" tabindex="-1">';
      g+='<path class="hit" d="'+pathOf(hl)+'" fill="'+col.f[1]+'"/>';
      g+='<path d="'+q(fl,fr,tfr,tfl,it.zb,it.zt)+'" fill="url(#'+uid+'f'+it.kind+')"/>';
      if(it.cx<camx) g+='<path d="'+q(fr,br_,tr_,tfr,it.zb,it.zt)+'" fill="url(#'+uid+'r'+it.kind+')"/>';
      else g+='<path d="'+q(bl,fl,tfl,tl,it.zb,it.zt)+'" fill="url(#'+uid+'l'+it.kind+')"/>';
      var tpath=pathOf(pt);
      g+='<path class="top" d="'+tpath+'" fill="url(#'+uid+'t'+it.kind+')"/>';
      g+='<path d="'+tpath+'" fill="url(#'+uid+'br)" opacity="'+TH.brush+'" style="mix-blend-mode:soft-light"/>';
      var dish=rr(it.cx,it.tcy+1,it.tw*.82,it.td*.8,c.rt*.8,3);
      g+='<path d="'+pathOf(pp(dish,it.zt))+'" fill="url(#'+uid+'d)" opacity=".55"/>';
      g+='<path d="'+tpath+'" fill="url(#'+uid+'sh)" opacity=".9"/>';
      g+='<path d="'+tpath+'" fill="none" stroke="url(#'+uid+'ch)" stroke-width="1.1" stroke-linejoin="round"/>';
      /* legend, drawn in the plane of the cap top */
      var o=pr([it.cx,it.tcy,it.zt]), ex=pr([it.cx+1,it.tcy,it.zt]), ey=pr([it.cx,it.tcy+1,it.zt]);
      var m=[ex[0]-o[0],ex[1]-o[1],ey[0]-o[0],ey[1]-o[1],o[0],o[1]].map(function(v){ return Math.round(v*1e4)/1e4 }).join(' ');
      g+='<g class="lg" transform="matrix('+m+')" fill="'+col.ink+'" text-anchor="middle" data-tw="'+f1(it.tw)+'" data-td="'+f1(it.td)+'" data-ink2="'+col.ink2+'" data-hi="'+col.hi+'" data-hio="'+col.hiO+'" data-dx="'+col.dx+'" data-dy="'+col.dy+'"></g>';
      g+='</g>';
      out+=g;
      keys.push({id:it.id,kind:it.kind,text:it.text,tw:it.tw,td:it.td,u:it.u,cx:it.cx,cy:it.cy,ri:it.ri,ci:it.ci});
    });
    /* the front rim stands higher than the plate, so it hides the bottom of the front keys: draw it last */
    var rx0=x0+22, rx1=x1-22;
    out+='<path d="'+pathOf([pr([ix0,iy1,H]),pr([ix1,iy1,H]),pr([rx1+8,y1-2,H]),pr([rx0-8,y1-2,H])])+'" fill="url(#'+uid+'cr)"/>';
    out+='<path d="'+pathOf([pr([rx0,y1,H]),pr([rx1,y1,H]),pr([rx1,y1,0]),pr([rx0,y1,0])])+'" fill="url(#'+uid+'cf)"/>';
    out+='<path d="'+pathOf([pr([rx0,y1,H]),pr([rx1,y1,H])])+'" stroke="#d9dde3" stroke-opacity=".55" stroke-width="1.2" fill="none"/>';
    out+='<path d="'+pathOf([pr([ix0,iy1,H]),pr([ix1,iy1,H])])+'" stroke="#0c0d10" stroke-width="1.2" fill="none"/>';
    var pad=14, vb=[f1(bb[0]-pad),f1(bb[1]-pad),f1(bb[2]-bb[0]+2*pad),f1(bb[3]-bb[1]+2*pad)];
    defs+='<filter id="'+uid+'bl" x="-20%" y="-60%" width="140%" height="220%"><feGaussianBlur stdDeviation="18"/></filter>';
    defs+='<filter id="'+uid+'bl2" x="-5%" y="-10%" width="110%" height="130%"><feGaussianBlur stdDeviation="3.2"/></filter>';
    function stops(arr,offs){ return arr.map(function(c,n){ return '<stop offset="'+offs[n]+'" stop-color="'+c+'"/>' }).join('') }
    defs+='<linearGradient id="'+uid+'cs" x1="0" y1="0" x2="0" y2="1">'+stops(TH.cs,[0,.18,.6,1])+'</linearGradient>';
    defs+='<linearGradient id="'+uid+'cf" x1="0" y1="0" x2="0" y2="1">'+stops(TH.cf,[0,.12,.55,1])+'</linearGradient>';
    defs+='<linearGradient id="'+uid+'cr" x1="0" y1="0" x2="1" y2="1">'+stops(TH.cr,[0,.22,.45,.62,1])+'</linearGradient>';
    defs+='<linearGradient id="'+uid+'rim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".65"/><stop offset=".5" stop-color="#fff" stop-opacity=".12"/><stop offset="1" stop-color="#000" stop-opacity=".5"/></linearGradient>';
    ['alpha','mod','accent'].forEach(function(k){
      var cl=COL[k], t=cl.top;
      defs+='<linearGradient id="'+uid+'t'+k+'" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="'+t[0]+'"/><stop offset=".38" stop-color="'+t[1]+'"/><stop offset=".62" stop-color="'+t[2]+'"/><stop offset="1" stop-color="'+t[3]+'"/></linearGradient>';
      ['f','l','r'].forEach(function(w){ defs+='<linearGradient id="'+uid+w+k+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+cl[w][0]+'"/><stop offset="1" stop-color="'+cl[w][1]+'"/></linearGradient>' });
    });
    defs+='<radialGradient id="'+uid+'d" cx=".5" cy=".4" r=".7"><stop offset="0" stop-color="#000" stop-opacity=".14"/><stop offset=".7" stop-color="#000" stop-opacity=".03"/><stop offset="1" stop-color="#fff" stop-opacity=".3"/></radialGradient>';
    defs+='<linearGradient id="'+uid+'sh" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".3" stop-color="#fff" stop-opacity=".0"/><stop offset=".4" stop-color="#fff" stop-opacity=".34"/><stop offset=".52" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>';
    defs+='<linearGradient id="'+uid+'ch" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset=".45" stop-color="#fff" stop-opacity=".2"/><stop offset="1" stop-color="#000" stop-opacity=".38"/></linearGradient>';
    defs+='<pattern id="'+uid+'br" patternUnits="userSpaceOnUse" width="160" height="64"><image width="160" height="64" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAABACAAAAAC44CNzAAAZfElEQVR42i3Wu45t23aQ4Xbrl3GZc1bVXvtYWJaMiAlJIEHiBUAiILOERIgTROrIshzBGyAIEBKpH8EBgZ8AkVjIhuPjs9eqmnPc+qX11gjMS/zfj3+AFJgJEXyUa/vav/bBZI6QplsasNwyU5onB6aYwzS5cnAHa1ft6rWajjEgTcR5Cd3MhgvJHPRSs/3zstGGxGnOEhc8vi6aYj9Hv+px9CgQlvVjnaRgbNXRasfAMCqInsVFXA6KtSgst3b1QeuvBFN0SeuMQDkSJ/IQcwA9rtKOr7/ezqvUfVNM0muxnGS+rXMgDBLaTqmddft6Po+CHG/r7XZ7+5jItKmP9gzhV9Brh5m84TKvbwGQ0CDN2MzHGK1puzps2zYygw50/KMljVJNsg9iF0ZZIwvqWXvvOurIGUAEeoNyqDal4UnAMTAHM5pEFVT7cY0wsccYgirGNVOauFwK5uOq1tp1DD623o1jIE+PdSIQThPU1o7XwFqHnkUlQBlxDiICnG+r8PG6zmO/BoICE44GKTOTGklOQtwOTlyLmo9rWCvV2YoCDHD1gXFaM5KEeEdKU4wMigHBnlsZdW9hvi15+UDtzhGGK6z4uurxOv+mtNqdo0z32/r7abnP68IohADuo/Zar6NBxX/89v6+iqARmHpin2+R15/m0Xs5nq/za+vNiFIC7UMiu8vyuE/TPAnIlBm09GN/fX/W8tphmqEZEVm5zu69eF7WJa4/f6wRJMDVvRStwAxAJAxdsR3DitEA2L/2TmGo0AA9LgMDRvzzUlovdVjbns8DJ+wK5vPHTGb9utpV6+t5dZGwzDK/TYElTWm+kQkjuh4FyUIMMaZpiaNuBfx8bTqOK8xisD6WZZlziu282nV0v55dxBTdWaCXpkiSArMQul4XzQJyu0uIhEyE8usU6Koxdhwma1V3T5FTnuYcuXv2/YTEvNzn7LX28vr8/vmXv2yjnLV0CPN6W5Zlvn/MIRAJnidQ1zH6yA9QNXj+2F578RDvC4c543Vd+3NrnNeFAAdHl9s6L3lagw2w8nptx1Yo58jLkiLjf7uO8nruVy2deRR4+/mnt/fH/S5kV63HVbqqk17HgLqfQ8iGalMX6AYg032S6XZ/e5uF8Xq99rPU68LbkhHYu4L20fpYfvVgWu9TQDTQ0gagteZ2nn2ULoHQzYGFQ0CMaVqj5ImslYJ/mOM0TXMCdVkSjuH9qqr1qAJF0SD5OW6PRBSXO7VwiyT+/NzPUl5f27ZvRxlGcX77aQ4xyKh1EDVLdFmEYvk2TXmeEyMzYBQKi7y+9u3rNDOjHEJe4Co6Rm8d5/dbmqKepbTer706Bvxn+RZ5XadJQpbarJfKiBGGOiDpa+9ASHGNHENeo/fSrF7mkJa3bz+ty5widO16/fjldagp5EzKTNBGWEI5h5BeRcfZxc+jDAhA7+85M4QljO5Yr+rjvDoaJ6D120ck7uf1+s0vzVQP/DfCADhsIGrr2lu9iud8e5vWZUqqcF3G5DYlkzkhzYt9Ha0P7ftRjh4IYnCOKXDE48epx2svfTg4cuI4BQFeZ5THt5/e1pBW7lfpeu37c2+jW2sCdUhc75PExDqUMgNTa4P97FBP/DOSofvZynl1EcApWB/Ua9k+X1ctxZnjlHKMy/vHKjLNgowijkH36vX7Vx/7dfzomZQFMc6Pj48c3x45MCKilx7RtVUD10tBLSYYrZ6naqthEZd5yWKldCPBUmyEeYqSlznT6Fbwv8Yp6VHP57afp5qxIAmNqhhCijGjG65pONXjem6lAVO4PdZ8y8xZDNIEWq/rqvvzVapax4DqVsf0ljkt8zq7AyKBt9ZPHdW9WA4cSYgozut9nrkcalq2535qO886gNfHmqfbmhj/OCUJOYCNcl4jztM9+6iK1l2GuqmitMskoY3WFCVNt2g4SevUz6aSHMLtLRqlUF/fv47P71vpkIINQ7LWjAPH2DblLCAx09DWPQSJwimTV8tJpjkg0JRtP+rx2fB4WUAI65zkrx+PmZ1ymmeuZzm3/1OaAfkIcRzNrRcLKRCikKs5M25fFIOkWPdWXqWV43JvA9O6ZAlI8e/9gzkhi2PMkSmF0ZvWH9+P69iUmTGEnMhqI5nmHGMiH2PYMczcGbTsJ4RVuo1yfUKW34W6qyGxa4rOKRiIjX4cI6T543Gb0/qYebT2/a9/+3r92CHOt8c0LxO1pZf5c2vIZSShnNMaKT5uaXq7eWE/XcbzrLV7b6bDBy21mCx5WVNcsl2lX6/WWjV0xUASyYgA0gwuKYARu1X8k/yY8/qIYK0ez4OFsOKdimox27+2S3XEFT3fwmAxIzYj7r2fxdjGdIsIRnFa13UOhoxEzuOoIiwxeDmKR+7XUcw7oITopdRyvJ7b2TTN+fGWZF6E+7Ef1cwoWMNpSkm0KgnL70L7qxPH2fX5ckJJMZKDWyl1MPfjVcwJOU3L+v5xW++PhSmyjfoqNnx4jr2Opu2vCiHETACgx3aVPnrrGEJI0xx7qVW9bY2jUFqTh/s3HBwDCptTiJIyDD33/bnvp0ejTLxOSbzJ/2rNzbAeFRJjXtd5muk6zVs5t7Z8uBM5xmnJJOv9PoFj5oFgYZR+7PuzuJdTKcoIy0e8rcss7QTmcZ3HUT7/9tdHa80cgFMitTjXZ5jzSSQoOYugg267izeKQvPv37IgL3BcBs/n7qJAGJjGtxQcyI2iOH27rYk4oLb99TwUAGW6P4LNSfdtu8rZTQ2DIH/8PC2kxqO61QtC/+UXvXAOSBKj0cfvlaoAGG8rI57FXMTzBCTg2FvrzuTd2XXY8OWWmKKwjiTTUV5fpw/8HzkNEBbCFGkc+7X/+L9/cwzt2jCyBGttgI8o6oRCkB+PSQxnf27X2TBFAp4m9j4ArRO0oqMNiYxgvZOf1WwgGmfwKJhSBAg4HKH1rpd6q+phfUzzkiNZsylBBXcUCSHNUf5nhNGq5WmORtDaQP6YB4+BqNXgerZ2nVcbxJxymu9LtopZf9R6FR1sZ1HHmGLikMMUvK7qsb+uy8dAh/DI87rO82OONlz35+dZjk8nAru2ozZlpvz+loRkbDBaLV2vdl1hjZKn5b7Kn+tQWnK3xHVwxN6HtjYAzGKi1iVDmiPL+phAIkCaWdUotOGmU+aQY5gyOSLj9fw8ztePZx0+TkVHAlkSL48prxMzGhLoiL9iDGhQqraugByCzFOe01AmZAnuBP34/O1v9/PXgP+9I27H1QaAIzIMwJDCus5LohwlUm1eXturHZ9nrcP71QnVzdIycVPjAApotaOduK7rLAMITeswMwzQj8Y5CkHvGCStSwqZhg4Wc1NntusCLmV0cOudl3WOyMuUuDcTJhHXen0/61cNojDfbuuaqJfig1NMk1gfyK5C+YN8uJsxaa+1u2sF0iqpPXfMCzJSvIUwy2haT3YzTFOAn3heH6kfyjGOPnT/7XbVAeiD5nWeF6HsMEfgHNydo1VFLE04rVwV8V8YhggdzBF5NE+sOE9pjgIOCB0kMAoQt8o5p4ROyMiZ9VQicEdsxfQ6j21rMmdJt3lJYYqOaQ11P5Ba5SCIzETWajdXHWPIOqVJgiC017MA1GugNxgdZZTe27Ud3UKQfziuYoFpuucwzeLdKK4JBftgPcrXj9cvHQIMpChaVQ1G2S0FWlcbRHpVq0fZf2y9w+0twciL7Zep83ybGSXNyyyeAgWOYKbXpa792Lt2HeB9pCl6S4/3NaRb4MDqOLi7mSNZHwLLw42tw/VqtVzt2NUpYw9LCvn9LT1+LzG0vZJcz6+zUn0VSnlePz5umVlsaFFoe+2lgwPqEFEjoYC19NHVip8al7ws94QSGHierDgiMHo7Dc7t6/Ns9bf/2yAv6xQAx1XMWhuS5yniv+8i0MqpkcMUBSiSdR+GJDmmAG7ez2swuxHBYHJwr9vVWlPlnOK0hKHEpQcyDLe3yJFHAyjnpU2tKrJwhONsQ6+91VcNiSXdluXxcc+IQqBDqFPyNuz4Otq5Ve0G6e0WOcnf1wpEaSIKjiFG1t6u/evHYWLFWBDSEnLiHAk6LsxkQF73z69tv67P4sPRKQgFVE/Zam1Fh1LAPnzg49vtNuMY+eNmo7bB4fGWecrQS1Ujt3LWkPXg+8zLnfMEar356NpBFcnkrySteVyfVwUeDdABRh0YZ0EJaEN7++HWTdKa5Z7eZ3fvtUG8hbfp/TGLZBm1o4MAIjgLALvaOM/tx+HeGkeJ9zVHbEflGAm8X8/hvfrYNeQo19N9fPemtRoAhTwOm8Povv6cB/7HRqTO0yLkmFyRUbvYOayXy2M0WhJyhFKHtdJK7YbWW3dAhLjMIeRlmu8TyhytWWQGd+Ry1l62ZlqO0wITjGGQ8+0uMQvAeBbbf+wO+6YYiEMm5Pl2vxEGNB2gdT8GiQT818dFM/P9vmQ069u2P49jKw2WJc1vHx9vb48lGUp5btvlxHK/TVkA+uu5GdoAZvbhOhyDUIjs3XOOSKN0wjhHgChq5ezHcXwe5eqjOznGzIYx0hhwPTWiUZjWSfItxcnOITQv9ty3T/yTjzUHCtaNwREozzKupu3YOuvZznJ+fVUKhITADNhrqa7VwnJ/3G9JglCAS6dcm7G3VrqCmxE6yjLHHJAZDOwsSDZQOAozxOStwZquLv1UG0jB2yAa3fpVuw69ylgeyxzwD/drWDMJNNrgPE1E0E1gaFEgApD77aefQroFJKjH9nVctSMbT1FyVAMnAhiU8ABWGx5jjIGnya6GeB0daAxidCAeXVuTjNpsmjEkNKvl3Mu5XUrCIizTcgtAGYshi75Kk+t79a7DR7M0icHJU5qn5XF7PKZlgrof9fz83Pfj8inYEHI9ytklIiCnKQvdVjLXqtq1W3nVVvez1WMMi7e3Nc0///zt26IVbQwCzKhH+On9PuXH+5wTAEDp9dqOo7XaBoLMy7KEsZ/ntqNs+O/MtDWrx0jL/f1Xv/uRUtB+/fh8fh3WjczzPQvHqCdE3K6AELwbajP1WmoHGk55ydP09u09DuuX9q+//eV1tHY2hIEhv/10Y5AAg5GmHBBZoBZ1BHYSDJk56YWBRMCawvB6FAMw1IZ/OlACgyrInGPkps6RDBPsdbQy2vPVrW2nu6EQrfccvDftHSKNwQJuYRLA+ZZYAo+KYMBiHqaUUs4ZMUcvr+frdVrfi2JaEue3qMJ9MHL0Y79a01Y5gYccmWXsFWAMw4T4T8L7T4/7fXFgEmvA3o8KQXxKoL1B0OO5eyAjRmKg++QAEq2d+2WjqKw/PdbbPGH5+qqOgjYoQtPRSxm9XGeprfbrdSIDTdOyvL8t97clWDetPfj2UlAlNANiCWDWm1+v11maUlhW/LeRSfwqvUsSzss6M9jrexm9qYe0LOsUELXvX1fztjcKNAzdAEFIJGeokDKxg4QcbWCv0l5HUdDmMq/r/TYHN3PX89LRrkrBQSK5Di97bUpQCzB4CMOQ5wySyQYg+tAgkqYpoH+wnqX2Wr6Pejny/NOv5jzNc+B1bdtx1Ko/AYCQWT2rqgLWRuysL+cw2jpDvK2Te87Q2rWPUVwQA1t36Z/K9YDoldLEE0fCflX30ZvTnBg4pODA3qoNNQ6kWppMiDOQPE8eXSKDt0oZMOS7LG+35R7dHAZeDRokIlJigdYt3RPrUZqO3mvxwP3zvOp2EnuY1/V+v033JdGbnq39XT6MqCn2cz9UIgAJhSnOMaALAwrFKd3e8ri01307nl86wDlidezIYtorENgo1/DfFsV0u40zCOXULWQYYY7uBPVViQcwcB6Ok+sYlEKq17MoTB+/T/PH2y2NEUI/2pO19tp0AInYeUEgkPD+DR0Z+ohZoiCRl6O1AQaAMgVzAiJ3KSOmaJHQah/yj8jGCGIDCK7tPPbt65eBwjZkmSikkOfl8ZhTbK/t3D/P1nuFYMYxEBjKkoFEoA94auU0k3mK52vfFNl5itOSJxnIMGrpEET30q+X7d+fZ8UU0Sr//P64x/j+xkO8O4M2GL2psaAi/oGCOzGT8PS4x6EIGOHYy3UNvfbrUjhHmN/fv/388XabpV+1HkcHZwZADgFHSKOMcV0DqJeuiizTkkIgxjBR81n6/vUs3o7LyHDJY5gTSSQ363pVHSCCWjszEQeMcRhzIBuq8jVc1Ug43ay+AiKrw9EY1WgWiA/CAB7myX79GzuajKK9MiFzrzrPPP/q57XLlGFcpW792Aaj5+h29jTh/ktrw4141E5hlTZMy/QWY5wnIYnYr6t8ff/x9WwI7pKjCcNp0k5HJxkD/6mpwfBIDo7T+03iTJbuk3ZtvZVy9lZdIkX20Sgwc17y/LZOycfopcGo1XIUFiCurwZupcd1nQI49DZwbM/rqu1scUaVFGIi95BA8xSnBCjMoJS8u10e4TLxbbPyurReVQ3/9Khu54VITPOdPIxTfZhSSoQUFzTCXhSJJGBpbMW0mfvoiHXELJTXW4yRAX3U7bmV1mtFMrmlIL15ZIM4Z0IAZlCA6qRmlSYhIQcWYkaRZQ2QJHgp7XgW99YhkA38z027OU+32Dtyf/3Y6nkYUQimAM2IAxOhW7zfWS1G9muEEGX0un/u1+tQpzhFyje0OAuEeeI+RJhIOEysx3kd5759bk0h3d4fKTCTsJ6ln5VSYsiP0LpxjCExsdPtxujetg4w8E/ByIq6NqAIGgLl2IrF9RaZvVcdhq3qABznUbp1Mx1pme5v8zzNcwRA1D7qeZz7Wbuq4hQhhDA9HvdlnkimMEoHbWN0Nx/kWyUd0CCGeMtgnFOiclH041nbObAXGxV8ACCJ/GVHJuCIkQGJhy9vS9Djan9znNt1lfiYQ1jfVgGyzuvKw2z04/U6dgJL98xmBFdB7gagg7F9uof7O9RXv5bHjTEvCzoCGOIovT9/2Wp9vYq7XiNk27tYhSmlFPIkK0L0ZnB+dcbrqPgvc0iPGYGj0Lg8JXcWL1fHKBAiam8j3JLhNAnoNZjOvQ2I6/v7LOyOo5RrfzVC4pC91WpkQMRA4qDn1iFkjss8rUHL67iu4+swROQQOCZiQdfyugCOr+1sJDwGxpRzbyH6IPwPTgRQz94vTr3SNI0BKh8f620NNFHdtv08trN0iBFoWuc5oXYktyGRJATSbdOhY9SqANehzcPfkeA+ZQRoTXVIpJDWNIZrbb0dJcQUCSWutyXgGIRWz+1r+3q2FJHWKa73JOD4n2qrA7QBSYqofWip11VKMREcWkckMLi93SaRkOY4dPS279fVlGYZLmzDnRBFxnm27RqY87S+f3z7nZ/fpiDIcL7O77/ZjmP7OqoimQRXCYyjerxPYclhXkV7OXY1XNdpIs7r5IpWroH/HKA18O7A+f6435b1fl8i9uFtO7evsw5TMG3nZVpLbQPCbVGYYsgR3azuxUKeUg75/dstBQTmuh8Dx9UpBoZr2/ZOWnlOy31dlhQS+Tg3xfb1bO0sFOKyTNP9FrTX45fv1+vHVo2ZiWKI+CfISBkOndcIZv3q7Sw0BaKYhWwAaG3nhWsagE52nu14XecpwVkEPORu2K/G6fbzI+aZjcbVOQnFlOdlZnat59761293oDYAgXl0Ir3G/R54ClX9eLV6lKullTR9PJb3j5l9XOfZCf+IGE0B21XCRHHOkxhSa1Z7Kw1YYmACsH5tlaBoXhNijugD+94EX1s5Lg7Ga0YFCdM6xzAnbFdpBt56PSFJmBOq2lUQSiWJb7cYiTK2LpGhtN77dR0VDFPICYySgAhGOfEP6nEh970Rhzwvt/efF8lLTlnPWq/Sr3MvTa+K822elgiJzmraUPrRJXFIzDkLpwDh/SMoBdKjePm+tQGACKiGgKrgrVDOaUo5goFeh/bzGjoCdPfhgGmSeJ8RyZW4V7O6t7rhX3y7JVLT19dr387z6zm4PXfKcB0ep2W5zfOaBUcdEn1/nt0BRcAImaGcXWsD7OehKEue1rd7MCSt1yFLdF5nB9azIoPznLrGPM0C8XELbdufz+26rm7IEWHJRGDu9VAatVNOIS23G/5xNyZtHpiRRF0Q7dr2Olr1fH/cb49FnLQMvfb9eWof05ymt8cShRlr1evCaUblnAWd+j7Q1IljptEBzZ3r1+fh3jrakHVxuL0FQEnCkiesjk0loxlgv6r56D6GuBK5WTvxX/VaHcFp/fbzmqY5sJ0XJSvN3ez/b156/PR+X0NKwlCa7dt5tKHhvnAMZuPUGGzfAM5raGvaO4R8v6cwT1DU+1l0XDWsMw8j8uOXA8kkuYqgCJ6HRXFHjmmdCCVEDty3o7bjfOGflTp0IPSjDkg0gNkoz+sasF1FTbf93PYxQGS+36a8LiEKaNle2zVGNWGI2Ut3QBpXbR7Xx7Q+AgcOdjXthiSo9exaju2512bTPC1vtxyXW5puiaE01edvP4+jOtTGIimFIHFalySM/yWiQSu1Wd3qaK0NEkIKCaoiobtV5ZyEQgTDwH2/qkmor+OqdbeAkFK+/843Vl6jm1KIUzQgd4MswOSGMaJZOz0AcW8YsmjXfh5dmwIzUAzgLGiI9dTazCSzcw6UkvwFCeKwlLHBjKjHcR5xkhDkJoJmo3WgSDTfA8cchYeRSPt67a/P759fnb2Dl998SgjujAH6oDitecT7in1oiO35OrsBikwrQwrjx+u4PGZiprtXNau7pjSU5xSXx+vSNhqgdo4B6P8BEC66aSp5QssAAAAASUVORK5CYII="/></pattern>';
    var svg='<svg xmlns="http://www.w3.org/2000/svg" class="kb-svg" viewBox="'+vb.join(' ')+'" preserveAspectRatio="xMidYMid meet" role="group" aria-label="Keyboard"><defs>'+defs+'</defs>'+out+'</svg>';
    return {svg:svg,vb:vb};
  }

  /* ---------------- legends (re-drawn when the script/layout/shift changes; geometry is not rebuilt) ---------------- */
  function legends(){
    if(!svgEl) return;
    var els=svgEl.querySelectorAll('.kb-key'), L=opt.legend;
    for(var i=0;i<els.length;i++){
      var el=els[i], k=keys[i], g=el.querySelector('.lg'), tw=k.tw, td=k.td, ink2=g.getAttribute('data-ink2'), h='', lab='';
      var hi=g.getAttribute('data-hi'), hio=g.getAttribute('data-hio'), edx=+g.getAttribute('data-dx'), edy=+g.getAttribute('data-dy');
      function etch(s,x,y,size,cls,anc){ return '<text x="'+f1(x+edx)+'" y="'+f1(y+edy)+'" font-size="'+size+'" class="'+cls+' eh" fill="'+hi+'" fill-opacity="'+hio+'"'+(anc?' text-anchor="'+anc+'"':'')+'>'+esc(s)+'</text>' }
      var id=k.id, ch=id.length===1&&id!==' ';
      el.setAttribute('aria-disabled', k.kind==='mod'&&/^(Control|Meta|Alt|Fn)$/.test(id)?'true':'false');
      if(ch){
        var lg=L(id)||{}, a=lg.a||{g:id}, shId=SH[id]||(/^[a-z]$/.test(id)?id.toUpperCase():null), b=lg.b||null;
        function txt(s,x,y,size,cls,fill,anc,et){ return (et?etch(s,x,y,size,cls,anc):'')+'<text x="'+f1(x)+'" y="'+f1(y)+'" font-size="'+size+'" class="'+cls+'"'+(fill?' fill="'+fill+'"':'')+(anc?' text-anchor="'+anc+'"':'')+'>'+esc(s)+'</text>' }
        if(lg.plain){      /* plain QWERTY: the legends of an ordinary keyboard and nothing else */
          var isL=/^[a-z]$/.test(id), sh2=SH[id], hh;
          if(isL) hh=txt(id.toUpperCase(),0,7,22,'tg pl',null,null,1);
          else hh=(sh2?txt(sh2,0,-4,15,'tg pl',null,null,1):'')+txt(id,0,sh2?13:7,sh2?17:20,'tg pl',null,null,1);
          g.innerHTML='<g class="base">'+hh+'</g><g class="shf">'+hh+'</g><g class="cap">'+hh+'</g>'; continue;
        }
        function main(o,y,cls){
          var big=o.txt?10:(/^[0-9]$/.test(id)?19:20), s=o.g||'';
          if(o.cap){ return txt(s,0,y-3,o.txt?10:18,cls+' mn'+(o.sp?' sp':''),o.sp?ink2:'',null,1)+txt(o.cap,0,td/2-3,8.4,cls+' cp',ink2) }
          return txt(s,2,y+(o.txt?3:5),big,cls+' mn'+(o.sp?' sp':''),o.sp?ink2:'',null,1);
        }
        var tag=txt(id.toUpperCase(),-tw/2+3,-td/2+15,16,'tg',null,'start');
        var shSm=(b&&b.g&&b.g!==a.g)?txt(b.g,tw/2-3,-td/2+16,16,'up',ink2,'end'):'';
        h+='<g class="base">'+tag+shSm+main(a,5,'b')+'</g>';
        var b2=b||a, shTag=txt((shId||id).toUpperCase(),-tw/2+3,-td/2+15,16,'tg',null,'start');
        h+='<g class="shf">'+shTag+main(b2,5,'b')+'</g>';
        /* caps lock shows the shifted letter too, handled by CSS class on the host */
        h+='<g class="cap">'+shTag+main(b2,5,'b')+'</g>';
      }else if(id===' '){
        h='<text x="0" y="3" font-size="9" class="tg" fill-opacity=".9">'+esc(opt.spaceLabel||'space')+'</text>';
      }else{
        var big=/^Arrow/.test(id)||id==='Shift'&&opt.layout==='phone'||id==='Backspace'&&layoutName==='phone'||id==='Enter'&&layoutName==='phone';
        if(Array.isArray(k.text)){
          var t1=k.text[0], t2=k.text[1], ly=td/2-15;
          h=etch(t1,0,-2.5,9.4,'md')+'<text x="0" y="-2.5" font-size="9.4" class="md" text-anchor="middle">'+esc(t1)+'</text>'
           +'<line x1="'+f1(-tw/2+8)+'" x2="'+f1(tw/2-8)+'" y1="1.6" y2="1.6" stroke="'+g.getAttribute("fill")+'" stroke-opacity=".55" stroke-width="1" class="md-ln"/>'
           +etch(t2,0,11,8.6,'md')+'<text x="0" y="11" font-size="8.6" class="md" text-anchor="middle">'+esc(t2)+'</text>';
          g.innerHTML=h; continue;
        }
        var lab=k.text||id, st='';
        if(id==='CapsLock') st='<circle class="led" cx="'+f1(-tw/2+6)+'" cy="'+f1(-td/2+6)+'" r="2.2"/>';
        h=(id==='Shift'||id==='CapsLock'||id==='Enter'||id==='Tab'||id==='Backspace'||id==='Escape'?'':'')+st+etch(lab,/^(Shift|CapsLock|Tab|Enter|Backspace)$/.test(id)&&layoutName==='full'?-tw/2+4:0,layoutName==='full'&&/^(Shift|CapsLock|Tab|Enter|Backspace|Escape|Delete|PageUp|PageDown)$/.test(id)?td/2-5:4,big?15:9.5,'md',/^(Shift|CapsLock|Tab|Enter|Backspace)$/.test(id)&&layoutName==='full'?'start':'middle')+'<text x="'+f1(/^(Shift|CapsLock|Tab|Enter|Backspace)$/.test(id)&&layoutName==='full'?-tw/2+4:0)+'" y="'+f1(layoutName==='full'&&/^(Shift|CapsLock|Tab|Enter|Backspace|Escape|Delete|PageUp|PageDown)$/.test(id)?td/2-5:4)+'" font-size="'+(big?15:9)+'" class="md" text-anchor="'+(/^(Shift|CapsLock|Tab|Enter|Backspace)$/.test(id)&&layoutName==='full'?'start':'middle')+'">'+esc(lab)+'</text>';
      }
      g.innerHTML=h;
    }
    applyState();
  }
  function applyState(){
    if(!svgEl) return;
    var on=(shiftMode>0||physShift);
    svgEl.classList.toggle('sh',on); svgEl.classList.toggle('cl',shiftMode===2&&false);
    var sb=svgEl.querySelectorAll('.kb-key[data-k="Shift"]'); for(var i=0;i<sb.length;i++) sb[i].classList.toggle('on',on);
    var cb=svgEl.querySelector('.kb-key[data-k="CapsLock"]'); if(cb) cb.classList.toggle('on',capsLock);
    svgEl.classList.toggle('caps',capsLock);
  }
  var capsLock=false;

  /* ---------------- build into host ---------------- */
  function render(){
    var r=build();
    host.innerHTML=r.svg; svgEl=host.querySelector('svg'); self.svg=svgEl;
    svgEl.style.width=(zoom*100)+'%';
    var first=null, els=svgEl.querySelectorAll('.kb-key');
    for(var i=0;i<els.length;i++){ if(!first&&/^[a-z]$/.test(keys[i].id)){ first=els[i]; first.setAttribute('tabindex','0') } }
    legends();
    ariaLabels();
  }
  function ariaLabels(){
    var els=svgEl.querySelectorAll('.kb-key'), L=opt.legend;
    for(var i=0;i<els.length;i++){
      var k=keys[i], id=k.id, s;
      if(id.length===1&&id!==' '){ var lg=L(id)||{}, a=lg.a||{g:id}, b=lg.b; s='Key '+id+' types '+(a.g||id)+(b&&b.g&&b.g!==a.g?'; with Shift '+b.g:''); if(lg.aria) s=lg.aria }
      else s={' ':'Space',Escape:'Escape',Backspace:'Backspace',Delete:'Delete',Enter:'Enter',Tab:'Tab',CapsLock:'Caps lock',Shift:'Shift',ArrowUp:'Arrow up',ArrowDown:'Arrow down',ArrowLeft:'Arrow left',ArrowRight:'Arrow right',PageUp:'Page up',PageDown:'Page down'}[id]||k.text||id;
      els[i].setAttribute('aria-label',s);
    }
  }

  /* ---------------- tooltip ---------------- */
  function showTip(el){
    if(!opt.tip) return; var k=el.getAttribute('data-k'); if(!(k.length===1&&k!==' ')){ hideTip(); return }
    var h=opt.tip(k); if(!h){ hideTip(); return }
    if(!tipEl){ tipEl=document.createElement('div'); tipEl.className='kb-tip'; tipEl.setAttribute('aria-hidden','true'); document.body.appendChild(tipEl) }
    tipEl.innerHTML=h; tipEl.style.display='block';
    var r=el.getBoundingClientRect(), tw=tipEl.offsetWidth, th=tipEl.offsetHeight, vw=document.documentElement.clientWidth, vh=document.documentElement.clientHeight;
    var x=r.left+r.width/2-tw/2, y=r.top-th-10; if(y<6) y=r.bottom+10; if(y+th>vh-6) y=Math.max(6,vh-th-6);
    x=Math.max(6,Math.min(vw-tw-6,x)); tipEl.style.left=x+'px'; tipEl.style.top=y+'px';
  }
  function hideTip(){ clearTimeout(tipTimer); if(tipEl) tipEl.style.display='none' }

  /* ---------------- long-press popup: matras, rare letters and common conjuncts of a key ---------------- */
  var down=null;
  function altsFor(el){
    if(!opt.alts||!opt.onText) return null;
    var id=el.getAttribute('data-k'); if(!id||id.length!==1) return null;
    var a=opt.alts(/^[A-Za-z]$/.test(id)?id.toLowerCase():id); return a&&a.length?a:null;
  }
  function lpOpen(el,list,e0){
    hideTip();
    pickPopup(el,list,e0,function(t){ down=null; if(t!==null) opt.onText(t,el) });
  }

  /* ---------------- interaction ---------------- */
  function keyOf(t){ return t&&t.closest?t.closest('.kb-key'):null }
  function fire(el,ev,viaTouch){
    var id=el.getAttribute('data-k'); if(el.getAttribute('aria-disabled')==='true') return;
    el.classList.add('dn'); setTimeout(function(){ el.classList.remove('dn') },140);
    if(id==='Shift'){ shiftMode=shiftMode?0:1; applyState(); if(opt.onShift) opt.onShift(shiftMode); return }
    if(id==='CapsLock'){ capsLock=!capsLock; applyState(); if(opt.onCaps) opt.onCaps(capsLock); return }
    var sh=(shiftMode>0||physShift||(ev&&ev.shiftKey)), key=id;
    if(id.length===1&&id!==' '){ if(/^[a-z]$/.test(id)){ if(sh!==capsLock) key=id.toUpperCase() } else if(sh&&SH[id]) key=SH[id] }
    if(shiftMode===1){ shiftMode=0; applyState(); if(opt.onShift) opt.onShift(0) }
    if(opt.onKey) opt.onKey(key,sh,el,ev);
  }
  function wire(){
    var pressTimer=0, longDone=false;
    host.addEventListener('pointerdown',function(e){
      var el=keyOf(e.target); if(!el) return; e.preventDefault(); host.setPointerCapture&&0;
      var touch=e.pointerType==='touch'||e.pointerType==='pen'; longDone=false; down=el;
      var al=altsFor(el);
      if(!touch&&!al){ fire(el,e) } else { clearTimeout(pressTimer);
        pressTimer=setTimeout(function(){ longDone=true; if(al&&opt.onText){ lpOpen(el,al,e) } else { showTip(el); if(opt.onHover) opt.onHover(el.getAttribute('data-k'),el); tipTimer=setTimeout(hideTip,6000) } },al?360:450) }
    });
    host.addEventListener('pointerup',function(e){
      var el=keyOf(e.target); clearTimeout(pressTimer);
      if(lpEl){ down=null; return }                                  /* the popup has its own listeners */
      if(e.pointerType==='mouse'&&!(el&&el===down&&altsFor(el))){ down=null; return }
      if(el&&el===down&&!longDone) fire(el,e,true);
      down=null;
    });
    host.addEventListener('pointercancel',function(){ clearTimeout(pressTimer); down=null });
    host.addEventListener('pointerleave',function(){ clearTimeout(pressTimer) });
    host.addEventListener('mouseover',function(e){ var el=keyOf(e.target); if(el){ showTip(el); if(opt.onHover) opt.onHover(el.getAttribute('data-k'),el) } });
    host.addEventListener('mouseout',function(e){ var el=keyOf(e.target); if(el&&!keyOf(e.relatedTarget)){ hideTip(); if(opt.onHover) opt.onHover(null) } });
    host.addEventListener('focusin',function(e){ var el=keyOf(e.target); if(el){ showTip(el); if(opt.onHover) opt.onHover(el.getAttribute('data-k'),el); lastFocus=el } });
    host.addEventListener('focusout',function(e){ hideTip() });
    host.addEventListener('contextmenu',function(e){ if(keyOf(e.target)) e.preventDefault() });
    host.addEventListener('keydown',function(e){
      var el=keyOf(e.target); if(!el) return;
      if(e.key==='Enter'||e.key===' '){ e.preventDefault(); fire(el,e); return }
      var dx=0,dy=0; if(e.key==='ArrowRight')dx=1; else if(e.key==='ArrowLeft')dx=-1; else if(e.key==='ArrowDown')dy=1; else if(e.key==='ArrowUp')dy=-1; else return;
      e.preventDefault();
      var i=+el.getAttribute('data-i'), a=keys[i], best=-1, bd=1e9;
      keys.forEach(function(b,j){ if(j===i) return; var vx=b.cx-a.cx, vy=b.cy-a.cy; if(dx&&(vx*dx<=2||Math.abs(vy)>P*.6)) return; if(dy&&(vy*dy<=2||Math.abs(vx)>P*1.5)) return; var d=vx*vx+vy*vy; if(d<bd){ bd=d; best=j } });
      if(best>=0){ var els=svgEl.querySelectorAll('.kb-key'); [].forEach.call(els,function(x){x.setAttribute('tabindex','-1')}); els[best].setAttribute('tabindex','0'); els[best].focus() }
    });
  }
  wire();

  /* ---------------- public ---------------- */
  self.render=function(){ render() };
  self.legends=function(){ legends(); ariaLabels() };
  self.setLayout=function(n){ if(n!==layoutName&&LAY[n]){ layoutName=n; render() } };
  self.layout=function(){ return layoutName };
  self.setDevice=function(d){ devPref=d; var n=resolve(d); if(n!==themeName){ themeName=n; render() } return themeName };
  self.device=function(){ return themeName };
  self.deviceLabel=function(){ return THEMES[themeName].label };
  self.setZoom=function(z){ zoom=Math.max(.4,Math.min(2.4,z)); if(svgEl) svgEl.style.width=(zoom*100)+'%' };
  self.getZoom=function(){ return zoom };
  self.shift=function(on){ physShift=!!on; applyState() };
  self.clearShift=function(){ shiftMode=0; physShift=false; applyState() };
  self.keyEl=function(k){
    if(!svgEl) return null; var id=k;
    if(k.length===1&&k!==' '){ id=k.toLowerCase(); for(var s in SH) if(SH[s]===k) id=s }
    if(k==='>') id='.';
    return svgEl.querySelector('.kb-key[data-k="'+id.replace(/(["\\])/g,'\\$1')+'"]');
  };
  self.down=function(k,on){ var el=self.keyEl(k); if(el) el.classList.toggle('dn',!!on); return el };
  self.hideTip=hideTip;
  self.destroy=function(){ hideTip(); if(tipEl&&tipEl.parentNode) tipEl.parentNode.removeChild(tipEl); host.innerHTML='' };
  render();
  return self;
}
var ALTS={"b":["ବ","ଭ","ବ୍ୟ","ବ୍ର","ବ୍ଲ","ଭ୍ର","ଭ୍ୟ","ବ୍ଦ","ବ୍ଧ"],"c":["ଚ","ଛ","ଚ୍ଛ","ଚ୍ଚ","ଚ୍ୟ","ଚ୍ର","ଚ୍କ","ଚ୍ଥ","ଚ୍ପ"],"d":["ଦ","ଧ","ଡ","ଢ","ଦ୍ୱ","ଦ୍ଧ","ଦ୍ର","ଦ୍ୟ","ଧ୍ୟ","ଡ୍ର","ଦ୍ଦ"],"f":["ଫ","ଫ୍ର","ଫ୍ଲ","ଫ୍ଟ","ଫ୍ୟ","ଫ୍ସ","ଫ୍କ","ଫ୍ତ"],"g":["ଗ","ଘ","ଙ","ଙ୍କ","ଙ୍ଗ","ଗ୍ର","ଗ୍ନ","ଗ୍ୟ","ଙ୍ଖ","ଗ୍ଲ"],"h":["ହ","ଃ","ହ୍ମ","ହ୍ନ","ହ୍ୟ","ହ୍ଲ","ହ୍ୱ","ହ୍ର"],"j":["ଜ","ଝ","ଞ","ଯ","ଞ୍ଚ","ଞ୍ଜ","ଜ୍ଞ","ଜ୍ୟ","ଜ୍ଜ","ଜ୍ର","ଯ୍ୟ"],"k":["କ","ଖ","କ୍ଷ","କ୍ତ","କ୍ର","କ୍ସ","କ୍ୟ","କ୍ଟ","ଖ୍ୟ"],"l":["ଲ","ଳ","ଌ","ୢ","ୡ","ୣ","ଲ୍ଲ","ଲ୍ୟ","ଳ୍ପ","ଲ୍ର","ଲ୍ଟ","ଲ୍ସ"],"m":["ମ","ଂ","ଁ","ଃ","ମ୍ବ","ମ୍ପ","ମ୍ଭ","ମ୍ୟ","ମ୍ମ","ମ୍ର"],"n":["ନ","ଣ","ଙ","ଞ","ଙ୍କ","ନ୍ତ","ଙ୍ଗ","ଣ୍ଡ","ନ୍ଦ","ଣ୍ଟ","ଞ୍ଚ"],"p":["ପ","ଫ","ପ୍ର","ପ୍ତ","ପ୍ଲ","ଫ୍ର","ପ୍ୟ","ଫ୍ଲ","ପ୍ଟ"],"q":["କ","କ୍ଷ","କ୍ତ","କ୍ର","କ୍ସ","କ୍ୟ","କ୍ଟ","କ୍ଲ"],"r":["ର","ଋ","ୃ","ୠ","ୄ","ର୍ମ","ର୍ବ","ର୍ଥ","ର୍ଗ","ର୍କ","ର୍ଟ","ର୍ଷ"],"s":["ସ","ଶ","ଷ","ଷ୍ଟ","ସ୍ତ","ସ୍ଥ","ସ୍ୱ","ଶ୍ର","ଶ୍ୱ","ସ୍କ"],"t":["ତ","ଥ","ଟ","ଠ","ତ୍ର","ତ୍ତ","ତ୍ୟ","ଟ୍ର","ତ୍ୱ","ତ୍ସ","ତ୍ମ"],"v":["ଵ","ବ","ଭ","ବ୍ୟ","ବ୍ର","ବ୍ଲ","ଭ୍ର","ଭ୍ୟ","ବ୍ଦ","ବ୍ଧ"],"w":["ୱ","ଵ"],"x":["କ୍ଷ","କ୍ଷ୍ମ","କ୍ଷ୍ଣ","କ୍ଷ୍ୟ"],"y":["ୟ","ଯ","ଯ୍ୟ"],"a":["ଅ","ଆ","ା","ଁ","ଽ"],"i":["ଇ","ଈ","ି","ୀ"],"u":["ଉ","ଊ","ୁ","ୂ"],"e":["ଏ","ଐ","େ","ୈ"],"o":["ଓ","ଔ","ୋ","ୌ"],"'":["ଽ","୰","ୖ","ୗ"],"z":["‌","‍","୍","୍‌"]};
return {pickPopup:pickPopup,create:create,SHIFT:SH,LAYOUTS:LAY,THEMES:THEMES,detect:detect,ALTS:ALTS};
})();

/* ସୁलेখk floating-panel controller: dock in the page, detach and drag anywhere, pin to the top or bottom edge,
   resize from the four corners, collapse, and a phone-size view. State survives reloads (localStorage, best effort). */
var SKWin=(function(){
'use strict';
function attach(o){
  var el=o.el, head=o.head, body=o.body, KEY=o.key||'sulekhakPanel', S={mode:'dock',x:40,y:80,w:760,h:0,open:true,mobile:false,mw:0};
  var MIN_W=o.minW||300, MIN_H=o.minH||150, ro=null, saved=null;
  try{ var v=JSON.parse(localStorage.getItem(KEY)||'null'); if(v&&typeof v==='object'){ ['mode','x','y','w','h','open','mobile'].forEach(function(k){ if(v[k]!==undefined) S[k]=v[k] }); if(['dock','float','top','bot'].indexOf(S.mode)<0) S.mode='dock' } }catch(e){}
  function save(){ try{ localStorage.setItem(KEY,JSON.stringify({mode:S.mode,x:S.x,y:S.y,w:S.w,h:S.h,open:S.open,mobile:S.mobile})) }catch(e){} }
  function vw(){ return document.documentElement.clientWidth }
  function vh(){ return window.innerHeight||document.documentElement.clientHeight }
  function clamp(){
    if(S.mode!=='float') return;
    S.w=Math.max(MIN_W,Math.min(vw()-8,S.w)); if(S.h) S.h=Math.max(MIN_H,Math.min(vh()-8,S.h));
    S.x=Math.max(-S.w+90,Math.min(vw()-90,S.x)); S.y=Math.max(0,Math.min(vh()-44,S.y));
  }
  function pad(){
    var d=document.documentElement.style;
    d.setProperty('--kwtop',S.mode==='top'?el.offsetHeight+'px':'0px'); d.setProperty('--kwbot',S.mode==='bot'?el.offsetHeight+'px':'0px');
  }
  function apply(){
    clamp();
    el.classList.toggle('kw-float',S.mode==='float'); el.classList.toggle('kw-top',S.mode==='top'); el.classList.toggle('kw-bot',S.mode==='bot');
    el.classList.toggle('kw-closed',!S.open); el.classList.toggle('kw-mobile',S.mobile);
    el.style.left=el.style.top=el.style.width=el.style.height='';
    if(S.mode==='float'){ el.style.left=S.x+'px'; el.style.top=S.y+'px'; el.style.width=(S.mobile?Math.min(S.w,420):S.w)+'px'; if(S.h&&S.open) el.style.height=S.h+'px' }
    if(body) body.hidden=!S.open;
    var hs=el.querySelectorAll('.kw-rz'); for(var i=0;i<hs.length;i++) hs[i].hidden=S.mode!=='float'||!S.open;
    pad(); if(o.onChange) o.onChange(S);
  }
  /* corner handles */
  ['nw','ne','sw','se'].forEach(function(c){ var h=document.createElement('span'); h.className='kw-rz kw-'+c; h.setAttribute('data-c',c); h.setAttribute('aria-hidden','true'); h.hidden=true; el.appendChild(h) });
  function drag(e,kind,corner){
    if(e.button!==undefined&&e.button!==0) return; e.preventDefault();
    var sx=e.clientX, sy=e.clientY, r=el.getBoundingClientRect(), x0=r.left, y0=r.top, w0=r.width, h0=r.height, id=e.pointerId;
    S.x=x0; S.y=y0; S.w=w0; if(kind==='size'&&!S.h) S.h=h0;
    el.classList.add('kw-drag');
    function mv(ev){
      var dx=ev.clientX-sx, dy=ev.clientY-sy;
      if(kind==='move'){ S.x=x0+dx; S.y=y0+dy }
      else{
        var nx=x0, ny=y0, nw=w0, nh=h0;
        if(corner.indexOf('e')>=0) nw=Math.max(MIN_W,w0+dx);
        if(corner.indexOf('w')>=0){ nw=Math.max(MIN_W,w0-dx); nx=x0+(w0-nw) }
        if(corner.indexOf('s')>=0) nh=Math.max(MIN_H,h0+dy);
        if(corner.indexOf('n')>=0){ nh=Math.max(MIN_H,h0-dy); ny=y0+(h0-nh) }
        S.x=nx; S.y=ny; S.w=nw; S.h=nh;
      }
      clamp(); el.style.left=S.x+'px'; el.style.top=S.y+'px'; el.style.width=S.w+'px'; if(kind==='size'&&S.h) el.style.height=S.h+'px';
      if(o.onResize) o.onResize(S);
    }
    function up(){ window.removeEventListener('pointermove',mv); window.removeEventListener('pointerup',up); window.removeEventListener('pointercancel',up); el.classList.remove('kw-drag'); save(); if(o.onChange) o.onChange(S) }
    window.addEventListener('pointermove',mv); window.addEventListener('pointerup',up); window.addEventListener('pointercancel',up);
  }
  head.addEventListener('pointerdown',function(e){
    if(S.mode!=='float'||e.target.closest('button,input,select,a,.kg-tools')) return; drag(e,'move');
  });
  head.addEventListener('dblclick',function(e){ if(e.target.closest('button,input,select,a')) return; api.toggleOpen() });
  el.addEventListener('pointerdown',function(e){ var h=e.target.closest('.kw-rz'); if(h&&S.mode==='float') drag(e,'size',h.getAttribute('data-c')) });
  head.addEventListener('keydown',function(e){
    if(S.mode!=='float'||e.target!==head) return;
    var d=e.shiftKey?40:12, dx=0, dy=0; if(e.key==='ArrowLeft')dx=-d; else if(e.key==='ArrowRight')dx=d; else if(e.key==='ArrowUp')dy=-d; else if(e.key==='ArrowDown')dy=d; else return;
    e.preventDefault(); if(e.altKey){ S.w+=dx; if(!S.h) S.h=el.offsetHeight; S.h+=dy } else { S.x+=dx; S.y+=dy } apply(); save();
  });
  window.addEventListener('resize',function(){ clamp(); if(S.mode==='float'){ el.style.left=S.x+'px'; el.style.top=S.y+'px'; el.style.width=S.w+'px' } pad() });
  if(window.ResizeObserver){ ro=new ResizeObserver(function(){ if(S.mode==='top'||S.mode==='bot') pad() }); ro.observe(el) }
  var api={
    state:function(){ return S },
    mode:function(){ return S.mode },
    setMode:function(m){
      if(m===S.mode) m='dock';
      if(m==='float'&&S.mode!=='float'){ S.w=Math.max(MIN_W,Math.min(vw()-24,S.mobile?420:660)); S.h=0; S.x=Math.max(8,vw()-S.w-24); S.y=Math.max(8,Math.min(70,vh()-200)) }
      S.mode=m; apply(); save();
    },
    toggleOpen:function(){ S.open=!S.open; apply(); save() },
    setOpen:function(v){ S.open=!!v; apply(); save() },
    toggleMobile:function(){ S.mobile=!S.mobile; if(S.mobile&&S.mode==='float'){ S.w=Math.min(S.w,420); S.h=0 } apply(); save() },
    reset:function(){ S.mode='dock'; S.open=true; S.h=0; apply(); save() },
    refresh:function(){ apply() }
  };
  apply();
  return api;
}
return {attach:attach};
})();
