/* Sulekhak English: word suggestions, completion, spelling correction, next-word prediction and swipe typing.
   Pure JavaScript, no input/output: the page gives it the three data files (text) and asks questions. Runs in a browser page, a worker and node.

     var E = SulekhakEnglish.create();
     E.load({ lex: <en_lex.txt>, ng: <en_ng.txt>, fix: <en_fix.txt> });
     E.suggest('teh', 'in')      -> { list:['the','teh',...], auto:1 }    list[0] is what the space key commits; auto:1 = list[1] is the text as typed
     E.next('thank')             -> ['you', ...]        E.next('thank you') / E.suggest('ver', 'thank you')  use the two words before the cursor (rows 'w1 w2' in the table)
     E.note(word, prev)          the host committed `word` after `prev`: a later question that gives only `word` still has two words of context
     E.swipe({k:{a:[x,y],...}, p:[[x,y,ms],...]}, prev, 10) -> ['hello', ...]      (lengths in key-widths)
     E.addUser(word, zipf100) / E.addFix(typed, fixed)  : what this person has taught it (see personal.js)

   Data (made by build_en.py):  en_lex.txt  form <TAB> zipf*100 [<TAB> flags]  sorted by lower-case form (capitals only where a word is a name or an acronym)
                                en_ng.txt   w1 <TAB> w2:q w2:q ...   (q = round(-ln P(w2|w1) * 10), "<s>" = sentence start)
                                            "w1 w2" <TAB> *L w3:q w3:q ...  (three-word rows: L = percent of the probability the three-word counts own, q as above)
                                en_fix.txt  typed <TAB> fixed        (common misspellings, missing apostrophes)                                    */
(function (root, factory) {
  var m = factory();
  if (typeof module === 'object' && module.exports) module.exports = m;
  root.SulekhakEnglish = m;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var LN10 = 2.302585092994046;

  /* ---- the QWERTY keys (rows are offset like a real keyboard): used for "this key is next to that one" ---- */
  var ROWS = ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'], KX = {}, KY = {};
  ROWS.forEach(function (r, ri) { for (var i = 0; i < r.length; i++) { KX[r[i]] = i + (ri === 1 ? 0.25 : ri === 2 ? 0.75 : 0); KY[r[i]] = ri; } });
  function adjacent(a, b) { if (!(a in KX) || !(b in KX)) return false; var dx = KX[a] - KX[b], dy = KY[a] - KY[b]; return dx * dx + dy * dy <= 1.6; }
  var NEAR = {};
  (function () { var a, b; for (a in KX) { NEAR[a] = []; for (b in KX) if (a !== b && adjacent(a, b)) NEAR[a].push(b); } })();
  var VOWEL = { a: 1, e: 1, i: 1, o: 1, u: 1 };

  function create() {
    var low = [], form = null, cased = Object.create(null), Z = null, LEN = null, PU = null, N = 0;
    var ngIndex = Object.create(null), ngCache = Object.create(null);
    var fix = Object.create(null);
    var uMap = Object.create(null), uList = [];                   /* the words this person has taught it */
    var alt = [];                                                 /* forms with a leading apostrophe ('cause, 'em) or a hyphen (bag-of-words), found by their plain letters: cause, em, bagofwords */
    var common = null;                                            /* words ordinary enough to be offered as a correction, by first letter */
    var fe = null;                                                /* swipe index: first letter x last letter -> word numbers */
    var ready = false;
    var ENDW = 0.8;
    var LENPEN = 0.05;
    var ALPHA = 5.0;                                              /* nats per unit of spelling-mistake cost */
    var BETA = 7.0;                                               /* nats per key-width of swipe-path distance */
    var MU3 = 1.0;                                                /* scale of the three-word weight */
    var LAMBDA = 0.8;                                             /* weight of the bigram in the mix with the word's own frequency */
    var AUTO = { lim4: 1.0, lim5: 1.5, margin: 0.5, minZ: 250, pre: 1, strict: 1, minLen: 4 };

    /* ------------------------------------------------------------ loading */
    function load(o) {
      var lines = o.lex.split('\n'), i, t, ln, f, t2;
      low = []; cased = Object.create(null); var zs = [];
      for (i = 0; i < lines.length; i++) {
        ln = lines[i]; if (!ln) continue;
        t = ln.indexOf('\t'); if (t < 0) continue;
        f = ln.substr(0, t); t2 = ln.indexOf('\t', t + 1);
        var z = +(t2 < 0 ? ln.substr(t + 1) : ln.substr(t + 1, t2 - t - 1));
        var lw = f.toLowerCase();
        if (lw !== f) cased[low.length] = f;
        low.push(lw); zs.push(z);
      }
      N = low.length;
      var ord = true; for (i = 1; i < N; i++) if (low[i - 1] > low[i]) { ord = false; break; }
      if (!ord) {                                                 /* the file is meant to be sorted; if it is not, sort it here */
        var ix = []; for (i = 0; i < N; i++) ix.push(i);
        ix.sort(function (a, b) { return low[a] < low[b] ? -1 : low[a] > low[b] ? 1 : 0; });
        var l2 = [], z2 = [], c2 = Object.create(null);
        for (i = 0; i < N; i++) { l2.push(low[ix[i]]); z2.push(zs[ix[i]]); if (cased[ix[i]]) c2[i] = cased[ix[i]]; }
        low = l2; zs = z2; cased = c2;
      }
      Z = new Int16Array(zs); LEN = new Uint8Array(N); PU = new Float32Array(N);
      for (i = 0; i < N; i++) { LEN[i] = Math.min(255, low[i].length); PU[i] = Math.exp((Z[i] / 100 - 9) * LN10); }
      ngIndex = Object.create(null); ngCache = Object.create(null); tgCache = Object.create(null);
      if (o.ng) { var g = o.ng.split('\n'); for (i = 0; i < g.length; i++) { t = g[i].indexOf('\t'); if (t > 0) ngIndex[g[i].substr(0, t)] = g[i].substr(t + 1); } }
      fix = Object.create(null);
      if (o.fix) { var x = o.fix.split('\n'); for (i = 0; i < x.length; i++) { t = x[i].indexOf('\t'); if (t > 0) fix[x[i].substr(0, t)] = x[i].substr(t + 1); } }
      common = {}; for (i = 0; i < N; i++) if (Z[i] >= 200) { var c0 = low[i].charAt(0); (common[c0] || (common[c0] = [])).push(i); }
      alt = [];
      for (i = 0; i < N; i++) { var aw = low[i]; if (aw.charAt(0) === "'" || aw.indexOf('-') > 0) alt.push({ k: aw.replace(/^'/, '').replace(/-/g, ''), h: aw.indexOf('-') > 0 ? aw.substr(0, aw.indexOf('-')) : '', i: i }); }
      alt.sort(function (a, b) { return a.k < b.k ? -1 : a.k > b.k ? 1 : 0; });
      fe = null; ready = true;
      return N;
    }

    /* ------------------------------------------------------------ lookups */
    function lb(s) { var lo = 0, hi = N; while (lo < hi) { var m = (lo + hi) >> 1; if (low[m] < s) lo = m + 1; else hi = m; } return lo; }
    function find(s) { var i = lb(s); return i < N && low[i] === s ? i : -1; }
    function formOf(i) { return cased[i] || low[i]; }
    function known(s) { return find(s) >= 0 || !!uMap[s]; }
    function zipfOf(s) { var i = find(s); if (i >= 0) return Z[i]; var u = uMap[s]; return u ? u.z : -1; }

    /* P(w2 | w1) from the bigram table, as a map word -> probability */
    function bigrams(prev) {
      if (!prev) return null;
      var c = ngCache[prev]; if (c !== undefined) return c;
      var row = ngIndex[prev], m = null;
      if (row) { m = Object.create(null); var p = row.split(' '); for (var i = 0; i < p.length; i++) { var k = p[i].lastIndexOf(':'); if (k > 0) m[p[i].substr(0, k)] = Math.exp(-(+p[i].substr(k + 1)) / 10); } }
      ngCache[prev] = m; return m;
    }
    /* the two words before the cursor: `prev` is "w1 w2" (or just "w2", or "<s>" at the start of a sentence).  The table holds rows "w1 w2<TAB>*L w3:q ..." beside the
       one-word rows; L (percent) is how much of the probability the three-word counts own (the rest is handed down to the one-word model), see build_lm.py */
    var tgCache = Object.create(null), noteW = '', noteP = '';
    function trigrams(key) {
      var c = tgCache[key]; if (c !== undefined) return c;
      var row = ngIndex[key], m = null;
      if (row && row.charAt(0) === '*') {
        var p = row.split(' '), L = (+p[0].substr(1)) / 100;
        if (L > 0) { m = { m: Object.create(null), L: Math.min(0.95, L * MU3) }; for (var i = 1; i < p.length; i++) { var k = p[i].lastIndexOf(':'); if (k > 0) m.m[p[i].substr(0, k)] = Math.exp(-(+p[i].substr(k + 1)) / 10); } }
      }
      tgCache[key] = m; return m;
    }
    function context(prev) {
      var p1 = '', p2 = '';
      if (prev) {
        prev = String(prev).toLowerCase().replace(/^\s+|\s+$/g, '');
        var sp = prev.lastIndexOf(' ');
        if (sp > 0) { p2 = prev.substr(0, sp).replace(/^.* /, ''); p1 = prev.substr(sp + 1); } else p1 = prev;
      }
      if (p1 && !p2 && p1 === noteW && noteP) p2 = noteP;           /* the host passes only the last word: the engine remembers the one before it (note) */
      var cx = p1 ? bigrams(p1) : null, tg = p1 && p2 ? trigrams(p2 + ' ' + p1) : null;
      return {
        cx: cx, tg: tg,
        p: function (lw, pu) {                                       /* P(lw | the words before): the three-word counts over the one-word mix over the word's own frequency */
          var pb = cx ? cx[lw] : undefined, base = (pb !== undefined ? LAMBDA * pb : 0) + (cx ? 1 - LAMBDA : 1) * pu;
          if (!tg) return base;
          var p3 = tg.m[lw];
          return tg.L * (p3 === undefined ? 0 : p3) + (1 - tg.L) * base;
        },
        each: function (fn) {                                        /* every word either table names */
          var k; if (tg) for (k in tg.m) fn(k); if (cx) for (k in cx) if (!tg || tg.m[k] === undefined) fn(k);
        }
      };
    }
    function note(word, prev) {                                      /* the host committed `word` after `prev` (one word): the next question about `word` has two words of context */
      noteW = word ? String(word).toLowerCase() : ''; noteP = prev && prev !== '<s>' ? String(prev).toLowerCase().replace(/^.* /, '') : (prev === '<s>' ? '<s>' : '');
    }

    /* ------------------------------------------------------------ the cost of turning what was typed into a word (Damerau-Levenshtein with keyboard-aware costs) */
    var D0 = new Float64Array(40), D1 = new Float64Array(40), D2 = new Float64Array(40);
    var STRICT = false;
    function subCost(a, b) { if (a === b) return 0; if (adjacent(a, b)) return 0.6; if (VOWEL[a] && VOWEL[b]) return STRICT ? 1.3 : 0.8; return STRICT ? 1.8 : 1; }
    function edCost(t, w, max) {                                   /* t: typed, w: the word; returns > max when it is further than max */
      var n = t.length, m = w.length, i, j;
      if (Math.abs(n - m) > max + 0.31) return max + 1;
      if (n > 36 || m > 36) return max + 1;
      var p2 = D2, p1 = D1, cu = D0, tmp;
      for (j = 0; j <= m; j++) p1[j] = j * 1;
      for (i = 1; i <= n; i++) {
        var ti = t.charCodeAt(i - 1) < 128 ? t[i - 1] : '?', rowMin;
        cu[0] = i * 1; rowMin = cu[0];
        for (j = 1; j <= m; j++) {
          var wj = w[j - 1];
          var best = p1[j - 1] + subCost(ti, wj);
          var del = p1[j] + ((i > 1 && t[i - 2] === ti) ? 0.6 : 1);                 /* an extra (often doubled) letter was typed */
          if (del < best) best = del;
          var ins = cu[j - 1] + ((j > 1 && w[j - 2] === wj) ? 0.7 : 1);             /* a letter is missing (a doubled letter written once) */
          if (ins < best) best = ins;
          if (i > 1 && j > 1 && ti === w[j - 2] && t[i - 2] === wj) { var tr = p2[j - 2] + 0.8; if (tr < best) best = tr; }
          cu[j] = best; if (best < rowMin) rowMin = best;
        }
        if (rowMin > max) return max + 1;
        tmp = p2; p2 = p1; p1 = cu; cu = tmp;
      }
      return p1[m];
    }

    /* ------------------------------------------------------------ capitals */
    function capMode(t) {
      if (t.length >= 2 && t === t.toUpperCase() && t !== t.toLowerCase()) return 2;
      if (t.charAt(0) !== t.charAt(0).toLowerCase()) return 1;
      return 0;
    }
    function shape(f, mode) {
      if (mode === 2) return f.toUpperCase();
      if (mode === 1 && f === f.toLowerCase()) return f.charAt(0).toUpperCase() + f.substr(1);
      return f;
    }

    /* ------------------------------------------------------------ suggestions */
    function topCompletions(p, K) {
      var lo = lb(p), hi = lb(p + '￿'), n = p.length, best = [], i, s, w, worst = -1;
      for (i = lo; i < hi; i++) {
        s = PU[i] * Math.pow(Math.exp(-LENPEN), LEN[i] - n);
        if (best.length < K || s > worst) {
          var pos = best.length; while (pos > 0 && best[pos - 1].s < s) pos--;
          best.splice(pos, 0, { i: i, s: s }); if (best.length > K) best.pop(); worst = best[best.length - 1].s;
        }
      }
      return best;
    }

    function suggest(buf, prev, opt) {
      opt = opt || {};
      var t = buf || '';
      if (!ready || !t) return { list: t ? [t] : [], auto: 0 };
      var tl = t.toLowerCase(), n = tl.length, mode = capMode(t), cq = context(prev);
      var cand = Object.create(null), cn = 0;                                /* lower-case word -> { s: ln score, f: display form, k: kind, c: cost } */
      function put(lw, f, lp, kind, cost) { var o = cand[lw]; if (!o || lp > o.s) { if (!o) cn++; cand[lw] = { s: lp, f: f, k: kind, c: cost || 0 }; } }
      function lnMix(pu, lw) { return Math.log(cq.p(lw, pu)); }

      /* 1. the words that begin with these letters */
      var top = topCompletions(tl, 14), i, k;
      for (i = 0; i < top.length; i++) { var wi = top[i].i; put(low[wi], formOf(wi), lnMix(PU[wi], low[wi]) - LENPEN * (LEN[wi] - n), 'c'); }
      cq.each(function (k) { if (k.length >= n && k.indexOf(tl) === 0) { var bi = find(k); if (bi >= 0) put(k, formOf(bi), lnMix(PU[bi], k) - LENPEN * (k.length - n), 'c'); } });
      for (i = 0; i < uList.length; i++) { var u = uList[i]; if (u.low.length >= n && u.low.indexOf(tl) === 0) put(u.low, u.form, lnMix(u.pu, u.low) - LENPEN * (u.low.length - n), 'u'); }

      if (alt.length && n >= 2 && !/[^a-z]/.test(tl)) {                  /* 'cause for cause, 'em for em, bag-of-words for bagofwords or for bag */
        var alo = 0, ahi = alt.length, am;
        while (alo < ahi) { am = (alo + ahi) >> 1; if (alt[am].k < tl) alo = am + 1; else ahi = am; }
        var amatch = [];
        for (k = alo; k < alt.length && alt[k].k.indexOf(tl) === 0 && amatch.length < 40; k++) {
          var ae = alt[k], ai = ae.i, abonus = ae.k === tl ? 5 : (ae.h === tl ? 3 : 0);
          if (!abonus && ae.k.length > n + 6) continue;
          amatch.push({ i: ai, s: lnMix(PU[ai], low[ai]) - LENPEN * (ae.k.length - n) + abonus });
        }
        amatch.sort(function (a, b) { return b.s - a.s; });
        for (k = 0; k < amatch.length && k < 6; k++) put(low[amatch[k].i], formOf(amatch[k].i), amatch[k].s, 'c');
      }
      var ti = find(tl), typedKnown = ti >= 0 || !!uMap[tl];
      if (opt.extra) for (i = 0; i < opt.extra.length; i++) {            /* words this person has used with these letters: [[word, weight]] */
        var xw = opt.extra[i][0], xl = xw.toLowerCase(), xi = find(xl); if (xl === tl) continue;
        put(xl, xi >= 0 ? formOf(xi) : xw, lnMix(xi >= 0 ? PU[xi] : (uMap[xl] ? uMap[xl].pu : 1e-6), xl) + 1.2 * opt.extra[i][1] - LENPEN * (xl.length - n), 'u');
      }
      var typedZ = ti >= 0 ? Z[ti] : (uMap[tl] ? uMap[tl].z : -1);
      var fx = fix[tl], fixHit = null;

      /* 2. spelling: the written-out fix list first, then the words a few keystrokes away */
      if (fx && !uMap[tl] && (!typedKnown || typedZ < 1000)) {
        var fl = fx.toLowerCase(), fi = find(fl);
        fixHit = fl;
        put(fl, fi >= 0 ? formOf(fi) : fx, lnMix(fi >= 0 ? PU[fi] : 1e-6, fl) + 1.0, 'f', 0.3);
      }
      var wantEd = !opt.noCorrect && n >= 2 && (!typedKnown || typedZ < 300) && !/[^a-z']/.test(tl);
      if (wantEd) {
        var maxc = n <= 3 ? 1.0 : n <= 5 ? 1.6 : 2.0, firsts = [tl.charAt(0)], pass;
        for (pass = 0; pass < 2; pass++) {
          var gotGood = false;
          for (var fi2 = 0; fi2 < firsts.length; fi2++) {
            var c0 = firsts[fi2], pen = pass ? 0.8 : 0, bucket = common[c0] || [];
            for (var bj = 0; bj < bucket.length; bj++) {
              i = bucket[bj];
              var L = LEN[i]; if (L < n - 2 || L > n + 2) continue;
              var cc = edCost(tl, low[i], maxc - pen); if (cc > maxc - pen) continue;
              cc += pen;
              put(low[i], formOf(i), lnMix(PU[i], low[i]) - ALPHA * cc, 'e', cc);
              if (cc <= 1.0) gotGood = true;
            }
          }
          if (pass === 0 && !gotGood && n >= 3) firsts = (NEAR[tl.charAt(0)] || []).concat(tl.length > 1 && NEAR[tl.charAt(0)].indexOf(tl.charAt(1)) < 0 ? [tl.charAt(1)] : []); else break;     /* the first letter itself was struck wrong */
        }
        for (i = 0; i < uList.length; i++) { var u2 = uList[i]; var c2 = edCost(tl, u2.low, maxc); if (c2 <= maxc && u2.low !== tl) put(u2.low, u2.form, lnMix(u2.pu, u2.low) - ALPHA * c2, 'e', c2); }
      }

      if (ti >= 0 && cased[ti] && cased[ti] !== t) put(tl + '\u0001', cased[ti], typedZ >= 0 ? lnMix(PU[ti], tl) - 0.01 : -30, 'v', 0);
      /* 3. what was typed */
      var typedScore = typedKnown ? lnMix(typedZ >= 0 ? Math.exp((typedZ / 100 - 9) * LN10) : 1e-9, tl) : -40;
      var arr = [], key;
      for (key in cand) if (key !== tl) arr.push(cand[key]);
      arr.sort(function (a, b) { return b.s - a.s; });

      /* is there a correction clear enough to apply when the space key is pressed? */
      var auto = null;
      if (!opt.noCorrect && n >= 2) {
        var best = null, second = null, e;
        for (i = 0; i < arr.length; i++) { e = arr[i]; if (e.k !== 'e' && e.k !== 'f') continue; if (!best) best = e; else { second = e; break; } }
        if (best) {
          var bz = zipfOf(best.f.toLowerCase()), ok = false;
          if (best.k === 'f') ok = true;
          else if (n >= AUTO.minLen && mode === 0 && !/(.)\1\1/.test(tl) && bz >= AUTO.minZ && (!second || best.s - second.s >= AUTO.margin)) {
            var lim = n <= 4 ? AUTO.lim4 : AUTO.lim5;
            STRICT = !!AUTO.strict; var sc = edCost(tl, best.f.toLowerCase(), lim + 1); STRICT = false;
            if (sc <= lim && !typedKnown) {
              ok = true;
              if (!typedKnown && AUTO.pre) {                          /* typed letters that begin a real word are probably unfinished or an abbreviation, not a slip */
                for (i = 0; i < top.length; i++) if (Z[top[i].i] >= 200 && low[top[i].i] !== tl && (AUTO.pre === 1 || low[top[i].i] === best.f.toLowerCase())) { ok = false; break; }
              }
            }
          }
          if (ok) auto = best;
        }
      }

      /* the list: [what the space key commits, (the text as typed when a correction is applied), ...the rest] */
      var out = [], seen = Object.create(null);
      function add(f) { if (!seen[f]) { seen[f] = 1; out.push(f); } }
      var shown;
      if (auto) { add(shape(auto.f, mode)); out.push(t); seen[t] = 1; }
      else { out.push(t); seen[t] = 1; }
      for (i = 0; i < arr.length && out.length < 9; i++) { shown = shape(arr[i].f, mode); add(shown); }
      return { list: out, auto: auto ? 1 : 0, fix: auto && auto.k === 'f' ? 1 : 0 };
    }

    /* the words that usually follow `prev` */
    function next(prev, n) {
      n = n || 6;
      var key = (prev || '<s>').toLowerCase().replace(/^\s+|\s+$/g, ''), cq = context(key), arr = [], out = [];
      cq.each(function (k) { var j = find(k), pu = j >= 0 ? PU[j] : 1e-9; arr.push([k, cq.p(k, pu), j]); });
      arr.sort(function (a, b) { return b[1] - a[1]; });
      for (var i = 0; i < arr.length && out.length < n; i++) out.push(arr[i][2] >= 0 ? formOf(arr[i][2]) : arr[i][0]);
      if (key.lastIndexOf('<s>') === key.length - 3) out = out.map(function (w) { return w.charAt(0).toUpperCase() + w.substr(1); });
      return out;
    }

    /* ------------------------------------------------------------ swipe typing */
    function buildFE() {
      fe = new Array(676);
      for (var i = 0; i < N; i++) {
        var w = low[i], a = w.charCodeAt(0) - 97, b = w.charCodeAt(w.length - 1) - 97;
        if (a < 0 || a > 25 || b < 0 || b > 25 || w.length < 2 || Z[i] < 200 || /[^a-z']/.test(w)) continue;
        var key = a * 26 + b; (fe[key] || (fe[key] = [])).push(i);
      }
    }
    var NS = 48, QX = new Float64Array(NS), QY = new Float64Array(NS), TX = new Float64Array(NS), TY = new Float64Array(NS);
    function resample(xs, ys, m, ox, oy) {                          /* m points along a polyline -> NS points at equal distances; returns the length */
      var L = 0, i; for (i = 1; i < m; i++) L += Math.hypot(xs[i] - xs[i - 1], ys[i] - ys[i - 1]);
      if (L < 1e-9) { for (i = 0; i < NS; i++) { ox[i] = xs[0]; oy[i] = ys[0]; } return 0; }
      var step = L / (NS - 1), seg = 1, acc = 0, d = Math.hypot(xs[1] - xs[0], ys[1] - ys[0]), px = xs[0], py = ys[0];
      ox[0] = xs[0]; oy[0] = ys[0];
      for (var o = 1; o < NS; o++) {
        var want = o * step;
        while (seg < m - 1 && acc + d < want - 1e-12) { acc += d; seg++; d = Math.hypot(xs[seg] - xs[seg - 1], ys[seg] - ys[seg - 1]); }
        var f = d > 1e-12 ? (want - acc) / d : 0; if (f > 1) f = 1;
        ox[o] = xs[seg - 1] + (xs[seg] - xs[seg - 1]) * f; oy[o] = ys[seg - 1] + (ys[seg] - ys[seg - 1]) * f;
      }
      return L;
    }
    function swipe(spec, prev, n) {
      n = n || 10;
      if (!ready || !spec || !spec.k || !spec.p || spec.p.length < 3) return [];
      var kx = new Float64Array(26), ky = new Float64Array(26), c, ch;
      for (c = 0; c < 26; c++) { ch = String.fromCharCode(97 + c); var kp = spec.k[ch]; if (!kp) return []; kx[c] = kp[0]; ky[c] = kp[1]; }
      var pts = spec.p, m = pts.length, xs = new Float64Array(m), ys = new Float64Array(m), i;
      for (i = 0; i < m; i++) { xs[i] = pts[i][0]; ys[i] = pts[i][1]; }
      var Lp = resample(xs, ys, m, QX, QY);
      if (Lp < 0.9) return [];                                       /* a tap, not a swipe */
      /* the distance from every key to the path (a dense copy of the path, so a fast swipe is not missed between two samples) */
      var dmin = new Float64Array(26).fill(1e9), dn = Math.max(NS, Math.ceil(Lp / 0.12)), DX = new Float64Array(dn), DY = new Float64Array(dn);
      (function () { var sv = NS; })();
      var segLen = Lp / (dn - 1), acc = 0, sg = 1, d = Math.hypot(xs[1] - xs[0], ys[1] - ys[0]);
      DX[0] = xs[0]; DY[0] = ys[0];
      for (i = 1; i < dn; i++) {
        var want = i * segLen;
        while (sg < m - 1 && acc + d < want - 1e-12) { acc += d; sg++; d = Math.hypot(xs[sg] - xs[sg - 1], ys[sg] - ys[sg - 1]); }
        var f = d > 1e-12 ? Math.min(1, (want - acc) / d) : 0;
        DX[i] = xs[sg - 1] + (xs[sg] - xs[sg - 1]) * f; DY[i] = ys[sg - 1] + (ys[sg] - ys[sg - 1]) * f;
      }
      for (c = 0; c < 26; c++) { var bd = 1e9; for (i = 0; i < dn; i++) { var dd = (DX[i] - kx[c]) * (DX[i] - kx[c]) + (DY[i] - ky[c]) * (DY[i] - ky[c]); if (dd < bd) bd = dd; } dmin[c] = Math.sqrt(bd); }
      function nearKeys(x, y) {
        var r = []; for (var q = 0; q < 26; q++) { var dq = Math.hypot(x - kx[q], y - ky[q]); r.push([q, dq]); }
        r.sort(function (a, b) { return a[1] - b[1]; });
        var out = [], j; for (j = 0; j < r.length && (j < 2 || (r[j][1] <= 1.15 && j < 4)); j++) out.push(r[j][0]);
        return out;
      }
      var S = nearKeys(xs[0], ys[0]), En = nearKeys(xs[m - 1], ys[m - 1]);
      if (!fe) buildFE();
      var cq = context(prev), res = [], tx = new Float64Array(40), ty = new Float64Array(40);
      function consider(lw, f, pu, letters) {
        var L = letters.length, j, bad = 0;
        for (j = 0; j < L; j++) { var cd = dmin[letters.charCodeAt(j) - 97]; if (cd > 1.25) return; if (cd > 0.85) bad++; }
        if (bad > 1 + (L >> 3)) return;
        var q = 0, last = -1;
        for (j = 0; j < L && q < 40; j++) { var cc = letters.charCodeAt(j) - 97; if (cc === last) continue; last = cc; tx[q] = kx[cc]; ty[q] = ky[cc]; q++; }
        if (q < 2) return;
        var Lt = resample(tx, ty, q, TX, TY); if (Lt < 0.3) return;
        var ratio = Lp / Lt; if (ratio < 0.55 || ratio > 2.2) return;
        var sum = 0, o; for (o = 0; o < NS; o++) sum += Math.hypot(QX[o] - TX[o], QY[o] - TY[o]);
        var cost = sum / NS + 0.5 * Math.abs(Math.log(ratio)) + ENDW * (Math.hypot(xs[0] - tx[0], ys[0] - ty[0]) + Math.hypot(xs[m - 1] - tx[q - 1], ys[m - 1] - ty[q - 1]));
        var pr = cq.p(lw, pu);
        res.push({ f: f, lw: lw, s: Math.log(pr) - BETA * cost });
      }
      var a, b, lst, t;
      for (a = 0; a < S.length; a++) for (b = 0; b < En.length; b++) {
        lst = fe[S[a] * 26 + En[b]]; if (!lst) continue;
        for (t = 0; t < lst.length; t++) { var wi = lst[t], w = low[wi]; consider(w, formOf(wi), PU[wi], w.indexOf("'") >= 0 ? w.replace(/'/g, '') : w); }
      }
      for (i = 0; i < uList.length; i++) { var u = uList[i], ul = u.low.replace(/[^a-z]/g, ''); if (ul.length >= 2 && S.indexOf(ul.charCodeAt(0) - 97) >= 0 && En.indexOf(ul.charCodeAt(ul.length - 1) - 97) >= 0) consider(u.low, u.form, u.pu, ul); }
      res.sort(function (x, y) { return y.s - x.s; });
      var out = [], seen = Object.create(null);
      for (i = 0; i < res.length && out.length < n; i++) { if (!seen[res[i].lw]) { seen[res[i].lw] = 1; out.push(res[i].f); } }
      return out;
    }

    /* ------------------------------------------------------------ what this person has taught it */
    function addUser(word, z) {
      var lw = word.toLowerCase(); if (!/^[a-z][a-z']*$/.test(lw) || lw.length > 30) return false;
      if (find(lw) >= 0 && !(z > Z[find(lw)])) return false;
      var o = uMap[lw];
      if (o) { if (z > o.z) { o.z = z; o.pu = Math.exp((z / 100 - 9) * LN10); } o.form = word; return true; }
      o = { low: lw, form: word, z: z || 350, pu: Math.exp(((z || 350) / 100 - 9) * LN10) }; uMap[lw] = o; uList.push(o); return true;
    }
    function addFix(typed, fixed) { typed = typed.toLowerCase(); if (!/^[a-z][a-z']*$/.test(typed) || !fixed) return false; dropUser(typed); fix[typed] = fixed; return true; }
    function dropUser(word) { var lw = word.toLowerCase(); if (!uMap[lw]) return; delete uMap[lw]; uList = uList.filter(function (u) { return u.low !== lw; }); }

    return {
      load: load, note: note, suggest: suggest, next: next, swipe: swipe, addUser: addUser, addFix: addFix, dropUser: dropUser, known: known, zipf: zipfOf,
      isReady: function () { return ready; }, size: function () { return N; }, fixCount: function () { return Object.keys(fix).length; },
      tune: function (o) { if (o.alpha != null) ALPHA = o.alpha; if (o.beta != null) BETA = o.beta; if (o.lambda != null) LAMBDA = o.lambda; if (o.mu3 != null) { MU3 = o.mu3; tgCache = Object.create(null); } if (o.lenPen != null) LENPEN = o.lenPen; if (o.endw != null) ENDW = o.endw; for (var k in o) if (k in AUTO) AUTO[k] = o[k]; },
      _cost: edCost, _find: find
    };
  }
  return { create: create, KX: KX, KY: KY, adjacent: adjacent };
});
