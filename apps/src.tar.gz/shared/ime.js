/* Sulekhak keyboard engine page (runs inside a hidden WebView on Android and WebView2 on Windows).
   The host calls   imeQuery(id, roman, prevWord)   and receives   {t:'c', id, buf, list:[odia candidates]}   as a JSON string.
   Other calls:     imeCommit(roman, odiaWord)   imeReplay([[roman, odiaWord], ...])
   Messages sent to the host: {t:'hello'} {t:'ready'} {t:'fail', e} {t:'c', ...}                                              */
(function () {
  'use strict';
  var E = OdiaEngine;
  E.loadBuiltin();
  function send(o) {
    var s = JSON.stringify(o);
    try {
      if (window.Android && window.Android.post) window.Android.post(s);
      else if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(s);
    } catch (e) {}
  }
  var W = null, ready = false, pend = {}, replay = [];
  /* ---- the cluster rule and the word list (the page side keeps its own copy of clus.txt and lex.txt) ----
     A conjunct that never occurs in real words (not in clus.txt, or only noise-level there) or one of five or more consonants is
     "impossible": it is never offered in suggestions. It can still be typed by hand, letter by letter with the halant. */
  var CL = null, ALLW = null, LEXTXT = null;
  function ensureAllw() {
    if (ALLW || !LEXTXT) return;
    var ws = [], lx = LEXTXT.split('\n'), q;
    for (q = 0; q < lx.length; q++) { var t = lx[q].indexOf('\t'); if (t > 0) ws.push(lx[q].substr(0, t)); }
    ALLW = '\n' + ws.join('\n') + '\n';
    LEXTXT = null;
  }
  var CONS = '[\u0B15-\u0B39\u0B5C\u0B5D\u0B5F\u0B71]';
  var CLRE = new RegExp(CONS + '(?:\u0B4D' + CONS + ')+', 'g');
  function clusOK(w) {
    var m = w.match(CLRE), i, c;
    if (!m) return true;
    for (i = 0; i < m.length; i++) {
      c = m[i];
      if (c.split('\u0B4D').length > 4) return false;
      if (CL) { var l = CL[c]; if (l === undefined || l === 2) return false; }
    }
    return true;
  }
  /* a segment: a whole word of the dictionary, or a part of one (so a swipe may give the front, the middle or the end of a long word) */
  function realPart(w) {
    if (!ALLW || !w || w.length < 2) return false;
    if (/[^\u0B01-\u0B77\u200C\u200D]/.test(w)) return false;
    return ALLW.indexOf('\n' + w + '\n') >= 0 || ALLW.indexOf(w) >= 0;
  }
  /* the language data: the word list, the Roman spellings, the cluster and syllable tables (text) and the two binary files:
     ng.bin (the bigram and trigram language model) and idx.bin (the prefix index of the word list) */
  var NAMES = ['cfg.json', 'lex.txt', 'rom.txt', 'clus.txt', 'syl_uni.txt', 'syl_bi.txt', 'syl_chan.txt'];
  var KEYS = ['cfg', 'lex', 'rom', 'clus', 'syl_uni', 'syl_bi', 'syl_chan'];
  var H = "var S=Sulekhak.create();onmessage=function(e){var m=e.data;" +
    "if(m.t==='init'){S.load(m.P);(m.replay||[]).forEach(function(x){S.commit(x)});postMessage({t:'ready'})}" +
    "else if(m.t==='sw'){var r=[];try{r=S.swipe(m.spec,m.prev,m.n)}catch(x){}postMessage({t:'swr',id:m.id,r:r})}" +
    "else if(m.t==='q'){postMessage({t:'r',id:m.id,r:S.suggest(m.buf,m.prev,m.nl,m.nc)})}" +
    "else if(m.t==='c'){S.commit(m.w)}" +
    "else if(m.t==='n'){postMessage({t:'nr',id:m.id,r:S.next(m.prev,6)})}};";
  function T(u) { return fetch(u).then(function (r) { if (!r.ok) throw new Error(u + ' ' + r.status); return r.text(); }); }
  function TB(u) { return fetch(u).then(function (r) { if (!r.ok) throw new Error(u + ' ' + r.status); return r.arrayBuffer(); }); }

  /* The script the host types in: 0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese (the engine works in Odia; every candidate is carried over here). OPT: bit 1 Marathi ळ, bit 2 anusvara instead of nasal conjuncts. */
  var SC = 0, OPT = 0;
  window.imeSetScript = function (sc, opt) { SC = (sc === 1 || sc === 2 || sc === 5) ? sc : 0; OPT = opt | 0; if (window.SKP) try { SKP.setMode(SC, OPT, false); } catch (e) {} };      /* (imeSetEnglish below switches the English mode on and off) */
  /* personal learning (private build): history re-orders the list; the typed text in slot 2 stays where it is */
  function lr(buf, prev, list) { if (!window.SKP || !list) return list; try { return SKP.rerank(buf, prev, list); } catch (e) { return list; } }
  function show(w) { if (!SC || !w) return w; try { return E.toScript(w, SC, OPT); } catch (e) { return w; } }
  function showList(odia, buf) {                /* the candidates as they are typed in the chosen script (Assamese: ৱ for v / w, ৎ beside ত্) */
    if (!SC) return odia;
    var D = [], O = [], i;
    for (i = 0; i < odia.length; i++) { D.push(show(odia[i])); O.push(odia[i]); }
    if (SC === 5 && E.asRefine) { try { return E.asRefine(buf, D, O).disp; } catch (e) {} }
    var seen = {}, out = [];
    for (i = 0; i < D.length; i++) { if (i === 1 || !seen[D[i]]) { seen[D[i]] = 1; out.push(D[i]); } }   /* slot 2 stays the typed text */
    return out;
  }
  function back(w) {                            /* what the host commits is in the chosen script; the memory and the dictionary are Odia */
    if (!w || !SC) return w;
    w = w.replace(/\u09CE/g, '\u0B24\u0B4D');
    try { return E.toOdia(w); } catch (e) { return w; }
  }

  var LRW = {};                                 /* the words the user has chosen before are always real words */
  var LR = {};                                  /* what the user has chosen before: typed roman -> Odia word (most recent wins) */
  var LRN = 0;
  function learn(roman, word) {
    if (!roman || !word) return;
    if (!(roman in LR)) LRN++;
    LR[roman] = word; LRW[word] = 1;
    if (LRN > 1500) { var n = 0; for (var k in LR) { delete LR[k]; LRN--; if (++n >= 300) break; } }
  }
  /* The smart engine reads Z as j and z as a plain letter, but in this scheme z is ZWNJ and Z is halant + ZWNJ,
     so a word that carries them is left to the rule engine. */
  function smartOK(buf) { return /^[A-Za-z]+$/.test(buf) && !/[zZ]/.test(buf); }

  /* ---- the universal candidate rules (ZWNJ before a ବ after a halant, nukta ଡ଼ ଢ଼ first) are E.postRules in engine.js: the same text as the Mac engine.c, so every app applies them alike.
     `keep` (the user's own earlier pick) is left exactly as it is; slot 2 is the typed text. ---- */
  function nkList(list, keep, slot2, roman) { return E.postRules(list, keep, slot2 ? 1 : -1, roman, SC); }
  function strictFin(list, buf) { return E.strictList ? E.strictList(list, SC, buf) : list; }       /* the last stage: no out-of-rule ବ / ଵ candidate leaves this file (strict rule, Odia only) */
  function dCount(w, re) { var m = w.match(re); return m ? m.length : 0; }
  function capDOrder(r, buf) {                  /* capital D / Dh is the retroflex letter: words without a ଡ / ଢ do not take the first places */
    var nd = dCount(buf, /D(?!h)/g), nh = dCount(buf, /Dh/g);
    if (!r || !r.length || (!nd && !nh)) return r;
    var good = [], bad = [];
    r.forEach(function (x) { (dCount(x[0], /[\u0B21\u0B5C]/g) >= nd && dCount(x[0], /[\u0B22\u0B5D]/g) >= nh ? good : bad).push(x); });
    return good.concat(bad);
  }

  function merge(od, r, buf) {                  /* slot 1 = a word chosen before, else the best smart word; slot 2 = the typed text */
    var O = [], seen = {}, i, L = LR[buf];
    r = capDOrder(r, buf);
    function push(o) { if (o && !seen[o]) { seen[o] = 1; O.push(o); } }
    if (L) push(L);
    if (/[zZ]/.test(buf)) return od.slice();     /* z / Z: the engine's own order (the ZWNJ spelling, the typed text, the same without ZWNJ, with ZWJ, the rest) */
    if (r && r.length) { if (od.length && od[0].indexOf('\u200C') >= 0 && od[0].replace(/\u200C/g, '') === r[0][0].replace(/\u200C/g, '')) push(od[0]); push(r[0][0]); }     /* the dictionary's ZWNJ spelling beats the same word without ZWNJ */
    else if (od.length) push(od[0]);
    if (od.length > 1) { if (!seen[od[1]]) { O.push(od[1]); seen[od[1]] = 1; } }
    if (buf.length >= 2) {                      /* longer words the user typed before that start with these letters */
      var pre = [];
      for (var k in LR) if (k.length > buf.length && k.indexOf(buf) === 0) pre.push(k);
      pre.sort(function (x, y) { return x.length - y.length; });
      for (i = 0; i < pre.length && i < 2; i++) push(LR[pre[i]]);
    }
    if (r) for (i = 1; i < r.length; i++) push(r[i][0]);
    for (i = 0; i < od.length; i++) if (i !== 1) push(od[i]);
    var ty = od.length > 1 ? od[1] : null, ti = ty ? O.indexOf(ty) : -1;       /* the typed text always sits in slot 2 */
    if (ti > 1) { O.splice(ti, 1); O.splice(1, 0, ty); }
    return nkList(O, L, true, buf);
  }

  var ANDROID = !!(window.Android && window.Android.post);      /* the cluster rule is for the phone keyboard for now */
  function strict(O, L) {                       /* slot 2 (what was typed) and the user's own earlier choice are never dropped */
    if (!ANDROID || O.length < 2) return O;
    var ty = O[1], rest = [], i;
    for (i = 0; i < O.length; i++) if (i !== 1 && (O[i] === L || clusOK(O[i]))) rest.push(O[i]);
    if (!rest.length) return [ty];
    return [rest[0], ty].concat(rest.slice(1));
  }

  var PREVRAW = '';
  window.imeQuery = function (id, buf, prev) {
    var old; PREVRAW = prev || ''; if (window.SKP) try { SKP.prev(PREVRAW); } catch (e) {} prev = back(prev);
    try { old = E.candidatesIn(buf, SC, OPT).odia; } catch (e) { old = [buf]; }
    if (!ANDROID && (buf === '*' || buf === '|')) { send({ t: 'c', id: id, buf: buf, list: showList(old, buf) }); return; }     /* the symbol lists (Windows PC keyboards only; the Android keyboard has its own symbol pages and long presses): the engine's own order, no merging */
    if (ready && smartOK(buf)) {
      pend[id] = { old: old, buf: buf };
      W.postMessage({ t: 'q', id: id, buf: buf, prev: prev || '<s>', nl: 4, nc: 2 });
    } else send({ t: 'c', id: id, buf: buf, list: lr(buf, PREVRAW, showList(strictFin(strict(merge(old, null, buf), LR[buf]), buf), buf)) });
  };
  /* Swipe typing: the host sends several guesses at the Roman spelling (the certain letters alone ... everything the finger passed over).
     Each goes through the same smart engine as typed letters; the words the dictionary knows come first, then the converted guesses.
     Answered like a typed word: {t:'c', id, buf: the first guess, list}. */
  function gestureLegacy(id, vars, prev, cb) {
    prev = back(prev);
    var n = vars.length, res = [], left = n, done = false, tm = null;
    function fin() {
      if (done) return; done = true; if (tm) clearTimeout(tm);
      var lex = [], conv = [], rule = [], seen = {}, a;
      function add(list, w) { if (w && !seen[w]) { seen[w] = 1; list.push(w); } }
      for (a = 0; a < n; a++) {
        var r = res[a]; if (!r) continue;
        (r.r || []).forEach(function (x) { if (x && x[0]) add(x[1] === 'lex' ? lex : conv, x[0]); });
        if (r.old && r.old[0]) add(rule, r.old[0]);
      }
      /* only dictionary words (best) and parts of dictionary words (after them) are accepted; the raw letter-by-letter conversion is never offered */
      ensureAllw();
      var out = [], got = {};
      function take(w, whole) { if (w && !got[w] && (LRW[w] || clusOK(w)) && (LRW[w] || (whole ? ALLW && ALLW.indexOf('\n' + w + '\n') >= 0 : realPart(w)))) { got[w] = 1; out.push(w); } }
      lex.forEach(function (w) { if (out.length < 6) take(w, true); });
      conv.forEach(function (w) { if (out.length < 9) take(w, false); });
      rule.forEach(function (w) { if (out.length < 11) take(w, false); });
      lex.forEach(function (w) { if (out.length < 11) take(w, false); });
      cb(strictFin(nkList(out, null), null));
    }
    vars.forEach(function (v, k) {
      var old; try { old = E.candidatesIn(v, SC, OPT).odia; } catch (e) { old = [v]; }
      if (ready && smartOK(v)) {
        var key = 'g' + id + '_' + k;
        pend[key] = { old: old, buf: v, g: function (r) { res[k] = { old: old, r: r }; if (--left === 0) fin(); } };
        W.postMessage({ t: 'q', id: key, buf: v, prev: prev || '<s>', nl: 4, nc: 2 });
      } else { res[k] = { old: old, r: null }; if (--left === 0) fin(); }
    });
    if (!done) tm = setTimeout(fin, 900);
  }
  window.imeGesture = function (id, vars, prev) {
    gestureLegacy(id, vars, prev, function (out) { send({ t: 'c', id: id, buf: vars[0], list: out.length ? showList(out, vars[0]) : [], none: out.length ? 0 : 1 }); });
  };
  /* The phone keyboard sends the finger's whole path (x, y, ms in key-widths) and the keys' centres: the engine matches it against the
     dictionary (shape, location, stops and the language model). The older guesses (vars) follow behind it, and fill in parts of words. */
  var SWP = {};
  window.imeSwipe = function (id, spec, vars, prev) {
    prev = back(prev);
    var st = { main: null, legacy: null }, k;
    function fin() {
      if (!st.main || !st.legacy) return;
      var out = [], got = {}, i;
      function take(w) { if (w && !got[w] && (LRW[w] || clusOK(w))) { got[w] = 1; out.push(w); } }
      for (i = 0; i < st.main.length && out.length < 6; i++) take(st.main[i][0]);
      for (i = 0; i < st.legacy.length && out.length < 11; i++) take(st.legacy[i]);
      out = strictFin(nkList(out, null), null);
      send({ t: 'c', id: id, buf: vars[0], list: out.length ? showList(out, vars[0]) : [], none: out.length ? 0 : 1 });
    }
    gestureLegacy(id, vars, prev, function (out) { st.legacy = out; fin(); });
    if (ready) { SWP[id] = function (r) { st.main = r || []; fin(); }; W.postMessage({ t: 'sw', id: id, spec: spec, prev: prev || '<s>', n: 10 }); }
    else st.main = [];
  };
  window.imeNext = function (id, prev) {           /* the words that usually follow `prev`; answered as {t:'n', id, list} */
    prev = back(prev);
    if (ready && prev) W.postMessage({ t: 'n', id: id, prev: prev }); else send({ t: 'n', id: id, list: [] });
  };
  window.imeCommit = function (roman, word) {
    if (window.SKP && word) try { if (roman) SKP.onPick(roman, word); else SKP.onWord(word); } catch (e) {}
    word = back(word);
    if (!word) return;
    try { if (roman) { E.lexAdd(roman, word, 3); learn(roman, word); } } catch (e) {}
    if (ready) W.postMessage({ t: 'c', w: word }); else replay.push([roman || '', word]);
  };
  /* the personal history, fed to the engine without touching what imeReplay set up: [[roman, word in the typing script], ...] */
  window.imeLearnAdd = function (arr) {
    for (var i = 0; i < (arr || []).length; i++) {
      var r = arr[i][0], w = back(arr[i][1]); if (!r || !w) continue;
      try { E.lexAdd(r, w, 3); learn(r, w); if (ready) W.postMessage({ t: 'c', w: w }); else replay.push([r, w]); } catch (e) {}
    }
  };
  window.imeNoteSwipe = function (word, accepted) { if (window.SKP && word) try { SKP.onSwipe(word, accepted !== false); } catch (e) {} };
  window.imeNoteSkip = function (roman, word) { if (window.SKP && roman && word) try { SKP.onSkip(roman, word); } catch (e) {} };
  window.imeNoteCorrection = function (typed, fixed) { if (window.SKP) try { SKP.onCorrection(typed, fixed); } catch (e) {} };
  window.imeReplay = function (arr) {
    replay = (arr || []).map(function (x) { return [x[0], back(x[1])]; });
    for (var i = 0; i < replay.length; i++) { try { E.lexAdd(replay[i][0], replay[i][1], 3); learn(replay[i][0], replay[i][1]); } catch (e) {} }
    if (ready) for (i = 0; i < replay.length; i++) W.postMessage({ t: 'c', w: replay[i][1] });
  };

  /* ---------------------------------------------------------------------------------------------------------------------------
     English (personal build): suggestions, spelling, next word and swipe typing, from the data in sulekhak/en/. The host calls
       imeSetEnglish(true|false)                              the typing mode (English learns into its own file, apart from every Indic language)
       imeEnQuery(id, typed, prevWord)                       -> {t:'c', id, buf, list, auto}   list[0] is what the space key commits; auto:1 = list[1] is the text as typed
       imeEnSwipe(id, trace, guesses, prevWord)               -> {t:'c', id, buf, list, none}
       imeEnNext(id, prevWord)                                -> {t:'n', id, list}
       imeEnCommit(typed, word, prevWord, how, passedOver)    how: typed | auto | pick | swipe | next | revert | keeptyped
     prevWord is lower case, or "<s>" at the start of a sentence.  The engine keeps the word before it (imeEnCommit) and answers with two words of context.
     --------------------------------------------------------------------------------------------------------------------------- */
  var EN = null, ENL = null, ENFAIL = 0, ENON = false, enSeen = {};
  function enLoad() {
    if (EN) return Promise.resolve(EN);
    if (ENL) return ENL;
    if (!window.SulekhakEnglish || Date.now() - ENFAIL < 30000) return Promise.resolve(null);
    ENL = Promise.all([T('sulekhak/en/en_lex.txt'), T('sulekhak/en/en_ng.txt'), T('sulekhak/en/en_fix.txt')]).then(function (a) {
      var e = window.SulekhakEnglish.create(); e.load({ lex: a[0], ng: a[1], fix: a[2] }); EN = e; enLearn(); return e;
    }).catch(function () { ENL = null; ENFAIL = Date.now(); return null; });
    return ENL;
  }
  function enLearn() {                       /* what this person has taught it: their own words and the fixes they made themselves */
    if (!EN || !window.SKP || SKP.lang !== 'en') return;
    try {
      SKP.learnedWords(2).forEach(function (x) { EN.addUser(x[0], 300 + Math.min(250, x[1] * 25)); });
      SKP.learnedCorrections(2).forEach(function (c) { EN.addFix(c[0], c[1]); });
    } catch (e) {}
  }
  window.imeEnLearn = enLearn;
  window.imeSetEnglish = function (on) {
    ENON = !!on;
    if (window.SKP) try { SKP.setMode(SC, OPT, ENON); } catch (e) {}
    if (ENON) enLoad();
  };
  function enRank(typed, prev, list, fixed) {            /* history re-orders the part of the list that the space key does not commit */
    if (!window.SKP || list.length <= fixed + 1) return list;
    try {
      var head = list.slice(0, fixed), rest = list.slice(fixed).map(function (w) { return [w.toLowerCase(), w]; });
      return head.concat(SKP.rerankRaw(typed.toLowerCase(), prev, rest).map(function (x) { return x[1]; }));
    } catch (e) { return list; }
  }
  window.imeEnQuery = function (id, typed, prev) {
    prev = (prev || '').toLowerCase(); if (window.SKP) try { SKP.prev(prev); } catch (e) {}
    enLoad().then(function (e) {
      if (!e) { send({ t: 'c', id: id, buf: typed, list: [typed], auto: 0 }); return; }
      var r; var xt = null; try { if (window.SKP && SKP.lang === 'en') xt = SKP.completionsFor(typed.toLowerCase(), 6); } catch (x) {}
      try { r = e.suggest(typed, prev || null, { extra: xt }); } catch (x) { r = { list: [typed], auto: 0 }; }
      send({ t: 'c', id: id, buf: typed, list: enRank(typed, prev, r.list, r.auto ? 2 : 1), auto: r.auto ? 1 : 0 });
    });
  };
  window.imeEnSwipe = function (id, trace, guesses, prev) {
    prev = (prev || '').toLowerCase(); if (window.SKP) try { SKP.prev(prev); } catch (e) {}
    enLoad().then(function (e) {
      var l = [];
      if (e) { try { l = e.swipe(trace, prev || null, 8); } catch (x) { l = []; } }
      if (!l.length && e && guesses && guesses[0]) { try { l = e.suggest(String(guesses[0]).toLowerCase(), prev || null, { noCorrect: true }).list.slice(1); } catch (x) { l = []; } }
      l = enRank('', prev, l, 0);
      send({ t: 'c', id: id, buf: l[0] || (guesses && guesses[0]) || '', list: l, none: l.length ? 0 : 1 });
    });
  };
  window.imeEnNext = function (id, prev) {
    prev = (prev || '').toLowerCase();
    enLoad().then(function (e) {
      var out = [], seen = {}, i;
      function add(w) { var k = w.toLowerCase(); if (w && !seen[k] && out.length < 6) { seen[k] = 1; out.push(w); } }
      try { if (window.SKP && SKP.lang === 'en') SKP.nextFor(prev, 3).forEach(function (x) { add(prev === '<s>' ? x[0].charAt(0).toUpperCase() + x[0].substr(1) : x[0]); }); } catch (x) {}
      if (e) { try { e.next(prev || '<s>', 6).forEach(add); } catch (x) {} }
      send({ t: 'n', id: id, list: out });
    });
  };
  window.imeEnCommit = function (typed, word, prev, how, passed) {
    if (EN && word && how !== 'revert') try { EN.note(word, (prev || '').toLowerCase()); } catch (e) {}     /* the next question about this word has two words of context */
    if (!window.SKP || !word) return;
    var tl = (typed || '').toLowerCase(), wl = word.toLowerCase(); prev = (prev || '').toLowerCase();
    try {
      if (how === 'swipe') { SKP.onSwipe(wl, true, prev); if (passed && passed.toLowerCase() !== wl) SKP.onSwipe(passed.toLowerCase(), false, prev); }
      else if (how === 'pick') {
        if (tl && wl.indexOf(tl) === 0) SKP.onPick(tl, wl, prev); else if (tl) { SKP.onCorrection(tl, wl); SKP.onWord(wl, prev); } else SKP.onWord(wl, prev);
        if (tl && passed && passed.toLowerCase() !== wl) SKP.onSkip(tl, passed.toLowerCase());
      }
      else if (how === 'keeptyped' || how === 'revert') {              /* the correction was refused: the typed word is the person's own word from now on */
        SKP.onWord(wl, prev);
        if (passed && passed.toLowerCase() !== wl) SKP.onSkip(tl, passed.toLowerCase());
        if (EN && !EN.known(wl)) EN.addUser(word, 400);
      }
      else {                                                           /* typed, auto, next: a word that went in */
        SKP.onWord(wl, prev);
        if (how === 'typed' && EN && !EN.known(wl)) { enSeen[wl] = (enSeen[wl] || 0) + 1; if (enSeen[wl] >= 2) EN.addUser(word, 350); }
      }
    } catch (e) {}
  };

  Promise.all(NAMES.map(function (n) { return T('sulekhak/' + n); }).concat([TB('sulekhak/ng.bin'), TB('sulekhak/idx.bin')])).then(function (a) {
    var P = {};
    KEYS.forEach(function (k, i) { P[k] = a[i]; });
    P.ng = [a[KEYS.length]]; P.idx = a[KEYS.length + 1];
    try {
      CL = {};
      P.clus.split('\n').forEach(function (l) { var f = l.split('\t'); if (f.length > 1) CL[f[0]] = +f[1]; });
      LEXTXT = P.lex;                                  /* the word list is made on the first swipe, not at start-up */
    } catch (e) { CL = null; }
    return T('sulekhak.js').then(function (src) {
      W = new Worker(URL.createObjectURL(new Blob([src + '\n' + H], { type: 'text/javascript' })));
      W.onmessage = function (e) {
        var m = e.data;
        if (m.t === 'ready') { ready = true; send({ t: 'ready' }); }
        else if (m.t === 'swr') { var f = SWP[m.id]; if (f) { delete SWP[m.id]; f(m.r); } }
        else if (m.t === 'nr') send({ t: 'n', id: m.id, list: nkList(m.r || [], null).map(show) });
        else if (m.t === 'r') {
          var p = pend[m.id]; if (!p) return; delete pend[m.id];
          if (p.g) { p.g(m.r); return; }
          send({ t: 'c', id: m.id, buf: p.buf, list: lr(p.buf, PREVRAW, showList(strictFin(strict(merge(p.old, m.r, p.buf), LR[p.buf]), p.buf), p.buf)) });
        }
      };
      W.onerror = function (e) { send({ t: 'fail', e: String(e && e.message) }); };
      W.postMessage({ t: 'init', P: P, replay: replay.map(function (x) { return x[1]; }) }, [P.ng[0], P.idx]);     /* the two binary files are handed over, not copied */
    });
  }).catch(function (e) { send({ t: 'fail', e: String(e) }); });
  /* Windows only: the Phonetic mode (IPA, extIPA, IAST). The host gets, for every key that has look-alike symbols, the list it offers. */
  function sendPhon() {
    try {
      if (typeof phCands !== 'function' || !window.SKPH) return;
      var m = {}, n = 0;
      window.SKPH.keys.forEach(function (k) { var l = phCands(k); if (l.length > 1) { m[k] = l; n++; } });
      send({ t: 'phon', map: m });
    } catch (e) {}
  }
  if (window.chrome && window.chrome.webview) {
    var loadJs = function (u) { return new Promise(function (ok, no) { var el = document.createElement('script'); el.src = u; el.onload = ok; el.onerror = no; document.head.appendChild(el); }); };
    loadJs('phon-data.js').then(function () { return loadJs('phon-core.js'); }).then(sendPhon).catch(function () {});
  }
  T('skel.dat').then(function (t) { E.loadSkel(t); }).catch(function () {});
  send({ t: 'hello' });
})();
