/* Sulekhak keyboard engine page (runs inside a hidden WebView on Android and WebView2 on Windows).
   The host calls   imeQuery(id, roman, prevWord)   and receives   {t:'c', id, buf, list:[odia candidates]}   as a JSON string.
   Other calls:     imeCommit(roman, odiaWord)   imeReplay([[roman, odiaWord], ...])
   Messages sent to the host: {t:'hello'} {t:'ready'} {t:'fail', e} {t:'c', ...}                                              */
(function () {
  'use strict';
  var E = OdiaEngine;
  E.loadBuiltin();
  function send(o) {
    var s = JSON.stringify(o);
    try {
      if (window.Android && window.Android.post) window.Android.post(s);
      else if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(s);
    } catch (e) {}
  }
  var W = null, ready = false, pend = {}, replay = [];
  var NAMES = ['cfg.json', 'lex.txt', 'rom.txt', 'big.txt', 'clus.txt', 'syl_uni.txt', 'syl_bi.txt', 'syl_chan.txt'];
  var KEYS = ['cfg', 'lex', 'rom', 'big', 'clus', 'syl_uni', 'syl_bi', 'syl_chan'];
  var H = "var S=Sulekhak.create();onmessage=function(e){var m=e.data;" +
    "if(m.t==='init'){S.load(m.P);(m.replay||[]).forEach(function(x){S.commit(x)});postMessage({t:'ready'})}" +
    "else if(m.t==='q'){postMessage({t:'r',id:m.id,r:S.suggest(m.buf,m.prev,m.nl,m.nc)})}" +
    "else if(m.t==='c'){S.commit(m.w)}" +
    "else if(m.t==='n'){postMessage({t:'nr',id:m.id,r:S.next(m.prev,6)})}};";
  function T(u) { return fetch(u).then(function (r) { if (!r.ok) throw new Error(u + ' ' + r.status); return r.text(); }); }

  /* The script the host types in: 0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese (the engine works in Odia; every candidate is carried over here). OPT: bit 1 Marathi ळ, bit 2 anusvara instead of nasal conjuncts. */
  var SC = 0, OPT = 0;
  window.imeSetScript = function (sc, opt) { SC = (sc === 1 || sc === 2 || sc === 5) ? sc : 0; OPT = opt | 0; };
  function show(w) { if (!SC || !w) return w; try { return E.toScript(w, SC, OPT); } catch (e) { return w; } }
  function showList(odia, buf) {                /* the candidates as they are typed in the chosen script (Assamese: ৱ for v / w, ৎ beside ত্) */
    if (!SC) return odia;
    var D = [], O = [], i;
    for (i = 0; i < odia.length; i++) { D.push(show(odia[i])); O.push(odia[i]); }
    if (SC === 5 && E.asRefine) { try { return E.asRefine(buf, D, O).disp; } catch (e) {} }
    var seen = {}, out = [];
    for (i = 0; i < D.length; i++) { if (i === 1 || !seen[D[i]]) { seen[D[i]] = 1; out.push(D[i]); } }   /* slot 2 stays the typed text */
    return out;
  }
  function back(w) {                            /* what the host commits is in the chosen script; the memory and the dictionary are Odia */
    if (!w || !SC) return w;
    w = w.replace(/\u09CE/g, '\u0B24\u0B4D');
    try { return E.toOdia(w); } catch (e) { return w; }
  }

  var LR = {};                                  /* what the user has chosen before: typed roman -> Odia word (most recent wins) */
  var LRN = 0;
  function learn(roman, word) {
    if (!roman || !word) return;
    if (!(roman in LR)) LRN++;
    LR[roman] = word;
    if (LRN > 1500) { var n = 0; for (var k in LR) { delete LR[k]; LRN--; if (++n >= 300) break; } }
  }
  /* The smart engine reads Z as j and z as a plain letter, but in this scheme z is ZWNJ and Z is halant + ZWNJ,
     so a word that carries them is left to the rule engine. */
  function smartOK(buf) { return /^[A-Za-z]+$/.test(buf) && !/[zZ]/.test(buf); }

  function merge(od, r, buf) {                  /* slot 1 = a word chosen before, else the best smart word; slot 2 = the typed text */
    var O = [], seen = {}, i, L = LR[buf];
    function push(o) { if (o && !seen[o]) { seen[o] = 1; O.push(o); } }
    if (L) push(L);
    if (/[zZ]/.test(buf)) return od.slice();     /* z / Z: the engine's own order (the ZWNJ spelling, the typed text, the same without ZWNJ, with ZWJ, the rest) */
    if (r && r.length) { if (od.length && od[0].indexOf('\u200C') >= 0 && od[0].replace(/\u200C/g, '') === r[0][0].replace(/\u200C/g, '')) push(od[0]); push(r[0][0]); }     /* the dictionary's ZWNJ spelling beats the same word without ZWNJ */
    else if (od.length) push(od[0]);
    if (od.length > 1) { if (!seen[od[1]]) { O.push(od[1]); seen[od[1]] = 1; } }
    if (buf.length >= 2) {                      /* longer words the user typed before that start with these letters */
      var pre = [];
      for (var k in LR) if (k.length > buf.length && k.indexOf(buf) === 0) pre.push(k);
      pre.sort(function (x, y) { return x.length - y.length; });
      for (i = 0; i < pre.length && i < 2; i++) push(LR[pre[i]]);
    }
    if (r) for (i = 1; i < r.length; i++) push(r[i][0]);
    for (i = 0; i < od.length; i++) if (i !== 1) push(od[i]);
    var ty = od.length > 1 ? od[1] : null, ti = ty ? O.indexOf(ty) : -1;       /* the typed text always sits in slot 2 */
    if (ti > 1) { O.splice(ti, 1); O.splice(1, 0, ty); }
    return O;
  }

  window.imeQuery = function (id, buf, prev) {
    var old; prev = back(prev);
    try { old = E.candidatesIn(buf, SC, OPT).odia; } catch (e) { old = [buf]; }
    if (ready && smartOK(buf)) {
      pend[id] = { old: old, buf: buf };
      W.postMessage({ t: 'q', id: id, buf: buf, prev: prev || '<s>', nl: 4, nc: 2 });
    } else send({ t: 'c', id: id, buf: buf, list: showList(merge(old, null, buf), buf) });
  };
  /* Swipe typing: the host sends several guesses at the Roman spelling (the certain letters alone ... everything the finger passed over).
     Each goes through the same smart engine as typed letters; the words the dictionary knows come first, then the converted guesses.
     Answered like a typed word: {t:'c', id, buf: the first guess, list}. */
  window.imeGesture = function (id, vars, prev) {
    prev = back(prev);
    var n = vars.length, res = [], left = n, done = false, tm = null;
    function fin() {
      if (done) return; done = true; if (tm) clearTimeout(tm);
      var lex = [], conv = [], rule = [], seen = {}, a;
      function add(list, w) { if (w && !seen[w]) { seen[w] = 1; list.push(w); } }
      for (a = 0; a < n; a++) {
        var r = res[a]; if (!r) continue;
        (r.r || []).forEach(function (x) { if (x && x[0]) add(x[1] === 'lex' ? lex : conv, x[0]); });
        if (r.old && r.old[0]) add(rule, r.old[0]);
      }
      var out = lex.slice(0, 6).concat(conv.slice(0, 3)).concat(rule.slice(0, 3));
      if (!out.length) out = [vars[0]];
      send({ t: 'c', id: id, buf: vars[0], list: showList(out, vars[0]) });
    }
    vars.forEach(function (v, k) {
      var old; try { old = E.candidatesIn(v, SC, OPT).odia; } catch (e) { old = [v]; }
      if (ready && smartOK(v)) {
        var key = 'g' + id + '_' + k;
        pend[key] = { old: old, buf: v, g: function (r) { res[k] = { old: old, r: r }; if (--left === 0) fin(); } };
        W.postMessage({ t: 'q', id: key, buf: v, prev: prev || '<s>', nl: 4, nc: 2 });
      } else { res[k] = { old: old, r: null }; if (--left === 0) fin(); }
    });
    if (!done) tm = setTimeout(fin, 900);
  };
  window.imeNext = function (id, prev) {           /* the words that usually follow `prev`; answered as {t:'n', id, list} */
    prev = back(prev);
    if (ready && prev) W.postMessage({ t: 'n', id: id, prev: prev }); else send({ t: 'n', id: id, list: [] });
  };
  window.imeCommit = function (roman, word) {
    word = back(word);
    if (!word) return;
    try { if (roman) { E.lexAdd(roman, word, 3); learn(roman, word); } } catch (e) {}
    if (ready) W.postMessage({ t: 'c', w: word }); else replay.push([roman || '', word]);
  };
  window.imeReplay = function (arr) {
    replay = (arr || []).map(function (x) { return [x[0], back(x[1])]; });
    for (var i = 0; i < replay.length; i++) { try { E.lexAdd(replay[i][0], replay[i][1], 3); learn(replay[i][0], replay[i][1]); } catch (e) {} }
    if (ready) for (i = 0; i < replay.length; i++) W.postMessage({ t: 'c', w: replay[i][1] });
  };

  Promise.all(NAMES.map(function (n) { return T('sulekhak/' + n); })).then(function (a) {
    var P = {};
    KEYS.forEach(function (k, i) { P[k] = a[i]; });
    return T('sulekhak.js').then(function (src) {
      W = new Worker(URL.createObjectURL(new Blob([src + '\n' + H], { type: 'text/javascript' })));
      W.onmessage = function (e) {
        var m = e.data;
        if (m.t === 'ready') { ready = true; send({ t: 'ready' }); }
        else if (m.t === 'nr') send({ t: 'n', id: m.id, list: (m.r || []).map(show) });
        else if (m.t === 'r') {
          var p = pend[m.id]; if (!p) return; delete pend[m.id];
          if (p.g) { p.g(m.r); return; }
          send({ t: 'c', id: m.id, buf: p.buf, list: showList(merge(p.old, m.r, p.buf), p.buf) });
        }
      };
      W.onerror = function (e) { send({ t: 'fail', e: String(e && e.message) }); };
      W.postMessage({ t: 'init', P: P, replay: replay.map(function (x) { return x[1]; }) });
    });
  }).catch(function (e) { send({ t: 'fail', e: String(e) }); });
  /* Windows only: the Phonetic mode (IPA, extIPA, IAST). The host gets, for every key that has look-alike symbols, the list it offers. */
  function sendPhon() {
    try {
      if (typeof phCands !== 'function' || !window.SKPH) return;
      var m = {}, n = 0;
      window.SKPH.keys.forEach(function (k) { var l = phCands(k); if (l.length > 1) { m[k] = l; n++; } });
      send({ t: 'phon', map: m });
    } catch (e) {}
  }
  if (window.chrome && window.chrome.webview) {
    var loadJs = function (u) { return new Promise(function (ok, no) { var el = document.createElement('script'); el.src = u; el.onload = ok; el.onerror = no; document.head.appendChild(el); }); };
    loadJs('phon-data.js').then(function () { return loadJs('phon-core.js'); }).then(sendPhon).catch(function () {});
  }
  T('skel.dat').then(function (t) { E.loadSkel(t); }).catch(function () {});
  send({ t: 'hello' });
})();
