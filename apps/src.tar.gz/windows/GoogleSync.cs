using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Sulekhak
{
    /// <summary>Sign-in with Google for the personal build: the system browser opens, Google redirects to a loopback address on this PC
    /// (OAuth for installed apps with PKCE). Only the refresh token is kept, encrypted for this Windows user (DPAPI). The account must be on the
    /// allowed list in GoogleCfg; any other account is refused and signed out.</summary>
    class GoogleSync
    {
        static readonly HttpClient http = new HttpClient();
        readonly string folder;
        string access, refresh, email;
        DateTime exp = DateTime.MinValue;
        public string Email { get { return email; } }
        public bool Configured { get { return GoogleCfg.ClientId.Length > 0 && GoogleCfg.ClientSecret.Length > 0; } }
        public bool SignedIn { get { return !string.IsNullOrEmpty(refresh); } }
        public event Action Changed;
        public string DeviceId { get; private set; }
        public string LearnDir { get { return Path.Combine(folder, "learning"); } }

        public GoogleSync()
        {
            folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Sulekhak");
            Directory.CreateDirectory(LearnDir);
            string idf = Path.Combine(folder, "device.id");
            try { DeviceId = File.Exists(idf) ? File.ReadAllText(idf).Trim() : null; } catch { }
            if (string.IsNullOrEmpty(DeviceId)) { DeviceId = "w" + Guid.NewGuid().ToString("N").Substring(0, 8); try { File.WriteAllText(idf, DeviceId); } catch { } }
            LoadToken();
        }

        // ---------------------------------------------------------------- the stored refresh token
        string TokFile { get { return Path.Combine(folder, "google.tok"); } }
        void LoadToken()
        {
            try
            {
                if (!File.Exists(TokFile)) return;
                var raw = ProtectedData.Unprotect(File.ReadAllBytes(TokFile), Encoding.UTF8.GetBytes("sulekhak-personal"), DataProtectionScope.CurrentUser);
                using (var d = JsonDocument.Parse(raw)) { refresh = d.RootElement.GetProperty("r").GetString(); email = d.RootElement.GetProperty("e").GetString(); }
            }
            catch { refresh = null; email = null; }
        }
        void SaveToken()
        {
            try
            {
                var raw = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new Dictionary<string, string> { { "r", refresh }, { "e", email } }));
                File.WriteAllBytes(TokFile, ProtectedData.Protect(raw, Encoding.UTF8.GetBytes("sulekhak-personal"), DataProtectionScope.CurrentUser));
            }
            catch { }
        }
        public void SignOut()
        {
            string r = refresh;
            refresh = null; access = null; email = null; exp = DateTime.MinValue;
            try { if (File.Exists(TokFile)) File.Delete(TokFile); } catch { }
            if (!string.IsNullOrEmpty(r)) { try { http.PostAsync("https://oauth2.googleapis.com/revoke", new FormUrlEncodedContent(new Dictionary<string, string> { { "token", r } })); } catch { } }
            if (Changed != null) Changed();
        }

        // ---------------------------------------------------------------- sign in
        static string B64Url(byte[] b) { return Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_'); }
        static int FreePort() { var l = new System.Net.Sockets.TcpListener(IPAddress.Loopback, 0); l.Start(); int p = ((IPEndPoint)l.LocalEndpoint).Port; l.Stop(); return p; }

        /// <summary>Opens the browser and waits (up to 5 minutes) for the answer. Returns null on success, else a short reason.</summary>
        public async Task<string> SignInAsync()
        {
            if (!Configured) return "Sign-in is not set up in this build.";
            string verifier = B64Url(RandomBytes(48)), state = B64Url(RandomBytes(16));
            string challenge = B64Url(SHA256.Create().ComputeHash(Encoding.ASCII.GetBytes(verifier)));
            int port = FreePort();
            string redirect = "http://127.0.0.1:" + port + "/";
            var listener = new HttpListener();
            listener.Prefixes.Add(redirect);
            try { listener.Start(); } catch (Exception ex) { return "Cannot listen on this PC: " + ex.Message; }
            string url = "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + Uri.EscapeDataString(GoogleCfg.ClientId) +
                "&redirect_uri=" + Uri.EscapeDataString(redirect) + "&response_type=code&scope=" + Uri.EscapeDataString("openid email https://www.googleapis.com/auth/drive.appdata") +
                "&code_challenge=" + challenge + "&code_challenge_method=S256&state=" + state + "&access_type=offline&prompt=select_account%20consent";
            try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true }); }
            catch (Exception ex) { listener.Close(); return "Could not open the browser: " + ex.Message; }
            string code = null, err = null;
            try
            {
                var ctxTask = listener.GetContextAsync();
                if (await Task.WhenAny(ctxTask, Task.Delay(TimeSpan.FromMinutes(5))) != ctxTask) { listener.Close(); return "Timed out waiting for the browser."; }
                var ctx = ctxTask.Result;
                var q = ctx.Request.QueryString;
                if (q["state"] != state) err = "The answer did not match the request."; else if (q["error"] != null) err = q["error"]; else code = q["code"];
                string page = err == null ? "<html><body style='font-family:sans-serif'><h3>Signed in</h3>You can close this tab and go back to Sulekhak.</body></html>"
                                          : "<html><body style='font-family:sans-serif'><h3>Not signed in</h3>" + WebUtility.HtmlEncode(err) + "</body></html>";
                var buf = Encoding.UTF8.GetBytes(page);
                ctx.Response.ContentType = "text/html; charset=utf-8"; ctx.Response.ContentLength64 = buf.Length;
                ctx.Response.OutputStream.Write(buf, 0, buf.Length); ctx.Response.Close();
            }
            catch (Exception ex) { err = ex.Message; }
            finally { try { listener.Close(); } catch { } }
            if (code == null) return err ?? "Cancelled.";
            var resp = await Token(new Dictionary<string, string> {
                { "code", code }, { "client_id", GoogleCfg.ClientId }, { "client_secret", GoogleCfg.ClientSecret }, { "redirect_uri", redirect },
                { "grant_type", "authorization_code" }, { "code_verifier", verifier } });
            if (resp == null) return "Google did not accept the sign-in.";
            string mail = EmailFromIdToken(resp.Value.id);
            if (!GoogleCfg.IsAllowed(mail))
            {
                try { http.PostAsync("https://oauth2.googleapis.com/revoke", new FormUrlEncodedContent(new Dictionary<string, string> { { "token", resp.Value.access } })); } catch { }
                return (mail ?? "That account") + " is not an authorised account for this app.";
            }
            access = resp.Value.access; exp = DateTime.UtcNow.AddSeconds(resp.Value.expires); email = mail;
            if (!string.IsNullOrEmpty(resp.Value.refresh)) refresh = resp.Value.refresh;
            SaveToken();
            if (Changed != null) Changed();
            return null;
        }
        static byte[] RandomBytes(int n) { var b = new byte[n]; using (var r = RandomNumberGenerator.Create()) r.GetBytes(b); return b; }

        struct Tok { public string access, refresh, id; public int expires; }
        async Task<Tok?> Token(Dictionary<string, string> form)
        {
            try
            {
                var r = await http.PostAsync("https://oauth2.googleapis.com/token", new FormUrlEncodedContent(form));
                string body = await r.Content.ReadAsStringAsync();
                if (!r.IsSuccessStatusCode) { lastError = body; return null; }
                using (var d = JsonDocument.Parse(body))
                {
                    var e = d.RootElement; var t = new Tok();
                    t.access = e.GetProperty("access_token").GetString(); t.expires = e.GetProperty("expires_in").GetInt32();
                    JsonElement x; if (e.TryGetProperty("refresh_token", out x)) t.refresh = x.GetString();
                    if (e.TryGetProperty("id_token", out x)) t.id = x.GetString();
                    return t;
                }
            }
            catch (Exception ex) { lastError = ex.Message; return null; }
        }
        string lastError;
        static string EmailFromIdToken(string jwt)
        {
            try
            {
                string p = jwt.Split('.')[1].Replace('-', '+').Replace('_', '/');
                p += new string('=', (4 - p.Length % 4) % 4);
                using (var d = JsonDocument.Parse(Convert.FromBase64String(p)))
                {
                    var e = d.RootElement; JsonElement v;
                    if (e.TryGetProperty("email_verified", out v) && v.ValueKind == JsonValueKind.False) return null;
                    return e.GetProperty("email").GetString().ToLowerInvariant();
                }
            }
            catch { return null; }
        }

        /// <summary>A valid access token (refreshing when it is about to run out). Null when signed out or when Google refuses the refresh token.</summary>
        public async Task<string[]> AccessAsync()
        {
            if (!SignedIn) return null;
            if (access == null || DateTime.UtcNow > exp.AddMinutes(-2))
            {
                var t = await Token(new Dictionary<string, string> { { "client_id", GoogleCfg.ClientId }, { "client_secret", GoogleCfg.ClientSecret }, { "refresh_token", refresh }, { "grant_type", "refresh_token" } });
                if (t == null)
                {
                    if (lastError != null && lastError.Contains("invalid_grant")) SignOut();       // expired (Google ends test-mode tokens after 7 days) or revoked: sign in again
                    return null;
                }
                access = t.Value.access; exp = DateTime.UtcNow.AddSeconds(t.Value.expires);
            }
            int secs = (int)Math.Max(60, (exp - DateTime.UtcNow).TotalSeconds);
            return new[] { access, secs.ToString(), email };
        }

        // ---------------------------------------------------------------- the local copy of each language file
        static bool GoodLang(string l) { return l == "or" || l == "hi" || l == "mr" || l == "bn" || l == "as" || l == "en"; }
        public string ReadLang(string lang)
        {
            if (!GoodLang(lang)) return "";
            try { string f = Path.Combine(LearnDir, lang + ".json"); return File.Exists(f) ? File.ReadAllText(f, Encoding.UTF8) : ""; } catch { return ""; }
        }
        public void WriteLang(string lang, string text)
        {
            if (!GoodLang(lang) || string.IsNullOrEmpty(text)) return;
            try
            {
                string f = Path.Combine(LearnDir, lang + ".json"), tmp = f + ".tmp";
                File.WriteAllText(tmp, text, new UTF8Encoding(false));
                if (File.Exists(f)) { try { File.Copy(f, f + ".bak", true); } catch { } }
                if (File.Exists(f)) File.Replace(tmp, f, null); else File.Move(tmp, f);
            }
            catch { }
        }
    }
}
