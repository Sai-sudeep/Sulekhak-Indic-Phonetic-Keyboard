using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Sulekhak
{
    /// <summary>
    /// Tray program that types Odia in any Windows program. While it is ON, Roman letters you type are collected in a small
    /// candidate window; Space or a number key types the chosen Odia word into the program you are using.
    /// (The tray menu switches it on and off; there is no hot key for that any more: Win+Space does the job.)
    /// </summary>
    class App : ApplicationContext
    {
        const string DataVersion = "7";
        /// <summary>-1 = the all-in-one program; otherwise the one script this copy types: 0 Odia, 1 Devanagari, 2 Bangla, 4 Phonetic (IPA), 5 Assamese. Set by the build (-p:EditionNum=n).</summary>
        internal static readonly int Edition = ReadEdition();
        static int ReadEdition()
        {
            try { foreach (var a in Assembly.GetExecutingAssembly().GetCustomAttributes<AssemblyMetadataAttribute>()) if (a.Key == "Edition") return int.Parse(a.Value); }
            catch { }
            return -1;
        }
        /// <summary>A language edition types its own language, and also English and Phonetic (IPA), so that every copy of Sulekhak has at least two languages. The all-in-one has them all.</summary>
        static bool Allows(int sc) { return Edition < 0 || sc == Edition || sc == 4 || sc == 6; }
        static string EdKey { get { return Edition < 0 ? "" : "\\Ed" + Edition; } }
        static string RunName { get { return Edition < 0 ? "Sulekhak" : "Sulekhak-" + Edition; } }
        internal static int LoadSettingPublic(string n, int d) { return LoadSetting(n, d); }
        internal static void SaveSettingPublic(string n, int v) { SaveSetting(n, v); }
        static int LoadSetting(string n, int d)
        {
            try { using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Sulekhak" + EdKey)) { if (k != null) { object v = k.GetValue(n); if (v != null) return Convert.ToInt32(v); } } }
            catch { }
            return d;
        }
        static void SaveSetting(string n, int v)
        {
            try { using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Sulekhak" + EdKey)) k.SetValue(n, v); }
            catch { }
        }
        // switches that the text service (another process) reads too: always in the base key, whatever the edition
        static int LoadBaseSetting(string n, int d)
        {
            try { using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Sulekhak")) { if (k != null) { object v = k.GetValue(n); if (v != null) return Convert.ToInt32(v); } } }
            catch { }
            return d;
        }
        static void SaveBaseSetting(string n, int v)
        {
            try { using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Sulekhak")) k.SetValue(n, v); }
            catch { }
        }
        static string ScriptName(int sc) { return sc == 6 ? "English" : sc == 1 ? "Devanagari" : sc == 2 ? "Bangla" : sc == 4 ? "Phonetic IPA" : sc == 5 ? "Assamese" : "Odia"; }
        static string Halant(int sc) { return sc == 1 ? "\u094D" : (sc == 2 || sc == 5) ? "\u09CD" : "\u0B4D"; }
        int script;                       // the script being typed now (in an edition: its own language, English or Phonetic)
        int lastScript;                   // the script to go back to when Phonetic mode is switched off
        int dvOpts;                       // Devanagari: bit 1 Marathi ळ, bit 2 anusvara instead of nasal conjuncts
        readonly ToolStripMenuItem[] miScript = new ToolStripMenuItem[7];
        static readonly string root = MigrateRoot(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Sulekhak"));
        static string MigrateRoot(string n)
        {
            try { string o = Path.Combine(Path.GetDirectoryName(n), "Sulekhk"); if (!Directory.Exists(n) && Directory.Exists(o)) Directory.Move(o, n); } catch { }
            return n;
        }
        readonly string dir = Path.Combine(root, "v" + DataVersion);
        readonly string histPath = Path.Combine(root, "history.tsv");      // outside the versioned folder, so words you taught it survive updates
        readonly NotifyIcon tray = new NotifyIcon();
        readonly ToolStripMenuItem miToggle = new ToolStripMenuItem();
        readonly ToolStripMenuItem miStart = new ToolStripMenuItem("Start with Windows");
        readonly ToolStripMenuItem miSurround = new ToolStripMenuItem("Auto-surround selected text:  ( )  [ ]  { }  \" \"  ' '  ` `  < >");
        bool autoSurround = LoadSetting("AutoSurround", 0) != 0;       // off until switched on (it reads the selection through UI Automation)
        readonly ToolStripMenuItem miOsk = new ToolStripMenuItem("On-screen keyboard   (Ctrl+Alt+K)");
        readonly ToolStripMenuItem miStatus = new ToolStripMenuItem("Smart suggestions: loading") { Enabled = false };
        readonly ToolStripMenuItem miSyncStatus = new ToolStripMenuItem("Sync: not signed in") { Enabled = false };
        readonly ToolStripMenuItem miSignIn = new ToolStripMenuItem("Sign in with Google to sync what Sulekhak learns...");
        readonly ToolStripMenuItem miSyncNow = new ToolStripMenuItem("Sync now");
        readonly ToolStripMenuItem miSignOut = new ToolStripMenuItem("Sign out of Google");
        GoogleSync gsync;
        EngineHost host;
        CandPopup popup;
        OskForm oskFlat;               // plain on-screen keyboard, used only if the 3D one cannot start
        Osk3dForm osk3d;               // the 3D keyboard with the Mac / Windows / iPad / Android styles
        volatile bool osk3dOk;
        IntPtr lastExternal = IntPtr.Zero;
        Native.LowLevelProc proc;        // kept in a field so the garbage collector cannot free it
        IntPtr hook = IntPtr.Zero;
        TipBridge tip;                   // the pipe the Windows text service (Sulekhak as a real input method) talks to
        bool tsfMode;                    // the text service works on this computer: Windows does the typing, the keyboard hook stays off
        bool tipSeen;                    // the text service has talked to this program: it is certainly live for this user
        bool? pipeOk;                    // result of the pipe self-test (null: not tested yet)
        string pipeWhy = "";
        string modeWhy = "";
        readonly Timer modeTimer = new Timer();
        Native.LowLevelProc mouseProc;   // a click moves the caret: what was typed last is then no longer right before it
        IntPtr mouseHook = IntPtr.Zero;
        string lastOut;                  // the text typed by the last pick, while it is certainly still just before the caret (for the lone nukta key)
        IntPtr lastOutWin = IntPtr.Zero;
        Icon iconOn, iconOff;
        bool enabled = true;
        bool phon;                       // Phonetic mode: each key offers the IPA, extIPA and IAST symbols that look like it (Tab swaps)

        readonly StringBuilder buf = new StringBuilder();
        List<string> cands = new List<string>();
        List<string> nextList = new List<string>();      // words that usually follow the last word (shown on the keyboard strip)
        int nid = 0;
        int sel = 0, qid = 0;
        string prev = "<s>";
        IntPtr bufWindow = IntPtr.Zero;
        Rectangle anchor = Rectangle.Empty;
        readonly HashSet<uint> swallowed = new HashSet<uint>();
        readonly Timer watch = new Timer();

        public App()
        {
            try { Extract(); }
            catch (Exception ex)
            {
                MessageBox.Show("Could not prepare the language data:\n" + ex.Message, "Sulekhak", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ExitThread();
                return;
            }
            script = Edition >= 0 ? Edition : 0;
            { int sv = LoadSetting("Script", script); if (Allows(sv)) script = sv; }
            if (script != 0 && script != 1 && script != 2 && script != 4 && script != 5 && script != 6) script = Edition >= 0 ? Edition : 0;
            lastScript = (script == 4 || script == 6) ? (Edition >= 0 && Edition != 4 ? Edition : 0) : script; dvOpts = LoadSetting("Opts", 0) & 3; phon = script == 4;
            iconOn = LoadIcon("sulekhak.ico") ?? MakeIcon(Color.FromArgb(58, 99, 208));
            iconOff = LoadIcon("sulekhak-off.ico") ?? MakeIcon(Color.Gray);
            popup = new CandPopup();
            popup.Picked += delegate (int idx) { Commit(idx, true); };
            oskFlat = new OskForm();
            oskFlat.KeyPressed += OskKey;
            osk3d = new Osk3dForm(dir);
            osk3d.SetScript(script, dvOpts);
            osk3d.KeyPressed += OskKey;
            osk3d.TextPicked += OskText;
            osk3d.SuggestPicked += OskSuggest;
            var menu = new ContextMenuStrip();
            miToggle.Click += delegate { Toggle(); };
            miStart.Checked = StartupOn();
            MigrateStartup();
            miStart.Click += delegate { SetStartup(!StartupOn()); miStart.Checked = StartupOn(); };
            var miExit = new ToolStripMenuItem("Exit");
            miExit.Click += delegate { Quit(); };
            miOsk.Click += delegate { ToggleOsk(); };
            menu.Items.Add(miToggle);
            {                                                // choose the script here (Ctrl+Alt+1 Odia, 2 Devanagari, 3 Bangla, 6 Assamese, 7 Phonetic, 8 English); a language edition lists its own language, Phonetic and English
                int[] scs = { 0, 1, 5, 2, 4, 6 }; string[] keys = { "1", "2", "6", "3", "7", "8" };
                for (int q = 0; q < scs.Length; q++)
                {
                    int sc = scs[q];
                    if (!Allows(sc)) continue;
                    miScript[sc] = new ToolStripMenuItem(ScriptName(sc) + "   (Ctrl+Alt+" + keys[q] + ")");
                    miScript[sc].Click += delegate { SetScript(sc); };
                    menu.Items.Add(miScript[sc]);
                }
            }
            if (Edition < 0 || Edition == 1)
            {
                var miMar = new ToolStripMenuItem("Devanagari: Marathi ळ   (Ctrl+Alt+4)"); miMar.Click += delegate { ToggleOpt(1); };
                var miAnu = new ToolStripMenuItem("Devanagari: anusvara ं instead of conjuncts   (Ctrl+Alt+5)"); miAnu.Click += delegate { ToggleOpt(2); };
                menu.Items.Add(miMar); menu.Items.Add(miAnu);
            }
            miSurround.Checked = autoSurround;
            miSurround.Click += delegate { autoSurround = !autoSurround; miSurround.Checked = autoSurround; SaveSetting("AutoSurround", autoSurround ? 1 : 0); };
            menu.Items.Add(miSurround);
            CandPopup.ThemeMode = LoadBaseSetting("CandTheme", 0);
            var miTh = new ToolStripMenuItem("Candidate box colour");
            var thNames = new[] { "Follow Windows (light or dark)", "Light", "Dark" };
            var thItems = new ToolStripMenuItem[3];
            for (int ti = 0; ti < 3; ti++)
            {
                int tv = ti;
                thItems[ti] = new ToolStripMenuItem(thNames[ti]) { Checked = CandPopup.ThemeMode == ti };
                thItems[ti].Click += delegate { CandPopup.ThemeMode = tv; SaveBaseSetting("CandTheme", tv); for (int j = 0; j < 3; j++) thItems[j].Checked = j == tv; };
                miTh.DropDownItems.Add(thItems[ti]);
            }
            menu.Items.Add(miTh);
            var miEnCap = new ToolStripMenuItem("English: capital letter at the start of a sentence, and for I");
            var miEnSmart = new ToolStripMenuItem("English: curly quotes, \u2014 for -- and \u2026 for ...");
            miEnCap.Checked = LoadBaseSetting("EnCap", 1) != 0; miEnSmart.Checked = LoadBaseSetting("EnSmart", 1) != 0;
            miEnCap.Click += delegate { miEnCap.Checked = !miEnCap.Checked; SaveBaseSetting("EnCap", miEnCap.Checked ? 1 : 0); };
            miEnSmart.Click += delegate { miEnSmart.Checked = !miEnSmart.Checked; SaveBaseSetting("EnSmart", miEnSmart.Checked ? 1 : 0); };
            var miEnNext = new ToolStripMenuItem("English: offer the next word (Tab takes it)");
            miEnNext.Checked = LoadBaseSetting("EnNext", 1) != 0;
            miEnNext.Click += delegate { miEnNext.Checked = !miEnNext.Checked; SaveBaseSetting("EnNext", miEnNext.Checked ? 1 : 0); };
            menu.Items.Add(miEnCap); menu.Items.Add(miEnSmart); menu.Items.Add(miEnNext);
            menu.Items.Add(miOsk);
            menu.Items.Add(miStatus);
            menu.Items.Add(new ToolStripSeparator());
            var miAddKb = new ToolStripMenuItem("Add Sulekhak keyboards to Windows...");
            miAddKb.Click += delegate { TipSetup.Report(null); };
            menu.Items.Add(miAddKb);
            var miLearn = new ToolStripMenuItem("Show the learning files (one JSON per language)");
            miLearn.Click += delegate
            {
                try { string d = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Sulekhak", "learning"); Directory.CreateDirectory(d); System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(d) { UseShellExecute = true }); }
                catch (Exception ex) { MessageBox.Show(ex.Message, "Sulekhak"); }
            };
            menu.Items.Add(miLearn);
            var miCheck = new ToolStripMenuItem("Check installation...");
            miCheck.Click += delegate { ShowDiagnostics(); };
            menu.Items.Add(miCheck);
            menu.Items.Add(miStart);
            menu.Items.Add(new ToolStripSeparator());
            miSignIn.Click += delegate { SignInClicked(); };
            miSyncNow.Click += delegate { host.SyncNow(); };
            miSignOut.Click += delegate { gsync.SignOut(); host.SignedOut(); UpdateSyncMenu(); };
            menu.Items.Add(miSyncStatus); menu.Items.Add(miSignIn); menu.Items.Add(miSyncNow); menu.Items.Add(miSignOut);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(miExit);
            tray.ContextMenuStrip = menu;
            tray.MouseClick += delegate (object s, MouseEventArgs e) { if (e.Button == MouseButtons.Left) Toggle(); };
            tray.Visible = true;
            UpdateTray();

            SetUserExit(false);
            MigrateHistory();
            gsync = new GoogleSync();
            host = new EngineHost(dir, histPath);
            host.Sync = gsync;
            host.SetScript(script, dvOpts);
            host.Candidates += OnCandidates;
            host.NextWords += OnNextWords;
            host.SmartReady += delegate
            {
                miStatus.Text = "Smart suggestions: ready";
                tray.ShowBalloonTip(2000, "Sulekhak", "Smart suggestions are ready.", ToolTipIcon.Info);
            };
            var t = host.StartAsync();
            t.ContinueWith(delegate (System.Threading.Tasks.Task task)
            {
                if (task.IsFaulted)
                {
                    try
                    {
                        host.BeginInvoke(new Action(delegate
                        {
                            MessageBox.Show("The Microsoft Edge WebView2 Runtime is needed for the word suggestions.\nInstall it from https://go.microsoft.com/fwlink/p/?LinkId=2124703 and start Sulekhak again.\n\n" + task.Exception.GetBaseException().Message,
                                "Sulekhak", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }));
                    }
                    catch { }
                }
            });

            osk3d.StartAsync().ContinueWith(delegate (System.Threading.Tasks.Task task) { osk3dOk = !task.IsFaulted; });

            tip = new TipBridge(host, host, popup, delegate (int sc) { SetScript(sc); }, delegate { return new int[] { script, dvOpts }; });
            tip.TipContact += delegate { if (!tipSeen) { tipSeen = true; try { BeginInvokeUi(delegate { ApplyMode(false); }); } catch { } } };
            tip.Start();
            // Who types?  With the text service working (Win+Space lists Sulekhak) Windows itself delivers the keys and the older keyboard hook stays off
            // (it would type every word twice).  Whenever the text service cannot work on this computer, or cannot be reached, the hook types, exactly like the
            // portable program, so that an installed Sulekhak is never worse than the portable one.  ApplyMode decides, and decides again every 20 seconds.
            ApplyMode(true);
            modeTimer.Interval = 20000;
            modeTimer.Tick += delegate { ApplyMode(false); if (pipeOk == false) BackgroundPipeTest(0); };
            modeTimer.Start();
            BackgroundPipeTest(4000);

            if (TipBridge.Registered() && !TipSetup.IsArm64()) { try { host.BeginInvoke(new Action(delegate { TipSetup.OfferOnce(null); })); } catch { } }
            else if (!TipBridge.Registered()) { try { host.BeginInvoke(new Action(delegate { TipSetup.PortableNoteOnce(null); })); } catch { } }
            host.SyncState += delegate (string st, string detail) { try { BeginInvokeUi(delegate { SyncStateChanged(st, detail); }); } catch { } };
            gsync.Changed += delegate { try { BeginInvokeUi(UpdateSyncMenu); } catch { } };
            UpdateSyncMenu();
            if (gsync.Configured && !gsync.SignedIn && LoadSetting("SyncAsked", 0) == 0) { try { host.BeginInvoke(new Action(OfferSignIn)); } catch { } }

            watch.Interval = 400;
            watch.Tick += delegate
            {
                IntPtr fg = Native.GetForegroundWindow();
                bool own = fg == osk3d.Handle || fg == oskFlat.Handle || fg == popup.Handle;
                if (!own) lastExternal = fg;
                if (buf.Length > 0 && !own && fg != bufWindow) { ClearBuffer(); prev = "<s>"; }
            };
            watch.Start();
            tray.ShowBalloonTip(2500, "Sulekhak " + ScriptName(script) + " typing", tsfMode
                ? "Ready. Press Win+Space and choose a Sulekhak keyboard. Ctrl+Alt+K shows the on-screen keyboard."
                : "ON. Type Roman letters. The tray menu switches it off, Ctrl+Alt+K shows the on-screen keyboard.", ToolTipIcon.Info);
            Log("started; " + (tsfMode ? "the text service types" : "the keyboard hook types") + " (" + modeWhy + ")");
        }

        void MigrateHistory()
        {
            try
            {
                if (File.Exists(histPath)) return;
                string old = Path.Combine(root, "v1", "history.tsv");
                if (File.Exists(old)) File.Copy(old, histPath);
            }
            catch { }
        }

        // ------------------------------------------------------------------ first-run data extraction
        void Extract()
        {
            string ok = Path.Combine(dir, ".ok");
            if (File.Exists(ok)) return;
            Directory.CreateDirectory(Path.Combine(dir, "sulekhak"));
            string[] plain = { "ime.html", "ime.js", "engine.js", "sulekhak.js", "osk.html", "kb3d.js", "phon-data.js", "phon-core.js", "learning.js", "drive.js", "personal.js" };
            foreach (var n in plain) CopyRes(n, Path.Combine(dir, n), false);
            // English (personal build): the engine and its word lists. A build without them still works; it just has no English.
            Directory.CreateDirectory(Path.Combine(dir, "sulekhak", "en"));
            CopyResIfPresent("english.js", Path.Combine(dir, "english.js"), false);
            foreach (var n in new[] { "en_lex", "en_ng", "en_fix" }) CopyResIfPresent(n + ".gz", Path.Combine(dir, "sulekhak", "en", n + ".txt"), true);
            CopyRes("skel.dat.gz", Path.Combine(dir, "skel.dat"), true);
            CopyRes("cfg.gz", Path.Combine(dir, "sulekhak", "cfg.json"), true);
            foreach (var n in new[] { "lex", "rom", "clus", "syl_uni", "syl_bi", "syl_chan" })
                CopyRes(n + ".gz", Path.Combine(dir, "sulekhak", n + ".txt"), true);
            CopyRes("ng.gz", Path.Combine(dir, "sulekhak", "ng.bin"), true);          // the bigram and trigram language model
            CopyRes("idx.gz", Path.Combine(dir, "sulekhak", "idx.bin"), true);        // the prefix index of the word list
            File.WriteAllText(ok, DataVersion);
        }

        static void CopyResIfPresent(string name, string to, bool gunzip)
        {
            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(name)) { if (s == null) return; }
            CopyRes(name, to, gunzip);
        }

        static void CopyRes(string name, string to, bool gunzip)
        {
            var asm = Assembly.GetExecutingAssembly();
            using (var s = asm.GetManifestResourceStream(name))
            {
                if (s == null) throw new FileNotFoundException("missing resource " + name);
                using (var o = File.Create(to))
                {
                    if (gunzip) { using (var g = new GZipStream(s, CompressionMode.Decompress)) g.CopyTo(o); }
                    else s.CopyTo(o);
                }
            }
        }

        // ------------------------------------------------------------------ tray
        /// <summary>The Sulekhak logo (embedded .ico: the same ସୁ logo as on Mac, iPad and the keyboard list). Null if it cannot be read.</summary>
        static Icon LoadIcon(string name)
        {
            try
            {
                using (var s = typeof(App).Assembly.GetManifestResourceStream(name))
                {
                    if (s == null) return null;
                    var sz = System.Windows.Forms.SystemInformation.SmallIconSize;
                    return new Icon(s, sz);
                }
            }
            catch { return null; }
        }

        static Icon MakeIcon(Color c)
        {
            using (var bmp = new Bitmap(32, 32))
            {
                using (var g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    using (var b = new SolidBrush(c)) g.FillEllipse(b, 1, 1, 30, 30);
                    using (var pen = new Pen(Color.White, 4f)) g.DrawEllipse(pen, 9, 8, 14, 15);
                }
                IntPtr h = bmp.GetHicon();
                var ic = (Icon)Icon.FromHandle(h).Clone();
                Native.DestroyIcon(h);
                return ic;
            }
        }

        // ------------------------------------------------------------------ who types: Windows (the text service) or the keyboard hook
        static readonly string logPath = Path.Combine(root, "sulekhak.log");
        static readonly object logLock = new object();
        /// <summary>One line in %LOCALAPPDATA%\Sulekhak\sulekhak.log (kept under 200 KB). Nothing typed is ever written here.</summary>
        internal static void Log(string line)
        {
            try
            {
                lock (logLock)
                {
                    Directory.CreateDirectory(root);
                    var fi = new FileInfo(logPath);
                    if (fi.Exists && fi.Length > 200 * 1024) { string old = logPath + ".old"; if (File.Exists(old)) File.Delete(old); File.Move(logPath, old); }
                    File.AppendAllText(logPath, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + line + "\r\n", Encoding.UTF8);
                }
            }
            catch { }
        }

        /// <summary>Should Windows (the text service) type, or the keyboard hook?  why says which check decided.</summary>
        bool WantTsf(out string why)
        {
            if (LoadSetting("ForceHook", 0) != 0) { why = "the ForceHook setting is on"; return false; }
            if (!TipBridge.Registered()) { why = TipBridge.InstalledByInstaller() ? "the text service is not registered on this computer" : "this is the portable program"; return false; }
            if (TipSetup.IsArm64()) { why = "Windows on ARM: the text service is built for x64 and ARM programs cannot load it"; return false; }
            string dll = TipBridge.RegisteredDll();
            if (string.IsNullOrEmpty(dll) || !File.Exists(dll)) { why = "the registered text service file is missing (" + (dll ?? "no path") + ")"; return false; }
            if (pipeOk == false) { why = "the text service could not reach this program (" + pipeWhy + ")"; return false; }
            if (!tipSeen && !TipSetup.InUserList()) { why = "no Sulekhak keyboard is in your Win+Space list yet"; return false; }
            why = tipSeen ? "the Sulekhak keyboard is in use" : "the Sulekhak keyboards are in your Win+Space list";
            return true;
        }

        void StartHooks()
        {
            if (hook == IntPtr.Zero)
            {
                proc = HookCallback;
                hook = Native.SetWindowsHookEx(Native.WH_KEYBOARD_LL, proc, Native.GetModuleHandle(null), 0);
                if (hook == IntPtr.Zero) { Log("could not start the keyboard hook"); MessageBox.Show("Could not start the keyboard hook.", "Sulekhak", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            if (mouseHook == IntPtr.Zero)
            {
                mouseProc = MouseCallback;
                mouseHook = Native.SetWindowsHookEx(Native.WH_MOUSE_LL, mouseProc, Native.GetModuleHandle(null), 0);     // optional: without it the lone nukta key simply types a nukta
            }
        }

        void StopHooks()
        {
            if (hook != IntPtr.Zero) { Native.UnhookWindowsHookEx(hook); hook = IntPtr.Zero; }
            if (mouseHook != IntPtr.Zero) { Native.UnhookWindowsHookEx(mouseHook); mouseHook = IntPtr.Zero; }
        }

        void ApplyMode(bool first)
        {
            string why;
            bool want = WantTsf(out why);
            modeWhy = why;
            if (!first && want == tsfMode) return;
            tsfMode = want;
            if (tsfMode) { buf.Length = 0; try { popup.HidePopup(); } catch { } StopHooks(); } else StartHooks();
            Log((tsfMode ? "text service types: " : "keyboard hook types: ") + why);
            if (!first)
            {
                tray.ShowBalloonTip(3500, "Sulekhak", tsfMode
                    ? "Windows now delivers the keys: press Win+Space and choose a Sulekhak keyboard."
                    : "Typing with the keyboard hook (" + why + "). The tray menu switches it off.", ToolTipIcon.Info);
                UpdateTray();
            }
        }

        /// <summary>Asks the program's own pipe (as the text service would) a few seconds after start, then again whenever it failed.</summary>
        void BackgroundPipeTest(int delayMs)
        {
            System.Threading.Tasks.Task.Run(delegate
            {
                System.Threading.Thread.Sleep(delayMs);
                string r = null;
                for (int i = 0; i < 3; i++) { r = TipBridge.SelfTest(); if (r == null) break; System.Threading.Thread.Sleep(1500); }
                pipeWhy = r ?? "";
                bool ok = r == null;
                if (pipeOk != ok) Log("pipe self-test: " + (ok ? "ok" : "FAILED: " + r));
                pipeOk = ok;
                try { BeginInvokeUi(delegate { ApplyMode(false); }); } catch { }
            });
        }

        string Diagnose()
        {
            var sb = new StringBuilder();
            Func<bool, string> ok = delegate (bool b) { return b ? "OK     " : "PROBLEM"; };
            string dll = TipBridge.RegisteredDll();
            bool reg = TipBridge.Registered();
            sb.AppendLine("Sulekhak " + Assembly.GetExecutingAssembly().GetName().Version + "   Windows " + Environment.OSVersion.Version + "   " + System.Runtime.InteropServices.RuntimeInformation.OSArchitecture + " (this program: " + System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture + ")");
            sb.AppendLine("Program: " + Application.ExecutablePath);
            sb.AppendLine("Installed with the installer: " + (TipBridge.InstalledByInstaller() ? "yes" : "no (portable)"));
            sb.AppendLine(ok(reg || !TipBridge.InstalledByInstaller()) + " Text service registered with Windows: " + (reg ? "yes" : "no"));
            sb.AppendLine(ok(!reg || (dll != null && File.Exists(dll))) + " Text service file: " + (dll ?? "(none)") + (dll != null && !File.Exists(dll) ? "  <- MISSING" : ""));
            sb.AppendLine(ok(!reg || TipSetup.InUserList() || tipSeen) + " Sulekhak keyboards in your Win+Space list: " + (TipSetup.InUserList() ? "yes" : "no"));
            string pr = TipBridge.SelfTest();
            sb.AppendLine(ok(pr == null) + " The pipe between keyboard and program: " + (pr == null ? "answers" : pr));
            sb.AppendLine(ok(host != null && host.EngineUp) + " Word engine (WebView2): " + (host != null && host.EngineUp ? "running" : "not running yet"));
            sb.AppendLine(ok(TipSetup.IsArm64() ? !reg : true) + " Windows on ARM: " + (TipSetup.IsArm64() ? "yes, so typing uses the keyboard hook" : "no"));
            sb.AppendLine("Text service seen in use this session: " + (tipSeen ? "yes" : "no"));
            sb.AppendLine();
            sb.AppendLine("Who types now: " + (tsfMode ? "Windows (the Sulekhak keyboard chosen with Win+Space)" : "the keyboard hook (the tray menu switches it off and on)"));
            sb.AppendLine("Because: " + modeWhy);
            sb.AppendLine();
            sb.AppendLine("Log file: " + logPath);
            try
            {
                string tl = Path.Combine(root, "tip.log");
                if (File.Exists(tl))
                {
                    var lines = File.ReadAllLines(tl);
                    sb.AppendLine("Last problems seen by the keyboard itself (" + tl + "):");
                    for (int i = Math.Max(0, lines.Length - 5); i < lines.Length; i++) sb.AppendLine("   " + lines[i]);
                }
            }
            catch { }
            return sb.ToString();
        }

        void ShowDiagnostics()
        {
            string rep = Diagnose();
            Log("check installation:\r\n" + rep);
            try { Clipboard.SetText(rep); } catch { }
            MessageBox.Show(rep + "\r\n(This report is also copied to the clipboard.)", "Sulekhak: check installation", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ------------------------------------------------------------------ Google sync (personal build)
        void BeginInvokeUi(Action a) { if (host != null && host.IsHandleCreated) host.BeginInvoke(a); }
        void UpdateSyncMenu()
        {
            bool cfg = gsync != null && gsync.Configured, on = cfg && gsync.SignedIn;
            miSignIn.Visible = cfg && !on; miSyncNow.Visible = on; miSignOut.Visible = on;
            miSyncStatus.Visible = cfg || BuildInfo.Repo != "Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard";      // the public build has no sign-in at all: no line about it
            miSyncStatus.Text = !cfg ? "Sync: not set up in this build" : on ? "Sync: signed in as " + gsync.Email : "Sync: not signed in";
        }
        void SyncStateChanged(string st, string detail)
        {
            if (gsync == null) return;
            if (st == "refused") { miSyncStatus.Text = "Sync: " + detail + " is not an authorised account"; return; }
            if (st == "synced") miSyncStatus.Text = "Sync: up to date (" + detail + ") - " + gsync.Email;
            else if (st == "syncing") miSyncStatus.Text = "Sync: working...";
            else if (st == "error") miSyncStatus.Text = "Sync: will retry (" + detail + ")";
            else UpdateSyncMenu();
        }
        async void SignInClicked()
        {
            string err = await gsync.SignInAsync();
            if (err != null) { MessageBox.Show(err, "Sulekhak - sign in with Google", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            host.GiveToken();
            UpdateSyncMenu();
        }
        void OfferSignIn()
        {
            SaveSetting("SyncAsked", 1);
            var r = MessageBox.Show("Sign in with your Google account so that the words you pick and the corrections you make are kept in step on all your devices?\n\nOnly your own, authorised Google account works. The data lives in a hidden app folder of your Google Drive, one file per language.",
                "Sulekhak", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes) SignInClicked();
        }

        void UpdateTray()
        {
            tray.Icon = enabled ? iconOn : iconOff;
            string nm = ScriptName(script);
            tray.Text = enabled ? ("Sulekhak: " + nm + " typing ON") : "Sulekhak: typing OFF";
            for (int q = 0; q < miScript.Length; q++) if (miScript[q] != null) miScript[q].Checked = q == script;
            miToggle.Text = enabled ? "Switch " + nm + " typing OFF" : "Switch " + nm + " typing ON";
        }

        void ToggleOsk()
        {
            Form o = osk3dOk ? (Form)osk3d : oskFlat;
            if (o.Visible) o.Hide(); else o.Show();
        }

        /// <summary>Ctrl+Alt+P: Phonetic (IPA) mode on, and back to the script you were typing.</summary>
        void TogglePhon()
        {
            if (!Allows(4)) return;
            SetScript(phon ? lastScript : 4);
        }

        void SetScript(int sc)
        {
            if (!Allows(sc)) return;                                          // an edition types its own language, English and Phonetic
            ClearBuffer(); prev = "<s>";
            script = sc; phon = sc == 4; if (sc != 4 && sc != 6) lastScript = sc;
            SaveSetting("Script", script);
            if (host != null) host.SetScript(script, dvOpts);
            if (osk3dOk && sc != 6) osk3d.SetScript(script, dvOpts);          // English has no layout of its own on the on-screen keyboard
            if (phon && !enabled) enabled = true;
            UpdateTray();
            string note = phon ? (host != null && host.PhonMap != null ? "Phonetic mode ON: each key offers the IPA, extIPA and IAST symbols that look like it. Tab swaps, Enter keeps. Ctrl+Alt+P goes back to " + ScriptName(lastScript) + "."
                                                                       : "Phonetic mode ON, still loading its symbol lists.") : sc == 6 ? (tsfMode ? "English: suggestions and spelling while you type. Space types the word (a clear spelling mistake is corrected, and Backspace right after puts your letters back); Tab chooses another word." : "English needs the Sulekhak keyboard in Win+Space (the text service); the keyboard hook does not do English.") : ScriptName(script) + " typing";
            tray.ShowBalloonTip(sc == 6 ? 4000 : 1800, "Sulekhak", note, ToolTipIcon.None);
        }

        /// <summary>Devanagari options: Marathi ळ (bit 1) and anusvara instead of nasal conjuncts (bit 2). In the all-in-one they also switch to Devanagari.</summary>
        void ToggleOpt(int bit)
        {
            if (Edition >= 0 && Edition != 1) return;
            dvOpts ^= bit; SaveSetting("Opts", dvOpts);
            if (script != 1 && Allows(1)) { SetScript(1); return; }
            ClearBuffer();
            if (host != null) host.SetScript(script, dvOpts);
            if (osk3dOk) osk3d.SetScript(script, dvOpts);
            tray.ShowBalloonTip(1500, "Sulekhak", ((dvOpts & 1) != 0 ? "Marathi ळ" : "ल for ଳ") + (((dvOpts & 2) != 0) ? " · anusvara ं" : " · conjuncts"), ToolTipIcon.None);
        }

        /// <summary>Ctrl+Alt+1 Odia, 2 Devanagari, 3 Bangla, 4 Marathi, 5 anusvara, 6 Assamese, 7 Phonetic, 8 English.</summary>
        bool HotScript(uint vk)
        {
            switch (vk)
            {
                case 0x31: if (!Allows(0)) return false; SetScript(0); return true;
                case 0x32: if (!Allows(1)) return false; SetScript(1); return true;
                case 0x33: if (!Allows(2)) return false; SetScript(2); return true;
                case 0x34: if (Edition >= 0 && Edition != 1) return false; ToggleOpt(1); return true;
                case 0x35: if (Edition >= 0 && Edition != 1) return false; ToggleOpt(2); return true;
                case 0x36: if (!Allows(5)) return false; SetScript(5); return true;
                case 0x37: if (!Allows(4)) return false; SetScript(4); return true;
                case 0x38: if (!Allows(6)) return false; SetScript(6); return true;
            }
            return false;
        }

        void Toggle()
        {
            enabled = !enabled;
            if (!enabled) { ClearBuffer(); prev = "<s>"; }
            UpdateTray();
            tray.ShowBalloonTip(1200, "Sulekhak", ScriptName(script) + (enabled ? " typing ON" : " typing OFF"), ToolTipIcon.None);
        }

        /// <summary>An older copy of Sulekhak may be what starts with Windows: when this one was installed to its proper place, it takes over that entry.</summary>
        static void MigrateStartup()
        {
            try
            {
                string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
                if (!Application.ExecutablePath.StartsWith(pf, StringComparison.OrdinalIgnoreCase)) return;
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (k == null) return;
                    string v = k.GetValue(RunName) as string;
                    if (v != null && !v.Trim('"').Equals(Application.ExecutablePath, StringComparison.OrdinalIgnoreCase)) k.SetValue(RunName, "\"" + Application.ExecutablePath + "\"");
                }
            }
            catch { }
        }

        static bool StartupOn()
        {
            using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", false))
                return k != null && k.GetValue(RunName) != null;
        }

        static void SetStartup(bool on)
        {
            using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
            {
                if (k == null) return;
                if (on) k.SetValue(RunName, "\"" + Application.ExecutablePath + "\"");
                else k.DeleteValue(RunName, false);
            }
        }

        /// <summary>Exit in the tray menu is an exit: the text service must not start the program again behind the user's back (HKCU\Software\Sulekhak\UserExit).</summary>
        static void SetUserExit(bool on)
        {
            try { using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Sulekhak")) { if (on) k.SetValue("UserExit", 1, RegistryValueKind.DWord); else k.DeleteValue("UserExit", false); } }
            catch { }
        }

        void Quit()
        {
            SetUserExit(true);
            try { watch.Stop(); } catch { }
            try { modeTimer.Stop(); } catch { }
            StopHooks();
            tray.Visible = false;
            try { popup.Close(); oskFlat.Close(); osk3d.Close(); host.Close(); } catch { }
            ExitThread();
        }

        // ------------------------------------------------------------------ typing logic
        void OnCandidates(int id, string b, List<string> list)
        {
            if (id != qid || buf.Length == 0) return;
            if (!phon) list = TipBridge.ScriptFilter(script, list);
            cands = list.Count > 0 ? list : new List<string> { buf.ToString() };
            sel = 0;
            ShowPopup(false);
        }

        void ShowPopup(bool newWord)
        {
            if (buf.Length == 0) { popup.HidePopup(); return; }
            var shown = phon ? PhonShow(cands) : ScriptShow(cands, script);
            popup.ShowCands(buf.ToString(), cands, sel, anchor, newWord);       // the popup labels and colours the joiners itself, so every way of showing a list looks the same
            if (osk3dOk) osk3d.SetSuggestions(shown, sel, false);
        }

        /// <summary>A halant with a joiner is spelled out so the difference can be seen: halant + ZWNJ as  ୍ + ┊ , halant + ZWJ as  ୍ + [ , a lone ZWNJ / ZWJ by name. A plain halant stays just the halant.</summary>
        static List<string> ScriptShow(List<string> l, int sc)
        {
            var o = new List<string>(l.Count);
            foreach (var x in l)
            {
                if (x == "\u200C") o.Add("ZWNJ");
                else if (x == "\u200D") o.Add("ZWJ");
                else if (x.Length >= 2 && (x[x.Length - 1] == '\u200C' || x[x.Length - 1] == '\u200D') && x[x.Length - 2] == Halant(sc)[0])
                {
                    string b = x.Substring(0, x.Length - 1);
                    if (b.Length == 1) b = "\u25CC" + b;
                    o.Add(b + " + " + (x[x.Length - 1] == '\u200C' ? "\u250A" : "["));
                }
                else o.Add(x);
            }
            return o;
        }

        /// <summary>A combining mark on its own gets a dotted circle in front, so it can be seen in the list.</summary>
        static List<string> PhonShow(List<string> l)
        {
            var o = new List<string>(l.Count);
            foreach (var x in l)
            {
                var cat = x.Length > 0 ? System.Globalization.CharUnicodeInfo.GetUnicodeCategory(x[0]) : System.Globalization.UnicodeCategory.OtherNotAssigned;
                bool mark = cat == System.Globalization.UnicodeCategory.NonSpacingMark || cat == System.Globalization.UnicodeCategory.SpacingCombiningMark || cat == System.Globalization.UnicodeCategory.EnclosingMark;
                o.Add(mark ? "\u25CC" + x : x);
            }
            return o;
        }

        /// <summary>Phonetic mode: a key with look-alike symbols starts a one-key choice list; keys without any are typed as they are.</summary>
        bool PhonBegin(string ch)
        {
            if (!phon || host == null || host.PhonMap == null || ch.Length != 1 || ch[0] <= 32 || ch[0] >= 127) return false;
            List<string> l;
            if (!host.PhonMap.TryGetValue(ch, out l) || l.Count < 2) return false;
            StartBuf();
            buf.Append(ch);
            cands = new List<string>(l);
            sel = 0;
            ShowPopup(true);
            return true;
        }

        void ClearBuffer()
        {
            buf.Length = 0;
            cands = new List<string>();
            sel = 0;
            anchor = Rectangle.Empty;
            popup.HidePopup();
            nid++;
            nextList = new List<string>();
            if (osk3dOk) osk3d.SetSuggestions(nextList, -1, true);
        }

        void Query()
        {
            if (buf.Length == 0) { ClearBuffer(); return; }
            qid++;
            host.Query(qid, buf.ToString(), prev);
        }

        static bool HasNonAscii(string s)
        {
            foreach (char c in s) if (c > 127) return true;
            return false;
        }

        static bool WordContinues(string w)
        {
            if (w.Length == 0) return true;
            char l = w[w.Length - 1];
            if (w.Length == 1 && (l == '*' || l == '\u0B3D' || l == '\u0B55' || l == '\u0B70' || (l >= '\u0B72' && l <= '\u0B77'))) return true;   // a symbol from the * list: no space after it
            return l == '୍' || l == '‌';
        }

        static bool CanLearn(string roman)
        {
            if (roman.Length == 0) return false;
            foreach (char c in roman) if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) return false;
            return true;
        }

        void Commit(int idx, bool space) { Commit(idx, space, false); }

        /// <summary>Types the chosen word. space: a space after it unless the word goes on; forceSpace: a space after it in every case (the Space key).</summary>
        void Commit(int idx, bool space, bool forceSpace)
        {
            if (buf.Length == 0) return;
            if (phon)                                              // a symbol is typed as it is: no space, nothing learned
            {
                string sym = (idx >= 0 && idx < cands.Count) ? cands[idx] : buf.ToString();
                Native.SendText(sym);
                prev = "<s>";
                lastOut = null;
                ClearBuffer();
                return;
            }
            string roman = buf.ToString();
            string word = (idx >= 0 && idx < cands.Count) ? cands[idx] : roman;
            bool sp = forceSpace || (space && !WordContinues(word));
            string typed = word + (sp ? " " : "");
            Native.SendText(typed);
            lastOut = typed;
            lastOutWin = Native.GetForegroundWindow();
            if (HasNonAscii(word) && CanLearn(roman)) { host.Learn(roman, word); prev = word; }
            else prev = "<s>";
            ClearBuffer();
            if (sp && HasNonAscii(word) && !WordContinues(word)) RequestNext(word);
        }

        /// <summary>Asks the engine which words usually follow `word`; they appear on the keyboard strip when they arrive.</summary>
        void RequestNext(string word)
        {
            nid++;
            if (host != null && host.Ready) host.Next(nid, word);
        }

        void OnNextWords(int id, List<string> list)
        {
            if (id != nid || buf.Length != 0) return;
            nextList = list ?? new List<string>();
            if (osk3dOk) osk3d.SetSuggestions(nextList, -1, true);
        }

        void ClearNext()
        {
            if (nextList.Count == 0) return;
            nid++;
            nextList = new List<string>();
            if (osk3dOk) osk3d.SetSuggestions(nextList, -1, true);
        }

        /// <summary>A suggested word was clicked on the keyboard strip.</summary>
        void OskSuggest(int idx, bool next)
        {
            try
            {
                IntPtr fg = Native.GetForegroundWindow();
                if ((fg == osk3d.Handle || fg == oskFlat.Handle || fg == popup.Handle) && lastExternal != IntPtr.Zero) Native.SetForegroundWindow(lastExternal);
            }
            catch { }
            if (!enabled || host == null) return;
            if (!next) { if (buf.Length > 0) Commit(idx, true); return; }       // a choice for the word being typed
            if (buf.Length > 0) Commit(sel, false);
            if (idx < 0 || idx >= nextList.Count) return;
            string w = nextList[idx];
            Native.SendText(w + " ");
            host.NoteWord(w);
            prev = w;
            RequestNext(w);
        }

        // letters, plus the marks the phonetic scheme uses inside a word: ` (halant) ~ (chandrabindu/anusvara) ' (nukta) > (virama+ZWNJ)
        static bool IsBufChar(string s)
        {
            if (s.Length != 1) return false;
            char c = s[0];
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '`' || c == '~' || c == '\'' || c == '>';
        }

        static bool IsLetter(string s)
        {
            return s.Length == 1 && ((s[0] >= 'a' && s[0] <= 'z') || (s[0] >= 'A' && s[0] <= 'Z'));
        }

        // "|" and "*" (shift + 8) open their own choice lists on the PC keyboard:  |  ->  ।  |  \    *  ->  *  then the Odia symbols no letter key gives (ଽ ୰ ୲ ୳ ୴ ୵ ୶ ୷ ୕)
        bool SymBuf { get { return !phon && buf.Length == 1 && (buf[0] == '*' || buf[0] == '|'); } }

        void StartSymbol(string ch)
        {
            StartBuf();
            buf.Append(ch);
            cands = new List<string> { ch };
            sel = 0;
            ShowPopup(true);
            Query();
        }

        void StartBuf()
        {
            bufWindow = Native.GetForegroundWindow();
            anchor = Native.CaretRect();          // the cursor spot is taken once, at the first letter, so the window does not wander
        }

        // ---- the actions below are shared by the physical keyboard and the on-screen keyboard
        void HandleChar(string ch)
        {
            if (buf.Length == 0)
            {
                if (!IsLetter(ch)) return;
                StartBuf();
                buf.Append(ch);
                cands = new List<string> { buf.ToString() };
                sel = 0;
                ShowPopup(true);
                Query();
                return;
            }
            buf.Append(ch);
            Query();
        }

        void HandleBackspace()
        {
            if (buf.Length == 0) { Native.SendVk(0x08, false); return; }
            if (phon) { ClearBuffer(); return; }                  // drop the pending symbol
            buf.Length -= 1;
            if (buf.Length == 0) ClearBuffer(); else Query();
        }

        void HandleSpace()
        {
            if (buf.Length == 0) { Native.SendVk(0x20, false); return; }
            if (phon) { Commit(sel, false); Native.SendVk(0x20, false); return; }
            Commit(sel, true);
        }

        void HandleEnter()
        {
            if (phon && buf.Length > 0) { Commit(sel, false); return; }       // Enter keeps the symbol (no new line)
            if (buf.Length > 0) Commit(sel, false);
            Native.SendVk(0x0D, false);
            prev = "<s>";
        }

        void HandleEsc() { if (phon && buf.Length > 0) Commit(0, false); else ClearBuffer(); }       // Phonetic: Esc keeps the letter you typed

        void HandleTab(bool back)
        {
            if (buf.Length == 0) { Native.SendVk(0x09, false); return; }
            sel = back ? (sel - 1 + cands.Count) % cands.Count : (sel + 1) % cands.Count;
            ShowPopup(false);
        }

        void HandlePage(bool next)
        {
            if (cands.Count <= 9) return;
            int p = sel / 9;
            if (next) { p++; if (p * 9 >= cands.Count) p = 0; }
            else { p--; if (p < 0) p = (cands.Count - 1) / 9; }
            sel = p * 9;
            ShowPopup(false);
        }

        bool HandleDigit(int n)       // n = 0..8 for the keys 1..9
        {
            int idx = (sel / 9) * 9 + n;
            if (idx < cands.Count) { Commit(idx, true); return true; }
            return false;
        }

        void HandlePunct(string ch)
        {
            if (ch == "|") ch = "।";
            if (buf.Length > 0) Commit(sel, false);
            Native.SendText(ch);
            prev = "<s>";
        }

        // ---- on-screen keyboard
        /// <summary>Text chosen from the on-screen keyboard's long-press popup: finish the word being typed, then put the piece in.</summary>
        void OskText(string t)
        {
            try
            {
                IntPtr fg = Native.GetForegroundWindow();
                if ((fg == osk3d.Handle || fg == oskFlat.Handle || fg == popup.Handle) && lastExternal != IntPtr.Zero) Native.SetForegroundWindow(lastExternal);
            }
            catch { }
            if (enabled && host != null && buf.Length > 0) Commit(sel, false);
            Native.SendText(t);
            prev = "<s>";
        }

        void OskKey(string k)
        {
            // if a click on the keyboard ever made it the active window, hand the focus back to the program being typed in
            try
            {
                IntPtr fg = Native.GetForegroundWindow();
                if ((fg == osk3d.Handle || fg == oskFlat.Handle || fg == popup.Handle) && lastExternal != IntPtr.Zero) Native.SetForegroundWindow(lastExternal);
            }
            catch { }
            if (!enabled || host == null) { SendPlain(k); return; }
            bool composing = buf.Length > 0;
            switch (k)
            {
                case "SPACE": case " ": HandleSpace(); return;
                case "ENTER": HandleEnter(); return;
                case "BACK": HandleBackspace(); return;
                case "TAB": HandleTab(false); return;
                case "ESC": if (composing) HandleEsc(); else Native.SendVk(0x1B, false); return;
                case "ArrowUp": if (composing) HandleTab(true); else Native.SendVk(0x26, true); return;
                case "ArrowDown": if (composing) HandleTab(false); else Native.SendVk(0x28, true); return;
                case "ArrowLeft":
                    if (composing && cands.Count > 9) { HandlePage(false); return; }
                    if (composing) Commit(sel, false);
                    Native.SendVk(0x25, true); return;
                case "ArrowRight":
                    if (composing && cands.Count > 9) { HandlePage(true); return; }
                    if (composing) Commit(sel, false);
                    Native.SendVk(0x27, true); return;
                case "PageUp": if (composing && cands.Count > 9) HandlePage(false); else { if (composing) Commit(sel, false); Native.SendVk(0x21, true); } return;
                case "PageDown": if (composing && cands.Count > 9) HandlePage(true); else { if (composing) Commit(sel, false); Native.SendVk(0x22, true); } return;
                case "Delete": if (composing) Commit(sel, false); Native.SendVk(0x2E, true); return;
            }
            if (k.Length != 1) return;                          // modifier keys and the like
            if (phon)
            {
                if (composing && k[0] >= '1' && k[0] <= '9' && !(buf.Length == 1 && char.IsDigit(buf[0])) && HandleDigit(k[0] - '1')) return;
                if (composing) Commit(sel, false);
                if (!PhonBegin(k)) Native.SendText(k);
                return;
            }
            if (IsLetter(k) || (composing && IsBufChar(k))) { HandleChar(k); return; }
            if (composing && k[0] >= '1' && k[0] <= '9' && HandleDigit(k[0] - '1')) return;
            HandlePunct(k);
        }

        void SendPlain(string k)
        {
            switch (k)
            {
                case "SPACE": Native.SendVk(0x20, false); break;
                case "ENTER": Native.SendVk(0x0D, false); break;
                case "BACK": Native.SendVk(0x08, false); break;
                case "TAB": Native.SendVk(0x09, false); break;
                default: Native.SendText(k); break;
            }
        }

        // ---- physical keyboard
        static bool IsModifier(uint vk)
        {
            return vk == 0x10 || vk == 0xA0 || vk == 0xA1 || vk == 0x11 || vk == 0xA2 || vk == 0xA3 || vk == 0x12 || vk == 0xA4 || vk == 0xA5
                || vk == 0x14 || vk == 0x5B || vk == 0x5C || vk == 0x90 || vk == 0x91;
        }

        static bool IsExtended(uint vk)
        {
            return (vk >= 0x21 && vk <= 0x2E) || vk == 0x5B || vk == 0x5C || vk == 0xA3 || vk == 0xA5 || vk == 0x6F;
        }

        IntPtr Next(int code, IntPtr w, IntPtr l) { return Native.CallNextHookEx(hook, code, w, l); }

        IntPtr Eat(uint vk) { swallowed.Add(vk); return (IntPtr)1; }

        /// <summary>Runs a shortcut's work after the keyboard hook has answered (on the interface thread); without a window yet it runs at once.</summary>
        void BeginHot(Action a)
        {
            Action safe = delegate { try { a(); } catch { } };
            try { if (host != null && host.IsHandleCreated) { host.BeginInvoke(safe); return; } } catch { }
            safe();
        }

        IntPtr HookCallback(int code, IntPtr wParam, IntPtr lParam)
        {
            if (code < 0) return Next(code, wParam, lParam);
            try
            {
                var k = (Native.KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(Native.KBDLLHOOKSTRUCT));
                if ((k.flags & 0x10) != 0 || k.dwExtraInfo == (IntPtr)Native.MAGIC) return Next(code, wParam, lParam);     // our own keys
                int msg = wParam.ToInt32();
                bool down = msg == Native.WM_KEYDOWN || msg == Native.WM_SYSKEYDOWN;
                bool up = msg == Native.WM_KEYUP || msg == Native.WM_SYSKEYUP;
                uint vk = k.vkCode;
                if (up)
                {
                    if (swallowed.Remove(vk)) return (IntPtr)1;
                    return Next(code, wParam, lParam);
                }
                if (!down) return Next(code, wParam, lParam);

                bool ctrl = Native.IsDown(0x11), alt = Native.IsDown(0x12), win = Native.IsDown(0x5B) || Native.IsDown(0x5C), shift = Native.IsDown(0x10);
                // Sulekhak's own Ctrl+Alt shortcuts are swallowed here at once and their work is done a moment later, outside the hook: Windows gives a keyboard
                // hook only a fraction of a second, and a hook that answers late has its answer ignored, so the digit (or letter) used to reach the text.
                // Every Ctrl+Alt+digit is taken, also the ones this edition does not use, so that no digit is ever typed by a language switch.
                if (ctrl && alt && !win && vk == 0x4B) { BeginHot(delegate { ToggleOsk(); }); return Eat(vk); }                       // Ctrl+Alt+K
                if (ctrl && alt && !win && vk == 0x50 && Allows(4)) { BeginHot(delegate { TogglePhon(); }); return Eat(vk); }          // Ctrl+Alt+P: Phonetic (IPA) mode on / off
                if (ctrl && alt && !shift && !win && vk >= 0x30 && vk <= 0x39) { uint hv = vk; BeginHot(delegate { HotScript(hv); }); return Eat(vk); }
                if (!enabled || host == null || IsModifier(vk) || script == 6) return Next(code, wParam, lParam);       // English is done by the text service only

                // a key with Ctrl / Alt / Windows: type the pending word first, then let the shortcut go on
                if (ctrl || alt || win)
                {
                    if (!phon) return RunKey(code, wParam, lParam, vk, "", (ctrl && !alt && !win && vk == 0x08) ? KeyClass.ChordDiscard : KeyClass.Chord);
                    if (buf.Length > 0) return CommitAndReplay(vk);
                    return Next(code, wParam, lParam);
                }

                string ch = Native.CharFor(vk, k.scanCode);

                if (autoSurround && buf.Length == 0 && ch.Length == 1 && Surround.Open.IndexOf(ch[0]) >= 0 && TrySurround(ch[0])) return Eat(vk);

                // every typing rule for the Roman-letter scripts comes from the shared table (keymap/sulekhak-keymap.json), the same as on the Mac
                if (!phon) return RunKey(code, wParam, lParam, vk, ch, KeyMachine.Classify(vk, ch, shift));

                if (buf.Length == 0)
                {
                    if (phon)
                    {
                        if (PhonBegin(ch)) return Eat(vk);
                        return Next(code, wParam, lParam);                                                      // no look-alike symbols: the key goes through as it is
                    }
                    if (IsLetter(ch)) { HandleChar(ch); return Eat(vk); }
                    if (ch == "|" || ch == "*") { StartSymbol(ch); return Eat(vk); }                          // | and * open a choice list (|  ।  \ ;  *  ଽ ୰ ୲ ...)
                    if (vk == 0x20) return Next(code, wParam, lParam);                                         // a space keeps the word context
                    prev = "<s>";
                    ClearNext();
                    return Next(code, wParam, lParam);
                }

                // ---- a word is being typed
                if (phon)
                {
                    bool digitPick = !shift && ((vk >= 0x31 && vk <= 0x39) || (vk >= 0x61 && vk <= 0x69)) && !(buf.Length == 1 && char.IsDigit(buf[0]));
                    if (!digitPick && ch.Length == 1 && ch[0] > 32 && ch[0] < 127)
                    {
                        Commit(sel, false);                                                                     // keep the symbol, then this key starts the next one
                        if (!PhonBegin(ch)) Native.SendText(ch);
                        return Eat(vk);
                    }
                }
                else if (SymBuf && (ch == "|" || ch == "*" || IsLetter(ch)))
                {
                    Commit(sel, false);                                                                         // keep the symbol, then this key starts the next thing
                    if (ch == "|" || ch == "*") StartSymbol(ch); else HandleChar(ch);
                    return Eat(vk);
                }
                else if (IsBufChar(ch)) { HandleChar(ch); return Eat(vk); }
                switch (vk)
                {
                    case 0x08: HandleBackspace(); break;
                    case 0x20: HandleSpace(); break;
                    case 0x0D: HandleEnter(); break;
                    case 0x1B: HandleEsc(); break;
                    case 0x09: if (shift && cands.Count > 9) HandlePage(true); else HandleTab(shift); break;     // Shift+Tab pages when there is more than one page of words (the same spec rule as the other PC apps)
                    case 0x28: HandleTab(false); break;      // Down
                    case 0x26: HandleTab(true); break;       // Up
                    case 0x27: case 0x22: HandlePage(true); break;    // Right / Page Down
                    case 0x25: case 0x21: HandlePage(false); break;   // Left / Page Up
                    default:
                        if (!shift && ((vk >= 0x31 && vk <= 0x39) || (vk >= 0x61 && vk <= 0x69)))
                        {
                            int n = (int)(vk >= 0x61 ? vk - 0x61 : vk - 0x31);
                            if (!HandleDigit(n)) return Eat(vk);                                              // no such candidate: ignore the key
                        }
                        else if (ch.Length > 0 && !char.IsControl(ch[0])) HandlePunct(ch);                    // punctuation: the word, then the mark
                        else return CommitAndReplay(vk);
                        break;
                }
                return Eat(vk);
            }
            catch
            {
                return Next(code, wParam, lParam);
            }
        }

        IntPtr MouseCallback(int code, IntPtr w, IntPtr l)
        {
            if (code >= 0) { int m = w.ToInt32(); if (m == 0x201 || m == 0x204 || m == 0x207 || m == 0x20B) lastOut = null; }
            return Native.CallNextHookEx(mouseHook, code, w, l);
        }

        /// <summary>Asks the shared rules what this key does now, and does it.</summary>
        IntPtr RunKey(int code, IntPtr wParam, IntPtr lParam, uint vk, string ch, KeyClass cls)
        {
            bool nuktaKey = buf.Length == 0 && cls == KeyClass.Gt;
            if (!nuktaKey) lastOut = null;
            bool wasIdle = buf.Length == 0;
            char dg = ch.Length == 1 ? ch[0] : '\0';
            bool pass = false, committed = false;
            Apply(KeyMachine.Decide(buf.ToString(), cands.Count, sel, cls, dg), cls, ch, dg, ref pass, ref committed);
            if (!pass) return Eat(vk);
            if (committed) { Native.SendVk((ushort)vk, IsExtended(vk)); return Eat(vk); }          // the word first, then the key itself
            if (wasIdle && vk != 0x20) { prev = "<s>"; ClearNext(); }                              // any other key ends the word context (a space keeps it)
            return Next(code, wParam, lParam);
        }

        void Apply(string[] effects, KeyClass cls, string ch, char dg, ref bool pass, ref bool committed)
        {
            foreach (string e in effects)
            {
                switch (e)
                {
                    case "start": StartWord(ch); break;
                    case "append": buf.Append(ch); Query(); break;
                    case "commit": Commit(sel, false); committed = true; break;
                    case "commitAuto": Commit(sel, true); break;
                    case "commitSpace": Commit(sel, true, true); break;
                    case "commitTyped": Commit(sel, false); Native.SendText(ch); prev = "<s>"; lastOut = null; break;
                    case "pick": HandleDigit(dg - '1'); break;
                    case "bksp": HandleBackspace(); break;
                    case "discard": ClearBuffer(); break;
                    case "candNext": HandleTab(false); break;
                    case "candPrev": HandleTab(true); break;
                    case "pageNext": HandlePage(true); break;
                    case "pagePrev": HandlePage(false); break;
                    case "nukta": LoneNukta(); break;
                    case "delCodepoint": pass = true; break;            // Windows: what Backspace removes is up to the program (see keymap decisions)
                    case "swallow": break;
                    case "pass": pass = true; break;
                    case "again": Apply(KeyMachine.Decide("", 0, 0, cls, dg), cls, ch, dg, ref pass, ref committed); break;
                    default: throw new InvalidOperationException("effect " + e);
                }
            }
        }

        void StartWord(string ch)
        {
            StartBuf();
            buf.Length = 0;
            buf.Append(ch);
            cands = new List<string> { buf.ToString() };
            sel = 0;
            ShowPopup(true);
            Query();
        }

        /// <summary>A lone  >  : the nukta goes on the ଡ / ଢ of the word typed just before, when that is certainly still before the caret; otherwise a nukta is typed.</summary>
        void LoneNukta()
        {
            int drop; string text;
            if (lastOut != null && lastOutWin == Native.GetForegroundWindow() && Nukta.Edit(lastOut, script, out drop, out text))
            {
                Native.SendBackspaces(drop);
                Native.SendText(text);
                lastOut = lastOut.Substring(0, lastOut.Length - drop) + text;
                return;
            }
            Native.SendText(Nukta.Lone(script));
            lastOut = null;
        }

        /// <summary>With text selected, types  open + text + close  over it and selects the text again (so (( )) can be stacked).</summary>
        bool TrySurround(char open)
        {
            string inner = Surround.Selection();
            if (inner == null || inner.IndexOf('\r') >= 0 || inner.IndexOf('\n') >= 0) return false;      // several lines: leave it as the program does (typing over them would also re-indent)
            Native.SendText(open + inner + Surround.Close[Surround.Open.IndexOf(open)]);
            if (Surround.Simple(inner)) Native.SelectInner(inner.Length);                 // step back over the closing mark, then select the text
            prev = "<s>";
            ClearNext();
            return true;
        }

        IntPtr CommitAndReplay(uint vk)
        {
            Commit(sel, false);
            Native.SendVk((ushort)vk, IsExtended(vk));
            return Eat(vk);
        }
    }
}
