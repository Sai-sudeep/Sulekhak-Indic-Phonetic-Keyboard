using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Sulekhak
{
    /// <summary>
    /// Tray program that types Odia in any Windows program. While it is ON, Roman letters you type are collected in a small
    /// candidate window; Space or a number key types the chosen Odia word into the program you are using.
    /// Ctrl+Alt+O switches it on and off.
    /// </summary>
    class App : ApplicationContext
    {
        const string DataVersion = "5";
        /// <summary>-1 = the all-in-one program; otherwise the one script this copy types: 0 Odia, 1 Devanagari, 2 Bangla, 4 Phonetic (IPA), 5 Assamese. Set by the build (-p:EditionNum=n).</summary>
        internal static readonly int Edition = ReadEdition();
        static int ReadEdition()
        {
            try { foreach (var a in Assembly.GetExecutingAssembly().GetCustomAttributes<AssemblyMetadataAttribute>()) if (a.Key == "Edition") return int.Parse(a.Value); }
            catch { }
            return -1;
        }
        static string EdKey { get { return Edition < 0 ? "" : "\\Ed" + Edition; } }
        static string RunName { get { return Edition < 0 ? "Sulekhak" : "Sulekhak-" + Edition; } }
        static int LoadSetting(string n, int d)
        {
            try { using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Sulekhak" + EdKey)) { if (k != null) { object v = k.GetValue(n); if (v != null) return Convert.ToInt32(v); } } }
            catch { }
            return d;
        }
        static void SaveSetting(string n, int v)
        {
            try { using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Sulekhak" + EdKey)) k.SetValue(n, v); }
            catch { }
        }
        static string ScriptName(int sc) { return sc == 1 ? "Devanagari" : sc == 2 ? "Bangla" : sc == 4 ? "Phonetic IPA" : sc == 5 ? "Assamese" : "Odia"; }
        static string Halant(int sc) { return sc == 1 ? "\u094D" : (sc == 2 || sc == 5) ? "\u09CD" : "\u0B4D"; }
        int script;                       // the script being typed now (always Edition in an edition)
        int lastScript;                   // the script to go back to when Phonetic mode is switched off
        int dvOpts;                       // Devanagari: bit 1 Marathi ळ, bit 2 anusvara instead of nasal conjuncts
        readonly ToolStripMenuItem[] miScript = new ToolStripMenuItem[6];
        static readonly string root = MigrateRoot(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Sulekhak"));
        static string MigrateRoot(string n)
        {
            try { string o = Path.Combine(Path.GetDirectoryName(n), "Sulekhk"); if (!Directory.Exists(n) && Directory.Exists(o)) Directory.Move(o, n); } catch { }
            return n;
        }
        readonly string dir = Path.Combine(root, "v" + DataVersion);
        readonly string histPath = Path.Combine(root, "history.tsv");      // outside the versioned folder, so words you taught it survive updates
        readonly NotifyIcon tray = new NotifyIcon();
        readonly ToolStripMenuItem miToggle = new ToolStripMenuItem();
        readonly ToolStripMenuItem miStart = new ToolStripMenuItem("Start with Windows");
        readonly ToolStripMenuItem miSurround = new ToolStripMenuItem("Auto-surround selected text:  ( )  [ ]  { }  \" \"  ' '  ` `  < >");
        bool autoSurround = LoadSetting("AutoSurround", 0) != 0;       // off until switched on (it reads the selection through UI Automation)
        readonly ToolStripMenuItem miOsk = new ToolStripMenuItem("On-screen keyboard   (Ctrl+Alt+K)");
        readonly ToolStripMenuItem miStatus = new ToolStripMenuItem("Smart suggestions: loading") { Enabled = false };
        EngineHost host;
        CandPopup popup;
        OskForm oskFlat;               // plain on-screen keyboard, used only if the 3D one cannot start
        Osk3dForm osk3d;               // the 3D keyboard with the Mac / Windows / iPad / Android styles
        volatile bool osk3dOk;
        IntPtr lastExternal = IntPtr.Zero;
        Native.LowLevelProc proc;        // kept in a field so the garbage collector cannot free it
        IntPtr hook = IntPtr.Zero;
        Icon iconOn, iconOff;
        bool enabled = true;
        bool phon;                       // Phonetic mode: each key offers the IPA, extIPA and IAST symbols that look like it (Tab swaps)

        readonly StringBuilder buf = new StringBuilder();
        List<string> cands = new List<string>();
        List<string> nextList = new List<string>();      // words that usually follow the last word (shown on the keyboard strip)
        int nid = 0;
        int sel = 0, qid = 0;
        string prev = "<s>";
        IntPtr bufWindow = IntPtr.Zero;
        Rectangle anchor = Rectangle.Empty;
        readonly HashSet<uint> swallowed = new HashSet<uint>();
        readonly Timer watch = new Timer();

        public App()
        {
            try { Extract(); }
            catch (Exception ex)
            {
                MessageBox.Show("Could not prepare the language data:\n" + ex.Message, "Sulekhak", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ExitThread();
                return;
            }
            script = Edition >= 0 ? Edition : LoadSetting("Script", 0);
            if (script != 0 && script != 1 && script != 2 && script != 4 && script != 5) script = 0;
            lastScript = script == 4 ? 0 : script; dvOpts = LoadSetting("Opts", 0) & 3; phon = script == 4;
            iconOn = MakeIcon(Color.FromArgb(58, 99, 208));
            iconOff = MakeIcon(Color.Gray);
            popup = new CandPopup();
            popup.Picked += delegate (int idx) { Commit(idx, true); };
            oskFlat = new OskForm();
            oskFlat.KeyPressed += OskKey;
            osk3d = new Osk3dForm(dir);
            osk3d.SetScript(script, dvOpts);
            osk3d.KeyPressed += OskKey;
            osk3d.TextPicked += OskText;
            osk3d.SuggestPicked += OskSuggest;
            var menu = new ContextMenuStrip();
            miToggle.Click += delegate { Toggle(); };
            miStart.Checked = StartupOn();
            miStart.Click += delegate { SetStartup(!StartupOn()); miStart.Checked = StartupOn(); };
            var miExit = new ToolStripMenuItem("Exit");
            miExit.Click += delegate { Quit(); };
            miOsk.Click += delegate { ToggleOsk(); };
            menu.Items.Add(miToggle);
            if (Edition < 0)                                 // the all-in-one: choose the script here (Ctrl+Alt+1 Odia, 2 Devanagari, 3 Bangla, 6 Assamese, 7 Phonetic)
            {
                int[] scs = { 0, 1, 5, 2, 4 }; string[] keys = { "1", "2", "6", "3", "7" };
                for (int q = 0; q < scs.Length; q++)
                {
                    int sc = scs[q];
                    miScript[sc] = new ToolStripMenuItem(ScriptName(sc) + "   (Ctrl+Alt+" + keys[q] + ")");
                    miScript[sc].Click += delegate { SetScript(sc); };
                    menu.Items.Add(miScript[sc]);
                }
            }
            if (Edition < 0 || Edition == 1)
            {
                var miMar = new ToolStripMenuItem("Devanagari: Marathi ळ   (Ctrl+Alt+4)"); miMar.Click += delegate { ToggleOpt(1); };
                var miAnu = new ToolStripMenuItem("Devanagari: anusvara ं instead of conjuncts   (Ctrl+Alt+5)"); miAnu.Click += delegate { ToggleOpt(2); };
                menu.Items.Add(miMar); menu.Items.Add(miAnu);
            }
            miSurround.Checked = autoSurround;
            miSurround.Click += delegate { autoSurround = !autoSurround; miSurround.Checked = autoSurround; SaveSetting("AutoSurround", autoSurround ? 1 : 0); };
            menu.Items.Add(miSurround);
            menu.Items.Add(miOsk);
            menu.Items.Add(miStatus);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(miStart);
            menu.Items.Add(miExit);
            tray.ContextMenuStrip = menu;
            tray.MouseClick += delegate (object s, MouseEventArgs e) { if (e.Button == MouseButtons.Left) Toggle(); };
            tray.Visible = true;
            UpdateTray();

            MigrateHistory();
            host = new EngineHost(dir, histPath);
            host.SetScript(script, dvOpts);
            host.Candidates += OnCandidates;
            host.NextWords += OnNextWords;
            host.SmartReady += delegate
            {
                miStatus.Text = "Smart suggestions: ready";
                tray.ShowBalloonTip(2000, "Sulekhak", "Smart suggestions are ready.", ToolTipIcon.Info);
            };
            var t = host.StartAsync();
            t.ContinueWith(delegate (System.Threading.Tasks.Task task)
            {
                if (task.IsFaulted)
                {
                    try
                    {
                        host.BeginInvoke(new Action(delegate
                        {
                            MessageBox.Show("The Microsoft Edge WebView2 Runtime is needed for the word suggestions.\nInstall it from https://go.microsoft.com/fwlink/p/?LinkId=2124703 and start Sulekhak again.\n\n" + task.Exception.GetBaseException().Message,
                                "Sulekhak", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }));
                    }
                    catch { }
                }
            });

            osk3d.StartAsync().ContinueWith(delegate (System.Threading.Tasks.Task task) { osk3dOk = !task.IsFaulted; });

            proc = HookCallback;
            hook = Native.SetWindowsHookEx(Native.WH_KEYBOARD_LL, proc, Native.GetModuleHandle(null), 0);
            if (hook == IntPtr.Zero) MessageBox.Show("Could not start the keyboard hook.", "Sulekhak", MessageBoxButtons.OK, MessageBoxIcon.Error);

            watch.Interval = 400;
            watch.Tick += delegate
            {
                IntPtr fg = Native.GetForegroundWindow();
                bool own = fg == osk3d.Handle || fg == oskFlat.Handle || fg == popup.Handle;
                if (!own) lastExternal = fg;
                if (buf.Length > 0 && !own && fg != bufWindow) { ClearBuffer(); prev = "<s>"; }
            };
            watch.Start();
            tray.ShowBalloonTip(2500, "Sulekhak " + ScriptName(script) + " typing", "ON. Type Roman letters. Ctrl+Alt+O switches it off, Ctrl+Alt+K shows the on-screen keyboard.", ToolTipIcon.Info);
        }

        void MigrateHistory()
        {
            try
            {
                if (File.Exists(histPath)) return;
                string old = Path.Combine(root, "v1", "history.tsv");
                if (File.Exists(old)) File.Copy(old, histPath);
            }
            catch { }
        }

        // ------------------------------------------------------------------ first-run data extraction
        void Extract()
        {
            string ok = Path.Combine(dir, ".ok");
            if (File.Exists(ok)) return;
            Directory.CreateDirectory(Path.Combine(dir, "sulekhak"));
            string[] plain = { "ime.html", "ime.js", "engine.js", "sulekhak.js", "osk.html", "kb3d.js", "phon-data.js", "phon-core.js" };
            foreach (var n in plain) CopyRes(n, Path.Combine(dir, n), false);
            CopyRes("skel.dat.gz", Path.Combine(dir, "skel.dat"), true);
            CopyRes("cfg.gz", Path.Combine(dir, "sulekhak", "cfg.json"), true);
            foreach (var n in new[] { "lex", "rom", "clus", "syl_uni", "syl_bi", "syl_chan" })
                CopyRes(n + ".gz", Path.Combine(dir, "sulekhak", n + ".txt"), true);
            CopyRes("ng.gz", Path.Combine(dir, "sulekhak", "ng.bin"), true);          // the bigram and trigram language model
            CopyRes("idx.gz", Path.Combine(dir, "sulekhak", "idx.bin"), true);        // the prefix index of the word list
            File.WriteAllText(ok, DataVersion);
        }

        static void CopyRes(string name, string to, bool gunzip)
        {
            var asm = Assembly.GetExecutingAssembly();
            using (var s = asm.GetManifestResourceStream(name))
            {
                if (s == null) throw new FileNotFoundException("missing resource " + name);
                using (var o = File.Create(to))
                {
                    if (gunzip) { using (var g = new GZipStream(s, CompressionMode.Decompress)) g.CopyTo(o); }
                    else s.CopyTo(o);
                }
            }
        }

        // ------------------------------------------------------------------ tray
        static Icon MakeIcon(Color c)
        {
            using (var bmp = new Bitmap(32, 32))
            {
                using (var g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    using (var b = new SolidBrush(c)) g.FillEllipse(b, 1, 1, 30, 30);
                    using (var pen = new Pen(Color.White, 4f)) g.DrawEllipse(pen, 9, 8, 14, 15);
                }
                IntPtr h = bmp.GetHicon();
                var ic = (Icon)Icon.FromHandle(h).Clone();
                Native.DestroyIcon(h);
                return ic;
            }
        }

        void UpdateTray()
        {
            tray.Icon = enabled ? iconOn : iconOff;
            string nm = ScriptName(script);
            tray.Text = enabled ? ("Sulekhak: " + nm + " typing ON (Ctrl+Alt+O)") : "Sulekhak: typing OFF (Ctrl+Alt+O)";
            for (int q = 0; q < miScript.Length; q++) if (miScript[q] != null) miScript[q].Checked = q == script;
            miToggle.Text = enabled ? "Switch " + nm + " typing OFF   (Ctrl+Alt+O)" : "Switch " + nm + " typing ON   (Ctrl+Alt+O)";
        }

        void ToggleOsk()
        {
            Form o = osk3dOk ? (Form)osk3d : oskFlat;
            if (o.Visible) o.Hide(); else o.Show();
        }

        /// <summary>Ctrl+Alt+P: Phonetic (IPA) mode on, and back to the script you were typing.</summary>
        void TogglePhon()
        {
            if (Edition >= 0) return;
            SetScript(phon ? lastScript : 4);
        }

        void SetScript(int sc)
        {
            if (Edition >= 0 && sc != Edition) return;                        // an edition keeps its one script
            ClearBuffer(); prev = "<s>";
            script = sc; phon = sc == 4; if (sc != 4) lastScript = sc;
            if (Edition < 0) SaveSetting("Script", script);
            if (host != null) host.SetScript(script, dvOpts);
            if (osk3dOk) osk3d.SetScript(script, dvOpts);
            if (phon && !enabled) enabled = true;
            UpdateTray();
            string note = phon ? (host != null && host.PhonMap != null ? "Phonetic mode ON: each key offers the IPA, extIPA and IAST symbols that look like it. Tab swaps, Enter keeps. Ctrl+Alt+P goes back to " + ScriptName(lastScript) + "."
                                                                       : "Phonetic mode ON, still loading its symbol lists.") : ScriptName(script) + " typing";
            tray.ShowBalloonTip(1800, "Sulekhak", note, ToolTipIcon.None);
        }

        /// <summary>Devanagari options: Marathi ळ (bit 1) and anusvara instead of nasal conjuncts (bit 2). In the all-in-one they also switch to Devanagari.</summary>
        void ToggleOpt(int bit)
        {
            if (Edition >= 0 && Edition != 1) return;
            dvOpts ^= bit; SaveSetting("Opts", dvOpts);
            if (Edition < 0 && script != 1) { SetScript(1); return; }
            ClearBuffer();
            if (host != null) host.SetScript(script, dvOpts);
            if (osk3dOk) osk3d.SetScript(script, dvOpts);
            tray.ShowBalloonTip(1500, "Sulekhak", ((dvOpts & 1) != 0 ? "Marathi ळ" : "ल for ଳ") + (((dvOpts & 2) != 0) ? " · anusvara ं" : " · conjuncts"), ToolTipIcon.None);
        }

        /// <summary>Ctrl+Alt+1 Odia, 2 Devanagari, 3 Bangla, 4 Marathi, 5 anusvara, 6 Assamese, 7 Phonetic.</summary>
        bool HotScript(uint vk)
        {
            switch (vk)
            {
                case 0x31: if (Edition >= 0) return false; SetScript(0); return true;
                case 0x32: if (Edition >= 0) return false; SetScript(1); return true;
                case 0x33: if (Edition >= 0) return false; SetScript(2); return true;
                case 0x34: if (Edition >= 0 && Edition != 1) return false; ToggleOpt(1); return true;
                case 0x35: if (Edition >= 0 && Edition != 1) return false; ToggleOpt(2); return true;
                case 0x36: if (Edition >= 0) return false; SetScript(5); return true;
                case 0x37: if (Edition >= 0) return false; SetScript(4); return true;
            }
            return false;
        }

        void Toggle()
        {
            enabled = !enabled;
            if (!enabled) { ClearBuffer(); prev = "<s>"; }
            UpdateTray();
            tray.ShowBalloonTip(1200, "Sulekhak", ScriptName(script) + (enabled ? " typing ON" : " typing OFF"), ToolTipIcon.None);
        }

        static bool StartupOn()
        {
            using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", false))
                return k != null && k.GetValue(RunName) != null;
        }

        static void SetStartup(bool on)
        {
            using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
            {
                if (k == null) return;
                if (on) k.SetValue(RunName, "\"" + Application.ExecutablePath + "\"");
                else k.DeleteValue(RunName, false);
            }
        }

        void Quit()
        {
            try { watch.Stop(); } catch { }
            if (hook != IntPtr.Zero) { Native.UnhookWindowsHookEx(hook); hook = IntPtr.Zero; }
            tray.Visible = false;
            try { popup.Close(); oskFlat.Close(); osk3d.Close(); host.Close(); } catch { }
            ExitThread();
        }

        // ------------------------------------------------------------------ typing logic
        void OnCandidates(int id, string b, List<string> list)
        {
            if (id != qid || buf.Length == 0) return;
            cands = list.Count > 0 ? list : new List<string> { buf.ToString() };
            sel = 0;
            ShowPopup(false);
        }

        void ShowPopup(bool newWord)
        {
            if (buf.Length == 0) { popup.HidePopup(); return; }
            var shown = phon ? PhonShow(cands) : ScriptShow(cands, script);
            popup.ShowCands(buf.ToString(), shown, sel, anchor, newWord);
            if (osk3dOk) osk3d.SetSuggestions(shown, sel, false);
        }

        /// <summary>A halant with a joiner is spelled out so the difference can be seen: halant + ZWNJ as  ୍ + ┊ , halant + ZWJ as  ୍ + [ , a lone ZWNJ / ZWJ by name. A plain halant stays just the halant.</summary>
        static List<string> ScriptShow(List<string> l, int sc)
        {
            var o = new List<string>(l.Count);
            foreach (var x in l)
            {
                if (x == "\u200C") o.Add("ZWNJ");
                else if (x == "\u200D") o.Add("ZWJ");
                else if (x.Length >= 2 && (x[x.Length - 1] == '\u200C' || x[x.Length - 1] == '\u200D') && x[x.Length - 2] == Halant(sc)[0])
                {
                    string b = x.Substring(0, x.Length - 1);
                    if (b.Length == 1) b = "\u25CC" + b;
                    o.Add(b + " + " + (x[x.Length - 1] == '\u200C' ? "\u250A" : "["));
                }
                else o.Add(x);
            }
            return o;
        }

        /// <summary>A combining mark on its own gets a dotted circle in front, so it can be seen in the list.</summary>
        static List<string> PhonShow(List<string> l)
        {
            var o = new List<string>(l.Count);
            foreach (var x in l)
            {
                var cat = x.Length > 0 ? System.Globalization.CharUnicodeInfo.GetUnicodeCategory(x[0]) : System.Globalization.UnicodeCategory.OtherNotAssigned;
                bool mark = cat == System.Globalization.UnicodeCategory.NonSpacingMark || cat == System.Globalization.UnicodeCategory.SpacingCombiningMark || cat == System.Globalization.UnicodeCategory.EnclosingMark;
                o.Add(mark ? "\u25CC" + x : x);
            }
            return o;
        }

        /// <summary>Phonetic mode: a key with look-alike symbols starts a one-key choice list; keys without any are typed as they are.</summary>
        bool PhonBegin(string ch)
        {
            if (!phon || host == null || host.PhonMap == null || ch.Length != 1 || ch[0] <= 32 || ch[0] >= 127) return false;
            List<string> l;
            if (!host.PhonMap.TryGetValue(ch, out l) || l.Count < 2) return false;
            StartBuf();
            buf.Append(ch);
            cands = new List<string>(l);
            sel = 0;
            ShowPopup(true);
            return true;
        }

        void ClearBuffer()
        {
            buf.Length = 0;
            cands = new List<string>();
            sel = 0;
            anchor = Rectangle.Empty;
            popup.HidePopup();
            nid++;
            nextList = new List<string>();
            if (osk3dOk) osk3d.SetSuggestions(nextList, -1, true);
        }

        void Query()
        {
            if (buf.Length == 0) { ClearBuffer(); return; }
            qid++;
            host.Query(qid, buf.ToString(), prev);
        }

        static bool HasNonAscii(string s)
        {
            foreach (char c in s) if (c > 127) return true;
            return false;
        }

        static bool WordContinues(string w)
        {
            if (w.Length == 0) return true;
            char l = w[w.Length - 1];
            if (w.Length == 1 && (l == '*' || l == '\u0B3D' || l == '\u0B55' || l == '\u0B70' || (l >= '\u0B72' && l <= '\u0B77'))) return true;   // a symbol from the * list: no space after it
            return l == '୍' || l == '‌';
        }

        static bool CanLearn(string roman)
        {
            if (roman.Length == 0) return false;
            foreach (char c in roman) if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) return false;
            return true;
        }

        void Commit(int idx, bool space)
        {
            if (buf.Length == 0) return;
            if (phon)                                              // a symbol is typed as it is: no space, nothing learned
            {
                string sym = (idx >= 0 && idx < cands.Count) ? cands[idx] : buf.ToString();
                Native.SendText(sym);
                prev = "<s>";
                ClearBuffer();
                return;
            }
            string roman = buf.ToString();
            string word = (idx >= 0 && idx < cands.Count) ? cands[idx] : roman;
            Native.SendText(word + ((space && !WordContinues(word)) ? " " : ""));
            if (HasNonAscii(word) && CanLearn(roman)) { host.Learn(roman, word); prev = word; }
            else prev = "<s>";
            ClearBuffer();
            if (space && HasNonAscii(word) && !WordContinues(word)) RequestNext(word);
        }

        /// <summary>Asks the engine which words usually follow `word`; they appear on the keyboard strip when they arrive.</summary>
        void RequestNext(string word)
        {
            nid++;
            if (host != null && host.Ready) host.Next(nid, word);
        }

        void OnNextWords(int id, List<string> list)
        {
            if (id != nid || buf.Length != 0) return;
            nextList = list ?? new List<string>();
            if (osk3dOk) osk3d.SetSuggestions(nextList, -1, true);
        }

        void ClearNext()
        {
            if (nextList.Count == 0) return;
            nid++;
            nextList = new List<string>();
            if (osk3dOk) osk3d.SetSuggestions(nextList, -1, true);
        }

        /// <summary>A suggested word was clicked on the keyboard strip.</summary>
        void OskSuggest(int idx, bool next)
        {
            try
            {
                IntPtr fg = Native.GetForegroundWindow();
                if ((fg == osk3d.Handle || fg == oskFlat.Handle || fg == popup.Handle) && lastExternal != IntPtr.Zero) Native.SetForegroundWindow(lastExternal);
            }
            catch { }
            if (!enabled || host == null) return;
            if (!next) { if (buf.Length > 0) Commit(idx, true); return; }       // a choice for the word being typed
            if (buf.Length > 0) Commit(sel, false);
            if (idx < 0 || idx >= nextList.Count) return;
            string w = nextList[idx];
            Native.SendText(w + " ");
            host.NoteWord(w);
            prev = w;
            RequestNext(w);
        }

        // letters, plus the marks the phonetic scheme uses inside a word: ` (halant) ~ (chandrabindu/anusvara) ' (nukta) > (virama+ZWNJ)
        static bool IsBufChar(string s)
        {
            if (s.Length != 1) return false;
            char c = s[0];
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '`' || c == '~' || c == '\'' || c == '>';
        }

        static bool IsLetter(string s)
        {
            return s.Length == 1 && ((s[0] >= 'a' && s[0] <= 'z') || (s[0] >= 'A' && s[0] <= 'Z'));
        }

        // "|" and "*" (shift + 8) open their own choice lists on the PC keyboard:  |  ->  ।  |  \    *  ->  *  then the Odia symbols no letter key gives (ଽ ୰ ୲ ୳ ୴ ୵ ୶ ୷ ୕)
        bool SymBuf { get { return !phon && buf.Length == 1 && (buf[0] == '*' || buf[0] == '|'); } }

        void StartSymbol(string ch)
        {
            StartBuf();
            buf.Append(ch);
            cands = new List<string> { ch };
            sel = 0;
            ShowPopup(true);
            Query();
        }

        void StartBuf()
        {
            bufWindow = Native.GetForegroundWindow();
            anchor = Native.CaretRect();          // the cursor spot is taken once, at the first letter, so the window does not wander
        }

        // ---- the actions below are shared by the physical keyboard and the on-screen keyboard
        void HandleChar(string ch)
        {
            if (buf.Length == 0)
            {
                if (!IsLetter(ch)) return;
                StartBuf();
                buf.Append(ch);
                cands = new List<string> { buf.ToString() };
                sel = 0;
                ShowPopup(true);
                Query();
                return;
            }
            buf.Append(ch);
            Query();
        }

        void HandleBackspace()
        {
            if (buf.Length == 0) { Native.SendVk(0x08, false); return; }
            if (phon) { ClearBuffer(); return; }                  // drop the pending symbol
            buf.Length -= 1;
            if (buf.Length == 0) ClearBuffer(); else Query();
        }

        void HandleSpace()
        {
            if (buf.Length == 0) { Native.SendVk(0x20, false); return; }
            if (phon) { Commit(sel, false); Native.SendVk(0x20, false); return; }
            Commit(sel, true);
        }

        void HandleEnter()
        {
            if (phon && buf.Length > 0) { Commit(sel, false); return; }       // Enter keeps the symbol (no new line)
            if (buf.Length > 0) Commit(sel, false);
            Native.SendVk(0x0D, false);
            prev = "<s>";
        }

        void HandleEsc() { if (phon && buf.Length > 0) Commit(0, false); else ClearBuffer(); }       // Phonetic: Esc keeps the letter you typed

        void HandleTab(bool back)
        {
            if (buf.Length == 0) { Native.SendVk(0x09, false); return; }
            sel = back ? (sel - 1 + cands.Count) % cands.Count : (sel + 1) % cands.Count;
            ShowPopup(false);
        }

        void HandlePage(bool next)
        {
            if (cands.Count <= 9) return;
            int p = sel / 9;
            if (next) { p++; if (p * 9 >= cands.Count) p = 0; }
            else { p--; if (p < 0) p = (cands.Count - 1) / 9; }
            sel = p * 9;
            ShowPopup(false);
        }

        bool HandleDigit(int n)       // n = 0..8 for the keys 1..9
        {
            int idx = (sel / 9) * 9 + n;
            if (idx < cands.Count) { Commit(idx, true); return true; }
            return false;
        }

        void HandlePunct(string ch)
        {
            if (ch == "|") ch = "।";
            if (buf.Length > 0) Commit(sel, false);
            Native.SendText(ch);
            prev = "<s>";
        }

        // ---- on-screen keyboard
        /// <summary>Text chosen from the on-screen keyboard's long-press popup: finish the word being typed, then put the piece in.</summary>
        void OskText(string t)
        {
            try
            {
                IntPtr fg = Native.GetForegroundWindow();
                if ((fg == osk3d.Handle || fg == oskFlat.Handle || fg == popup.Handle) && lastExternal != IntPtr.Zero) Native.SetForegroundWindow(lastExternal);
            }
            catch { }
            if (enabled && host != null && buf.Length > 0) Commit(sel, false);
            Native.SendText(t);
            prev = "<s>";
        }

        void OskKey(string k)
        {
            // if a click on the keyboard ever made it the active window, hand the focus back to the program being typed in
            try
            {
                IntPtr fg = Native.GetForegroundWindow();
                if ((fg == osk3d.Handle || fg == oskFlat.Handle || fg == popup.Handle) && lastExternal != IntPtr.Zero) Native.SetForegroundWindow(lastExternal);
            }
            catch { }
            if (!enabled || host == null) { SendPlain(k); return; }
            bool composing = buf.Length > 0;
            switch (k)
            {
                case "SPACE": case " ": HandleSpace(); return;
                case "ENTER": HandleEnter(); return;
                case "BACK": HandleBackspace(); return;
                case "TAB": HandleTab(false); return;
                case "ESC": if (composing) HandleEsc(); else Native.SendVk(0x1B, false); return;
                case "ArrowUp": if (composing) HandleTab(true); else Native.SendVk(0x26, true); return;
                case "ArrowDown": if (composing) HandleTab(false); else Native.SendVk(0x28, true); return;
                case "ArrowLeft":
                    if (composing && cands.Count > 9) { HandlePage(false); return; }
                    if (composing) Commit(sel, false);
                    Native.SendVk(0x25, true); return;
                case "ArrowRight":
                    if (composing && cands.Count > 9) { HandlePage(true); return; }
                    if (composing) Commit(sel, false);
                    Native.SendVk(0x27, true); return;
                case "PageUp": if (composing && cands.Count > 9) HandlePage(false); else { if (composing) Commit(sel, false); Native.SendVk(0x21, true); } return;
                case "PageDown": if (composing && cands.Count > 9) HandlePage(true); else { if (composing) Commit(sel, false); Native.SendVk(0x22, true); } return;
                case "Delete": if (composing) Commit(sel, false); Native.SendVk(0x2E, true); return;
            }
            if (k.Length != 1) return;                          // modifier keys and the like
            if (phon)
            {
                if (composing && k[0] >= '1' && k[0] <= '9' && !(buf.Length == 1 && char.IsDigit(buf[0])) && HandleDigit(k[0] - '1')) return;
                if (composing) Commit(sel, false);
                if (!PhonBegin(k)) Native.SendText(k);
                return;
            }
            if (IsLetter(k) || (composing && IsBufChar(k))) { HandleChar(k); return; }
            if (composing && k[0] >= '1' && k[0] <= '9' && HandleDigit(k[0] - '1')) return;
            HandlePunct(k);
        }

        void SendPlain(string k)
        {
            switch (k)
            {
                case "SPACE": Native.SendVk(0x20, false); break;
                case "ENTER": Native.SendVk(0x0D, false); break;
                case "BACK": Native.SendVk(0x08, false); break;
                case "TAB": Native.SendVk(0x09, false); break;
                default: Native.SendText(k); break;
            }
        }

        // ---- physical keyboard
        static bool IsModifier(uint vk)
        {
            return vk == 0x10 || vk == 0xA0 || vk == 0xA1 || vk == 0x11 || vk == 0xA2 || vk == 0xA3 || vk == 0x12 || vk == 0xA4 || vk == 0xA5
                || vk == 0x14 || vk == 0x5B || vk == 0x5C || vk == 0x90 || vk == 0x91;
        }

        static bool IsExtended(uint vk)
        {
            return (vk >= 0x21 && vk <= 0x2E) || vk == 0x5B || vk == 0x5C || vk == 0xA3 || vk == 0xA5 || vk == 0x6F;
        }

        IntPtr Next(int code, IntPtr w, IntPtr l) { return Native.CallNextHookEx(hook, code, w, l); }

        IntPtr Eat(uint vk) { swallowed.Add(vk); return (IntPtr)1; }

        IntPtr HookCallback(int code, IntPtr wParam, IntPtr lParam)
        {
            if (code < 0) return Next(code, wParam, lParam);
            try
            {
                var k = (Native.KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(Native.KBDLLHOOKSTRUCT));
                if ((k.flags & 0x10) != 0 || k.dwExtraInfo == (IntPtr)Native.MAGIC) return Next(code, wParam, lParam);     // our own keys
                int msg = wParam.ToInt32();
                bool down = msg == Native.WM_KEYDOWN || msg == Native.WM_SYSKEYDOWN;
                bool up = msg == Native.WM_KEYUP || msg == Native.WM_SYSKEYUP;
                uint vk = k.vkCode;
                if (up)
                {
                    if (swallowed.Remove(vk)) return (IntPtr)1;
                    return Next(code, wParam, lParam);
                }
                if (!down) return Next(code, wParam, lParam);

                bool ctrl = Native.IsDown(0x11), alt = Native.IsDown(0x12), win = Native.IsDown(0x5B) || Native.IsDown(0x5C), shift = Native.IsDown(0x10);
                if (ctrl && alt && vk == 0x4F) { Toggle(); return Eat(vk); }                                 // Ctrl+Alt+O
                if (ctrl && alt && vk == 0x4B) { ToggleOsk(); return Eat(vk); }                              // Ctrl+Alt+K
                if (ctrl && alt && vk == 0x50 && Edition < 0) { TogglePhon(); return Eat(vk); }
                if (ctrl && alt && !shift && vk >= 0x31 && vk <= 0x37 && HotScript(vk)) return Eat(vk);                             // Ctrl+Alt+P: Phonetic (IPA) mode on / off
                if (!enabled || host == null || IsModifier(vk)) return Next(code, wParam, lParam);

                // a key with Ctrl / Alt / Windows: type the pending word first, then let the shortcut go on
                if (ctrl || alt || win)
                {
                    if (buf.Length > 0) return CommitAndReplay(vk);
                    return Next(code, wParam, lParam);
                }

                string ch = Native.CharFor(vk, k.scanCode);

                if (autoSurround && buf.Length == 0 && ch.Length == 1 && Surround.Open.IndexOf(ch[0]) >= 0 && TrySurround(ch[0])) return Eat(vk);

                if (buf.Length == 0)
                {
                    if (phon)
                    {
                        if (PhonBegin(ch)) return Eat(vk);
                        return Next(code, wParam, lParam);                                                      // no look-alike symbols: the key goes through as it is
                    }
                    if (IsLetter(ch)) { HandleChar(ch); return Eat(vk); }
                    if (ch == "|" || ch == "*") { StartSymbol(ch); return Eat(vk); }                          // | and * open a choice list (|  ।  \ ;  *  ଽ ୰ ୲ ...)
                    if (vk == 0x20) return Next(code, wParam, lParam);                                         // a space keeps the word context
                    prev = "<s>";
                    ClearNext();
                    return Next(code, wParam, lParam);
                }

                // ---- a word is being typed
                if (phon)
                {
                    bool digitPick = !shift && ((vk >= 0x31 && vk <= 0x39) || (vk >= 0x61 && vk <= 0x69)) && !(buf.Length == 1 && char.IsDigit(buf[0]));
                    if (!digitPick && ch.Length == 1 && ch[0] > 32 && ch[0] < 127)
                    {
                        Commit(sel, false);                                                                     // keep the symbol, then this key starts the next one
                        if (!PhonBegin(ch)) Native.SendText(ch);
                        return Eat(vk);
                    }
                }
                else if (SymBuf && (ch == "|" || ch == "*" || IsLetter(ch)))
                {
                    Commit(sel, false);                                                                         // keep the symbol, then this key starts the next thing
                    if (ch == "|" || ch == "*") StartSymbol(ch); else HandleChar(ch);
                    return Eat(vk);
                }
                else if (IsBufChar(ch)) { HandleChar(ch); return Eat(vk); }
                switch (vk)
                {
                    case 0x08: HandleBackspace(); break;
                    case 0x20: HandleSpace(); break;
                    case 0x0D: HandleEnter(); break;
                    case 0x1B: HandleEsc(); break;
                    case 0x09: HandleTab(shift); break;
                    case 0x28: HandleTab(false); break;      // Down
                    case 0x26: HandleTab(true); break;       // Up
                    case 0x27: case 0x22: HandlePage(true); break;    // Right / Page Down
                    case 0x25: case 0x21: HandlePage(false); break;   // Left / Page Up
                    default:
                        if (!shift && ((vk >= 0x31 && vk <= 0x39) || (vk >= 0x61 && vk <= 0x69)))
                        {
                            int n = (int)(vk >= 0x61 ? vk - 0x61 : vk - 0x31);
                            if (!HandleDigit(n)) return Eat(vk);                                              // no such candidate: ignore the key
                        }
                        else if (ch.Length > 0 && !char.IsControl(ch[0])) HandlePunct(ch);                    // punctuation: the word, then the mark
                        else return CommitAndReplay(vk);
                        break;
                }
                return Eat(vk);
            }
            catch
            {
                return Next(code, wParam, lParam);
            }
        }

        /// <summary>With text selected, types  open + text + close  over it and selects the text again (so (( )) can be stacked).</summary>
        bool TrySurround(char open)
        {
            string inner = Surround.Selection();
            if (inner == null || inner.IndexOf('\r') >= 0 || inner.IndexOf('\n') >= 0) return false;      // several lines: leave it as the program does (typing over them would also re-indent)
            Native.SendText(open + inner + Surround.Close[Surround.Open.IndexOf(open)]);
            if (Surround.Simple(inner)) Native.SelectInner(inner.Length);                 // step back over the closing mark, then select the text
            prev = "<s>";
            ClearNext();
            return true;
        }

        IntPtr CommitAndReplay(uint vk)
        {
            Commit(sel, false);
            Native.SendVk((ushort)vk, IsExtended(vk));
            return Eat(vk);
        }
    }
}
