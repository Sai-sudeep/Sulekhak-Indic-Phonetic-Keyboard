using System;
using System.Collections.Generic;

namespace Sulekhak
{
    /// <summary>The kinds of key the typing rules tell apart (see keymap/sulekhak-keymap.json, the one source of the rules for every desktop keyboard).</summary>
    enum KeyClass { Letter, Mark, Gt, Digit0, Digit19, Dot, Bar, Star, Punct, Space, Enter, Esc, Bksp, Tab, ShTab, Up, Down, Left, Right, PgUp, PgDn, Nav, SelNav, Chord, ChordDiscard }

    /// <summary>
    /// Decides what a key does while a word is, or is not, being typed. Pure logic with no knowledge of Windows: the keyboard hook turns a real
    /// key into a KeyClass, asks Decide, and carries out the effects. The table is generated from the shared spec (KeyTable.g.cs).
    /// </summary>
    static class KeyMachine
    {
        public static string StateOf(string buf)
        {
            if (string.IsNullOrEmpty(buf)) return "idle";
            bool digits = true, dots = true;
            foreach (char c in buf) { if (c < '0' || c > '9') digits = false; if (c != '.') dots = false; }
            if (digits) return "digits";
            if (dots) return "dots";
            if (buf == "|" || buf == "*") return "sym";
            return "word";
        }

        /// <summary>Class of a printable character (what the layout produced, Shift included); null when it is not printable.</summary>
        public static KeyClass? CharClass(string s)
        {
            if (s == null || s.Length != 1) return null;
            char c = s[0];
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) return KeyClass.Letter;
            if (c == '`' || c == '~' || c == '\'') return KeyClass.Mark;
            if (c == '>') return KeyClass.Gt;
            if (c == '0') return KeyClass.Digit0;
            if (c >= '1' && c <= '9') return KeyClass.Digit19;
            if (c == '.') return KeyClass.Dot;
            if (c == '|') return KeyClass.Bar;
            if (c == '*') return KeyClass.Star;
            if (c > 32 && c != 127) return KeyClass.Punct;
            return null;
        }

        /// <summary>The kind of key a physical key is, for the typing rules.</summary>
        public static KeyClass Classify(uint vk, string ch, bool shift)
        {
            bool nav = vk == 0x25 || vk == 0x26 || vk == 0x27 || vk == 0x28 || vk == 0x21 || vk == 0x22 || vk == 0x23 || vk == 0x24;
            if (shift && nav) return KeyClass.SelNav;
            switch (vk)
            {
                case 0x20: return KeyClass.Space;
                case 0x0D: return KeyClass.Enter;
                case 0x1B: return KeyClass.Esc;
                case 0x08: return KeyClass.Bksp;
                case 0x09: return shift ? KeyClass.ShTab : KeyClass.Tab;
                case 0x26: return KeyClass.Up;
                case 0x28: return KeyClass.Down;
                case 0x25: return KeyClass.Left;
                case 0x27: return KeyClass.Right;
                case 0x21: return KeyClass.PgUp;
                case 0x22: return KeyClass.PgDn;
            }
            KeyClass? c = CharClass(ch);
            return c ?? KeyClass.Nav;                       // Home, End, Delete, F-keys, dead keys and the like
        }

        static string Name(KeyClass k)
        {
            switch (k)
            {
                case KeyClass.Digit0: return "digit0";
                case KeyClass.Digit19: return "digit19";
                case KeyClass.ShTab: return "shtab";
                case KeyClass.PgUp: return "pgup";
                case KeyClass.PgDn: return "pgdn";
                case KeyClass.SelNav: return "selnav";
                case KeyClass.ChordDiscard: return "chordDiscard";
                default: { string n = k.ToString(); return char.ToLowerInvariant(n[0]) + n.Substring(1); }
            }
        }

        /// <summary>The effects, in order, of a key of this class. nCands/sel describe the list of choices; digit is the typed character for the number keys.</summary>
        public static string[] Decide(string buf, int nCands, int sel, KeyClass cls, char digit)
        {
            string rule;
            if (!KeyTable.Rules.TryGetValue(StateOf(buf) + "/" + Name(cls), out rule)) throw new InvalidOperationException("no rule for " + StateOf(buf) + "/" + Name(cls));
            if (rule[0] == '?')
            {
                string[] p = rule.Substring(1).Split('|');
                bool yes;
                if (p[0] == "multiPage") yes = (nCands + KeyTable.PageSize - 1) / KeyTable.PageSize > 1;
                else if (p[0] == "hasChoice") yes = (sel / KeyTable.PageSize) * KeyTable.PageSize + (digit - '1') < nCands;
                else throw new InvalidOperationException("condition " + p[0]);
                rule = yes ? p[1] : p[2];
            }
            return rule.Split(',');
        }
    }
}
