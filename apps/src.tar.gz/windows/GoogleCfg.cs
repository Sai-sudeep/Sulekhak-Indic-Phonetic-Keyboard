namespace Sulekhak
{
    /// <summary>Filled in by the build (see .github/workflows/build-apps.yml): the Google OAuth desktop client of the personal project and the
    /// accounts that may sign in. The three @@ markers are replaced with sed; a build made without them simply has sync switched off.</summary>
    static class GoogleCfg
    {
        const string C = "@@GCLIENT@@", S = "@@GSECRET@@", A = "@@GALLOWED@@";
        public static readonly string ClientId = C.StartsWith("@@") ? "" : C;
        public static readonly string ClientSecret = S.StartsWith("@@") ? "" : S;
        static readonly string[] Allowed = A.StartsWith("@@") ? new string[0] : A.ToLowerInvariant().Split(',');
        public static bool IsAllowed(string email)
        {
            if (string.IsNullOrEmpty(email)) return false;
            foreach (var a in Allowed) if (a.Trim() == email.ToLowerInvariant()) return true;
            return false;
        }
        public static string AllowedJson { get { return "[" + string.Join(",", System.Array.ConvertAll(Allowed, x => "\"" + x.Trim() + "\"")) + "]"; } }
    }
}
