using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Sulekhak
{
    /// <summary>
    /// An on-screen keyboard in the same layout as the web tool and the phone keyboard. It never takes the focus, so clicking
    /// a key types into the program you were using. Drag it by its title strip.
    /// </summary>
    class OskForm : Form
    {
        /// <summary>One key press: a character, or SPACE / ENTER / BACK / TAB.</summary>
        public event Action<string> KeyPressed;

        class K
        {
            public string Label = "", Out = "", Hint = "";
            public float W = 1f;
            public bool Fn, Accent, Spacer, Repeat, IsShift, Letter;
            public RectangleF R;
        }

        readonly List<K[]> rows = new List<K[]>();
        bool shift = false, dark = false;
        K down = null;
        readonly Timer rep = new Timer();
        Font fKey, fFn, fHint, fTitle;
        int fontDpi = 0;

        static readonly string[] ShiftDigits = { "!", "@", "#", "$", "%", "^", "&", "*", "(", ")" };

        public OskForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            rep.Interval = 400;
            rep.Tick += delegate
            {
                rep.Interval = 55;
                if (down != null && down.Repeat) Fire(down);
            };
            Build();
            ApplySize();
            var scr = Screen.PrimaryScreen.WorkingArea;
            Location = new Point(scr.Left + (scr.Width - Width) / 2, scr.Bottom - Height - S(12));
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 0x08000000 | 0x00000080 | 0x00000008;   // NOACTIVATE | TOOLWINDOW | TOPMOST
                cp.ClassStyle |= 0x00020000;
                return cp;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int pref = 2; Native.DwmSetWindowAttribute(Handle, 33, ref pref, 4); } catch { }
        }

        int S(int px) { return (int)Math.Round(px * DeviceDpi / 96.0); }

        int Strip { get { return S(24); } }

        void ApplySize()
        {
            ClientSize = new Size(S(640), Strip + S(5 * 50 + 10));
        }

        protected override void OnDpiChanged(DpiChangedEventArgs e)
        {
            base.OnDpiChanged(e);
        }

        static bool SystemDark()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", false))
                {
                    object v = k == null ? null : k.GetValue("AppsUseLightTheme");
                    return v is int && (int)v == 0;
                }
            }
            catch { return false; }
        }

        // ------------------------------------------------------------------ layout
        K Ch(string c, string hint)
        {
            var k = new K();
            k.Label = c; k.Out = c; k.Hint = hint;
            k.Letter = c.Length == 1 && char.IsLetter(c[0]) && c[0] < 128;
            return k;
        }

        K Fn(string label, string outv, float w)
        {
            var k = new K();
            k.Label = label; k.Out = outv; k.W = w; k.Fn = true;
            return k;
        }

        K Sp(float w)
        {
            var k = new K();
            k.Spacer = true; k.W = w;
            return k;
        }

        K[] Letters(string s)
        {
            var r = new K[s.Length];
            for (int i = 0; i < r.Length; i++)
            {
                string c = s.Substring(i, 1);
                string hint = c == "z" ? "ZWNJ" : (c == "x" ? "କ୍ଷ" : "");
                r[i] = Ch(c, hint);
            }
            return r;
        }

        static K[] Join(params object[] parts)
        {
            var l = new List<K>();
            foreach (var p in parts)
            {
                if (p is K) l.Add((K)p);
                else l.AddRange((K[])p);
            }
            return l.ToArray();
        }

        void Build()
        {
            rows.Clear();
            var digits = new K[10];
            for (int i = 0; i < 10; i++)
            {
                string d = ((i + 1) % 10).ToString();
                digits[i] = Ch(d, "");
            }
            var back = Fn("⌫", "BACK", 1.5f); back.Repeat = true;
            rows.Add(Join(digits, back));
            rows.Add(Join(Fn("Tab", "TAB", 1.5f), Letters("qwertyuiop")));
            var enter = Fn("↵", "ENTER", 1f); enter.Accent = true;
            rows.Add(Join(Sp(0.5f), Letters("asdfghjkl"), Fn("Tab", "TAB", 1f), enter));
            var sh = Fn("⇧", "SHIFT", 2f); sh.IsShift = true;
            rows.Add(Join(sh, Letters("zxcvbnm"), Ch("`", "◌୍"), Ch("~", "◌ଁ"), Sp(0.5f)));
            var space = Fn("space", " ", 5.5f); space.Fn = false;
            rows.Add(Join(Ch(">", "◌଼"), Ch("'", ""), space, Ch(".", ""), Ch(",", ""), Ch("।", ""), Ch("?", "")));
        }

        void Relayout()
        {
            float pad = S(6), gx = S(4), gy = S(4);
            float top = Strip + S(3);
            float rowH = (ClientSize.Height - top - S(4)) / rows.Count;
            for (int r = 0; r < rows.Count; r++)
            {
                var row = rows[r];
                float tot = 0;
                foreach (var k in row) tot += k.W;
                float x = pad, avail = ClientSize.Width - 2 * pad;
                foreach (var k in row)
                {
                    float cw = avail * k.W / tot;
                    k.R = new RectangleF(x + gx / 2, top + r * rowH + gy / 2, cw - gx, rowH - gy);
                    x += cw;
                }
            }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Relayout();
            Invalidate();
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);
            if (Visible) { dark = SystemDark(); Relayout(); }
        }

        string LabelOf(K k)
        {
            if (k.Letter) return shift ? k.Label.ToUpperInvariant() : k.Label;
            if (shift && k.Label.Length == 1 && k.Label[0] >= '0' && k.Label[0] <= '9') return ShiftDigits[(k.Label[0] - '0' + 9) % 10];
            return k.Label;
        }

        // ------------------------------------------------------------------ mouse
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0021) { m.Result = (IntPtr)3; return; }        // WM_MOUSEACTIVATE: never take the focus
            if (m.Msg == 0x0084)                                           // WM_NCHITTEST: the title strip drags the window
            {
                int lp = unchecked((int)(long)m.LParam);
                var pt = PointToClient(new Point((short)(lp & 0xFFFF), (short)((lp >> 16) & 0xFFFF)));
                if (pt.Y >= 0 && pt.Y < Strip && pt.X < Width - S(30)) { m.Result = (IntPtr)2; return; }
            }
            base.WndProc(ref m);
        }

        K KeyAt(Point p)
        {
            foreach (var row in rows)
                foreach (var k in row)
                    if (!k.Spacer)
                    {
                        var r = k.R;
                        r.Inflate(S(2), S(2));
                        if (r.Contains(p)) return k;
                    }
            return null;
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            if (e.Y < Strip)
            {
                if (e.X >= Width - S(30)) Hide();
                return;
            }
            var k = KeyAt(e.Location);
            if (k == null) return;
            down = k;
            Invalidate();
            Fire(k);
            if (k.Repeat) { rep.Interval = 400; rep.Start(); }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            rep.Stop();
            if (down != null) { down = null; Invalidate(); }
        }

        void Fire(K k)
        {
            if (k.IsShift) { shift = !shift; Invalidate(); return; }
            string o = k.Out;
            if (k.Letter && shift) o = o.ToUpperInvariant();
            else if (shift && o.Length == 1 && o[0] >= '0' && o[0] <= '9') o = ShiftDigits[(o[0] - '0' + 9) % 10];
            if (shift && !k.Fn) { shift = false; Invalidate(); }
            if (KeyPressed != null) KeyPressed(o);
        }

        // ------------------------------------------------------------------ painting
        void EnsureFonts()
        {
            if (fKey != null && fontDpi == DeviceDpi) return;
            if (fKey != null) { fKey.Dispose(); fFn.Dispose(); fHint.Dispose(); fTitle.Dispose(); }
            fKey = new Font("Segoe UI", 13f);
            fFn = new Font("Segoe UI", 10f);
            fHint = new Font("Nirmala UI", 7f);
            fTitle = new Font("Segoe UI", 8.5f);
            fontDpi = DeviceDpi;
        }

        static GraphicsPath Round(RectangleF r, float rad)
        {
            var p = new GraphicsPath();
            float d = rad * 2;
            p.AddArc(r.Left, r.Top, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            EnsureFonts();
            var g = e.Graphics;
            Color bg = dark ? Color.FromArgb(28, 33, 48) : Color.FromArgb(223, 227, 236);
            Color key = dark ? Color.FromArgb(52, 59, 84) : Color.FromArgb(246, 247, 251);
            Color fn = dark ? Color.FromArgb(38, 45, 68) : Color.FromArgb(205, 211, 225);
            Color shadow = dark ? Color.FromArgb(18, 22, 36) : Color.FromArgb(185, 191, 208);
            Color text = dark ? Color.FromArgb(234, 238, 250) : Color.FromArgb(40, 48, 68);
            Color dim = dark ? Color.FromArgb(154, 164, 196) : Color.FromArgb(107, 116, 144);
            Color accent = dark ? Color.FromArgb(79, 123, 232) : Color.FromArgb(58, 99, 208);
            g.Clear(bg);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter;
            TextRenderer.DrawText(g, "Sulekhak  ·  on-screen keyboard", fTitle, new Rectangle(S(10), 0, Width - S(50), Strip), dim,
                TextFormatFlags.NoPadding | TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(g, "✕", fTitle, new Rectangle(Width - S(30), 0, S(26), Strip), dim, fl);
            foreach (var row in rows)
                foreach (var k in row)
                {
                    if (k.Spacer) continue;
                    bool on = (k == down) || (k.IsShift && shift);
                    Color face = on || k.Accent ? accent : (k.Fn ? fn : key);
                    Color fg = on || k.Accent ? Color.White : text;
                    if (!on)
                    {
                        var sr = k.R; sr.Offset(0, S(2));
                        using (var sp = Round(sr, S(7))) using (var sb = new SolidBrush(shadow)) g.FillPath(sb, sp);
                    }
                    using (var fp = Round(k.R, S(7))) using (var fb = new SolidBrush(face)) g.FillPath(fb, fp);
                    var rect = Rectangle.Round(k.R);
                    if (k.Label == "space") { TextRenderer.DrawText(g, "ଓଡ଼ିଆ", fHint, rect, on ? Color.White : dim, fl); continue; }
                    TextRenderer.DrawText(g, LabelOf(k), k.Fn ? fFn : fKey, rect, fg, fl);
                    if (k.Hint.Length > 0)
                        TextRenderer.DrawText(g, k.Hint, fHint, new Rectangle(rect.Left, rect.Top + S(2), rect.Width - S(4), S(14)), on ? Color.White : dim,
                            TextFormatFlags.NoPadding | TextFormatFlags.Right | TextFormatFlags.Top);
                }
        }
    }
}
