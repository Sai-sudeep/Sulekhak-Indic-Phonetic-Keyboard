using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Sulekhak
{
    /// <summary>
    /// Puts the Sulekhak keyboards into the Windows keyboard list (Win+Space) for the user who runs the program. The installer registered the
    /// text service for the whole computer; each user still decides which keyboards appear in their own list.
    /// </summary>
    static class TipSetup
    {
        static string Script
        {
            get
            {
                using (var st = typeof(TipSetup).Assembly.GetManifestResourceStream("AddKeyboards.ps1"))
                using (var rd = new StreamReader(st, Encoding.UTF8)) return rd.ReadToEnd();
            }
        }   // the same file res\AddKeyboards.ps1 is run by the installer test

        /// <summary>Runs the script. Returns null when it worked, otherwise a short reason.</summary>
        public static string AddKeyboards()
        {
            try
            {
                string enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(Script));
                var psi = new ProcessStartInfo("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + enc)
                { UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardOutput = true };
                using (Process p = Process.Start(psi))
                {
                    string err = p.StandardError.ReadToEnd();
                    if (!p.WaitForExit(60000)) { try { p.Kill(); } catch { } return "timed out"; }
                    if (p.ExitCode != 0) return err.Trim().Length > 0 ? err.Trim() : "exit code " + p.ExitCode;
                }
                return null;
            }
            catch (Exception e) { return e.Message; }
        }

        /// <summary>Is any Sulekhak keyboard in this user's own keyboard list (the list Win+Space switches through)? Read from the user's profile in the registry:
        /// HKCU\Control Panel\International\User Profile\&lt;language&gt; has one value per keyboard, named like 0448:{text service}{profile}.</summary>
        public static bool InUserList()
        {
            try
            {
                string clsid = TipBridge.TipClsid.ToString().ToUpperInvariant();
                using (var root = Registry.CurrentUser.OpenSubKey(@"Control Panel\International\User Profile"))
                {
                    if (root == null) return false;
                    foreach (string lang in root.GetSubKeyNames())
                        using (var k = root.OpenSubKey(lang))
                            if (k != null) foreach (string v in k.GetValueNames()) if (v.ToUpperInvariant().Contains(clsid)) return true;
                }
            }
            catch { }
            return false;
        }

        /// <summary>Windows on ARM: a text service built for x64 cannot be loaded by the programs that run natively on ARM (most of them), so there the program types with its
        /// keyboard hook, like the portable one, and the installer does not register the x64 text service at all.</summary>
        public static bool IsArm64()
        {
            try { return System.Runtime.InteropServices.RuntimeInformation.OSArchitecture == System.Runtime.InteropServices.Architecture.Arm64; }
            catch { return false; }
        }

        /// <summary>The portable program types with a keyboard hook and cannot be in the Win+Space list; the installer can. Say so once, with a way to get it.</summary>
        public static void PortableNoteOnce(IWin32Window owner)
        {
            if (TipBridge.Registered() || TipBridge.InstalledByInstaller() || App.LoadSettingPublic("PortableNote", 0) >= 1) return;
            App.SaveSettingPublic("PortableNote", 1);
            var r = MessageBox.Show(owner,
                "This is the portable Sulekhak. It types by watching your keys, so it cannot appear in the Win+Space keyboard list.\n\nTo switch with Win+Space like any other Windows keyboard, install Sulekhak-Windows-Setup.exe (it keeps your words).\n\nOpen the download page now?",
                "Sulekhak", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (r == DialogResult.Yes) { try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(BuildInfo.ReleasesUrl) { UseShellExecute = true }); } catch { } }
        }

        /// <summary>Once for each user and each major step of the setup: ask, then add. The tray menu offers it again at any time.
        /// (The installer already adds the keyboards for the person who ran it, so this asks only when they are missing from the list.)</summary>
        public static void OfferOnce(IWin32Window owner)
        {
            if (!TipBridge.Registered() || IsArm64() || App.LoadSettingPublic("TipUserSetup", 0) >= 1 || InUserList()) return;
            App.SaveSettingPublic("TipUserSetup", 1);
            var r = MessageBox.Show(owner,
                "Sulekhak is now a Windows keyboard.\n\nAdd the Sulekhak keyboards (All Languages, Odia, Hindi, Marathi, Bangla, Assamese, English) to your keyboard list, so that Win+Space can switch to them?\n\nYou can change this later in Windows Settings, or from the Sulekhak tray menu.",
                "Sulekhak", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes) Report(owner);
        }

        public static void Report(IWin32Window owner)
        {
            if (IsArm64())
            {
                MessageBox.Show(owner, "This is Windows for ARM. The Sulekhak keyboard for the Win+Space list is built for x64 and ARM programs cannot load it yet, so Sulekhak types with its keyboard hook instead: it works in the programs you type in, and the tray menu switches it off and on.",
                    "Sulekhak", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!TipBridge.Registered())
            {
                MessageBox.Show(owner, "The Sulekhak keyboard is not installed on this computer (this is the portable program).\nRun Sulekhak-Windows-Setup.exe once; it also adds the keyboards to your Win+Space list.",
                    "Sulekhak", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string why = AddKeyboards();
            MessageBox.Show(owner, why == null ? "Done. Press Win+Space and choose a Sulekhak keyboard." : "The keyboards could not be added (" + why + ").\nOpen Windows Settings > Time & language > Language & region, choose a language and Add a keyboard: the Sulekhak ones are in the list.",
                "Sulekhak", MessageBoxButtons.OK, why == null ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }
    }
}
