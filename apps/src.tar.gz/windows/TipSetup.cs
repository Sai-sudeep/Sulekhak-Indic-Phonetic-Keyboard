using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Sulekhak
{
    /// <summary>
    /// Puts the Sulekhak keyboards into the Windows keyboard list (Win+Space) for the user who runs the program. The installer registered the
    /// text service for the whole computer; each user still decides which keyboards appear in their own list.
    /// </summary>
    static class TipSetup
    {
        static string Script
        {
            get
            {
                using (var st = typeof(TipSetup).Assembly.GetManifestResourceStream("AddKeyboards.ps1"))
                using (var rd = new StreamReader(st, Encoding.UTF8)) return rd.ReadToEnd();
            }
        }   // the same file res\AddKeyboards.ps1 is run by the installer test

        /// <summary>Runs the script. Returns null when it worked, otherwise a short reason.</summary>
        public static string AddKeyboards()
        {
            try
            {
                string enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(Script));
                var psi = new ProcessStartInfo("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + enc)
                { UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardOutput = true };
                using (Process p = Process.Start(psi))
                {
                    string err = p.StandardError.ReadToEnd();
                    if (!p.WaitForExit(60000)) { try { p.Kill(); } catch { } return "timed out"; }
                    if (p.ExitCode != 0) return err.Trim().Length > 0 ? err.Trim() : "exit code " + p.ExitCode;
                }
                return null;
            }
            catch (Exception e) { return e.Message; }
        }

        /// <summary>Once for each user and each major step of the setup: ask, then add. The tray menu offers it again at any time.</summary>
        public static void OfferOnce(IWin32Window owner)
        {
            if (!TipBridge.Registered() || App.LoadSettingPublic("TipUserSetup", 0) >= 1) return;
            App.SaveSettingPublic("TipUserSetup", 1);
            var r = MessageBox.Show(owner,
                "Sulekhak is now a Windows keyboard.\n\nAdd the Sulekhak keyboards (All Languages, Odia, Hindi, Marathi, Bangla, Assamese) to your keyboard list, so that Win+Space can switch to them?\n\nYou can change this later in Windows Settings, or from the Sulekhak tray menu.",
                "Sulekhak", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes) Report(owner);
        }

        public static void Report(IWin32Window owner)
        {
            string why = AddKeyboards();
            MessageBox.Show(owner, why == null ? "Done. Press Win+Space and choose a Sulekhak keyboard." : "The keyboards could not be added (" + why + ").\nOpen Windows Settings > Time & language > Language & region, choose a language and Add a keyboard: the Sulekhak ones are in the list.",
                "Sulekhak", MessageBoxButtons.OK, why == null ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }
    }
}
