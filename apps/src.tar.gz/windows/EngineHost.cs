using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace Sulekhak
{
    /// <summary>Hosts the language engine (a web page with the same JavaScript as the web tool) in an off-screen WebView2.</summary>
    class EngineHost : Form
    {
        readonly WebView2 wv = new WebView2();
        readonly string dir, hist;
        public bool Ready;                                     // smart suggestions loaded
        public bool Failed;
        public event Action<int, string, List<string>> Candidates;
        public event Action SmartReady;
        public event Action<int, List<string>> NextWords;
        public Dictionary<string, List<string>> PhonMap;        // Phonetic mode: every key that has look-alike symbols -> the list it offers (the key itself first)      // the words that usually follow a word: (request id, words)

        public EngineHost(string dataDir, string historyFile)
        {
            dir = dataDir;
            hist = historyFile;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            Location = new Point(-32000, -32000);
            Size = new Size(16, 16);
            wv.Dock = DockStyle.Fill;
            Controls.Add(wv);
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 0x08000000 | 0x00000080;          // NOACTIVATE | TOOLWINDOW
                return cp;
            }
        }

        public async Task StartAsync()
        {
            Show();
            var env = await CoreWebView2Environment.CreateAsync(null, Path.Combine(dir, "webview2"));
            await wv.EnsureCoreWebView2Async(env);
            var core = wv.CoreWebView2;
            core.SetVirtualHostNameToFolderMapping("sulekhak.local", dir, CoreWebView2HostResourceAccessKind.Allow);
            core.WebMessageReceived += OnMessage;
            core.NavigationCompleted += delegate { Replay(); };
            core.Navigate("https://sulekhak.local/ime.html");
        }

        void Replay()
        {
            try
            {
                string f = hist;
                var list = new List<string[]>();
                if (File.Exists(f))
                {
                    var lines = File.ReadAllLines(f);
                    if (lines.Length > 3000)
                    {
                        var keep = new string[1500];
                        Array.Copy(lines, lines.Length - 1500, keep, 0, 1500);
                        File.WriteAllLines(f, keep);
                        lines = keep;
                    }
                    for (int i = Math.Max(0, lines.Length - 800); i < lines.Length; i++)
                    {
                        var p = lines[i].Split('\t');
                        if (p.Length >= 2 && p[0].Length > 0 && p[1].Length > 0) list.Add(new[] { p[0], p[1] });
                    }
                }
                wv.CoreWebView2.ExecuteScriptAsync("imeReplay(" + JsonSerializer.Serialize(list) + ")");
            }
            catch { }
        }

        void OnMessage(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            string j;
            try { j = e.TryGetWebMessageAsString(); } catch { return; }
            try
            {
                using (var d = JsonDocument.Parse(j))
                {
                    var r = d.RootElement;
                    string t = r.GetProperty("t").GetString();
                    if (t == "c")
                    {
                        int id = r.GetProperty("id").GetInt32();
                        string buf = r.GetProperty("buf").GetString();
                        var l = new List<string>();
                        foreach (var x in r.GetProperty("list").EnumerateArray()) l.Add(x.GetString());
                        if (Candidates != null) Candidates(id, buf, l);
                    }
                    else if (t == "n")
                    {
                        int id = r.GetProperty("id").GetInt32();
                        var l = new List<string>();
                        foreach (var x in r.GetProperty("list").EnumerateArray()) l.Add(x.GetString());
                        if (NextWords != null) NextWords(id, l);
                    }
                    else if (t == "phon")
                    {
                        var map = new Dictionary<string, List<string>>();
                        foreach (var pr in r.GetProperty("map").EnumerateObject())
                        {
                            var l = new List<string>();
                            foreach (var x in pr.Value.EnumerateArray()) l.Add(x.GetString());
                            map[pr.Name] = l;
                        }
                        PhonMap = map;
                    }
                    else if (t == "ready") { Ready = true; if (SmartReady != null) SmartReady(); }
                    else if (t == "fail") { Failed = true; }
                }
            }
            catch { }
        }

        public void Query(int id, string buf, string prev)
        {
            try
            {
                wv.CoreWebView2.ExecuteScriptAsync("imeQuery(" + id + "," + JsonSerializer.Serialize(buf) + "," + JsonSerializer.Serialize(prev) + ")");
            }
            catch { }
        }

        /// <summary>Asks which words usually follow `word`; the answer comes back through NextWords.</summary>
        public void Next(int id, string word)
        {
            try { wv.CoreWebView2.ExecuteScriptAsync("imeNext(" + id + "," + JsonSerializer.Serialize(word) + ")"); }
            catch { }
        }

        /// <summary>A word that was typed without going through the candidate list (a suggestion): tell the memory cache.</summary>
        public void NoteWord(string word)
        {
            try { wv.CoreWebView2.ExecuteScriptAsync("imeCommit(\"\"," + JsonSerializer.Serialize(word) + ")"); }
            catch { }
        }

        public void Learn(string roman, string word)
        {
            try
            {
                File.AppendAllText(hist, roman + "\t" + word + "\n");
                wv.CoreWebView2.ExecuteScriptAsync("imeCommit(" + JsonSerializer.Serialize(roman) + "," + JsonSerializer.Serialize(word) + ")");
            }
            catch { }
        }
    }
}
