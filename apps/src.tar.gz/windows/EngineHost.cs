using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace Sulekhak
{
    /// <summary>Hosts the language engine (a web page with the same JavaScript as the web tool) in an off-screen WebView2.</summary>
    class EngineHost : Form
    {
        readonly WebView2 wv = new WebView2();
        readonly string dir, hist;
        public bool Ready;                                     // smart suggestions loaded
        public bool Failed;
        public bool EngineUp { get { try { return !Failed && wv.CoreWebView2 != null; } catch { return false; } } }      // the WebView2 that runs the word engine started
        public event Action<int, string, List<string>> Candidates;
        public event Action SmartReady;
        public event Action<int, List<string>> NextWords;
        public GoogleSync Sync;                                  // the personal build: sign-in and the local copies of what is learned
        public event Action<string, string> SyncState;
        public Dictionary<string, List<string>> PhonMap;        // Phonetic mode: every key that has look-alike symbols -> the list it offers (the key itself first)      // the words that usually follow a word: (request id, words)

        public EngineHost(string dataDir, string historyFile)
        {
            dir = dataDir;
            hist = historyFile;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            Location = new Point(-32000, -32000);
            Size = new Size(16, 16);
            wv.Dock = DockStyle.Fill;
            Controls.Add(wv);
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 0x08000000 | 0x00000080;          // NOACTIVATE | TOOLWINDOW
                return cp;
            }
        }

        public async Task StartAsync()
        {
            Show();
            var env = await CoreWebView2Environment.CreateAsync(null, Path.Combine(dir, "webview2"));
            await wv.EnsureCoreWebView2Async(env);
            var core = wv.CoreWebView2;
            core.SetVirtualHostNameToFolderMapping("sulekhak.local", dir, CoreWebView2HostResourceAccessKind.Allow);
            core.WebMessageReceived += OnMessage;
            core.NavigationCompleted += delegate { InitPersonal(); PushScript(); Replay(); };
            core.Navigate("https://sulekhak.local/ime.html");
        }

        int scr, sopt;
        public int Scr { get { return scr; } }
        public int Sopt { get { return sopt; } }
        /// <summary>The script the candidates are carried over to (0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese) and the Devanagari options.</summary>
        public void SetScript(int sc, int opt) { scr = sc; sopt = opt; PushScript(); }
        void PushScript()
        {
            try { if (wv.CoreWebView2 != null) wv.CoreWebView2.ExecuteScriptAsync("window.imeSetScript&&imeSetScript(" + scr + "," + sopt + ");window.imeSetEnglish&&imeSetEnglish(" + (scr == 6 ? "true" : "false") + ")"); }
            catch { }
        }

        // ------------------------------------------------------------------ personal learning and Google sync
        void InitPersonal()
        {
            if (Sync == null) return;
            try
            {
                wv.CoreWebView2.ExecuteScriptAsync("window.SKP&&SKP.initHost({did:" + JsonSerializer.Serialize(Sync.DeviceId) + ",name:" + JsonSerializer.Serialize(Environment.MachineName) +
                    ",platform:'windows',allowed:" + GoogleCfg.AllowedJson + ",post:function(o){window.chrome.webview.postMessage(JSON.stringify(o))}})");
                GiveToken();
            }
            catch { }
        }
        public async void GiveToken()
        {
            if (Sync == null || wv.CoreWebView2 == null) return;
            try
            {
                var t = await Sync.AccessAsync();
                if (t == null) wv.CoreWebView2.ExecuteScriptAsync("window.SKP&&SKP.signedOut()");
                else wv.CoreWebView2.ExecuteScriptAsync("window.SKP&&SKP.setToken(" + JsonSerializer.Serialize(t[0]) + "," + t[1] + "," + JsonSerializer.Serialize(t[2]) + ")");
            }
            catch { }
        }
        public void SignedOut() { try { wv.CoreWebView2.ExecuteScriptAsync("window.SKP&&SKP.signedOut()"); } catch { } }
        public void SyncNow() { try { wv.CoreWebView2.ExecuteScriptAsync("window.SKP&&SKP.syncNow()"); } catch { } }

        void Replay()
        {
            try
            {
                string f = hist;
                var list = new List<string[]>();
                if (File.Exists(f))
                {
                    var lines = File.ReadAllLines(f);
                    if (lines.Length > 3000)
                    {
                        var keep = new string[1500];
                        Array.Copy(lines, lines.Length - 1500, keep, 0, 1500);
                        File.WriteAllLines(f, keep);
                        lines = keep;
                    }
                    for (int i = Math.Max(0, lines.Length - 800); i < lines.Length; i++)
                    {
                        var p = lines[i].Split('\t');
                        if (p.Length >= 2 && p[0].Length > 0 && p[1].Length > 0) list.Add(new[] { p[0], p[1] });
                    }
                }
                wv.CoreWebView2.ExecuteScriptAsync("imeReplay(" + JsonSerializer.Serialize(list) + ")");
            }
            catch { }
        }

        void OnMessage(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            string j;
            try { j = e.TryGetWebMessageAsString(); } catch { return; }
            try
            {
                using (var d = JsonDocument.Parse(j))
                {
                    var r = d.RootElement;
                    string t = r.GetProperty("t").GetString();
                    if (t == "c")
                    {
                        int id = r.GetProperty("id").GetInt32();
                        string buf = r.GetProperty("buf").GetString();
                        var l = new List<string>();
                        foreach (var x in r.GetProperty("list").EnumerateArray()) l.Add(x.GetString());
                        if (Candidates != null) Candidates(id, buf, l);
                    }
                    else if (t == "n")
                    {
                        int id = r.GetProperty("id").GetInt32();
                        var l = new List<string>();
                        foreach (var x in r.GetProperty("list").EnumerateArray()) l.Add(x.GetString());
                        if (NextWords != null) NextWords(id, l);
                    }
                    else if (t == "phon")
                    {
                        var map = new Dictionary<string, List<string>>();
                        foreach (var pr in r.GetProperty("map").EnumerateObject())
                        {
                            var l = new List<string>();
                            foreach (var x in pr.Value.EnumerateArray()) l.Add(x.GetString());
                            map[pr.Name] = l;
                        }
                        PhonMap = map;
                    }
                    else if (t == "sk-need" && Sync != null) { string lg = r.GetProperty("lang").GetString(); wv.CoreWebView2.ExecuteScriptAsync("SKP.hostLoad(" + JsonSerializer.Serialize(lg) + "," + JsonSerializer.Serialize(Sync.ReadLang(lg)) + ")"); }
                    else if (t == "sk-save" && Sync != null) { Sync.WriteLang(r.GetProperty("lang").GetString(), r.GetProperty("text").GetString()); }
                    else if (t == "sk-token") { GiveToken(); }
                    else if (t == "sk-signout" && Sync != null) { Sync.SignOut(); }
                    else if (t == "sk-state") { if (SyncState != null) SyncState(r.GetProperty("state").GetString(), r.GetProperty("detail").GetString()); }
                    else if (t == "ready") { Ready = true; if (SmartReady != null) SmartReady(); }
                    else if (t == "fail") { Failed = true; }
                }
            }
            catch { }
        }

        public void Query(int id, string buf, string prev)
        {
            try
            {
                wv.CoreWebView2.ExecuteScriptAsync("imeQuery(" + id + "," + JsonSerializer.Serialize(buf) + "," + JsonSerializer.Serialize(prev) + ")");
            }
            catch { }
        }

        // ------------------------------------------------------------------ English (script 6): the engine page answers through the same 'c' message
        /// <summary>The words for the English letters typed so far: list[0] is what the Space key types; with a correction list[1] is the text as typed.</summary>
        public void EnQuery(int id, string typed, string prev)
        {
            try { wv.CoreWebView2.ExecuteScriptAsync("imeEnQuery(" + id + "," + JsonSerializer.Serialize(typed) + "," + JsonSerializer.Serialize(prev) + ")"); }
            catch { }
        }

        /// <summary>A word went in. how: typed | auto | pick | revert; passed: the word the engine would have chosen instead.</summary>
        public void EnCommit(string typed, string word, string prev, string how, string passed)
        {
            try
            {
                wv.CoreWebView2.ExecuteScriptAsync("imeEnCommit(" + JsonSerializer.Serialize(typed) + "," + JsonSerializer.Serialize(word) + "," + JsonSerializer.Serialize(prev) + "," +
                    JsonSerializer.Serialize(how) + "," + JsonSerializer.Serialize(passed) + ")");
            }
            catch { }
        }

        /// <summary>English: asks which words usually follow `prev` ("&lt;s&gt;" at the start of a sentence); the answer comes back through NextWords.</summary>
        public void EnNext(int id, string prev)
        {
            try { wv.CoreWebView2.ExecuteScriptAsync("imeEnNext(" + id + "," + JsonSerializer.Serialize(prev) + ")"); }
            catch { }
        }

        /// <summary>Asks which words usually follow `word`; the answer comes back through NextWords.</summary>
        public void Next(int id, string word)
        {
            try { wv.CoreWebView2.ExecuteScriptAsync("imeNext(" + id + "," + JsonSerializer.Serialize(word) + ")"); }
            catch { }
        }

        /// <summary>A word that was typed without going through the candidate list (a suggestion): tell the memory cache.</summary>
        public void NoteWord(string word)
        {
            try { wv.CoreWebView2.ExecuteScriptAsync("imeCommit(\"\"," + JsonSerializer.Serialize(word) + ")"); }
            catch { }
        }

        public void Learn(string roman, string word)
        {
            try
            {
                File.AppendAllText(hist, roman + "\t" + word + "\n");
                wv.CoreWebView2.ExecuteScriptAsync("imeCommit(" + JsonSerializer.Serialize(roman) + "," + JsonSerializer.Serialize(word) + ")");
            }
            catch { }
        }
    }
}
