namespace Sulekhak
{
    /// <summary>Where this build is released. The build replaces @@REPO@@ with the repository it runs in (so a private build points at its own Releases page);
    /// a build made without it points at the public repository.</summary>
    static class BuildInfo
    {
        const string R = "@@REPO@@";
        public static readonly string Repo = R.StartsWith("@@") ? "Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard" : R;
        public static string ReleasesUrl { get { return "https://github.com/" + Repo + "/releases/latest"; } }
    }
}
