using System;
using System.Threading;
using System.Windows.Forms;

namespace Sulekhk
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            bool created;
            using (var m = new Mutex(true, "Sulekhk.Odia.Typing.SingleInstance", out created))
            {
                if (!created) return;
                Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new App());
            }
        }
    }
}
