using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Sulekhk
{
    /// <summary>
    /// The candidate window that appears next to the text cursor. It never takes the keyboard focus (so the program you
    /// are typing in keeps it), can be clicked, follows the Windows light/dark setting, and is moved and resized in one
    /// step so it does not flicker while you type.
    /// </summary>
    class CandPopup : Form
    {
        public event Action<int> Picked;           // index of the candidate that was clicked

        string roman = "";
        List<string> cands = new List<string>();
        int sel = 0, hover = -1;
        const int Page = 9;
        Rectangle anchor = Rectangle.Empty;
        Size lastSize = Size.Empty;
        Point lastLoc = new Point(int.MinValue, 0);
        bool dark;
        Font fOdia, fSmall, fNum;
        int fontDpi = 0;

        public CandPopup()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(200, 80);
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 0x08000000 | 0x00000080 | 0x00000008;   // NOACTIVATE | TOOLWINDOW | TOPMOST
                cp.ClassStyle |= 0x00020000;                          // drop shadow
                return cp;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int pref = 2; Native.DwmSetWindowAttribute(Handle, 33, ref pref, 4); } catch { }      // rounded corners on Windows 11
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0021) { m.Result = (IntPtr)3; return; }       // WM_MOUSEACTIVATE: never take the focus
            base.WndProc(ref m);
        }

        int S(int px) { return (int)Math.Round(px * DeviceDpi / 96.0); }

        static bool SystemDark()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", false))
                {
                    object v = k == null ? null : k.GetValue("AppsUseLightTheme");
                    return v is int && (int)v == 0;
                }
            }
            catch { return false; }
        }

        void EnsureFonts()
        {
            if (fOdia != null && fontDpi == DeviceDpi) return;
            if (fOdia != null) { fOdia.Dispose(); fSmall.Dispose(); fNum.Dispose(); }
            fOdia = new Font("Nirmala UI", 15f);
            fSmall = new Font("Segoe UI", 9f);
            fNum = new Font("Segoe UI", 9f, FontStyle.Bold);
            fontDpi = DeviceDpi;
        }

        /// <summary>Shows the list. anchor is the text cursor rectangle in screen pixels; it is remembered while the word is typed.</summary>
        public void ShowCands(string roman, List<string> cands, int sel, Rectangle anchorRect, bool newWord)
        {
            EnsureFonts();
            if (newWord || anchor.IsEmpty) { anchor = anchorRect; dark = SystemDark(); }
            this.roman = roman; this.cands = cands; this.sel = sel; hover = -1;
            int start = (sel / Page) * Page;
            int rows = Math.Max(1, Math.Min(Page, cands.Count - start));
            int w = S(190);
            for (int i = 0; i < rows; i++)
            {
                var sz = TextRenderer.MeasureText(cands[start + i], fOdia, new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding);
                w = Math.Max(w, sz.Width + S(84));
            }
            int h = S(30) + rows * S(36) + S(8);
            var scr = Screen.FromPoint(anchor.Location).WorkingArea;
            int x = Math.Max(scr.Left, Math.Min(anchor.Left, scr.Right - w - S(4)));
            int y = anchor.Bottom + S(4);
            if (y + h > scr.Bottom) y = Math.Max(scr.Top, anchor.Top - h - S(4));
            if (!Visible)
            {
                Bounds = new Rectangle(x, y, w, h);
                lastLoc = new Point(x, y); lastSize = new Size(w, h);
                Show();
            }
            else if (lastLoc.X != x || lastLoc.Y != y || lastSize.Width != w || lastSize.Height != h)
            {
                Native.SetWindowPos(Handle, IntPtr.Zero, x, y, w, h, 0x0010 | 0x0004);      // NOACTIVATE | NOZORDER, one step
                lastLoc = new Point(x, y); lastSize = new Size(w, h);
            }
            Invalidate();
        }

        public void HidePopup()
        {
            anchor = Rectangle.Empty;
            if (Visible) Hide();
        }

        Rectangle RowRect(int i)
        {
            return new Rectangle(S(4), S(28) + i * S(36), Width - S(8), S(34));
        }

        int RowAt(Point p)
        {
            int start = (sel / Page) * Page;
            for (int i = 0; start + i < cands.Count && i < Page; i++) if (RowRect(i).Contains(p)) return start + i;
            return -1;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int r = RowAt(e.Location);
            if (r != hover) { hover = r; Invalidate(); }
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            if (hover != -1) { hover = -1; Invalidate(); }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            int r = RowAt(e.Location);
            if (r >= 0 && Picked != null) Picked(r);
        }

        static GraphicsPath Round(Rectangle r, int rad)
        {
            var p = new GraphicsPath();
            int d = rad * 2;
            p.AddArc(r.Left, r.Top, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            EnsureFonts();
            var g = e.Graphics;
            Color bg = dark ? Color.FromArgb(42, 48, 71) : Color.FromArgb(250, 250, 253);
            Color border = dark ? Color.FromArgb(74, 82, 114) : Color.FromArgb(200, 205, 220);
            Color text = dark ? Color.FromArgb(234, 238, 250) : Color.FromArgb(30, 34, 50);
            Color dim = dark ? Color.FromArgb(154, 164, 196) : Color.FromArgb(110, 118, 140);
            Color accent = dark ? Color.FromArgb(79, 123, 232) : Color.FromArgb(58, 99, 208);
            Color hov = dark ? Color.FromArgb(54, 61, 90) : Color.FromArgb(232, 236, 248);
            g.Clear(bg);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var pen = new Pen(border)) g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
            var fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.Left | TextFormatFlags.VerticalCenter;
            TextRenderer.DrawText(g, roman, fSmall, new Rectangle(S(12), S(4), Width - S(70), S(22)), dim, fl);
            if (cands.Count > Page)
            {
                string pg = ((sel / Page) + 1) + "/" + ((cands.Count + Page - 1) / Page);
                TextRenderer.DrawText(g, pg, fSmall, new Rectangle(Width - S(52), S(4), S(44), S(22)), dim, TextFormatFlags.NoPadding | TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
            }
            int start = (sel / Page) * Page;
            for (int i = 0; start + i < cands.Count && i < Page; i++)
            {
                var rr = RowRect(i);
                bool on = (start + i) == sel;
                bool hv = (start + i) == hover;
                if (on || hv)
                {
                    using (var path = Round(rr, S(8)))
                    using (var b = new SolidBrush(on ? accent : hov))
                        g.FillPath(b, path);
                }
                Color fg = on ? Color.White : text;
                TextRenderer.DrawText(g, (i + 1).ToString(), fNum, new Rectangle(rr.Left + S(10), rr.Top, S(22), rr.Height), on ? Color.White : dim, fl);
                TextRenderer.DrawText(g, cands[start + i], fOdia, new Rectangle(rr.Left + S(36), rr.Top, rr.Width - S(40), rr.Height), fg, fl);
            }
        }
    }
}
