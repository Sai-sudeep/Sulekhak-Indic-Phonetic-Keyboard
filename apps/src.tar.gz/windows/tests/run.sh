#!/bin/sh
# Compiles and runs the C# conformance tests without Windows (mono) or with any C# compiler: sh tests/run.sh
set -e
cd "$(dirname "$0")/.."
mcs -codepage:utf8 -out:/tmp/sk_conf.exe KeyMachine.cs Nukta.cs KeyTable.g.cs tests/KeyVectors.g.cs tests/ConformanceTests.cs
mono /tmp/sk_conf.exe
