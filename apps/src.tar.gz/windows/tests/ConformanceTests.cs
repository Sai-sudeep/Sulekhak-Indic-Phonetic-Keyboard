using System;
using System.Collections.Generic;
using System.Text;

namespace Sulekhak
{
    /// <summary>Runs the shared key vectors (keymap/vectors.json) against the C# key machine. Build: see tests/run.sh (mono) or dotnet test in CI.</summary>
    static class ConformanceTests
    {
        static readonly Dictionary<string, KeyClass> Tok = new Dictionary<string, KeyClass> {
            {"sp", KeyClass.Space}, {"ent", KeyClass.Enter}, {"esc", KeyClass.Esc}, {"bs", KeyClass.Bksp}, {"tab", KeyClass.Tab}, {"stab", KeyClass.ShTab},
            {"up", KeyClass.Up}, {"dn", KeyClass.Down}, {"lt", KeyClass.Left}, {"rt", KeyClass.Right}, {"pgup", KeyClass.PgUp}, {"pgdn", KeyClass.PgDn},
            {"nav", KeyClass.Nav}, {"snav", KeyClass.SelNav}, {"chord", KeyClass.Chord}, {"cdisc", KeyClass.ChordDiscard} };

        sealed class Host { public string Buf = ""; public int Sel; public StringBuilder Out = new StringBuilder(); public int Cands = -1; }

        static int DefaultCands(string buf)
        {
            switch (KeyMachine.StateOf(buf)) { case "word": return 5; case "digits": return 2; case "sym": return buf == "*" ? 9 : 3; case "dots": return 3; default: return 0; }
        }

        static void Key(Host h, KeyClass cls, char ch, string tok, bool forceIdle)
        {
            string buf = forceIdle ? "" : h.Buf;
            int n = h.Cands >= 0 ? h.Cands : DefaultCands(h.Buf);
            foreach (string e in KeyMachine.Decide(buf, n, h.Sel, cls, ch))
            {
                switch (e)
                {
                    case "start": h.Buf = ch.ToString(); h.Sel = 0; break;
                    case "append": h.Buf += ch; h.Sel = 0; break;
                    case "commit": h.Out.Append("{" + h.Buf + "}"); h.Buf = ""; break;
                    case "commitAuto": h.Out.Append("{" + h.Buf + "}_"); h.Buf = ""; break;
                    case "commitSpace": h.Out.Append("{" + h.Buf + "}␣"); h.Buf = ""; break;
                    case "commitTyped": h.Out.Append("{" + h.Buf + "}" + ch); h.Buf = ""; break;
                    case "pick": h.Out.Append("{" + h.Buf + "#" + ch + "}_"); h.Buf = ""; break;
                    case "bksp": h.Buf = h.Buf.Substring(0, h.Buf.Length - 1); break;
                    case "discard": h.Buf = ""; break;
                    case "nukta": h.Out.Append("<nukta>"); break;
                    case "delCodepoint": h.Out.Append("<del1>"); break;
                    case "candNext": h.Out.Append("<next>"); break;
                    case "candPrev": h.Out.Append("<prev>"); break;
                    case "pageNext": h.Out.Append("<pageNext>"); break;
                    case "pagePrev": h.Out.Append("<pagePrev>"); break;
                    case "swallow": break;
                    case "again": Key(h, cls, ch, tok, true); break;
                    case "pass": h.Out.Append("<pass:" + tok + ">"); break;
                    default: throw new Exception("effect " + e);
                }
            }
        }

        static string Run(string keys, int cands)
        {
            var h = new Host { Cands = cands };
            int i = 0;
            while (i < keys.Length)
            {
                if (keys[i] == '[')
                {
                    int j = keys.IndexOf(']', i);
                    string t = keys.Substring(i + 1, j - i - 1);
                    Key(h, Tok[t], '\0', t, false);
                    i = j + 1;
                }
                else
                {
                    char c = keys[i++];
                    KeyClass? k = KeyMachine.CharClass(c.ToString());
                    if (k == null) throw new Exception("not a key: " + c);
                    Key(h, k.Value, c, c.ToString(), false);
                }
            }
            return h.Out.ToString() + (h.Buf.Length > 0 ? "«" + h.Buf + "»" : "");
        }

        public static int Main()
        {
            int bad = 0, n = 0;
            foreach (KeyVector v in KeyVectors.Keys)
            {
                n++;
                string got = Run(v.Keys, v.Cands);
                if (got != v.Expect) { bad++; Console.WriteLine("FAIL " + v.Keys + "\n  expected " + v.Expect + "\n  got      " + got); }
            }
            foreach (NuktaVector v in KeyVectors.Nukta)
            {
                n++;
                int drop; string text;
                bool ok = Nukta.Edit(v.Before, v.Script, out drop, out text);
                bool want = v.Drop >= 0;
                if (ok != want || (ok && (drop != v.Drop || text != v.Text))) { bad++; Console.WriteLine("FAIL nukta " + v.Before + " -> " + (ok ? drop + "/" + text : "none") + ", expected " + (want ? v.Drop + "/" + v.Text : "none")); }
            }
            // physical keys of a US layout, as the Windows hook sees them (virtual-key code, the character the layout gives, Shift)
            object[][] phys = {
                new object[] { 0xBE, ".", false, KeyClass.Dot },  new object[] { 0xBE, ">", true, KeyClass.Gt },
                new object[] { 0xC0, "`", false, KeyClass.Mark }, new object[] { 0xC0, "~", true, KeyClass.Mark },
                new object[] { 0xDE, "'", false, KeyClass.Mark }, new object[] { 0xDC, "|", true, KeyClass.Bar },
                new object[] { 0x38, "*", true, KeyClass.Star },  new object[] { 0x38, "8", false, KeyClass.Digit19 },
                new object[] { 0x30, "0", false, KeyClass.Digit0 }, new object[] { 0x65, "5", false, KeyClass.Digit19 },
                new object[] { 0x25, "", true, KeyClass.SelNav }, new object[] { 0x25, "", false, KeyClass.Left },
                new object[] { 0x09, "", true, KeyClass.ShTab },  new object[] { 0x24, "", false, KeyClass.Nav },
                new object[] { 0x2E, "", false, KeyClass.Nav },   new object[] { 0x70, "", false, KeyClass.Nav } };
            foreach (object[] p in phys)
            {
                n++;
                KeyClass got = KeyMachine.Classify((uint)(int)p[0], (string)p[1], (bool)p[2]);
                if (got != (KeyClass)p[3]) { bad++; Console.WriteLine("FAIL classify vk=" + p[0] + " ch=" + p[1] + " shift=" + p[2] + ": " + got + ", expected " + p[3]); }
            }
            n++;
            string[] nuk = KeyMachine.Decide("", 0, 0, KeyMachine.Classify(0xBE, ">", true), '>');
            if (nuk.Length != 1 || nuk[0] != "nukta") { bad++; Console.WriteLine("FAIL Shift+. on an idle keyboard must be the nukta key"); }
            Console.WriteLine((n - bad) + "/" + n + " conformance vectors passed (C# key machine)");
            return bad == 0 ? 0 : 1;
        }
    }
}
