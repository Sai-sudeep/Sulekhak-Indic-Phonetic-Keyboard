; Sulekhak for Windows: installer.  Build:  iscc /DAppVersion=1.5.0 /DSrcExe=..\out\Sulekhak.exe /DTipDir=..\tip\build Sulekhak.iss
;
; Identity rules (never change them, an upgrade relies on them):
;   AppId                      {B6A0D5C2-5E3A-4F5B-9A57-2C4D9B7E8F10}  -> Windows sees every release as the same program and upgrades it in place
;   Text service CLSID         {96DB1CE7-2FD4-45AD-BD63-BE53EF2753E6}  -> every release re-registers over the previous one
;   Profile GUIDs              see tip\guids.h                         -> the keyboards in Win+Space keep their place in the user's list
;
; Upgrade rules:
;   * The text service DLL lives in {app}\tip\<version>\.  Windows loads it into every application that has had a text box, and a loaded DLL cannot be
;     overwritten, so each release gets its own folder and the registration is pointed at the new one.  Applications pick the new DLL up the next time they start.
;     Older folders are removed best-effort (immediately where nothing uses them, otherwise at the next install or uninstall).
;   * User data (%APPDATA%\Sulekhak, HKCU\Software\Sulekhak) is never touched by install, upgrade or uninstall.
;   * A running Sulekhak.exe is closed by the installer (CloseApplications) and not restarted behind the user's back.
#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif
#ifndef SrcExe
  #define SrcExe "..\out\Sulekhak.exe"
#endif
#ifndef TipDir
  #define TipDir "..\tip\build"
#endif
#ifndef KbScript
  #define KbScript "..\res\AddKeyboards.ps1"
#endif

[Setup]
AppId={{B6A0D5C2-5E3A-4F5B-9A57-2C4D9B7E8F10}
AppName=Sulekhak Phonetic Keyboard
AppVersion={#AppVersion}
AppVerName=Sulekhak {#AppVersion}
AppPublisher=Sai Sudeep Das
AppPublisherURL=https://github.com/Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard
VersionInfoVersion={#AppVersion}
DefaultDirName={autopf}\Sulekhak
DefaultGroupName=Sulekhak
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputBaseFilename=Sulekhak-Windows-Setup
OutputDir=..\out
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\Sulekhak.exe
SetupIconFile=..\tip\sulekhak.ico
CloseApplications=force
CloseApplicationsFilter=Sulekhak*.exe
RestartApplications=no
UsePreviousAppDir=yes
#ifdef SignTool
SignTool={#SignTool}
SignedUninstaller=yes
#endif

[Files]
Source: "{#SrcExe}"; DestDir: "{app}"; DestName: "Sulekhak.exe"; Flags: ignoreversion
Source: "{#KbScript}"; DestDir: "{app}"; DestName: "AddKeyboards.ps1"; Flags: ignoreversion
; the 64-bit text service, registered in the 64-bit registry; and the 32-bit one for 32-bit programs
; (not on Windows for ARM: the programs that run natively there cannot load an x64 text service, so the program types with its keyboard hook instead, like the portable one.
;  noregerror: if Windows refuses the registration the installation still completes, and the program then types with its keyboard hook; "Check installation..." in the tray menu says why.)
Source: "{#TipDir}\sulekhak_tip_x64.dll"; DestDir: "{app}\tip\{#AppVersion}"; Flags: ignoreversion regserver 64bit noregerror uninsrestartdelete; Check: WantTextService
Source: "{#TipDir}\sulekhak_tip_x86.dll"; DestDir: "{app}\tip\{#AppVersion}"; Flags: ignoreversion regserver 32bit noregerror uninsrestartdelete; Check: WantTextService

[Registry]
Root: HKLM; Subkey: "Software\Sulekhak"; ValueType: string; ValueName: "InstallDir"; ValueData: "{app}"; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Sulekhak"; ValueType: string; ValueName: "Version"; ValueData: "{#AppVersion}"; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Sulekhak"; ValueType: string; ValueName: "TipDir"; ValueData: "{app}\tip\{#AppVersion}"; Flags: uninsdeletevalue; Check: WantTextService
Root: HKLM; Subkey: "Software\Sulekhak"; Flags: uninsdeletekeyifempty
; start for everybody who signs in (the app itself moves an older per-user entry over to this one)
Root: HKLM; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "Sulekhak"; ValueData: """{app}\Sulekhak.exe"""; Flags: uninsdeletevalue; Tasks: autostart

[Tasks]
Name: "autostart"; Description: "Start Sulekhak when I sign in to Windows"; Flags: checkedonce
Name: "addkeyboards"; Description: "Add the Sulekhak keyboards to my Windows keyboard list, so that Win+Space switches to them"

[Icons]
Name: "{autoprograms}\Sulekhak"; Filename: "{app}\Sulekhak.exe"

[Run]
; the keyboard list belongs to each user, not to the computer: the person who ran the installer gets the keyboards in their own Win+Space list
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File ""{app}\AddKeyboards.ps1"""; StatusMsg: "Adding the Sulekhak keyboards to your Windows keyboard list..."; Flags: runhidden runasoriginaluser; Tasks: addkeyboards; Check: WantTextService
Filename: "{app}\Sulekhak.exe"; Description: "Start Sulekhak now"; Flags: nowait postinstall skipifsilent runasoriginaluser

[Code]
// Windows on ARM (the setup program itself runs emulated there, so Windows names the real processor in PROCESSOR_ARCHITEW6432)
function IsArmWindows: Boolean;
begin
  Result := (GetEnv('PROCESSOR_ARCHITECTURE') = 'ARM64') or (GetEnv('PROCESSOR_ARCHITEW6432') = 'ARM64');
end;

function WantTextService: Boolean;
begin
  Result := not IsArmWindows;
end;

// Removes the text service folders of earlier releases.  A folder that is still loaded by some application stays until the next time.
procedure CleanOldTipDirs;
var
  FindRec: TFindRec;
  Base, Current: String;
begin
  Base := ExpandConstant('{app}\tip\');
  Current := '{#AppVersion}';
  if FindFirst(Base + '*', FindRec) then
  begin
    try
      repeat
        if (FindRec.Attributes and FILE_ATTRIBUTE_DIRECTORY <> 0) and (FindRec.Name <> '.') and (FindRec.Name <> '..') and (FindRec.Name <> Current) then
          DelTree(Base + FindRec.Name, True, True, True);   // failures are fine
      until not FindNext(FindRec);
    finally
      FindClose(FindRec);
    end;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then CleanOldTipDirs;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then CleanOldTipDirs;
end;
