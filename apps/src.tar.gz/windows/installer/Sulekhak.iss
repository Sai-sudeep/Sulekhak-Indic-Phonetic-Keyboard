; Sulekhak for Windows: installer.  Build:  iscc /DAppVersion=1.5.0 /DSrcExe=..\out\Sulekhak.exe /DTipDir=..\tip\build Sulekhak.iss
;
; Identity rules (never change them, an upgrade relies on them):
;   AppId                      {B6A0D5C2-5E3A-4F5B-9A57-2C4D9B7E8F10}  -> Windows sees every release as the same program and upgrades it in place
;   Text service CLSID         {96DB1CE7-2FD4-45AD-BD63-BE53EF2753E6}  -> every release re-registers over the previous one
;   Profile GUIDs              see tip\guids.h                         -> the keyboards in Win+Space keep their place in the user's list
;
; Upgrade rules:
;   * The text service DLL lives in {app}\tip\<version>\.  Windows loads it into every application that has had a text box, and a loaded DLL cannot be
;     overwritten, so each release gets its own folder and the registration is pointed at the new one.  Applications pick the new DLL up the next time they start.
;     Older folders are removed best-effort (immediately where nothing uses them, otherwise at the next install or uninstall).
;   * User data (%APPDATA%\Sulekhak, HKCU\Software\Sulekhak) is never touched by install, upgrade or uninstall.
;   * A running Sulekhak.exe is closed by the installer (CloseApplications) and not restarted behind the user's back.
#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif
#ifndef SrcExe
  #define SrcExe "..\out\Sulekhak.exe"
#endif
#ifndef TipDir
  #define TipDir "..\tip\build"
#endif

[Setup]
AppId={{B6A0D5C2-5E3A-4F5B-9A57-2C4D9B7E8F10}
AppName=Sulekhak Phonetic Keyboard
AppVersion={#AppVersion}
AppVerName=Sulekhak {#AppVersion}
AppPublisher=Sai Sudeep Das
AppPublisherURL=https://github.com/Sai-sudeep/Sulekhak-Indic-Phonetic-Keyboard
VersionInfoVersion={#AppVersion}
DefaultDirName={autopf}\Sulekhak
DefaultGroupName=Sulekhak
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputBaseFilename=Sulekhak-Windows-Setup
OutputDir=..\out
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\Sulekhak.exe
CloseApplications=force
CloseApplicationsFilter=Sulekhak*.exe
RestartApplications=no
UsePreviousAppDir=yes
#ifdef SignTool
SignTool={#SignTool}
SignedUninstaller=yes
#endif

[Files]
Source: "{#SrcExe}"; DestDir: "{app}"; DestName: "Sulekhak.exe"; Flags: ignoreversion
; the 64-bit text service, registered in the 64-bit registry; and the 32-bit one for 32-bit programs
Source: "{#TipDir}\sulekhak_tip_x64.dll"; DestDir: "{app}\tip\{#AppVersion}"; Flags: ignoreversion regserver 64bit uninsrestartdelete
Source: "{#TipDir}\sulekhak_tip_x86.dll"; DestDir: "{app}\tip\{#AppVersion}"; Flags: ignoreversion regserver 32bit uninsrestartdelete

[Registry]
Root: HKLM; Subkey: "Software\Sulekhak"; ValueType: string; ValueName: "InstallDir"; ValueData: "{app}"; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Sulekhak"; ValueType: string; ValueName: "Version"; ValueData: "{#AppVersion}"; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Sulekhak"; ValueType: string; ValueName: "TipDir"; ValueData: "{app}\tip\{#AppVersion}"; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Sulekhak"; Flags: uninsdeletekeyifempty
; start for everybody who signs in (the app itself moves an older per-user entry over to this one)
Root: HKLM; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "Sulekhak"; ValueData: """{app}\Sulekhak.exe"""; Flags: uninsdeletevalue; Tasks: autostart

[Tasks]
Name: "autostart"; Description: "Start Sulekhak when I sign in to Windows"; Flags: checkedonce

[Icons]
Name: "{autoprograms}\Sulekhak"; Filename: "{app}\Sulekhak.exe"

[Run]
Filename: "{app}\Sulekhak.exe"; Description: "Start Sulekhak now"; Flags: nowait postinstall skipifsilent runasoriginaluser

[Code]
// Removes the text service folders of earlier releases.  A folder that is still loaded by some application stays until the next time.
procedure CleanOldTipDirs;
var
  FindRec: TFindRec;
  Base, Current: String;
begin
  Base := ExpandConstant('{app}\tip\');
  Current := '{#AppVersion}';
  if FindFirst(Base + '*', FindRec) then
  begin
    try
      repeat
        if (FindRec.Attributes and FILE_ATTRIBUTE_DIRECTORY <> 0) and (FindRec.Name <> '.') and (FindRec.Name <> '..') and (FindRec.Name <> Current) then
          DelTree(Base + FindRec.Name, True, True, True);   // failures are fine
      until not FindNext(FindRec);
    finally
      FindClose(FindRec);
    end;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then CleanOldTipDirs;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then CleanOldTipDirs;
end;
