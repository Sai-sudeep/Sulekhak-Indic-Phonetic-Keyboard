# Install / upgrade / rollback / uninstall test for the Windows installer. Runs on a real Windows machine (CI: windows-latest), as administrator.
#   test_install.ps1 -OldSetup <older Setup.exe> -NewSetup <Setup.exe to ship> -OldVer 1.4.1.0 -NewVer 1.5.1.0 -Driver tip_driver.exe -AddKeyboardsScript AddKeyboards.ps1 -LaunchDll sulekhak_tip_x64.dll
param([Parameter(Mandatory)]$OldSetup, [Parameter(Mandatory)]$NewSetup, [Parameter(Mandatory)]$OldVer, [Parameter(Mandatory)]$NewVer,
      [Parameter(Mandatory)]$Driver, [Parameter(Mandatory)]$AddKeyboardsScript, [Parameter(Mandatory)]$LaunchDll)
$ErrorActionPreference = 'Stop'
$script:fail = 0
function Ok($m)  { Write-Host "PASS  $m" }
function Bad($m) { Write-Host "FAIL  $m"; $script:fail++ }
function Check($cond, $m) { if ($cond) { Ok $m } else { Bad $m } }

$app   = Join-Path $env:ProgramFiles 'Sulekhak'
$clsid = '{96DB1CE7-2FD4-45AD-BD63-BE53EF2753E6}'
$uninstKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{B6A0D5C2-5E3A-4F5B-9A57-2C4D9B7E8F10}_is1'
function Inproc($wow) {
    $p = if ($wow) { "HKLM:\SOFTWARE\WOW6432Node\Classes\CLSID\$clsid\InprocServer32" } else { "HKLM:\SOFTWARE\Classes\CLSID\$clsid\InprocServer32" }
    if (Test-Path $p) { (Get-ItemProperty $p).'(default)' } else { $null }
}
function Run-Setup($exe, $tag) {
    $p = Start-Process $exe -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/SP-', "/LOG=$env:TEMP\sk_setup_$tag.log" -Wait -PassThru
    return $p.ExitCode
}
function Run-Driver($a) { $p = Start-Process $Driver -ArgumentList $a -Wait -PassThru -NoNewWindow -RedirectStandardOutput "$env:TEMP\drv.txt"; Get-Content "$env:TEMP\drv.txt" | Write-Host; return $p.ExitCode }
# Windows may need a moment before a new text service shows up in its list: ask again for up to 30 seconds and say how long it took
function Wait-Driver($a, $what) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($true) {
        $rc = Run-Driver $a
        if ($rc -eq 0) { Write-Host ("      (appeared after {0:N0} s)" -f $sw.Elapsed.TotalSeconds); return 0 }
        if ($sw.Elapsed.TotalSeconds -gt 30) { return $rc }
        Start-Sleep -Seconds 3
    }
}
function Uninstall-Count { @(Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall' | Where-Object { $_.PSChildName -like '{B6A0D5C2-*' }).Count }

# user data that must survive everything
$dataDir = Join-Path $env:LOCALAPPDATA 'Sulekhak'
New-Item -ItemType Directory -Force $dataDir | Out-Null
"learned`tword`t3" | Set-Content (Join-Path $dataDir 'history.tsv')
New-Item -Force 'HKCU:\Software\Sulekhak' | Out-Null
Set-ItemProperty 'HKCU:\Software\Sulekhak' -Name 'AutoSurround' -Value 7 -Type DWord

Write-Host "== fresh install of the older release ($OldVer)"
Check ((Run-Setup $OldSetup 'old') -eq 0) 'older release installs (exit 0)'
$old64 = Join-Path $app "tip\$OldVer\sulekhak_tip_x64.dll"
Check ((Inproc $false) -eq $old64) "64-bit registration points at $old64"
Check ((Inproc $true)  -eq (Join-Path $app "tip\$OldVer\sulekhak_tip_x86.dll")) '32-bit registration points at the 32-bit DLL'
Check (Test-Path $old64) 'DLL file exists'
Check ((Get-ItemProperty 'HKLM:\SOFTWARE\Sulekhak').Version -eq $OldVer) 'HKLM\Software\Sulekhak\Version is the old version'
Check ((Uninstall-Count) -eq 1) 'exactly one entry in Apps & features'
Check ((Wait-Driver '--list') -eq 0) 'Windows lists all 6 Sulekhak keyboards (ITfInputProcessorProfiles), allowing 30 s'
Check (Test-Path (Join-Path $app 'AddKeyboards.ps1')) 'the installer put AddKeyboards.ps1 next to the program'
# the installer itself adds the keyboards to the list of the person who ran it (no question asked, nothing left to do in Settings)
$tipsNow = (Get-WinUserLanguageList | ForEach-Object { $_.InputMethodTips }) -join ' '
foreach ($g in '247AD1A0-5475-4EFD-A145-E98534721942', '7658630A-EA26-4BBC-A217-683F8AF6A72D', '2EC164E4-DAC0-41C0-B3AC-539678AA7D42',
               'D4F9A6A4-9099-4BAF-8BDE-ACCD53A78C28', 'DB803BB1-C7A9-4A21-BEB8-E51ABA1AFF80', '1423AD18-CFFA-4959-9D75-0DFCFAB192F5') {
    Check ($tipsNow -match [regex]::Escape($g)) "right after the installer finished, the user's keyboard list (Win+Space) contains profile $g"
}

Write-Host "== an application is using the old DLL while the upgrade runs"
Add-Type -Namespace SK -Name Win -MemberDefinition '[DllImport("kernel32.dll", CharSet=CharSet.Unicode)] public static extern System.IntPtr LoadLibrary(string f); [DllImport("kernel32.dll")] public static extern bool FreeLibrary(System.IntPtr h);'
$h = [SK.Win]::LoadLibrary($old64)
Check ($h -ne [IntPtr]::Zero) 'old DLL loaded into a running process (file is locked)'

Write-Host "== upgrade in place to $NewVer"
Check ((Run-Setup $NewSetup 'new') -eq 0) 'upgrade installs (exit 0) although the old DLL is in use'
$new64 = Join-Path $app "tip\$NewVer\sulekhak_tip_x64.dll"
Check ((Inproc $false) -eq $new64) 'registration now points at the new DLL'
Check ((Inproc $true) -eq (Join-Path $app "tip\$NewVer\sulekhak_tip_x86.dll")) '32-bit registration points at the new 32-bit DLL'
Check (Test-Path $new64) 'new DLL exists'
Check ((Get-ItemProperty 'HKLM:\SOFTWARE\Sulekhak').Version -eq $NewVer) 'version value updated'
Check ((Uninstall-Count) -eq 1) 'still exactly one entry in Apps & features (same AppId)'
Check ((Get-Content (Join-Path $dataDir 'history.tsv') -Raw) -match 'learned') 'learned-words file preserved'
Check ((Get-ItemProperty 'HKCU:\Software\Sulekhak').AutoSurround -eq 7) 'user settings preserved'
Check ((Run-Driver '--list') -eq 0) 'still 6 keyboards listed after the upgrade (no duplicates, none lost)'

[void][SK.Win]::FreeLibrary($h)
Write-Host "== obsolete files are cleaned at the next install"
Check ((Run-Setup $NewSetup 'repair') -eq 0) 'reinstall (repair) of the same version'
Check (-not (Test-Path (Join-Path $app "tip\$OldVer"))) "the old version folder $OldVer was removed"

Write-Host "== the real text service, driven through Windows TSF (no mocks of TSF)"
$env:SULEKHAK_TIP_LOG = '1'; $tipLog = Join-Path $env:TEMP 'sulekhak_tip.log'; Remove-Item $tipLog -ErrorAction SilentlyContinue
$drvOk = ((Run-Driver "`"$new64`" --no-reg") -eq 0)
Check $drvOk 'tip_driver against the installed DLL passes'
if (-not $drvOk -and (Test-Path $tipLog)) { Write-Host '--- text service log of that run (last 400 lines) ---'; Get-Content $tipLog -Tail 400 | Write-Host }
Remove-Item Env:\SULEKHAK_TIP_LOG -ErrorAction SilentlyContinue

# end-to-end checks that have not run on a real runner yet: reported loudly, and made blocking (SK_E2E_STRICT=1) once they have been seen to pass
function Soft($cond, $m) {
    if ($cond) { Write-Host "PASS  $m" }
    else { Write-Host "SOFT-FAIL  $m"; Write-Host "::warning::SOFT-FAIL $m"; if ($env:SK_E2E_STRICT -eq '1') { $script:fail++ } }
}
Write-Host "== (reported, not yet blocking the release) the installed program itself: its pipe answers the text service with real Odia words (real Sulekhak.exe, real word engine, real pipe)"
function Pipe-Ask($msg) {
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $c = New-Object IO.Pipes.NamedPipeClientStream('.', "SulekhakTip-$sid", [IO.Pipes.PipeDirection]::InOut)
    try {
        $c.Connect(3000)
        $c.ReadMode = [IO.Pipes.PipeTransmissionMode]::Message
        $b = [Text.Encoding]::UTF8.GetBytes($msg)
        $c.Write($b, 0, $b.Length); $c.Flush()
        $buf = New-Object byte[] 65536
        $n = $c.Read($buf, 0, $buf.Length)
        return [Text.Encoding]::UTF8.GetString($buf, 0, $n)
    } catch { return "error: $($_.Exception.Message)" } finally { $c.Dispose() }
}
$exe = Join-Path $app 'Sulekhak.exe'
$prog = Start-Process $exe -PassThru
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$up = $false
for ($i = 0; $i -lt 60; $i++) { if (Test-Path "\\.\pipe\SulekhakTip-$sid") { $up = $true; break }; if ($prog.HasExited) { break }; Start-Sleep -Seconds 1 }
$sklog = Join-Path $dataDir 'sulekhak.log'
if (-not $up) {
    Write-Host "      the program did not open its pipe (exited: $($prog.HasExited), exit code: $(if ($prog.HasExited) { $prog.ExitCode } else { '-' }))"
    if (Test-Path $sklog) { Get-Content $sklog | Write-Host }
    Soft $false 'the installed Sulekhak.exe opens the pipe of the text service'
} else {
    Soft $true 'the installed Sulekhak.exe opens the pipe of the text service'
    Soft ((Pipe-Ask 'S') -eq 'K') 'self-test message S answered K'
    $odia = $false; $ans = ''
    for ($i = 0; $i -lt 60 -and -not $odia; $i++) {
        try { $ans = Pipe-Ask "Q`t0`t0`t<s>`tnamaste" } catch { $ans = "error: $($_.Exception.Message)" }
        if ($ans -match '^C[\s\S]*[\u0B00-\u0B7F]') { $odia = $true } else { Start-Sleep -Seconds 1 }
    }
    Write-Host "      answer to 'namaste' (Odia): $ans"
    Soft $odia 'Q namaste (Odia) returns Odia candidates through the pipe (the word engine runs inside the installed program)'
    Soft ((Pipe-Ask "Q`t6`t0`t<s>`thello") -match '^C') 'Q hello (English) returns candidates through the pipe'
    Start-Sleep -Seconds 6
    if (Test-Path $sklog) {
        $lg = Get-Content $sklog -Raw
        Write-Host "      --- sulekhak.log ---"; Write-Host $lg
        Soft ($lg -match 'started;') 'the program wrote its start line to sulekhak.log'
        Soft ($lg -match 'pipe self-test: ok' -or $lg -notmatch 'pipe self-test: FAILED') 'the program own pipe self-test did not fail'
    } else { Soft $false 'sulekhak.log was written' }
}
if (-not $prog.HasExited) { Stop-Process -Id $prog.Id -Force -ErrorAction SilentlyContinue }

Write-Host "== adding the keyboards to the user's list (what the app does on first run)"
& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $AddKeyboardsScript
Check ($LASTEXITCODE -eq 0) 'AddKeyboards.ps1 exit 0'
$tips = (Get-WinUserLanguageList | ForEach-Object { $_.InputMethodTips }) -join ' '
foreach ($g in '247AD1A0-5475-4EFD-A145-E98534721942', '7658630A-EA26-4BBC-A217-683F8AF6A72D', '2EC164E4-DAC0-41C0-B3AC-539678AA7D42',
               'D4F9A6A4-9099-4BAF-8BDE-ACCD53A78C28', 'DB803BB1-C7A9-4A21-BEB8-E51ABA1AFF80', '1423AD18-CFFA-4959-9D75-0DFCFAB192F5') {
    Check ($tips -match [regex]::Escape($g)) "language list contains profile $g"
}

Write-Host "== Windows activates the keyboard itself (what choosing it in Win+Space does)"
Check ((Run-Driver '--activate') -eq 0) 'ActivateProfile(Odia) succeeds, Sulekhak becomes the active keyboard and Windows loads the DLL'

Write-Host "== rollback to the older release"
Check ((Run-Setup $OldSetup 'rollback') -eq 0) 'older installer runs over the newer one'
Check ((Inproc $false) -eq $old64) 'registration points back at the old DLL'
Check ((Run-Driver '--list') -eq 0) '6 keyboards listed after the rollback'
Check ((Uninstall-Count) -eq 1) 'one entry in Apps & features'
Check ((Run-Setup $NewSetup 'again') -eq 0) 'and forward again'
Check ((Inproc $false) -eq $new64) 'registration points at the new DLL again'

Write-Host "== uninstall"
$un = Join-Path $app 'unins000.exe'
Check (Test-Path $un) 'uninstaller exists'
$p = Start-Process $un -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART' -Wait -PassThru
Check ($p.ExitCode -eq 0) 'uninstall exit 0'
Check ($null -eq (Inproc $false)) '64-bit COM registration removed'
Check ($null -eq (Inproc $true)) '32-bit COM registration removed'
Check (-not (Test-Path 'HKLM:\SOFTWARE\Sulekhak')) 'HKLM\Software\Sulekhak removed'
Check ($null -eq (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -ErrorAction SilentlyContinue).Sulekhak) 'startup entry removed'
Check ((Uninstall-Count) -eq 0) 'entry gone from Apps & features'
Check ((Run-Driver '--expect-none') -eq 0) 'Windows lists no Sulekhak keyboards any more'
Check (Test-Path (Join-Path $dataDir 'history.tsv')) 'user data still there after uninstall (by design)'

Write-Host "== the keyboard starts the Sulekhak program when it is not running (text service driven through TSF, a stand-in Sulekhak.exe)"
Check ((Run-Driver "--launch `"$LaunchDll`"") -eq 0) 'launch test: starts the program on a key press, not after Exit, not again and again'

if ($script:fail -gt 0) { Write-Host "`n$($script:fail) check(s) FAILED"; exit 1 }
Write-Host "`nall checks passed"
