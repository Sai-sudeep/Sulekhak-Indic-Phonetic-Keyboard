# A real window, real key presses, screenshots. Runs on a real Windows machine (CI: windows-latest) after the installer test.
#   test_gui.ps1 -Setup <Setup.exe> -Driver tip_driver.exe -OutDir gui
# It installs the program, starts it, opens a window with an edit box (tip_driver.exe --gui), activates the Sulekhak Odia keyboard for that window and
# types with SendInput like a person: a word, Space, Backspace, a word and Backspace while it is being typed.  Screenshots (png) and logs go to OutDir.
param([Parameter(Mandatory)]$Setup, [Parameter(Mandatory)]$Driver, [Parameter(Mandatory)]$OutDir, $AddKeyboardsScript)
$ErrorActionPreference = 'Continue'
New-Item -ItemType Directory -Force $OutDir | Out-Null
$OutDir = (Resolve-Path $OutDir).Path
Add-Type -AssemblyName System.Drawing, System.Windows.Forms
function Snap($name) {
    try {
        $b = [Windows.Forms.SystemInformation]::VirtualScreen
        $bmp = New-Object Drawing.Bitmap $b.Width, $b.Height
        $g = [Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen($b.Left, $b.Top, 0, 0, $bmp.Size)
        $bmp.Save((Join-Path $OutDir "$name.png"), [Drawing.Imaging.ImageFormat]::Png)
        $g.Dispose(); $bmp.Dispose()
    } catch { Write-Host "screenshot $name failed: $($_.Exception.Message)" }
}

Write-Host "== installing the program and the text service"
$p = Start-Process $Setup -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/SP-', "/LOG=$env:TEMP\sk_gui_setup.log" -Wait -PassThru
Write-Host "setup exit code $($p.ExitCode)"
$app = Join-Path $env:ProgramFiles 'Sulekhak'
if ($AddKeyboardsScript) { & powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $AddKeyboardsScript | Out-Host }
$env:SULEKHAK_TIP_LOG = '1'
$prog = Start-Process (Join-Path $app 'Sulekhak.exe') -PassThru
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
for ($i = 0; $i -lt 60; $i++) { if (Test-Path "\\.\pipe\SulekhakTip-$sid") { break }; if ($prog.HasExited) { break }; Start-Sleep -Seconds 1 }
Write-Host ("the program's pipe is " + $(if (Test-Path "\\.\pipe\SulekhakTip-$sid") { 'up' } else { 'NOT up' }))
Start-Sleep -Seconds 8
Snap '00-desktop-before'

Write-Host "== typing into a real window"
$out = & $Driver --gui $OutDir 2>&1
$rc = $LASTEXITCODE
$out | Out-Host
$out | Set-Content (Join-Path $OutDir 'result.txt') -Encoding UTF8
Snap '99-desktop-after'

# bmp (window only) -> png
Get-ChildItem $OutDir -Filter *.bmp | ForEach-Object {
    try { $img = [Drawing.Image]::FromFile($_.FullName); $img.Save(($_.FullName -replace '\.bmp$', '.png'), [Drawing.Imaging.ImageFormat]::Png); $img.Dispose(); Remove-Item $_.FullName } catch { }
}
$tl = Join-Path $env:TEMP 'sulekhak_tip.log'
if (Test-Path $tl) { Copy-Item $tl (Join-Path $OutDir 'text-service.log'); Write-Host "--- text service log (last 60 lines) ---"; Get-Content $tl -Tail 60 | Out-Host }
$sl = Join-Path $env:LOCALAPPDATA 'Sulekhak\sulekhak.log'
if (Test-Path $sl) { Copy-Item $sl (Join-Path $OutDir 'program.log'); Write-Host "--- program log ---"; Get-Content $sl -Tail 30 | Out-Host }

Write-Host "== cleaning up"
if (-not $prog.HasExited) { Stop-Process -Id $prog.Id -Force -ErrorAction SilentlyContinue }
$un = Join-Path $app 'unins000.exe'
if (Test-Path $un) { Start-Process $un -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART' -Wait }
if ($rc -ne 0) { Write-Host "the window test reported failures (exit $rc)" }
exit $rc
