#pragma once
#include <windows.h>
extern HINSTANCE g_hInst;
void SkLog(const char* fmt, ...);
