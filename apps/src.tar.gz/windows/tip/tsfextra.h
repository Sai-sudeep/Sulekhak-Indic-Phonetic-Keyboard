#pragma once
// Interfaces the MinGW headers lack (the Windows SDK has them in msctf.h and ctfutb.h).
#include <windows.h>
#include <msctf.h>

MIDL_INTERFACE("6e4e2102-f9cd-433d-b496-303ce03a6507")
ITfTextInputProcessorEx : public ITfTextInputProcessor {
    virtual HRESULT STDMETHODCALLTYPE ActivateEx(ITfThreadMgr* ptim, TfClientId tid, DWORD dwFlags) = 0;
};

MIDL_INTERFACE("fee47777-163c-4769-996a-6e9c50ad8f54")
ITfDisplayAttributeProvider : public IUnknown {
    virtual HRESULT STDMETHODCALLTYPE EnumDisplayAttributeInfo(IEnumTfDisplayAttributeInfo** ppEnum) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetDisplayAttributeInfo(REFGUID guid, ITfDisplayAttributeInfo** ppInfo) = 0;
};

// The candidate list as an element that the program (the Start / Search box, Settings, store apps, ...) can draw itself: "UI-less" mode.
#ifndef TF_CLUIE_DOCUMENTMGR
#define TF_CLUIE_DOCUMENTMGR 0x0001
#define TF_CLUIE_COUNT       0x0002
#define TF_CLUIE_SELECTION   0x0004
#define TF_CLUIE_STRING      0x0008
#define TF_CLUIE_PAGEINDEX   0x0010
#define TF_CLUIE_CURRENTPAGE 0x0020
#endif
MIDL_INTERFACE("ea1ea138-19df-11d7-a6d2-00065b84435c")
ITfCandidateListUIElement : public ITfUIElement {
    virtual HRESULT STDMETHODCALLTYPE GetUpdatedFlags(DWORD* pdwFlags) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetDocumentMgr(ITfDocumentMgr** ppdim) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetCount(UINT* puCount) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetSelection(UINT* puIndex) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetString(UINT uIndex, BSTR* pstr) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetPageIndex(UINT* pIndex, UINT uSize, UINT* puPageCnt) = 0;
    virtual HRESULT STDMETHODCALLTYPE SetPageIndex(UINT* pIndex, UINT uPageCnt) = 0;
    virtual HRESULT STDMETHODCALLTYPE GetCurrentPage(UINT* puPage) = 0;
};
