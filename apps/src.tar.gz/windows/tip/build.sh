#!/bin/sh
# Builds the text service DLL for 64-bit and 32-bit Windows with MinGW-w64 (static runtime: nothing else to install).  sh build.sh [outdir]
set -e
cd "$(dirname "$0")"
OUT=${1:-build}
mkdir -p "$OUT"
for arch in x86_64 i686; do
  case $arch in x86_64) d=x64;; i686) d=x86;; esac
  CXX=$arch-w64-mingw32-g++
  RC=$arch-w64-mingw32-windres
  $RC -O coff -o "$OUT/res_$d.o" tip.rc
  CC=$arch-w64-mingw32-gcc
  $CC -std=gnu11 -O2 -w -Iengine -c engine/engine.c -o "$OUT/engine_$d.o"
  $CXX -std=c++17 -O2 -Wall -Wextra -Wno-unused-parameter -Wno-cast-function-type -DUNICODE -D_UNICODE -shared -static -static-libgcc -static-libstdc++ \
       -o "$OUT/sulekhak_tip_$d.dll" tip.cpp register.cpp tipcore.cpp sulekhak_tip.def "$OUT/res_$d.o" "$OUT/engine_$d.o" \
       -lole32 -loleaut32 -luuid -lshlwapi -ladvapi32 -luser32
  $arch-w64-mingw32-strip --strip-unneeded "$OUT/sulekhak_tip_$d.dll"
done
ls -l "$OUT"/*.dll
