#include "tipcore.h"
#include <cstring>

namespace sk {

#include "keytable.inc"

static int Nrm(int c) {
    if (c >= 0x0900 && c <= 0x097F && c != 0x0964 && c != 0x0965) return c + 0x200;
    if (c == 0x09F0) return 0x0B30;
    if (c == 0x09F1) return 0x0B71;
    if (c >= 0x0980 && c <= 0x09FF) return c + 0x180;
    return c;
}
static bool Mark(int c) { c = Nrm(c); return (c >= 0x0B3E && c <= 0x0B44) || c == 0x0B47 || c == 0x0B48 || c == 0x0B4B || c == 0x0B4C || c == 0x0B56 || c == 0x0B57 || c == 0x0B62 || c == 0x0B63 || c == 0x0B3C || (c >= 0x0B01 && c <= 0x0B03) || c == 0x0B4D || c == 0x200C || c == 0x200D; }
static bool Lett(int c) { c = Nrm(c); return (c >= 0x0B05 && c <= 0x0B39) || c == 0x0B5C || c == 0x0B5D || c == 0x0B5F || c == 0x0B60 || c == 0x0B61 || c == 0x0B71; }

ustr LoneNukta(int script) { return ustr(1, (char16_t)(script == 1 ? 0x093C : (script == 2 || script == 5) ? 0x09BC : 0x0B3C)); }

bool IsIndicBlockChar(char16_t c) { int n = Nrm(c); return (n >= 0x0B00 && n <= 0x0B7F) || c == 0x200C || c == 0x200D; }

bool NuktaEdit(const ustr& before, int script, int* drop, ustr* text) {
    int len = (int)before.size();
    if (len == 0) return false;
    int n = len < 14 ? len : 14, end = n, i, j, cs;
    ustr s = before.substr(len - n);
    bool space = false;
    if (end >= 2 && s[end - 1] == u' ' && (Mark(s[end - 2]) || Lett(s[end - 2]))) { space = true; end--; }
    i = end - 1;
    while (i > 0 && Mark(s[i])) i--;
    if (i < 0 || !Lett(s[i])) return false;
    cs = i;
    while (cs > 0 && Nrm(s[cs - 1]) == 0x0B4D) { cs--; if (cs > 0 && Lett(s[cs - 1])) cs--; else break; }
    int at = -1;
    ustr nuk = LoneNukta(script);
    for (j = end - 1; j >= cs; j--) {
        int u = s[j];
        if ((Nrm(u) == 0x0B21 || Nrm(u) == 0x0B22) && !(j + 1 < end && Nrm(s[j + 1]) == 0x0B3C)) { at = j + 1; nuk = ustr(1, (char16_t)(0x0B3C + (u - Nrm(u)))); break; }
    }
    if (at < 0) return false;
    ustr seg = s.substr(cs, end - cs);
    seg = seg.substr(0, at - cs) + nuk + seg.substr(at - cs);
    if (space) seg += u' ';
    *drop = n - cs;
    *text = seg;
    return true;
}

std::string StateOf(const ustr& buf) {
    if (buf.empty()) return "idle";
    bool digits = true, dots = true;
    for (char16_t c : buf) { if (c < u'0' || c > u'9') digits = false; if (c != u'.') dots = false; }
    if (digits) return "digits";
    if (dots) return "dots";
    if (buf.size() == 1 && (buf[0] == u'|' || buf[0] == u'*')) return "sym";
    return "word";
}

static const char* Name(Cls c) {
    switch (c) {
        case Cls::Letter: return "letter"; case Cls::Mark: return "mark"; case Cls::Gt: return "gt"; case Cls::Digit0: return "digit0";
        case Cls::Digit19: return "digit19"; case Cls::Dot: return "dot"; case Cls::Bar: return "bar"; case Cls::Star: return "star";
        case Cls::Punct: return "punct"; case Cls::Space: return "space"; case Cls::Enter: return "enter"; case Cls::Esc: return "esc";
        case Cls::Bksp: return "bksp"; case Cls::Tab: return "tab"; case Cls::ShTab: return "shtab"; case Cls::Up: return "up";
        case Cls::Down: return "down"; case Cls::Left: return "left"; case Cls::Right: return "right"; case Cls::PgUp: return "pgup";
        case Cls::PgDn: return "pgdn"; case Cls::Nav: return "nav"; case Cls::SelNav: return "selnav"; case Cls::Chord: return "chord";
        case Cls::ChordDiscard: return "chordDiscard";
    }
    return "nav";
}

static bool CharClass(char16_t c, Cls* out) {
    if ((c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z')) { *out = Cls::Letter; return true; }
    if (c == u'`' || c == u'~' || c == u'\'') { *out = Cls::Mark; return true; }
    if (c == u'>') { *out = Cls::Gt; return true; }
    if (c == u'0') { *out = Cls::Digit0; return true; }
    if (c >= u'1' && c <= u'9') { *out = Cls::Digit19; return true; }
    if (c == u'.') { *out = Cls::Dot; return true; }
    if (c == u'|') { *out = Cls::Bar; return true; }
    if (c == u'*') { *out = Cls::Star; return true; }
    if (c > 32 && c != 127) { *out = Cls::Punct; return true; }
    return false;
}

Cls Classify(const Key& k) {
    if (k.ctrl || k.alt || k.win) return (k.ctrl && !k.alt && !k.win && k.vk == 0x08) ? Cls::ChordDiscard : Cls::Chord;
    uint32_t vk = k.vk;
    bool nav = vk == 0x25 || vk == 0x26 || vk == 0x27 || vk == 0x28 || vk == 0x21 || vk == 0x22 || vk == 0x23 || vk == 0x24;
    if (k.shift && nav) return Cls::SelNav;
    switch (vk) {
        case 0x20: return Cls::Space; case 0x0D: return Cls::Enter; case 0x1B: return Cls::Esc; case 0x08: return Cls::Bksp;
        case 0x09: return k.shift ? Cls::ShTab : Cls::Tab; case 0x26: return Cls::Up; case 0x28: return Cls::Down;
        case 0x25: return Cls::Left; case 0x27: return Cls::Right; case 0x21: return Cls::PgUp; case 0x22: return Cls::PgDn;
    }
    Cls c;
    if (k.ch && CharClass(k.ch, &c)) return c;
    return Cls::Nav;
}

std::vector<std::string> Decide(const std::string& state, Cls cls, int nCands, int sel, char digit) {
    std::string key = state + "/" + Name(cls);
    const char* rule = nullptr;
    for (const auto& r : kRules) if (key == r.key) { rule = r.rule; break; }
    std::string s = rule ? rule : "pass";
    if (!s.empty() && s[0] == '?') {
        size_t a = s.find('|'), b = s.find('|', a + 1);
        std::string cond = s.substr(1, a - 1), th = s.substr(a + 1, b - a - 1), el = s.substr(b + 1);
        bool yes = false;
        if (cond == "multiPage") yes = (nCands + kPageSize - 1) / kPageSize > 1;
        else if (cond == "hasChoice") yes = (sel / kPageSize) * kPageSize + (digit - '1') < nCands;
        s = yes ? th : el;
    }
    std::vector<std::string> out;
    size_t p = 0;
    while (p <= s.size()) { size_t q = s.find(',', p); if (q == std::string::npos) q = s.size(); out.push_back(s.substr(p, q - p)); p = q + 1; }
    return out;
}

static bool HasNonAscii(const ustr& s) { for (char16_t c : s) if (c > 127) return true; return false; }
static bool CanLearn(const ustr& r) { if (r.empty()) return false; for (char16_t c : r) if (!((c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z'))) return false; return true; }
static bool WordContinues(const ustr& w) {
    if (w.empty()) return true;
    char16_t l = w.back();
    if (w.size() == 1 && (l == u'*' || l == 0x0B3D || l == 0x0B55 || l == 0x0B70 || (l >= 0x0B72 && l <= 0x0B77))) return true;
    return l == 0x0B4D || l == 0x200C;
}

void Core::Refresh() {
    std::vector<ustr> out;
    if (!eng_ || !eng_->Query(script_, buf_, prev_, out) || out.empty()) { out.clear(); out.push_back(buf_); }
    cands_ = out;
    sel_ = 0;
    doc_->Compose(cands_[0]);
    if (eng_) eng_->ShowList(cands_, sel_, buf_);
}

void Core::CommitIdx(int idx, int mode, char16_t typed) {
    if (buf_.empty()) return;
    ustr roman = buf_;
    ustr word = (idx >= 0 && idx < (int)cands_.size()) ? cands_[idx] : roman;
    bool cont = WordContinues(word);
    ustr out = word;
    if (mode == 1 && !cont) out += u' ';
    else if (mode == 2) out += u' ';
    else if (mode == 3) out += typed;
    doc_->Commit(out);
    if (HasNonAscii(word) && CanLearn(roman)) { if (eng_) eng_->Learn(script_, roman, word); prev_ = (mode == 3) ? ustr(u"<s>") : word; }
    else prev_ = u"<s>";
    buf_.clear(); cands_.clear(); sel_ = 0;
    if (eng_) eng_->HideList();
}

void Core::Reset() {
    recent_.clear();
    HideNext();
    if (buf_.empty()) return;
    if (script_ == 6) { CommitEn(0, 0); return; }
    CommitIdx(sel_, 0, 0);
}

void Core::Lost() {
    HideNext();
    buf_.clear(); cands_.clear(); sel_ = 0; picked_ = false; last_.valid = false;
    if (eng_) eng_->HideList();
}

void Core::Forget() {
    HideNext();
    if (buf_.empty()) return;
    buf_.clear(); cands_.clear(); sel_ = 0; picked_ = false;
    doc_->EndEmpty();
    if (eng_) eng_->HideList();
}

void Core::Apply(const std::vector<std::string>& eff, const Key& k, Cls cls, bool* pass) {
    for (const std::string& e : eff) {
        if (e == "start") { buf_ = ustr(1, k.ch); Refresh(); }
        else if (e == "append") { buf_ += k.ch; Refresh(); }
        else if (e == "commit") CommitIdx(sel_, 0, 0);
        else if (e == "commitAuto") CommitIdx(sel_, 1, 0);
        else if (e == "commitSpace") CommitIdx(sel_, 2, 0);
        else if (e == "commitTyped") CommitIdx(sel_, 3, k.ch);
        else if (e == "pick") { int i = (sel_ / kPageSize) * kPageSize + (int)(k.ch - u'1'); CommitIdx(i, 1, 0); }
        else if (e == "bksp") { buf_.pop_back(); if (buf_.empty()) { cands_.clear(); doc_->EndEmpty(); if (eng_) eng_->HideList(); } else Refresh(); }
        else if (e == "discard") { buf_.clear(); cands_.clear(); sel_ = 0; doc_->EndEmpty(); if (eng_) eng_->HideList(); }
        else if (e == "candNext" || e == "candPrev") {
            int n = (int)cands_.size();
            if (n > 0) { sel_ = e == "candNext" ? (sel_ + 1) % n : (sel_ + n - 1) % n; doc_->Compose(cands_[sel_]); if (eng_) eng_->ShowList(cands_, sel_, buf_); }
        }
        else if (e == "pageNext" || e == "pagePrev") {
            int n = (int)cands_.size(), pages = (n + kPageSize - 1) / kPageSize, p = sel_ / kPageSize;
            if (pages > 1) { p = e == "pageNext" ? (p + 1) % pages : (p + pages - 1) % pages; sel_ = p * kPageSize; doc_->Compose(cands_[sel_]); if (eng_) eng_->ShowList(cands_, sel_, buf_); }
        }
        else if (e == "nukta") {
            int drop; ustr text;
            if (NuktaEdit(doc_->Before(14), script_, &drop, &text)) doc_->ReplaceBefore(drop, text);
            else doc_->ReplaceBefore(0, LoneNukta(script_));
            prev_ = u"<s>";
        }
        else if (e == "delCodepoint") {
            ustr b = doc_->Before(1);
            if (b.size() == 1 && IsIndicBlockChar(b[0])) doc_->ReplaceBefore(1, ustr());
            else *pass = true;
        }
        else if (e == "swallow") {}
        else if (e == "pass") *pass = true;
        else if (e == "again") Apply(Decide("idle", cls, 0, 0, (char)(k.ch < 128 ? k.ch : 0)), k, cls, pass);
    }
}

bool Core::OwnsIdleBackspace() const {
    ustr b = doc_->Before(1);
    return b.size() == 1 && IsIndicBlockChar(b[0]);
}

bool Core::WouldEat(const Key& k) const {
    if (script_ == 6) return WouldEatEn(k);
    Cls cls = Classify(k);
    std::vector<std::string> eff = Decide(StateOf(buf_), cls, (int)cands_.size(), sel_, (char)(k.ch < 128 ? k.ch : 0));
    for (const std::string& e : eff) {
        if (e == "pass") return false;
        if (e == "again") { for (const std::string& f : Decide("idle", cls, 0, 0, (char)(k.ch < 128 ? k.ch : 0))) if (f == "pass") return false; }
    }
    return true;
}

bool Core::OnKey(const Key& k) {
    if (script_ == 6) return OnKeyEn(k);
    Cls cls = Classify(k);
    bool wasIdle = buf_.empty();
    std::vector<std::string> eff = Decide(StateOf(buf_), cls, (int)cands_.size(), sel_, (char)(k.ch < 128 ? k.ch : 0));
    bool pass = false;
    Apply(eff, k, cls, &pass);
    if (pass && wasIdle && k.vk != 0x20) prev_ = u"<s>";
    return !pass;
}

// ------------------------------------------------------------------------------------------------------------------------------------------ English (script 6)
static bool IsApos(char16_t c) { return c == u'\'' || c == 0x2019; }
static ustr LowerAscii(ustr s) { for (auto& c : s) if (c >= u'A' && c <= u'Z') c = (char16_t)(c + 32); return s; }
static bool IsSpaceCh(char16_t c) { return c == u' ' || c == u'\t' || c == u'\n' || c == u'\r' || c == 0xA0; }
static ustr StraightApos(ustr s) { for (auto& c : s) if (c == 0x2019 || c == 0x2018) c = u'\''; return s; }
static ustr CurlyApos(ustr s) { for (auto& c : s) if (c == u'\'') c = 0x2019; return s; }
// a lone i, and i'm i'll i've i'd, are written with a capital I
static ustr CapitalI(const ustr& w) {
    ustr l = LowerAscii(StraightApos(w));
    if (l == u"i" || l == u"i'm" || l == u"i'll" || l == u"i've" || l == u"i'd") { ustr r = w; r[0] = u'I'; return r; }
    return w;
}
static bool Abbreviation(const ustr& before) {           // the letters before a full stop ("Dr", "e.g", "p.m"): a stop after them does not end a sentence
    size_t e = before.size(), b = e;
    while (b > 0 && ((before[b - 1] >= u'a' && before[b - 1] <= u'z') || (before[b - 1] >= u'A' && before[b - 1] <= u'Z') || before[b - 1] == u'.')) b--;
    ustr w = LowerAscii(before.substr(b, e - b));
    static const char16_t* kAb[] = { u"mr", u"mrs", u"ms", u"dr", u"prof", u"sr", u"jr", u"st", u"vs", u"etc", u"e.g", u"i.e", u"no", u"fig", u"eq", u"approx", u"dept", u"est", u"inc", u"ltd", u"co", u"mt", u"ft", u"vol", u"pp", u"p", u"a.m", u"p.m", u"u.s", u"u.k" };
    for (const char16_t* a : kAb) if (w == a) return true;
    return false;
}
ustr Core::Ctx(int n) {
    ustr r = doc_->Before(n);
    if (!r.empty()) return r;
    return recent_.size() > (size_t)n ? recent_.substr(recent_.size() - n) : recent_;
}
void Core::Note(const ustr& s) {
    recent_ += s;
    if (recent_.size() > 60) recent_.erase(0, recent_.size() - 60);
}
bool Core::SentenceStart() {                             // the next letter begins a sentence: start of the text, a new line, or ". ! ? …" (closing quotes and brackets allowed) and a space
    ustr p = Ctx(60);
    for (;;) {                                               // an opening quote or bracket directly before the letter does not hide the sentence start behind it
        if (p.empty()) return true;
        char16_t l = p.back();
        bool open = l == 0x201C || l == 0x2018 || l == u'(' || l == u'[' || ((l == u'"') && (p.size() == 1 || IsSpaceCh(p[p.size() - 2])));
        if (!open) break;
        p.pop_back();
    }
    size_t n = p.size(), sp = 0;
    while (n > 0 && IsSpaceCh(p[n - 1])) { if (p[n - 1] == u'\n' || p[n - 1] == u'\r') return true; n--; sp++; }
    if (n == 0) return true;                                // only spaces so far
    if (sp == 0) return false;
    while (n > 0 && (p[n - 1] == u'"' || p[n - 1] == u'\'' || p[n - 1] == 0x201D || p[n - 1] == 0x2019 || p[n - 1] == u')' || p[n - 1] == u']')) n--;
    if (n == 0) return false;
    char16_t e = p[n - 1];
    if (e != u'.' && e != u'!' && e != u'?' && e != 0x2026) return false;
    if (e == u'.' && (n < 2 || p[n - 2] != u'.') && Abbreviation(p.substr(0, n - 1))) return false;
    return true;
}
bool Core::OpenContext() {                               // a quote typed here opens (after a space, a bracket, a dash, or at the start) rather than closes
    ustr b = Ctx(1);
    if (b.empty()) return true;
    char16_t c = b[0];
    return IsSpaceCh(c) || c == u'(' || c == u'[' || c == u'{' || c == 0x2014 || c == 0x2013 || c == 0x201C || c == 0x2018 || c == u'/' || c == u'-';
}

static ustr CoreOf(const ustr& buf, ustr* tail) {         // the word without the apostrophes at its end (a closing quote is not part of the word)
    size_t n = buf.size();
    while (n > 0 && IsApos(buf[n - 1])) n--;
    if (tail) *tail = buf.substr(n);
    return buf.substr(0, n);
}

void Core::RefreshEn() {
    ustr tail, core = CoreOf(buf_, &tail);
    std::vector<ustr> out;
    if (core.empty() || !eng_ || !eng_->Query(script_, core, prev_, out) || out.empty()) { out.clear(); out.push_back(core.empty() ? buf_ : core); }
    cands_ = out;
    sel_ = 0;
    picked_ = false;
    doc_->Compose(buf_);                                  // what was typed stays in the document; the list below it is only offered
    if (eng_) eng_->ShowList(cands_, sel_, buf_);
}

void Core::CommitEn(int mode, char16_t ch) {
    if (buf_.empty()) return;
    ustr tail, core = CoreOf(buf_, &tail);
    ustr word = core;
    if (!core.empty() && sel_ >= 0 && sel_ < (int)cands_.size() && (mode == 1 || picked_)) word = cands_[sel_];   // Space takes the engine's choice; every other key only what was chosen by hand
    bool corrected = word != core;
    if (enCap_) word = CapitalI(word);
    if (enSmart_) { word = CurlyApos(word); tail = CurlyApos(tail); if (mode == 2 && ch == u'"') ch = 0x201D; }
    ustr trailing = mode == 1 ? ustr(u" ") : mode == 2 ? ustr(1, ch) : ustr();
    doc_->Commit(word + tail + trailing);
    Note(word + tail + trailing);
    ustr prevBefore = prev_;
    if (!core.empty() && eng_) {
        ustr passed = (!cands_.empty() && cands_[0] != word && cands_[0] != core) ? cands_[0] : ustr();     // a correction that the person refused by picking another word
        eng_->LearnEnglish(core, StraightApos(word), prevBefore, picked_ ? "pick" : corrected ? "auto" : "typed", passed);
    }
    last_.typed = core; last_.word = word; last_.tail = tail + trailing; last_.prev = prevBefore;
    last_.valid = corrected && !picked_ && mode == 1;      // only a correction made by the Space key can be taken back with Backspace
    if (mode == 1) prev_ = LowerAscii(StraightApos(word));
    else if (mode == 2 && (ch == u'.' || ch == u'!' || ch == u'?')) prev_ = u"<s>";
    else prev_ = ustr();
    buf_.clear(); cands_.clear(); sel_ = 0; picked_ = false;
    if (eng_) eng_->HideList();
    if (mode == 1) ShowNextWords();
}

void Core::HideNext() {
    if (!nextShown_) return;
    nextShown_ = false; next_.clear(); nextSel_ = 0;
    if (eng_) eng_->HideNext();
}

void Core::ShowNextWords() {
    HideNext();
    if (!nextOn_ || !eng_ || script_ != 6 || prev_.empty()) return;
    std::vector<ustr> out;
    if (!eng_->Next(prev_, out) || out.empty()) return;
    if (out.size() > 6) out.resize(6);
    next_ = out; nextSel_ = 0; nextShown_ = true;
    eng_->ShowNext(next_, nextSel_);
}

bool Core::AcceptNext(int idx) {
    if (!nextShown_ || idx < 0 || idx >= (int)next_.size()) return false;
    ustr w = next_[idx], before = prev_;
    HideNext();
    bool sentence = before == u"<s>";
    if (sentence && enCap_ && !w.empty() && w[0] >= u'a' && w[0] <= u'z') w[0] = (char16_t)(w[0] - 32);
    if (enCap_) w = CapitalI(w);
    if (enSmart_) w = CurlyApos(w);
    ustr typed = w + u" ";
    doc_->ReplaceBefore(0, typed);
    Note(typed);
    last_.valid = false;
    if (eng_) eng_->LearnEnglish(StraightApos(w), StraightApos(w), before, "next", ustr());
    prev_ = LowerAscii(StraightApos(w));
    ShowNextWords();
    return true;
}

bool Core::WouldEatEn(const Key& k) const {
    if (!buf_.empty()) return true;                        // while a word is being typed every key goes through us (and may be handed on after the word is in)
    Cls cls = Classify(k);
    if (nextShown_ && nextKeys_ && (cls == Cls::Tab || cls == Cls::ShTab)) return true;
    if (cls == Cls::Letter) return true;
    if (cls == Cls::Bksp) return last_.valid;
    if (enSmart_ && !k.ctrl && !k.alt && !k.win && (k.ch == u'"' || k.ch == u'\'')) return true;
    if (enSmart_ && !k.ctrl && !k.alt && !k.win && (k.ch == u'-' || k.ch == u'.')) { return const_cast<Core*>(this)->Ctx(k.ch == u'-' ? 1 : 2) == (k.ch == u'-' ? ustr(u"-") : ustr(u"..")); }
    return false;
}

bool Core::OnKeyEn(const Key& k) {
    Cls cls = Classify(k);
    bool idle = buf_.empty();
    bool apos = cls == Cls::Mark && IsApos(k.ch);
    if (idle && nextShown_ && nextKeys_) {                   // the offered next words: Tab takes the highlighted one, Shift+Tab moves the highlight
        if (cls == Cls::Tab) { if (AcceptNext(nextSel_)) return true; }
        else if (cls == Cls::ShTab) { nextSel_ = (nextSel_ + 1) % (int)next_.size(); eng_->ShowNext(next_, nextSel_); return true; }
    }
    if (nextShown_) HideNext();                              // any other key puts the offer away
    if (idle) {
        if (cls == Cls::Letter) {
            last_.valid = false;
            char16_t c0 = k.ch;
            if (enCap_ && c0 >= u'a' && c0 <= u'z' && SentenceStart()) c0 = (char16_t)(c0 - 32);
            buf_ = ustr(1, c0); RefreshEn(); return true;
        }
        if (cls == Cls::Bksp && last_.valid) {
            ustr cur = last_.word + last_.tail;
            if (doc_->Before((int)cur.size()) == cur) {
                doc_->ReplaceBefore((int)cur.size(), last_.typed + last_.tail);
                if (eng_) eng_->LearnEnglish(last_.typed, last_.typed, last_.prev, "revert", last_.word);
                prev_ = LowerAscii(last_.typed);
                last_.valid = false;
                return true;
            }
        }
        last_.valid = false;
        if (enSmart_ && !k.ctrl && !k.alt && !k.win) {          // curly quotes, em dash, ellipsis
            if (k.ch == u'"' || k.ch == u'\'') {
                bool open = OpenContext();
                ustr q(1, k.ch == u'"' ? (open ? (char16_t)0x201C : (char16_t)0x201D) : (open ? (char16_t)0x2018 : (char16_t)0x2019));
                doc_->ReplaceBefore(0, q); Note(q); if (k.ch == u'"') prev_ = ustr();
                return true;
            }
            if (k.ch == u'-' && Ctx(1) == u"-") { doc_->ReplaceBefore(1, ustr(1, (char16_t)0x2014)); recent_.pop_back(); Note(ustr(1, (char16_t)0x2014)); return true; }
            if (k.ch == u'.' && Ctx(2) == u"..") { doc_->ReplaceBefore(2, ustr(1, (char16_t)0x2026)); recent_.erase(recent_.size() > 2 ? recent_.size() - 2 : 0); Note(ustr(1, (char16_t)0x2026)); prev_ = u"<s>"; return true; }
        }
        if (cls == Cls::Bksp) { if (!recent_.empty()) recent_.pop_back(); }
        else if (cls == Cls::Nav || cls == Cls::SelNav || cls == Cls::Left || cls == Cls::Right || cls == Cls::Up || cls == Cls::Down || cls == Cls::Chord) recent_.clear();
        else if (cls == Cls::Enter) Note(ustr(1, u'\n'));
        else if (k.ch >= 32 && k.ch != 127 && !k.ctrl && !k.alt && !k.win) Note(ustr(1, k.ch));
        if (cls == Cls::Space) { if (prev_ == u"<s>") ShowNextWords(); return false; }     // a space after a sentence end (or a word the person typed with a punctuation mark): offer what usually starts / follows
        if (cls == Cls::Enter) prev_ = u"<s>";
        else if (cls == Cls::Dot || cls == Cls::Punct || cls == Cls::Mark || cls == Cls::Gt || cls == Cls::Bar || cls == Cls::Star || cls == Cls::Digit0 || cls == Cls::Digit19) {
            if (k.ch == u'.' || k.ch == u'!' || k.ch == u'?') prev_ = u"<s>"; else if (!apos) prev_ = ustr();
        }
        return false;
    }
    // a word is being typed
    last_.valid = false;
    if (cls == Cls::Letter || apos) { buf_ += k.ch; RefreshEn(); return true; }
    switch (cls) {
        case Cls::Space: CommitEn(1, 0); return true;
        case Cls::Esc: CommitEn(0, 0); return true;                                   // keeps what was typed
        case Cls::Bksp:
            buf_.pop_back();
            if (buf_.empty()) { cands_.clear(); picked_ = false; doc_->EndEmpty(); if (eng_) eng_->HideList(); }
            else RefreshEn();
            return true;
        case Cls::Digit19: {                                                              // a number key picks the choice with that number (the numeric keypad always types the digit)
            bool keypad = k.vk >= 0x60 && k.vk <= 0x69;
            int n = (int)cands_.size(), i = (sel_ / kPageSize) * kPageSize + (int)(k.ch - u'1');
            if (!keypad && n > 1 && i >= 0 && i < n) { sel_ = i; picked_ = true; CommitEn(1, 0); return true; }
            break;
        }
        case Cls::Tab: case Cls::Down: case Cls::Right: case Cls::PgDn:
        case Cls::ShTab: case Cls::Up: case Cls::Left: case Cls::PgUp: {
            bool fwd = cls == Cls::Tab || cls == Cls::Down;
            bool back = cls == Cls::ShTab || cls == Cls::Up;
            int n = (int)cands_.size(), pages = (n + kPageSize - 1) / kPageSize;
            if ((cls == Cls::ShTab || cls == Cls::PgDn || cls == Cls::PgUp) && pages > 1) {      // Shift+Tab and Page Down: the next page; Page Up: the previous one
                int p = sel_ / kPageSize;
                p = cls == Cls::PgUp ? (p + pages - 1) % pages : (p + 1) % pages;
                sel_ = p * kPageSize; picked_ = true; doc_->Compose(cands_[sel_]); if (eng_) eng_->ShowList(cands_, sel_, buf_);
                return true;
            }
            if (!fwd && !back) { CommitEn(0, 0); return false; }                       // Left, Right, Page keys move the cursor: the word first, then the key
            if (n > 0) { sel_ = fwd ? (sel_ + 1) % n : (sel_ + n - 1) % n; picked_ = true; doc_->Compose(cands_[sel_]); if (eng_) eng_->ShowList(cands_, sel_, buf_); }
            return true;
        }
        case Cls::Enter: CommitEn(0, 0); prev_ = u"<s>"; return false;                 // the word as typed, then the Enter key itself
        case Cls::ChordDiscard: Forget(); return true;
        case Cls::Chord: case Cls::Nav: case Cls::SelNav: CommitEn(0, 0); return false;
        default: break;
    }
    if (k.ch >= 32 && k.ch != 127) { CommitEn(2, k.ch); return true; }                // a digit or a mark: the word, then the character
    CommitEn(0, 0);
    return false;
}

}  // namespace sk
