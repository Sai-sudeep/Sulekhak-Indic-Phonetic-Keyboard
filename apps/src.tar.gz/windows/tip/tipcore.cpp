#include "tipcore.h"
#include <cstring>

namespace sk {

#include "keytable.inc"

static int Nrm(int c) {
    if (c >= 0x0900 && c <= 0x097F && c != 0x0964 && c != 0x0965) return c + 0x200;
    if (c == 0x09F0) return 0x0B30;
    if (c == 0x09F1) return 0x0B71;
    if (c >= 0x0980 && c <= 0x09FF) return c + 0x180;
    return c;
}
static bool Mark(int c) { c = Nrm(c); return (c >= 0x0B3E && c <= 0x0B44) || c == 0x0B47 || c == 0x0B48 || c == 0x0B4B || c == 0x0B4C || c == 0x0B56 || c == 0x0B57 || c == 0x0B62 || c == 0x0B63 || c == 0x0B3C || (c >= 0x0B01 && c <= 0x0B03) || c == 0x0B4D || c == 0x200C || c == 0x200D; }
static bool Lett(int c) { c = Nrm(c); return (c >= 0x0B05 && c <= 0x0B39) || c == 0x0B5C || c == 0x0B5D || c == 0x0B5F || c == 0x0B60 || c == 0x0B61 || c == 0x0B71; }

ustr LoneNukta(int script) { return ustr(1, (char16_t)(script == 1 ? 0x093C : (script == 2 || script == 5) ? 0x09BC : 0x0B3C)); }

bool IsIndicBlockChar(char16_t c) { int n = Nrm(c); return (n >= 0x0B00 && n <= 0x0B7F) || c == 0x200C || c == 0x200D; }

bool NuktaEdit(const ustr& before, int script, int* drop, ustr* text) {
    int len = (int)before.size();
    if (len == 0) return false;
    int n = len < 14 ? len : 14, end = n, i, j, cs;
    ustr s = before.substr(len - n);
    bool space = false;
    if (end >= 2 && s[end - 1] == u' ' && (Mark(s[end - 2]) || Lett(s[end - 2]))) { space = true; end--; }
    i = end - 1;
    while (i > 0 && Mark(s[i])) i--;
    if (i < 0 || !Lett(s[i])) return false;
    cs = i;
    while (cs > 0 && Nrm(s[cs - 1]) == 0x0B4D) { cs--; if (cs > 0 && Lett(s[cs - 1])) cs--; else break; }
    int at = -1;
    ustr nuk = LoneNukta(script);
    for (j = end - 1; j >= cs; j--) {
        int u = s[j];
        if ((Nrm(u) == 0x0B21 || Nrm(u) == 0x0B22) && !(j + 1 < end && Nrm(s[j + 1]) == 0x0B3C)) { at = j + 1; nuk = ustr(1, (char16_t)(0x0B3C + (u - Nrm(u)))); break; }
    }
    if (at < 0) return false;
    ustr seg = s.substr(cs, end - cs);
    seg = seg.substr(0, at - cs) + nuk + seg.substr(at - cs);
    if (space) seg += u' ';
    *drop = n - cs;
    *text = seg;
    return true;
}

std::string StateOf(const ustr& buf) {
    if (buf.empty()) return "idle";
    bool digits = true, dots = true;
    for (char16_t c : buf) { if (c < u'0' || c > u'9') digits = false; if (c != u'.') dots = false; }
    if (digits) return "digits";
    if (dots) return "dots";
    if (buf.size() == 1 && (buf[0] == u'|' || buf[0] == u'*')) return "sym";
    return "word";
}

static const char* Name(Cls c) {
    switch (c) {
        case Cls::Letter: return "letter"; case Cls::Mark: return "mark"; case Cls::Gt: return "gt"; case Cls::Digit0: return "digit0";
        case Cls::Digit19: return "digit19"; case Cls::Dot: return "dot"; case Cls::Bar: return "bar"; case Cls::Star: return "star";
        case Cls::Punct: return "punct"; case Cls::Space: return "space"; case Cls::Enter: return "enter"; case Cls::Esc: return "esc";
        case Cls::Bksp: return "bksp"; case Cls::Tab: return "tab"; case Cls::ShTab: return "shtab"; case Cls::Up: return "up";
        case Cls::Down: return "down"; case Cls::Left: return "left"; case Cls::Right: return "right"; case Cls::PgUp: return "pgup";
        case Cls::PgDn: return "pgdn"; case Cls::Nav: return "nav"; case Cls::SelNav: return "selnav"; case Cls::Chord: return "chord";
        case Cls::ChordDiscard: return "chordDiscard";
    }
    return "nav";
}

static bool CharClass(char16_t c, Cls* out) {
    if ((c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z')) { *out = Cls::Letter; return true; }
    if (c == u'`' || c == u'~' || c == u'\'') { *out = Cls::Mark; return true; }
    if (c == u'>') { *out = Cls::Gt; return true; }
    if (c == u'0') { *out = Cls::Digit0; return true; }
    if (c >= u'1' && c <= u'9') { *out = Cls::Digit19; return true; }
    if (c == u'.') { *out = Cls::Dot; return true; }
    if (c == u'|') { *out = Cls::Bar; return true; }
    if (c == u'*') { *out = Cls::Star; return true; }
    if (c > 32 && c != 127) { *out = Cls::Punct; return true; }
    return false;
}

Cls Classify(const Key& k) {
    if (k.ctrl || k.alt || k.win) return (k.ctrl && !k.alt && !k.win && k.vk == 0x08) ? Cls::ChordDiscard : Cls::Chord;
    uint32_t vk = k.vk;
    bool nav = vk == 0x25 || vk == 0x26 || vk == 0x27 || vk == 0x28 || vk == 0x21 || vk == 0x22 || vk == 0x23 || vk == 0x24;
    if (k.shift && nav) return Cls::SelNav;
    switch (vk) {
        case 0x20: return Cls::Space; case 0x0D: return Cls::Enter; case 0x1B: return Cls::Esc; case 0x08: return Cls::Bksp;
        case 0x09: return k.shift ? Cls::ShTab : Cls::Tab; case 0x26: return Cls::Up; case 0x28: return Cls::Down;
        case 0x25: return Cls::Left; case 0x27: return Cls::Right; case 0x21: return Cls::PgUp; case 0x22: return Cls::PgDn;
    }
    Cls c;
    if (k.ch && CharClass(k.ch, &c)) return c;
    return Cls::Nav;
}

std::vector<std::string> Decide(const std::string& state, Cls cls, int nCands, int sel, char digit) {
    std::string key = state + "/" + Name(cls);
    const char* rule = nullptr;
    for (const auto& r : kRules) if (key == r.key) { rule = r.rule; break; }
    std::string s = rule ? rule : "pass";
    if (!s.empty() && s[0] == '?') {
        size_t a = s.find('|'), b = s.find('|', a + 1);
        std::string cond = s.substr(1, a - 1), th = s.substr(a + 1, b - a - 1), el = s.substr(b + 1);
        bool yes = false;
        if (cond == "multiPage") yes = (nCands + kPageSize - 1) / kPageSize > 1;
        else if (cond == "hasChoice") yes = (sel / kPageSize) * kPageSize + (digit - '1') < nCands;
        s = yes ? th : el;
    }
    std::vector<std::string> out;
    size_t p = 0;
    while (p <= s.size()) { size_t q = s.find(',', p); if (q == std::string::npos) q = s.size(); out.push_back(s.substr(p, q - p)); p = q + 1; }
    return out;
}

static bool HasNonAscii(const ustr& s) { for (char16_t c : s) if (c > 127) return true; return false; }
static bool CanLearn(const ustr& r) { if (r.empty()) return false; for (char16_t c : r) if (!((c >= u'a' && c <= u'z') || (c >= u'A' && c <= u'Z'))) return false; return true; }
static bool WordContinues(const ustr& w) {
    if (w.empty()) return true;
    char16_t l = w.back();
    if (w.size() == 1 && (l == u'*' || l == 0x0B3D || l == 0x0B55 || l == 0x0B70 || (l >= 0x0B72 && l <= 0x0B77))) return true;
    return l == 0x0B4D || l == 0x200C;
}

void Core::Refresh() {
    std::vector<ustr> out;
    if (!eng_ || !eng_->Query(script_, buf_, prev_, out) || out.empty()) { out.clear(); out.push_back(buf_); }
    cands_ = out;
    sel_ = 0;
    doc_->Compose(cands_[0]);
    if (eng_) eng_->ShowList(cands_, sel_, buf_);
}

void Core::CommitIdx(int idx, int mode, char16_t typed) {
    if (buf_.empty()) return;
    ustr roman = buf_;
    ustr word = (idx >= 0 && idx < (int)cands_.size()) ? cands_[idx] : roman;
    bool cont = WordContinues(word);
    ustr out = word;
    if (mode == 1 && !cont) out += u' ';
    else if (mode == 2) out += u' ';
    else if (mode == 3) out += typed;
    doc_->Commit(out);
    if (HasNonAscii(word) && CanLearn(roman)) { if (eng_) eng_->Learn(script_, roman, word); prev_ = (mode == 3) ? ustr(u"<s>") : word; }
    else prev_ = u"<s>";
    buf_.clear(); cands_.clear(); sel_ = 0;
    if (eng_) eng_->HideList();
}

void Core::Reset() {
    if (buf_.empty()) return;
    CommitIdx(sel_, 0, 0);
}

void Core::Lost() {
    buf_.clear(); cands_.clear(); sel_ = 0;
    if (eng_) eng_->HideList();
}

void Core::Forget() {
    if (buf_.empty()) return;
    buf_.clear(); cands_.clear(); sel_ = 0;
    doc_->EndEmpty();
    if (eng_) eng_->HideList();
}

void Core::Apply(const std::vector<std::string>& eff, const Key& k, Cls cls, bool* pass) {
    for (const std::string& e : eff) {
        if (e == "start") { buf_ = ustr(1, k.ch); Refresh(); }
        else if (e == "append") { buf_ += k.ch; Refresh(); }
        else if (e == "commit") CommitIdx(sel_, 0, 0);
        else if (e == "commitAuto") CommitIdx(sel_, 1, 0);
        else if (e == "commitSpace") CommitIdx(sel_, 2, 0);
        else if (e == "commitTyped") CommitIdx(sel_, 3, k.ch);
        else if (e == "pick") { int i = (sel_ / kPageSize) * kPageSize + (int)(k.ch - u'1'); CommitIdx(i, 1, 0); }
        else if (e == "bksp") { buf_.pop_back(); if (buf_.empty()) { cands_.clear(); doc_->EndEmpty(); if (eng_) eng_->HideList(); } else Refresh(); }
        else if (e == "discard") { buf_.clear(); cands_.clear(); sel_ = 0; doc_->EndEmpty(); if (eng_) eng_->HideList(); }
        else if (e == "candNext" || e == "candPrev") {
            int n = (int)cands_.size();
            if (n > 0) { sel_ = e == "candNext" ? (sel_ + 1) % n : (sel_ + n - 1) % n; doc_->Compose(cands_[sel_]); if (eng_) eng_->ShowList(cands_, sel_, buf_); }
        }
        else if (e == "pageNext" || e == "pagePrev") {
            int n = (int)cands_.size(), pages = (n + kPageSize - 1) / kPageSize, p = sel_ / kPageSize;
            if (pages > 1) { p = e == "pageNext" ? (p + 1) % pages : (p + pages - 1) % pages; sel_ = p * kPageSize; doc_->Compose(cands_[sel_]); if (eng_) eng_->ShowList(cands_, sel_, buf_); }
        }
        else if (e == "nukta") {
            int drop; ustr text;
            if (NuktaEdit(doc_->Before(14), script_, &drop, &text)) doc_->ReplaceBefore(drop, text);
            else doc_->ReplaceBefore(0, LoneNukta(script_));
            prev_ = u"<s>";
        }
        else if (e == "delCodepoint") {
            ustr b = doc_->Before(1);
            if (b.size() == 1 && IsIndicBlockChar(b[0])) doc_->ReplaceBefore(1, ustr());
            else *pass = true;
        }
        else if (e == "swallow") {}
        else if (e == "pass") *pass = true;
        else if (e == "again") Apply(Decide("idle", cls, 0, 0, (char)(k.ch < 128 ? k.ch : 0)), k, cls, pass);
    }
}

bool Core::WouldEat(const Key& k) const {
    Cls cls = Classify(k);
    std::vector<std::string> eff = Decide(StateOf(buf_), cls, (int)cands_.size(), sel_, (char)(k.ch < 128 ? k.ch : 0));
    for (const std::string& e : eff) {
        if (e == "pass") return false;
        if (e == "again") { for (const std::string& f : Decide("idle", cls, 0, 0, (char)(k.ch < 128 ? k.ch : 0))) if (f == "pass") return false; }
    }
    return true;
}

bool Core::OnKey(const Key& k) {
    Cls cls = Classify(k);
    bool wasIdle = buf_.empty();
    std::vector<std::string> eff = Decide(StateOf(buf_), cls, (int)cands_.size(), sel_, (char)(k.ch < 128 ? k.ch : 0));
    bool pass = false;
    Apply(eff, k, cls, &pass);
    if (pass && wasIdle && k.vk != 0x20) prev_ = u"<s>";
    return !pass;
}

}  // namespace sk
