// Registration of the text service: what makes it appear in Win+Space. regsvr32 (or the installer) calls DllRegisterServer with administrator rights.
#include <windows.h>
#include <string>
#include <msctf.h>
#include <shlwapi.h>
#include "guids.h"
#include "tip.h"

struct Prof { const GUID* guid; LANGID lang; const wchar_t* name; };
static const Prof kProfiles[] = {
    { &GUID_ProfileAll,      0x0409, L"Sulekhak — All Languages" },
    { &GUID_ProfileOdia,     0x0448, L"Sulekhak — Odia" },
    { &GUID_ProfileHindi,    0x0439, L"Sulekhak — Hindi (Devanagari)" },
    { &GUID_ProfileMarathi,  0x044E, L"Sulekhak — Marathi" },
    { &GUID_ProfileBangla,   0x0445, L"Sulekhak — Bangla" },
    { &GUID_ProfileAssamese, 0x044D, L"Sulekhak — Assamese" },
};
// {046B8C80-1647-40F7-9B21-B93B81AABC1B}
DEFINE_GUID(SK_GUID_TFCAT_DISPLAYATTRIBUTEPROVIDER, 0x046b8c80, 0x1647, 0x40f7, 0x9b, 0x21, 0xb9, 0x3b, 0x81, 0xaa, 0xbc, 0x1b);

static const GUID* kCategories[] = { &GUID_TFCAT_TIP_KEYBOARD, &SK_GUID_TFCAT_DISPLAYATTRIBUTEPROVIDER, &SK_GUID_TFCAT_TIPCAP_IMMERSIVESUPPORT,
                                     &SK_GUID_TFCAT_TIPCAP_SYSTRAYSUPPORT, &SK_GUID_TFCAT_TIPCAP_UIELEMENTENABLED, &SK_GUID_TFCAT_TIPCAP_COMLESS };

static std::wstring ClsidKey() {
    wchar_t g[64]; StringFromGUID2(CLSID_SulekhakTip, g, 64);
    return std::wstring(L"Software\\Classes\\CLSID\\") + g;
}

STDAPI DllRegisterServer() {
    wchar_t path[MAX_PATH];
    if (!GetModuleFileNameW(g_hInst, path, MAX_PATH)) return E_FAIL;
    std::wstring key = ClsidKey();
    HKEY k = nullptr;
    LONG r = RegCreateKeyExW(HKEY_LOCAL_MACHINE, key.c_str(), 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr);
    if (r != ERROR_SUCCESS) return HRESULT_FROM_WIN32(r);
    RegSetValueExW(k, nullptr, 0, REG_SZ, (const BYTE*)SK_TEXTSERVICE_NAME, (DWORD)((wcslen(SK_TEXTSERVICE_NAME) + 1) * 2));
    RegCloseKey(k);
    r = RegCreateKeyExW(HKEY_LOCAL_MACHINE, (key + L"\\InprocServer32").c_str(), 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr);
    if (r != ERROR_SUCCESS) return HRESULT_FROM_WIN32(r);
    RegSetValueExW(k, nullptr, 0, REG_SZ, (const BYTE*)path, (DWORD)((wcslen(path) + 1) * 2));
    const wchar_t* tm = L"Both";
    RegSetValueExW(k, L"ThreadingModel", 0, REG_SZ, (const BYTE*)tm, (DWORD)((wcslen(tm) + 1) * 2));
    RegCloseKey(k);

    // Each keyboard is registered on its own, so that one that Windows refuses (a language this edition of Windows does not have) does not stop the others.
    // Windows 8 and later: RegisterProfile. When that is not available or refuses, the older Register + AddLanguageProfile does the same.
    HRESULT hr = S_OK, firstErr = S_OK;
    int registered = 0;
    ITfInputProcessorProfileMgr* pm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfileMgr, (void**)&pm))) pm = nullptr;
    ITfInputProcessorProfiles* pp = nullptr;
    bool oldReady = false;
    for (const Prof& p : kProfiles) {
        HRESULT h = E_FAIL;
        if (pm) h = pm->RegisterProfile(CLSID_SulekhakTip, p.lang, *p.guid, p.name, (ULONG)wcslen(p.name), path, (ULONG)wcslen(path), 0, nullptr, 0, TRUE, 0);
        if (FAILED(h)) {
            if (!pp) {
                if (SUCCEEDED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfiles, (void**)&pp))) oldReady = SUCCEEDED(pp->Register(CLSID_SulekhakTip));
            }
            if (pp && oldReady) h = pp->AddLanguageProfile(CLSID_SulekhakTip, p.lang, *p.guid, p.name, (ULONG)wcslen(p.name), path, (ULONG)wcslen(path), 0);
        }
        if (SUCCEEDED(h)) registered++; else if (SUCCEEDED(firstErr)) firstErr = h;
    }
    if (pm) pm->Release();
    if (pp) pp->Release();
    if (registered == 0) return FAILED(firstErr) ? firstErr : E_FAIL;      // nothing at all could be registered: that is a failure
    ITfCategoryMgr* cm = nullptr;
    HRESULT h = CoCreateInstance(CLSID_TF_CategoryMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfCategoryMgr, (void**)&cm);
    if (FAILED(h)) return h;
    for (const GUID* c : kCategories) {
        h = cm->RegisterCategory(CLSID_SulekhakTip, *c, CLSID_SulekhakTip);
        if (FAILED(h) && c == &GUID_TFCAT_TIP_KEYBOARD) hr = h;          // the others are optional
    }
    cm->Release();
    return hr;
}

STDAPI DllUnregisterServer() {
    ITfInputProcessorProfileMgr* pm = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfileMgr, (void**)&pm))) {
        for (const Prof& p : kProfiles) pm->UnregisterProfile(CLSID_SulekhakTip, p.lang, *p.guid, 0);
        pm->Release();
    }
    ITfCategoryMgr* cm = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_TF_CategoryMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfCategoryMgr, (void**)&cm))) {
        for (const GUID* c : kCategories) cm->UnregisterCategory(CLSID_SulekhakTip, *c, CLSID_SulekhakTip);
        cm->Release();
    }
    ITfInputProcessorProfiles* pp = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfiles, (void**)&pp))) {
        pp->Unregister(CLSID_SulekhakTip);
        pp->Release();
    }
    SHDeleteKeyW(HKEY_LOCAL_MACHINE, ClsidKey().c_str());
    return S_OK;
}

// rundll32 sulekhak_tip.dll,EnableForUser : switches the keyboards on for the user who runs it (the installer registered them for the computer)
extern "C" void CALLBACK EnableForUser(HWND, HINSTANCE, LPSTR, int) {
    CoInitialize(nullptr);
    ITfInputProcessorProfiles* pp = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfiles, (void**)&pp))) {
        for (const Prof& p : kProfiles) pp->EnableLanguageProfile(CLSID_SulekhakTip, p.lang, *p.guid, TRUE);
        pp->Release();
    }
    CoUninitialize();
}
