// The typing logic of the Sulekhak text service, with no Windows in it: the same rules as the Mac input method and the Windows keyboard hook
// (keymap/sulekhak-keymap.json), driven through two small interfaces so that it can be tested on any computer.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace sk {

typedef std::u16string ustr;

enum class Cls { Letter, Mark, Gt, Digit0, Digit19, Dot, Bar, Star, Punct, Space, Enter, Esc, Bksp, Tab, ShTab, Up, Down, Left, Right, PgUp, PgDn, Nav, SelNav, Chord, ChordDiscard };

// A key press: the virtual-key code, the character the layout gives it (0 when it gives none), and the modifier keys.
struct Key { uint32_t vk; char16_t ch; bool shift, ctrl, alt, win; };

// What the text service needs from the program it types into (the TSF layer implements it with ITfRange; the tests with a string).
struct Doc {
    virtual ~Doc() {}
    virtual ustr Before(int n) = 0;                              // up to n code units before the caret, outside the composition
    virtual void Compose(const ustr& s) = 0;                     // show s as the underlined word being typed (starts the composition when needed)
    virtual void Commit(const ustr& s) = 0;                      // replace the composition by s and end it, caret after s
    virtual void EndEmpty() = 0;                                 // end the composition and leave nothing
    virtual void ReplaceBefore(int drop, const ustr& s) = 0;     // remove `drop` code units before the caret and type s there
};

// What it needs from the engine, which runs in the Sulekhak program (another process).
struct Engine {
    virtual ~Engine() {}
    virtual bool Query(int script, const ustr& buf, const ustr& prev, std::vector<ustr>& out) = 0;   // false: the engine cannot be reached
    virtual void Learn(int script, const ustr& roman, const ustr& word) { (void)script; (void)roman; (void)word; }
    virtual void ShowList(const std::vector<ustr>& list, int sel, const ustr& roman) { (void)list; (void)sel; (void)roman; }
    virtual void HideList() {}
    // English (script 6): what was typed, what went in, the word before, how ("typed", "auto", "pick", "revert"), and the word the engine would have chosen instead
    virtual void LearnEnglish(const ustr& typed, const ustr& word, const ustr& prev, const std::string& how, const ustr& passed) { (void)typed; (void)word; (void)prev; (void)how; (void)passed; }
};

// The nukta rule: the lone  >  puts a nukta on the ଡ / ଢ of the word just typed. false: nothing to mark.
bool NuktaEdit(const ustr& before, int script, int* drop, ustr* text);
ustr LoneNukta(int script);
bool IsIndicBlockChar(char16_t c);           // a character that Backspace removes one code point of

// Classify a key for the rules.
Cls Classify(const Key& k);
// The effects of a key of class `cls` when the buffer is `buf` (keytable.inc). `digit` is the typed number character.
std::vector<std::string> Decide(const std::string& state, Cls cls, int nCands, int sel, char digit);
std::string StateOf(const ustr& buf);

class Core {
public:
    Core(Doc* d, Engine* e) : doc_(d), eng_(e) {}
    void SetScript(int script) { script_ = script; }
    int Script() const { return script_; }
    bool Composing() const { return !buf_.empty(); }
    const ustr& Buffer() const { return buf_; }
    bool OnKey(const Key& k);                // true: the key is used up
    bool WouldEat(const Key& k) const;       // the same answer without doing anything (for the test-key calls of TSF)
    void Reset();                            // focus left or the program was switched: keep what was typed, as the highlighted word
    void Forget();                           // drop the word being typed and its text
    void Lost();                             // the program ended our composition (a click elsewhere): its text stays as plain text, only our state is cleared
    const ustr& Previous() const { return prev_; }
    void SetPrevious(const ustr& p) { prev_ = p; }

private:
    void Apply(const std::vector<std::string>& eff, const Key& k, Cls cls, bool* pass);
    void Refresh();
    // English typing (script 6): the letters stay as typed in the document until Space; only Space applies a correction, and Backspace right after one puts the typed letters back.
    bool OnKeyEn(const Key& k);
    bool WouldEatEn(const Key& k) const;
    void RefreshEn();
    void CommitEn(int mode, char16_t ch);        // mode: 0 the word only, 1 and a space (Space: the engine's choice), 2 and the character ch
    struct LastEn { ustr typed, word, tail, prev; bool valid = false; } last_;
    bool picked_ = false;                        // English: a word of the list was chosen with Tab / the arrows
    void CommitIdx(int idx, int mode, char16_t typed);   // mode: 0 none, 1 auto space, 2 space, 3 typed char
    Doc* doc_;
    Engine* eng_;
    int script_ = 0;
    ustr buf_;
    ustr prev_ = u"<s>";
    std::vector<ustr> cands_;
    int sel_ = 0;
};

}  // namespace sk
