// The Sulekhak text service (a TSF "text input processor"): what makes Sulekhak a real input method in Windows, listed by Win+Space
// next to the other keyboards, in every program that uses the normal text services. The typing rules are in tipcore.cpp; the words come
// from the Sulekhak program (engine host) through a named pipe.
#include <windows.h>
#include <msctf.h>
#include <sddl.h>
#include <algorithm>
#include <functional>
#include <string>
#include <vector>
#include "guids.h"
#include "tsfextra.h"
#include "tipcore.h"
#include "tip.h"
extern "C" {
#include "engine/engine.h"
}

HINSTANCE g_hInst = nullptr;
static LONG g_objects = 0, g_locks = 0;

void SkLog(const char* fmt, ...) {
    wchar_t flag[8];
    if (!GetEnvironmentVariableW(L"SULEKHAK_TIP_LOG", flag, 8)) return;
    wchar_t tmp[MAX_PATH]; if (!GetTempPathW(MAX_PATH, tmp)) return;
    std::wstring p = std::wstring(tmp) + L"sulekhak_tip.log";
    HANDLE f = CreateFileW(p.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, 0, nullptr);
    if (f == INVALID_HANDLE_VALUE) return;
    char line[512]; va_list ap; va_start(ap, fmt); int n = vsnprintf(line, 500, fmt, ap); va_end(ap);
    if (n < 0) n = 0;
    if (n > 500) n = 500;
    line[n++] = '\r'; line[n++] = '\n';
    DWORD w; WriteFile(f, line, n, &w, nullptr); CloseHandle(f);
}

// Problems (never what is typed) go to %LOCALAPPDATA%\Sulekhak\tip.log, at most one line a minute for each program, and the file stops growing at 100 KB.
// This is what tells "the keyboard could not reach its words" from "the keyboard did not load" when someone reports that it does not work.
void SkErr(const char* fmt, ...) {
    static DWORD last = 0;
    DWORD now = GetTickCount();
    if (last && (DWORD)(now - last) < 60000) return;
    last = now;
    wchar_t base[MAX_PATH];
    DWORD n = GetEnvironmentVariableW(L"LOCALAPPDATA", base, MAX_PATH);
    if (!n || n >= MAX_PATH - 20) return;
    std::wstring dir = std::wstring(base) + L"\\Sulekhak";
    CreateDirectoryW(dir.c_str(), nullptr);
    std::wstring p = dir + L"\\tip.log";
    HANDLE f = CreateFileW(p.c_str(), FILE_APPEND_DATA | FILE_READ_ATTRIBUTES, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, 0, nullptr);
    if (f == INVALID_HANDLE_VALUE) return;
    LARGE_INTEGER sz; sz.QuadPart = 0;
    if (GetFileSizeEx(f, &sz) && sz.QuadPart > 100 * 1024) { CloseHandle(f); return; }
    wchar_t exe[MAX_PATH]; exe[0] = 0; GetModuleFileNameW(nullptr, exe, MAX_PATH);
    const wchar_t* base_name = wcsrchr(exe, L'\\'); base_name = base_name ? base_name + 1 : exe;
    char name[MAX_PATH * 3]; WideCharToMultiByte(CP_UTF8, 0, base_name, -1, name, sizeof name, nullptr, nullptr);
    SYSTEMTIME st; GetLocalTime(&st);
    char line[700];
    int k = snprintf(line, 200, "%04d-%02d-%02d %02d:%02d:%02d  %s (pid %lu): ", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, name, (unsigned long)GetCurrentProcessId());
    if (k < 0) k = 0;
    if (k > 200) k = 200;
    va_list ap; va_start(ap, fmt); int m = vsnprintf(line + k, 480, fmt, ap); va_end(ap);
    if (m < 0) m = 0;
    if (m > 480) m = 480;
    k += m;
    line[k++] = '\r'; line[k++] = '\n';
    DWORD w; WriteFile(f, line, k, &w, nullptr); CloseHandle(f);
}

// ---------------------------------------------------------------------------------------------------------------- strings
static std::string ToUtf8(const sk::ustr& s) {
    if (s.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, (const wchar_t*)s.data(), (int)s.size(), nullptr, 0, nullptr, nullptr);
    std::string o(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, (const wchar_t*)s.data(), (int)s.size(), &o[0], n, nullptr, nullptr);
    return o;
}
static sk::ustr FromUtf8(const char* p, int len) {
    if (len <= 0) return sk::ustr();
    int n = MultiByteToWideChar(CP_UTF8, 0, p, len, nullptr, 0);
    sk::ustr o(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, p, len, (wchar_t*)&o[0], n);
    return o;
}


// ---------------------------------------------------------------------------------------------------------------- starting the Sulekhak program
// The words come from the Sulekhak program (the tray icon). If it is not running when a Sulekhak keyboard is used (after a restart, when "start with
// Windows" was not chosen, or after a crash), the keyboard starts it, at most once every 20 seconds, never from an elevated program (its pipe would
// then belong to the wrong integrity level) and never after the user chose Exit in the tray menu (the program writes HKCU\Software\Sulekhak\UserExit=1).
static bool IsElevated() {
    HANDLE tok = nullptr; bool el = false;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) {
        TOKEN_ELEVATION te = {}; DWORD n = 0;
        if (GetTokenInformation(tok, TokenElevation, &te, sizeof te, &n)) el = te.TokenIsElevated != 0;
        CloseHandle(tok);
    }
    return el;
}
static bool RegFlag(const wchar_t* name, bool def) {      // a DWORD switch of the tray program (Software\\Sulekhak); def when it was never set
    HKEY k; DWORD v = 0, n = sizeof v, type = 0;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Sulekhak", 0, KEY_READ, &k) != ERROR_SUCCESS) return def;
    LONG r = RegQueryValueExW(k, name, nullptr, &type, (BYTE*)&v, &n);
    RegCloseKey(k);
    return (r == ERROR_SUCCESS && type == REG_DWORD) ? v != 0 : def;
}
static bool UserChoseExit() {
    HKEY k; DWORD v = 0, n = sizeof v, type = 0;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Sulekhak", 0, KEY_READ, &k) != ERROR_SUCCESS) return false;
    LONG r = RegQueryValueExW(k, L"UserExit", nullptr, &type, (BYTE*)&v, &n);
    RegCloseKey(k);
    return r == ERROR_SUCCESS && type == REG_DWORD && v != 0;
}
static void LaunchHost() {
    static DWORD last = 0;
    DWORD now = GetTickCount();
    if (last && (DWORD)(now - last) < 20000) return;
    wchar_t flag[4];
    bool allowElevated = GetEnvironmentVariableW(L"SULEKHAK_TIP_ALLOW_ELEVATED", flag, 4) != 0;      // only the installer test sets this (its runner is an administrator)
    if ((IsElevated() && !allowElevated) || UserChoseExit()) { SkLog("host not started (elevated or exited by the user)"); return; }
    last = now;
    HKEY k;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"Software\\Sulekhak", 0, KEY_READ | KEY_WOW64_64KEY, &k) != ERROR_SUCCESS) return;
    wchar_t dir[MAX_PATH + 2]; DWORD n = MAX_PATH * sizeof(wchar_t), type = 0;
    LONG r = RegQueryValueExW(k, L"InstallDir", nullptr, &type, (BYTE*)dir, &n);
    RegCloseKey(k);
    if (r != ERROR_SUCCESS || type != REG_SZ) return;
    dir[n / sizeof(wchar_t) < MAX_PATH ? n / sizeof(wchar_t) : MAX_PATH] = 0;
    std::wstring exe = std::wstring(dir) + L"\\Sulekhak.exe";
    if (GetFileAttributesW(exe.c_str()) == INVALID_FILE_ATTRIBUTES) { SkLog("host exe not found"); return; }
    std::wstring cmd = L"\"" + exe + L"\" --from-text-service";
    STARTUPINFOW si = {}; si.cb = sizeof si;
    PROCESS_INFORMATION pi = {};
    // leave the job of the program that is typing (a browser may end its children with it); some jobs do not allow that, then start it normally
    BOOL ok = CreateProcessW(exe.c_str(), &cmd[0], nullptr, nullptr, FALSE, CREATE_BREAKAWAY_FROM_JOB | DETACHED_PROCESS, nullptr, dir, &si, &pi);
    if (!ok) ok = CreateProcessW(exe.c_str(), &cmd[0], nullptr, nullptr, FALSE, DETACHED_PROCESS, nullptr, dir, &si, &pi);
    if (ok) { SkLog("host started"); CloseHandle(pi.hThread); CloseHandle(pi.hProcess); }
    else SkLog("host start failed (%lu)", (unsigned long)GetLastError());
}

// ---------------------------------------------------------------------------------------------------------------- the built-in Odia engine
// The same C engine the Mac keyboard uses, inside the DLL. When the Sulekhak program does not answer in time (a slow start, a busy or older PC,
// the program closed) the Odia, Hindi/Marathi, Bangla and Assamese keyboards still give real words instead of the Roman letters.
static CRITICAL_SECTION g_localCs;
static bool g_localInit = false, g_localReady = false;
static bool LocalQuery(int script, int opt, const sk::ustr& buf, std::vector<sk::ustr>& out) {
    if (script != 0 && script != 1 && script != 2 && script != 5) return false;
    if (!g_localInit) return false;
    EnterCriticalSection(&g_localCs);
    if (!g_localReady) { odia_load_builtin(); g_localReady = true; }
    static char cands[ODIA_MAX_CANDS][ODIA_CAND_LEN];
    std::string u = ToUtf8(buf);
    int n = odia_candidates_in(u.c_str(), script, cands);
    out.clear();
    for (int i = 0; i < n && i < ODIA_MAX_CANDS; i++) {
        if (!cands[i][0]) continue;
        char conv[ODIA_CAND_LEN];
        if (script == 0) snprintf(conv, sizeof conv, "%s", cands[i]);
        else odia_convert(cands[i], script, opt, conv, sizeof conv);       // the engine thinks in Odia; carry each word into the keyboard's script
        sk::ustr w = FromUtf8(conv, (int)strlen(conv));
        if (i > 1 && script != 0 && std::find(out.begin(), out.end(), w) != out.end()) continue;   // two Odia spellings that look the same in this script
        out.push_back(w);
    }
    LeaveCriticalSection(&g_localCs);
    return !out.empty();
}

// ---------------------------------------------------------------------------------------------------------------- the pipe to the engine
// One request, one answer, in message mode:  Q script opt prev buf -> C word word ...   L script roman word -> K   P x y h sel roman words... -> K
// H -> K   G -> T script opt   W script opt -> K   E typed word prev how passed -> K   (fields are separated by a tab; script 6 is English)
class PipeEngine : public sk::Engine {
public:
    PipeEngine() { name_ = PipeName(); }
    ~PipeEngine() { Close(); }
    int scriptOverride = -1, opt = 0;
    static std::wstring PipeName() {
        std::wstring sid = L"user";
        HANDLE tok = nullptr;
        if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) {
            DWORD n = 0; GetTokenInformation(tok, TokenUser, nullptr, 0, &n);
            std::vector<BYTE> buf(n ? n : 1);
            if (n && GetTokenInformation(tok, TokenUser, buf.data(), n, &n)) {
                wchar_t* s = nullptr;
                if (ConvertSidToStringSidW(((TOKEN_USER*)buf.data())->User.Sid, &s)) { sid = s; LocalFree(s); }
            }
            CloseHandle(tok);
        }
        return L"\\\\.\\pipe\\SulekhakTip-" + sid;
    }
    bool Call(const std::string& req, std::string& resp) {
        DWORD now = GetTickCount();
        if (down_ && (LONG)(now - downUntil_) < 0) return false;
        for (int attempt = 0; attempt < 2; attempt++) {
            if (h_ == INVALID_HANDLE_VALUE && !Open()) { Down(2500); return false; }
            if (Transact(req, resp)) { down_ = false; return true; }
            Close();
        }
        Down();
        return false;
    }
    bool Query(int script, const sk::ustr& buf, const sk::ustr& prev, std::vector<sk::ustr>& out) override {
        std::string r;
        std::string q = "Q\t" + std::to_string(script) + "\t" + std::to_string(opt) + "\t" + ToUtf8(prev) + "\t" + ToUtf8(buf);
        if (!Call(q, r) || r.size() < 1 || r[0] != 'C') return LocalQuery(script, opt, buf, out);
        out.clear();
        size_t p = 2;
        while (p <= r.size() && r.size() > 1) {
            size_t e = r.find('\t', p);
            if (e == std::string::npos) e = r.size();
            if (e > p) out.push_back(FromUtf8(r.data() + p, (int)(e - p)));
            p = e + 1;
        }
        return !out.empty();
    }
    void Learn(int script, const sk::ustr& roman, const sk::ustr& word) override {
        std::string r; Call("L\t" + std::to_string(script) + "\t" + ToUtf8(roman) + "\t" + ToUtf8(word), r);
    }
    void ShowList(const std::vector<sk::ustr>& list, int sel, const sk::ustr& roman) override {
        SkLog("ShowList roman=%u words=%u", (unsigned)roman.size(), (unsigned)list.size());
        if (roman.size() <= 1 && uiEnd) uiEnd();       // a new word begins: a list element left open by an earlier word is closed, the program is told afresh
        if (uiShow && uiShow(list, sel)) return;       // the program draws the list itself (UI-less mode: the Start / Search box and other store-style windows)
        RECT rc = {0, 0, 0, 0};
        if (rectFn) rectFn(&rc);
        std::string q = "P\t" + std::to_string(rc.left) + "\t" + std::to_string(rc.bottom) + "\t" + std::to_string(rc.bottom - rc.top) + "\t" + std::to_string(sel) + "\t" + ToUtf8(roman);
        for (const auto& c : list) q += "\t" + ToUtf8(c);
        std::string r; Call(q, r);
    }
    void HideList() override { if (uiEnd && uiEnd()) return; std::string r; Call("H", r); }
    // English: E typed word prev how passed -> K
    void LearnEnglish(const sk::ustr& typed, const sk::ustr& word, const sk::ustr& prev, const std::string& how, const sk::ustr& passed) override {
        std::string r; Call("E\t" + ToUtf8(typed) + "\t" + ToUtf8(word) + "\t" + ToUtf8(prev) + "\t" + how + "\t" + ToUtf8(passed), r);
    }
    // the script the "All Languages" keyboard types now, as the Sulekhak program has it
    bool FetchScript(int* script, int* o) {
        std::string r;
        if (!Call("G", r) || r.size() < 3 || r[0] != 'T') return false;
        *script = atoi(r.c_str() + 2);
        size_t t = r.find('\t', 2);
        *o = t == std::string::npos ? 0 : atoi(r.c_str() + t + 1);
        return true;
    }
    void SetScript(int script, int o) { std::string r; Call("W\t" + std::to_string(script) + "\t" + std::to_string(o), r); }
    std::function<void(RECT*)> rectFn;
    std::function<bool(const std::vector<sk::ustr>&, int)> uiShow;   // true: the program shows the list (nothing is drawn by Sulekhak)
    std::function<bool()> uiEnd;                                      // true: the program had been showing it
private:
    bool Open() {
        for (int i = 0; i < 2; i++) {
            h_ = CreateFileW(name_.c_str(), GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, nullptr);
            if (h_ != INVALID_HANDLE_VALUE) break;
            DWORD e = GetLastError();
            lastErr_ = e;
            if (e == ERROR_FILE_NOT_FOUND) LaunchHost();           // the Sulekhak program is not running
            if (e != ERROR_PIPE_BUSY || !WaitNamedPipeW(name_.c_str(), 50)) return false;
        }
        if (h_ == INVALID_HANDLE_VALUE) return false;
        DWORD mode = PIPE_READMODE_MESSAGE;
        SetNamedPipeHandleState(h_, &mode, nullptr, nullptr);
        return true;
    }
    void Close() { if (h_ != INVALID_HANDLE_VALUE) { CloseHandle(h_); h_ = INVALID_HANDLE_VALUE; } }
    void Down(DWORD lockMs = 8000) { down_ = true; downUntil_ = GetTickCount() + lockMs; SkErr("the Sulekhak program did not answer on its pipe (error %lu)", (unsigned long)lastErr_); }
    bool Wait(OVERLAPPED* ov, DWORD ms, DWORD* n) {
        DWORD w = WaitForSingleObject(ov->hEvent, ms);
        if (w != WAIT_OBJECT_0) { CancelIoEx(h_, ov); GetOverlappedResult(h_, ov, n, TRUE); return false; }
        return GetOverlappedResult(h_, ov, n, FALSE) != 0;
    }
    bool Transact(const std::string& req, std::string& resp) {
        HANDLE ev = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (!ev) return false;
        bool ok = false;
        OVERLAPPED ov = {}; ov.hEvent = ev;
        DWORD n = 0;
        if (!WriteFile(h_, req.data(), (DWORD)req.size(), nullptr, &ov) && GetLastError() != ERROR_IO_PENDING) goto done;
        if (!Wait(&ov, 700, &n)) goto done;
        resp.clear();
        for (;;) {
            char buf[8192];
            ResetEvent(ev); ov = OVERLAPPED(); ov.hEvent = ev;
            BOOL r = ReadFile(h_, buf, sizeof buf, nullptr, &ov);
            DWORD err = r ? 0 : GetLastError();
            if (!r && err != ERROR_IO_PENDING && err != ERROR_MORE_DATA) goto done;
            n = 0;
            if (!r && err == ERROR_IO_PENDING) { if (!Wait(&ov, 2000, &n)) { if (GetLastError() != ERROR_MORE_DATA) goto done; } }
            else GetOverlappedResult(h_, &ov, &n, TRUE);
            resp.append(buf, n);
            if (r || err != ERROR_MORE_DATA) {
                if (!r && err == ERROR_IO_PENDING) { /* completed by Wait */ }
                ok = true; break;
            }
        }
    done:
        CloseHandle(ev);
        return ok;
    }
    std::wstring name_;
    HANDLE h_ = INVALID_HANDLE_VALUE;
    bool down_ = false;
    DWORD downUntil_ = 0;
    DWORD lastErr_ = 0;
};

// ---------------------------------------------------------------------------------------------------------------- display attribute (the underline)
class DisplayAttrInfo : public ITfDisplayAttributeInfo {
public:
    DisplayAttrInfo() { InterlockedIncrement(&g_objects); }
    virtual ~DisplayAttrInfo() { InterlockedDecrement(&g_objects); }
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        if (r == IID_IUnknown || r == IID_ITfDisplayAttributeInfo) { *p = static_cast<ITfDisplayAttributeInfo*>(this); AddRef(); return S_OK; }
        *p = nullptr; return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }
    STDMETHODIMP GetGUID(GUID* g) override { *g = GUID_DisplayAttrInput; return S_OK; }
    STDMETHODIMP GetDescription(BSTR* b) override { *b = SysAllocString(L"Sulekhak input"); return *b ? S_OK : E_OUTOFMEMORY; }
    STDMETHODIMP GetAttributeInfo(TF_DISPLAYATTRIBUTE* a) override {
        a->crText.type = TF_CT_NONE; a->crText.nIndex = 0;
        a->crBk.type = TF_CT_NONE; a->crBk.nIndex = 0;
        a->lsStyle = TF_LS_DOT; a->fBoldLine = FALSE;
        a->crLine.type = TF_CT_NONE; a->crLine.nIndex = 0;
        a->bAttr = TF_ATTR_INPUT;
        return S_OK;
    }
    STDMETHODIMP SetAttributeInfo(const TF_DISPLAYATTRIBUTE*) override { return E_NOTIMPL; }
    STDMETHODIMP Reset() override { return S_OK; }
private:
    LONG ref_ = 1;
};

class EnumDisplayAttr : public IEnumTfDisplayAttributeInfo {
public:
    EnumDisplayAttr() { InterlockedIncrement(&g_objects); }
    virtual ~EnumDisplayAttr() { InterlockedDecrement(&g_objects); }
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        if (r == IID_IUnknown || r == IID_IEnumTfDisplayAttributeInfo) { *p = static_cast<IEnumTfDisplayAttributeInfo*>(this); AddRef(); return S_OK; }
        *p = nullptr; return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }
    STDMETHODIMP Clone(IEnumTfDisplayAttributeInfo** pp) override { EnumDisplayAttr* e = new EnumDisplayAttr(); e->i_ = i_; *pp = e; return S_OK; }
    STDMETHODIMP Next(ULONG count, ITfDisplayAttributeInfo** pp, ULONG* fetched) override {
        ULONG n = 0;
        if (count > 0 && i_ == 0) { pp[0] = new DisplayAttrInfo(); n = 1; i_ = 1; }
        if (fetched) *fetched = n;
        return n == count ? S_OK : S_FALSE;
    }
    STDMETHODIMP Reset() override { i_ = 0; return S_OK; }
    STDMETHODIMP Skip(ULONG c) override { i_ = (i_ + c) > 1 ? 1 : i_ + c; return S_OK; }
private:
    LONG ref_ = 1;
    ULONG i_ = 0;
};

// ---------------------------------------------------------------------------------------------------------------- the text service
class TextService;

class EditSession : public ITfEditSession {
public:
    explicit EditSession(std::function<HRESULT(TfEditCookie)> f) : fn_(f) {}
    virtual ~EditSession() {}
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        if (r == IID_IUnknown || r == IID_ITfEditSession) { *p = static_cast<ITfEditSession*>(this); AddRef(); return S_OK; }
        *p = nullptr; return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }
    STDMETHODIMP DoEditSession(TfEditCookie ec) override { return fn_(ec); }
private:
    LONG ref_ = 1;
    std::function<HRESULT(TfEditCookie)> fn_;
};

// The document the typing logic writes to: valid only inside an edit session.
class TsfDoc : public sk::Doc {
public:
    TextService* svc = nullptr;
    ITfContext* ctx = nullptr;
    TfEditCookie ec = 0;
    sk::ustr Before(int n) override;
    void Compose(const sk::ustr& s) override;
    void Commit(const sk::ustr& s) override;
    void EndEmpty() override;
    void ReplaceBefore(int drop, const sk::ustr& s) override;
    void CaretRect(RECT* rc);
private:
    ITfRange* SelectionRange();
    void Caret(ITfRange* r);
    void Mark(ITfRange* r, bool on);
};

static int ScriptOf(REFGUID prof, int* opt, bool* all) {
    *opt = 0; *all = false;
    if (prof == GUID_ProfileOdia) return 0;
    if (prof == GUID_ProfileHindi) return 1;
    if (prof == GUID_ProfileMarathi) { *opt = 1; return 1; }
    if (prof == GUID_ProfileBangla) return 2;
    if (prof == GUID_ProfileAssamese) return 5;
    *all = true;
    return 0;
}


// The candidate list as a TSF UI element. A program that wants to draw the list itself (the Start / Search box, store apps) says so when the element
// begins (it answers "do not show"), and then reads the words from here; any other program leaves the drawing to Sulekhak's own list.
static const GUID kIidCand = { 0xea1ea138, 0x19df, 0x11d7, { 0xa6, 0xd2, 0x00, 0x06, 0x5b, 0x84, 0x43, 0x5c } };      // IID_ITfCandidateListUIElement
static const UINT kCandPage = 9;            // the page size of keytable.inc (9 words, chosen with the digits 1..9)
class CandUI : public ITfCandidateListUIElement {
public:
    std::vector<std::wstring> items;
    UINT sel = 0;
    BOOL shown = TRUE;
    ITfDocumentMgr* dm = nullptr;
    void Set(const std::vector<sk::ustr>& list, int s, ITfThreadMgr* tm) {
        items.clear();
        for (const auto& c : list) items.push_back(std::wstring((const wchar_t*)c.data(), c.size()));
        sel = s < 0 ? 0 : (UINT)s;
        if (dm) { dm->Release(); dm = nullptr; }
        if (tm) tm->GetFocus(&dm);
    }
    virtual ~CandUI() { if (dm) dm->Release(); }
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        *p = nullptr;
        if (r == IID_IUnknown || r == IID_ITfUIElement || r == kIidCand) *p = static_cast<ITfCandidateListUIElement*>(this);
        if (!*p) return E_NOINTERFACE;
        AddRef(); return S_OK;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }
    // ITfUIElement
    STDMETHODIMP GetDescription(BSTR* p) override { if (!p) return E_INVALIDARG; *p = SysAllocString(L"Sulekhak candidate list"); return *p ? S_OK : E_OUTOFMEMORY; }
    STDMETHODIMP GetGUID(GUID* g) override { if (!g) return E_INVALIDARG; *g = kGuid(); return S_OK; }
    STDMETHODIMP Show(BOOL b) override { shown = b; return S_OK; }
    STDMETHODIMP IsShown(BOOL* b) override { if (!b) return E_INVALIDARG; *b = shown; return S_OK; }
    // ITfCandidateListUIElement
    STDMETHODIMP GetUpdatedFlags(DWORD* f) override { if (!f) return E_INVALIDARG; *f = TF_CLUIE_DOCUMENTMGR | TF_CLUIE_COUNT | TF_CLUIE_SELECTION | TF_CLUIE_STRING | TF_CLUIE_PAGEINDEX | TF_CLUIE_CURRENTPAGE; return S_OK; }
    STDMETHODIMP GetDocumentMgr(ITfDocumentMgr** p) override { if (!p) return E_INVALIDARG; *p = dm; if (dm) dm->AddRef(); return S_OK; }
    STDMETHODIMP GetCount(UINT* n) override { if (!n) return E_INVALIDARG; *n = (UINT)items.size(); return S_OK; }
    STDMETHODIMP GetSelection(UINT* i) override { if (!i) return E_INVALIDARG; *i = sel; return S_OK; }
    STDMETHODIMP GetString(UINT i, BSTR* p) override {
        if (!p) return E_INVALIDARG;
        if (i >= items.size()) { *p = nullptr; return E_INVALIDARG; }
        *p = SysAllocStringLen(items[i].data(), (UINT)items[i].size());
        return *p ? S_OK : E_OUTOFMEMORY;
    }
    STDMETHODIMP GetPageIndex(UINT* idx, UINT size, UINT* pages) override {
        UINT n = (UINT)items.size(), ps = kCandPage, pc = n ? (n + ps - 1) / ps : 1;
        if (pages) *pages = pc;
        if (idx) for (UINT i = 0; i < pc && i < size; i++) idx[i] = i * ps;
        return S_OK;
    }
    STDMETHODIMP SetPageIndex(UINT*, UINT) override { return S_OK; }
    STDMETHODIMP GetCurrentPage(UINT* p) override { if (!p) return E_INVALIDARG; *p = sel / kCandPage; return S_OK; }
private:
    static GUID kGuid() { static const GUID g = { 0x5b6d6c41, 0x2d0e, 0x4d8b, { 0x9a, 0x71, 0x0c, 0x3e, 0x8a, 0x52, 0x4f, 0x19 } }; return g; }
    LONG ref_ = 1;
};

class TextService : public ITfTextInputProcessorEx, public ITfThreadMgrEventSink, public ITfKeyEventSink,
                    public ITfCompositionSink, public ITfActiveLanguageProfileNotifySink, public ITfDisplayAttributeProvider {
public:
    TextService() : core_(&doc_, &eng_) {
        InterlockedIncrement(&g_objects);
        doc_.svc = this;
        eng_.rectFn = [this](RECT* rc) { doc_.CaretRect(rc); };
        cand_ = new CandUI();
        eng_.uiShow = [this](const std::vector<sk::ustr>& l, int sel) { return UiShow(l, sel); };
        eng_.uiEnd = [this]() { return UiEnd(); };
    }
    virtual ~TextService() { if (cand_) cand_->Release(); InterlockedDecrement(&g_objects); }

    // IUnknown
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        *p = nullptr;
        if (r == IID_IUnknown || r == IID_ITfTextInputProcessor) *p = static_cast<ITfTextInputProcessorEx*>(this);
        else if (r == SK_IID_ITfTextInputProcessorEx) *p = static_cast<ITfTextInputProcessorEx*>(this);
        else if (r == IID_ITfThreadMgrEventSink) *p = static_cast<ITfThreadMgrEventSink*>(this);
        else if (r == IID_ITfKeyEventSink) *p = static_cast<ITfKeyEventSink*>(this);
        else if (r == IID_ITfCompositionSink) *p = static_cast<ITfCompositionSink*>(this);
        else if (r == IID_ITfActiveLanguageProfileNotifySink) *p = static_cast<ITfActiveLanguageProfileNotifySink*>(this);
        else if (r == SK_IID_ITfDisplayAttributeProvider) *p = static_cast<ITfDisplayAttributeProvider*>(this);
        if (!*p) return E_NOINTERFACE;
        AddRef();
        return S_OK;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }

    // ITfTextInputProcessor(Ex)
    STDMETHODIMP Activate(ITfThreadMgr* ptim, TfClientId tid) override { return ActivateEx(ptim, tid, 0); }
    STDMETHODIMP ActivateEx(ITfThreadMgr* ptim, TfClientId tid, DWORD) override {
        SkLog("Activate");
        tm_ = ptim; tm_->AddRef(); cid_ = tid;
        { ITfThreadMgrEx* tex = nullptr; if (SUCCEEDED(tm_->QueryInterface(IID_ITfThreadMgrEx, (void**)&tex)) && tex) { DWORD fl = 0; tex->GetActiveFlags(&fl); SkLog("thread active flags %08lx", (unsigned long)fl); tex->Release(); } }
        HRESULT hr = S_OK;
        ITfSource* src = nullptr;
        if (SUCCEEDED(tm_->QueryInterface(IID_ITfSource, (void**)&src))) {
            src->AdviseSink(IID_ITfThreadMgrEventSink, static_cast<ITfThreadMgrEventSink*>(this), &cookieTm_);
            src->Release();
        }
        ITfKeystrokeMgr* km = nullptr;
        if (SUCCEEDED(tm_->QueryInterface(IID_ITfKeystrokeMgr, (void**)&km))) {
            hr = km->AdviseKeyEventSink(cid_, static_cast<ITfKeyEventSink*>(this), TRUE);
            km->Release();
        }
        ITfCategoryMgr* cm = nullptr;
        if (SUCCEEDED(CoCreateInstance(CLSID_TF_CategoryMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfCategoryMgr, (void**)&cm))) {
            cm->RegisterGUID(GUID_DisplayAttrInput, &atom_);
            cm->Release();
        }
        ITfInputProcessorProfileMgr* pm = nullptr;
        if (SUCCEEDED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfileMgr, (void**)&pm))) {
            TF_INPUTPROCESSORPROFILE prof;
            if (SUCCEEDED(pm->GetActiveProfile(GUID_TFCAT_TIP_KEYBOARD, &prof)) && prof.clsid == CLSID_SulekhakTip) SetProfile(prof.guidProfile);
            pm->Release();
        }
        ITfSource* src2 = nullptr;
        if (SUCCEEDED(tm_->QueryInterface(IID_ITfSource, (void**)&src2))) {
            // the profile in use changes when the user picks another keyboard in the list
            src2->AdviseSink(IID_ITfActiveLanguageProfileNotifySink, static_cast<ITfActiveLanguageProfileNotifySink*>(this), &cookieLp_);
            src2->Release();
        }
        return hr;
    }
    STDMETHODIMP Deactivate() override {
        SkLog("Deactivate");
        FlushComposition();
        if (tm_) {
            ITfSource* src = nullptr;
            if (SUCCEEDED(tm_->QueryInterface(IID_ITfSource, (void**)&src))) {
                if (cookieTm_ != TF_INVALID_COOKIE) src->UnadviseSink(cookieTm_);
                if (cookieLp_ != TF_INVALID_COOKIE) src->UnadviseSink(cookieLp_);
                src->Release();
            }
            cookieTm_ = cookieLp_ = TF_INVALID_COOKIE;
            ITfKeystrokeMgr* km = nullptr;
            if (SUCCEEDED(tm_->QueryInterface(IID_ITfKeystrokeMgr, (void**)&km))) { km->UnadviseKeyEventSink(cid_); km->Release(); }
            UiEnd();
            tm_->Release(); tm_ = nullptr;
        }
        eng_.HideList();
        return S_OK;
    }

    // ITfThreadMgrEventSink
    STDMETHODIMP OnInitDocumentMgr(ITfDocumentMgr*) override { return S_OK; }
    STDMETHODIMP OnUninitDocumentMgr(ITfDocumentMgr*) override { return S_OK; }
    STDMETHODIMP OnSetFocus(ITfDocumentMgr* now, ITfDocumentMgr* prev) override {
        if (core_.Composing() && prev != now) {
            // the word being typed is kept as it stands, in the document that lost the focus
            ITfContext* c = nullptr;
            if (prev && SUCCEEDED(prev->GetTop(&c)) && c) { RunOn(c, [this](TfEditCookie) { core_.Reset(); return S_OK; }); c->Release(); }
            core_.Lost();
            eng_.HideList();
        }
        return S_OK;
    }
    STDMETHODIMP OnPushContext(ITfContext*) override { return S_OK; }
    STDMETHODIMP OnPopContext(ITfContext*) override { return S_OK; }

    // ITfActiveLanguageProfileNotifySink
    STDMETHODIMP OnActivated(REFCLSID clsid, REFGUID prof, BOOL activated) override {
        if (clsid == CLSID_SulekhakTip && activated) SetProfile(prof);
        return S_OK;
    }

    // ITfCompositionSink
    STDMETHODIMP OnCompositionTerminated(TfEditCookie, ITfComposition*) override {
        // the program ended the word (a click elsewhere, for example): its text stays as typed
        if (comp_) { comp_->Release(); comp_ = nullptr; }
        if (compCtx_) { compCtx_->Release(); compCtx_ = nullptr; }
        core_.Lost();
        return S_OK;
    }

    // ITfKeyEventSink
    STDMETHODIMP OnSetFocus(BOOL fore) override { if (!fore) FlushComposition(); else RefreshScript(); return S_OK; }
    STDMETHODIMP OnTestKeyDown(ITfContext* pic, WPARAM wp, LPARAM lp, BOOL* eaten) override { *eaten = Handle(pic, wp, lp, true); if (wp != VK_SHIFT && wp != VK_CONTROL && wp != VK_MENU) SkLog("test key vk=%x ctx=%d script=%d -> %d", (unsigned)wp, pic ? 1 : 0, core_.Script(), (int)*eaten); return S_OK; }
    STDMETHODIMP OnKeyDown(ITfContext* pic, WPARAM wp, LPARAM lp, BOOL* eaten) override { *eaten = Handle(pic, wp, lp, false); return S_OK; }
    STDMETHODIMP OnTestKeyUp(ITfContext*, WPARAM, LPARAM, BOOL* eaten) override { *eaten = FALSE; return S_OK; }
    STDMETHODIMP OnKeyUp(ITfContext*, WPARAM, LPARAM, BOOL* eaten) override { *eaten = FALSE; return S_OK; }
    STDMETHODIMP OnPreservedKey(ITfContext*, REFGUID, BOOL* eaten) override { *eaten = FALSE; return S_OK; }

    // ITfDisplayAttributeProvider
    STDMETHODIMP EnumDisplayAttributeInfo(IEnumTfDisplayAttributeInfo** pp) override { *pp = new EnumDisplayAttr(); return S_OK; }
    STDMETHODIMP GetDisplayAttributeInfo(REFGUID g, ITfDisplayAttributeInfo** pp) override {
        if (g != GUID_DisplayAttrInput) { *pp = nullptr; return E_INVALIDARG; }
        *pp = new DisplayAttrInfo();
        return S_OK;
    }

    ITfComposition* comp_ = nullptr;
    ITfContext* compCtx_ = nullptr;
    TfGuidAtom atom_ = 0;
    TfClientId cid_ = 0;

private:
    friend class TsfDoc;
    // UI-less candidate list: tell Windows about the list; when the program draws it (Start / Search box ...) Sulekhak draws nothing itself.
    bool UiShow(const std::vector<sk::ustr>& list, int sel) {
        if (!tm_ || !cand_) return false;
        ITfUIElementMgr* mgr = nullptr;
        if (FAILED(tm_->QueryInterface(IID_ITfUIElementMgr, (void**)&mgr)) || !mgr) return false;
        cand_->Set(list, sel, tm_);
        if (!uiOpen_) {
            BOOL show = TRUE; DWORD id = 0;
            HRESULT hb = mgr->BeginUIElement(cand_, &show, &id);
            if (SUCCEEDED(hb)) { uiOpen_ = true; uiId_ = id; hostDraws_ = !show; cand_->shown = show; }
            SkLog("candidate list: BeginUIElement hr=%08lx id=%lu show=%d -> %s", (unsigned long)hb, (unsigned long)id, (int)show, (SUCCEEDED(hb) && !show) ? "the program draws it" : "Sulekhak draws it");
        } else {
            HRESULT hu = mgr->UpdateUIElement(uiId_);
            SkLog("candidate list: UpdateUIElement id=%lu hr=%08lx words=%u", (unsigned long)uiId_, (unsigned long)hu, (unsigned)list.size());
        }
        mgr->Release();
        return uiOpen_ && hostDraws_;
    }
    bool UiEnd() {
        bool had = uiOpen_ && hostDraws_;
        if (uiOpen_ && tm_) {
            ITfUIElementMgr* mgr = nullptr;
            if (SUCCEEDED(tm_->QueryInterface(IID_ITfUIElementMgr, (void**)&mgr)) && mgr) { HRESULT he = mgr->EndUIElement(uiId_); SkLog("candidate list: EndUIElement id=%lu hr=%08lx", (unsigned long)uiId_, (unsigned long)he); mgr->Release(); }
        }
        uiOpen_ = false; hostDraws_ = false;
        return had;
    }
    CandUI* cand_ = nullptr;
    bool uiOpen_ = false, hostDraws_ = false;
    DWORD uiId_ = 0;
    HRESULT RunOn(ITfContext* c, std::function<HRESULT(TfEditCookie)> fn, DWORD flags = TF_ES_SYNC | TF_ES_READWRITE) {
        EditSession* s = new EditSession([this, c, fn](TfEditCookie ec) { doc_.ctx = c; doc_.ec = ec; HRESULT hr = fn(ec); doc_.ctx = nullptr; return hr; });
        HRESULT hrSession = E_FAIL;
        HRESULT hr = c->RequestEditSession(cid_, s, flags, &hrSession);
        s->Release();
        return SUCCEEDED(hr) ? hrSession : hr;
    }
    void FlushComposition() {
        if (core_.Composing() && compCtx_) {
            ITfContext* c = compCtx_; c->AddRef();
            RunOn(c, [this](TfEditCookie) { core_.Reset(); return S_OK; });
            c->Release();
        }
        if (core_.Composing()) core_.Lost();
        eng_.HideList();
    }
    void SetProfile(REFGUID prof) {
        int o; bool all;
        int s = ScriptOf(prof, &o, &all);
        all_ = all;
        if (!all) { core_.SetScript(s); eng_.opt = o; }
        else RefreshScript();
    }
    void RefreshScript() {
        if (!all_) return;
        int s, o;
        if (eng_.FetchScript(&s, &o)) { core_.SetScript(s); eng_.opt = o; }
    }
    sk::Key MakeKey(WPARAM wp, LPARAM lp) {
        if (core_.Script() == 6) core_.SetEnglishOptions(RegFlag(L"EnCap", true), RegFlag(L"EnSmart", true));      // English: capital letters and curly punctuation (tray menu switches)
        sk::Key k{(uint32_t)wp, 0, false, false, false, false};
        k.shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
        k.ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
        k.alt = (GetKeyState(VK_MENU) & 0x8000) != 0;
        k.win = (GetKeyState(VK_LWIN) & 0x8000) != 0 || (GetKeyState(VK_RWIN) & 0x8000) != 0;
        if (!k.ctrl && !k.alt && !k.win) {
            BYTE st[256] = {};
            if (k.shift) st[VK_SHIFT] = 0x80;
            if (GetKeyState(VK_CAPITAL) & 1) st[VK_CAPITAL] = 1;
            WCHAR w[8] = {};
            UINT scan = (lp >> 16) & 0xFF;
            int n = ToUnicodeEx((UINT)wp, scan, st, w, 8, 0x4, GetKeyboardLayout(0));
            if (n == 1) k.ch = w[0];
            // A language's own layout (the Windows Odia InScript, for example) gives Odia letters for the keys; Sulekhak types from the Latin letters,
            // so such a layout is read again as the US keyboard (loaded without activating it).
            if (n != 1 || k.ch >= 0x80) {
                static HKL us = LoadKeyboardLayoutW(L"00000409", KLF_NOTELLSHELL);
                WCHAR w2[8] = {};
                if (us && ToUnicodeEx((UINT)wp, scan, st, w2, 8, 0x4, us) == 1 && w2[0] < 0x80) k.ch = w2[0];
            }
        }
        return k;
    }
    bool Handle(ITfContext* pic, WPARAM wp, LPARAM lp, bool test) {
        sk::Key k = MakeKey(wp, lp);
        if (k.vk == VK_SHIFT || k.vk == VK_CONTROL || k.vk == VK_MENU || k.vk == VK_CAPITAL || k.vk == VK_LWIN || k.vk == VK_RWIN || k.vk == VK_NUMLOCK) return false;
        // Ctrl+Alt+1, 2, 3, 6 choose the script of the "All Languages" keyboard (as in the Sulekhak program); Ctrl+Alt+8 is English
        if (k.ctrl && k.alt && !k.shift && all_) {
            int s = k.vk == '1' ? 0 : k.vk == '2' ? 1 : k.vk == '3' ? 2 : k.vk == '6' ? 5 : k.vk == '8' ? 6 : -1;
            if (s >= 0) { if (!test) { FlushComposition(); eng_.SetScript(s, 0); core_.SetScript(s); eng_.opt = 0; } return true; }
        }
        if (test) {
            // Backspace with no word being typed: we take the key only when we really delete the character (one code point of an Indic letter).
            // Saying "eaten" here and handing the key back later makes many programs (the Start / Search box among them) lose the key altogether,
            // so the answer is found out now, and when it cannot be found out the program's own Backspace runs.
            if (k.vk == VK_BACK && !k.ctrl && !k.alt && !k.win && core_.Script() != 6 && !core_.Composing()) {
                bool mine = false;
                if (pic) { HRESULT hq = RunOn(pic, [&](TfEditCookie) { mine = core_.OwnsIdleBackspace(); return S_OK; }, TF_ES_SYNC | TF_ES_READ); if (FAILED(hq)) mine = false; }
                SkLog("test bksp mine=%d", (int)mine);
                return mine;
            }
            return core_.WouldEat(k);
        }
        if (!pic) return false;
        bool eaten = false;
        if (compCtx_ && compCtx_ != pic && core_.Composing()) FlushComposition();
        HRESULT hr = RunOn(pic, [&](TfEditCookie) { eaten = core_.OnKey(k); return S_OK; });
        SkLog("key vk=%x ch=%x eaten=%d hr=%x", (unsigned)wp, (unsigned)k.ch, (int)eaten, (unsigned)hr);
        return SUCCEEDED(hr) && eaten;
    }

    LONG ref_ = 1;
    ITfThreadMgr* tm_ = nullptr;
    DWORD cookieTm_ = TF_INVALID_COOKIE, cookieLp_ = TF_INVALID_COOKIE;
    bool all_ = true;
    TsfDoc doc_;
    PipeEngine eng_;
    sk::Core core_;
};

// ---------------------------------------------------------------------------------------------------------------- TsfDoc
ITfRange* TsfDoc::SelectionRange() {
    TF_SELECTION sel; ULONG fetched = 0;
    HRESULT hg = ctx->GetSelection(ec, TF_DEFAULT_SELECTION, 1, &sel, &fetched);
    if (FAILED(hg) || fetched != 1) { SkLog("GetSelection hr=%08lx fetched=%lu", (unsigned long)hg, (unsigned long)fetched); return nullptr; }
    return sel.range;                                                         // owned by the caller
}
void TsfDoc::Caret(ITfRange* r) {
    ITfRange* e = nullptr;
    if (FAILED(r->Clone(&e)) || !e) return;
    e->Collapse(ec, TF_ANCHOR_END);
    TF_SELECTION ts; ts.range = e; ts.style.ase = TF_AE_NONE; ts.style.fInterimChar = FALSE;
    ctx->SetSelection(ec, 1, &ts);
    e->Release();
}
void TsfDoc::Mark(ITfRange* r, bool on) {
    ITfProperty* prop = nullptr;
    if (FAILED(ctx->GetProperty(GUID_PROP_ATTRIBUTE, &prop)) || !prop) return;
    if (on) { VARIANT v; VariantInit(&v); v.vt = VT_I4; v.lVal = (LONG)svc->atom_; prop->SetValue(ec, r, &v); }
    else prop->Clear(ec, r);
    prop->Release();
}
sk::ustr TsfDoc::Before(int n) {
    ITfRange* s = SelectionRange();
    if (!s) return sk::ustr();
    ITfRange* r = nullptr;
    HRESULT hc = s->Clone(&r); s->Release();
    if (!r) { SkLog("Before: Clone hr=%08lx", (unsigned long)hc); return sk::ustr(); }
    HRESULT h1 = r->Collapse(ec, TF_ANCHOR_START);
    LONG shifted = 0;
    HRESULT h2 = r->ShiftStart(ec, -n, &shifted, nullptr);
    WCHAR buf[64] = {}; ULONG cch = 0;
    HRESULT h3 = r->GetText(ec, 0, buf, n < 63 ? n : 63, &cch);
    SkLog("Before(%d): collapse=%08lx shift=%08lx moved=%ld gettext=%08lx cch=%lu", n, (unsigned long)h1, (unsigned long)h2, (long)shifted, (unsigned long)h3, (unsigned long)cch);
    r->Release();
    return sk::ustr((const char16_t*)buf, cch);
}
void TsfDoc::Compose(const sk::ustr& s) {
    if (!svc->comp_) {
        ITfContextComposition* cc = nullptr;
        ITfInsertAtSelection* ias = nullptr;
        ITfRange* sel = nullptr;
        HRESULT hq = ctx->QueryInterface(IID_ITfContextComposition, (void**)&cc);
        if (SUCCEEDED(hq)) hq = ctx->QueryInterface(IID_ITfInsertAtSelection, (void**)&ias);
        if (SUCCEEDED(hq)) hq = ias->InsertTextAtSelection(ec, TF_IAS_QUERYONLY, nullptr, 0, &sel);   // where the word starts (a selection is replaced)
        if (ias) ias->Release();
        if (FAILED(hq) || !sel) { SkLog("Compose: cannot start (hr=%08lx)", (unsigned long)hq); if (sel) sel->Release(); if (cc) cc->Release(); return; }
        ITfComposition* comp = nullptr;
        HRESULT hs = cc->StartComposition(ec, sel, static_cast<ITfCompositionSink*>(svc), &comp);
        SkLog("StartComposition hr=%08lx comp=%p", (unsigned long)hs, (void*)comp);
        sel->Release(); cc->Release();
        if (!comp) return;
        svc->comp_ = comp;
        svc->compCtx_ = ctx; ctx->AddRef();
    }
    ITfRange* r = nullptr;
    if (FAILED(svc->comp_->GetRange(&r)) || !r) return;
    HRESULT hst = r->SetText(ec, 0, (const WCHAR*)s.data(), (LONG)s.size());
    SkLog("Compose SetText hr=%08lx len=%d", (unsigned long)hst, (int)s.size());
    Mark(r, true);
    Caret(r);
    r->Release();
}
void TsfDoc::Commit(const sk::ustr& s) {
    if (!svc->comp_) {
        ITfInsertAtSelection* ins = nullptr;
        if (SUCCEEDED(ctx->QueryInterface(IID_ITfInsertAtSelection, (void**)&ins))) {
            ITfRange* r = nullptr;
            ins->InsertTextAtSelection(ec, 0, (const WCHAR*)s.data(), (LONG)s.size(), &r);
            if (r) { Caret(r); r->Release(); }
            ins->Release();
        }
        return;
    }
    ITfRange* r = nullptr;
    if (SUCCEEDED(svc->comp_->GetRange(&r)) && r) {
        r->SetText(ec, 0, (const WCHAR*)s.data(), (LONG)s.size());
        Mark(r, false);
        Caret(r);
        r->Release();
    }
    svc->comp_->EndComposition(ec);
    svc->comp_->Release(); svc->comp_ = nullptr;
    if (svc->compCtx_) { svc->compCtx_->Release(); svc->compCtx_ = nullptr; }
}
void TsfDoc::EndEmpty() {
    if (!svc->comp_) return;
    ITfRange* r = nullptr;
    if (SUCCEEDED(svc->comp_->GetRange(&r)) && r) { r->SetText(ec, 0, L"", 0); Mark(r, false); r->Release(); }
    svc->comp_->EndComposition(ec);
    svc->comp_->Release(); svc->comp_ = nullptr;
    if (svc->compCtx_) { svc->compCtx_->Release(); svc->compCtx_ = nullptr; }
}
void TsfDoc::ReplaceBefore(int drop, const sk::ustr& s) {
    ITfRange* sel = SelectionRange();
    if (!sel) return;
    ITfRange* r = nullptr;
    sel->Clone(&r); sel->Release();
    if (!r) return;
    r->Collapse(ec, TF_ANCHOR_START);
    if (drop > 0) { LONG sh = 0; r->ShiftStart(ec, -drop, &sh, nullptr); }
    r->SetText(ec, 0, (const WCHAR*)s.data(), (LONG)s.size());
    Caret(r);
    r->Release();
}
void TsfDoc::CaretRect(RECT* rc) {
    ITfContextView* view = nullptr;
    if (FAILED(ctx->GetActiveView(&view)) || !view) return;
    ITfRange* r = nullptr;
    if (svc->comp_) svc->comp_->GetRange(&r); else r = SelectionRange();
    if (r) {
        BOOL clipped = FALSE;
        RECT t = {};
        if (SUCCEEDED(view->GetTextExt(ec, r, &t, &clipped))) *rc = t;
        r->Release();
    }
    view->Release();
}

// ---------------------------------------------------------------------------------------------------------------- COM plumbing
class ClassFactory : public IClassFactory {
public:
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        if (r == IID_IUnknown || r == IID_IClassFactory) { *p = static_cast<IClassFactory*>(this); AddRef(); return S_OK; }
        *p = nullptr; return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return 2; }
    STDMETHODIMP_(ULONG) Release() override { return 1; }
    STDMETHODIMP CreateInstance(IUnknown* outer, REFIID r, void** p) override {
        *p = nullptr;
        if (outer) return CLASS_E_NOAGGREGATION;
        TextService* t = new TextService();
        HRESULT hr = t->QueryInterface(r, p);
        t->Release();
        return hr;
    }
    STDMETHODIMP LockServer(BOOL l) override { if (l) InterlockedIncrement(&g_locks); else InterlockedDecrement(&g_locks); return S_OK; }
};
static ClassFactory g_factory;

STDAPI DllGetClassObject(REFCLSID clsid, REFIID riid, void** ppv) {
    if (clsid != CLSID_SulekhakTip) { *ppv = nullptr; return CLASS_E_CLASSNOTAVAILABLE; }
    return g_factory.QueryInterface(riid, ppv);
}
STDAPI DllCanUnloadNow() { return (g_objects == 0 && g_locks == 0) ? S_OK : S_FALSE; }

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) { g_hInst = h; DisableThreadLibraryCalls(h); InitializeCriticalSection(&g_localCs); g_localInit = true; }
    return TRUE;
}
