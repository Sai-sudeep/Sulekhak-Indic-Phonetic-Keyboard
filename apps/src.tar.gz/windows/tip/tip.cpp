// The Sulekhak text service (a TSF "text input processor"): what makes Sulekhak a real input method in Windows, listed by Win+Space
// next to the other keyboards, in every program that uses the normal text services. The typing rules are in tipcore.cpp; the words come
// from the Sulekhak program (engine host) through a named pipe.
#include <windows.h>
#include <msctf.h>
#include <sddl.h>
#include <functional>
#include <string>
#include <vector>
#include "guids.h"
#include "tsfextra.h"
#include "tipcore.h"
#include "tip.h"

HINSTANCE g_hInst = nullptr;
static LONG g_objects = 0, g_locks = 0;

void SkLog(const char* fmt, ...) {
    wchar_t flag[8];
    if (!GetEnvironmentVariableW(L"SULEKHAK_TIP_LOG", flag, 8)) return;
    wchar_t tmp[MAX_PATH]; if (!GetTempPathW(MAX_PATH, tmp)) return;
    std::wstring p = std::wstring(tmp) + L"sulekhak_tip.log";
    HANDLE f = CreateFileW(p.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, 0, nullptr);
    if (f == INVALID_HANDLE_VALUE) return;
    char line[512]; va_list ap; va_start(ap, fmt); int n = vsnprintf(line, 500, fmt, ap); va_end(ap);
    if (n < 0) n = 0;
    if (n > 500) n = 500;
    line[n++] = '\r'; line[n++] = '\n';
    DWORD w; WriteFile(f, line, n, &w, nullptr); CloseHandle(f);
}

// ---------------------------------------------------------------------------------------------------------------- strings
static std::string ToUtf8(const sk::ustr& s) {
    if (s.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, (const wchar_t*)s.data(), (int)s.size(), nullptr, 0, nullptr, nullptr);
    std::string o(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, (const wchar_t*)s.data(), (int)s.size(), &o[0], n, nullptr, nullptr);
    return o;
}
static sk::ustr FromUtf8(const char* p, int len) {
    if (len <= 0) return sk::ustr();
    int n = MultiByteToWideChar(CP_UTF8, 0, p, len, nullptr, 0);
    sk::ustr o(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, p, len, (wchar_t*)&o[0], n);
    return o;
}

// ---------------------------------------------------------------------------------------------------------------- the pipe to the engine
// One request, one answer, in message mode:  Q script opt prev buf -> C word word ...   L script roman word -> K   P x y h sel roman words... -> K
// H -> K   G -> T script opt   W script opt -> K        (fields are separated by a tab)
class PipeEngine : public sk::Engine {
public:
    PipeEngine() { name_ = PipeName(); }
    ~PipeEngine() { Close(); }
    int scriptOverride = -1, opt = 0;
    static std::wstring PipeName() {
        std::wstring sid = L"user";
        HANDLE tok = nullptr;
        if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) {
            DWORD n = 0; GetTokenInformation(tok, TokenUser, nullptr, 0, &n);
            std::vector<BYTE> buf(n ? n : 1);
            if (n && GetTokenInformation(tok, TokenUser, buf.data(), n, &n)) {
                wchar_t* s = nullptr;
                if (ConvertSidToStringSidW(((TOKEN_USER*)buf.data())->User.Sid, &s)) { sid = s; LocalFree(s); }
            }
            CloseHandle(tok);
        }
        return L"\\\\.\\pipe\\SulekhakTip-" + sid;
    }
    bool Call(const std::string& req, std::string& resp) {
        DWORD now = GetTickCount();
        if (down_ && (LONG)(now - downUntil_) < 0) return false;
        for (int attempt = 0; attempt < 2; attempt++) {
            if (h_ == INVALID_HANDLE_VALUE && !Open()) { Down(); return false; }
            if (Transact(req, resp)) { down_ = false; return true; }
            Close();
        }
        Down();
        return false;
    }
    bool Query(int script, const sk::ustr& buf, const sk::ustr& prev, std::vector<sk::ustr>& out) override {
        std::string r;
        std::string q = "Q\t" + std::to_string(script) + "\t" + std::to_string(opt) + "\t" + ToUtf8(prev) + "\t" + ToUtf8(buf);
        if (!Call(q, r) || r.size() < 1 || r[0] != 'C') return false;
        out.clear();
        size_t p = 2;
        while (p <= r.size() && r.size() > 1) {
            size_t e = r.find('\t', p);
            if (e == std::string::npos) e = r.size();
            if (e > p) out.push_back(FromUtf8(r.data() + p, (int)(e - p)));
            p = e + 1;
        }
        return !out.empty();
    }
    void Learn(int script, const sk::ustr& roman, const sk::ustr& word) override {
        std::string r; Call("L\t" + std::to_string(script) + "\t" + ToUtf8(roman) + "\t" + ToUtf8(word), r);
    }
    void ShowList(const std::vector<sk::ustr>& list, int sel, const sk::ustr& roman) override {
        RECT rc = {0, 0, 0, 0};
        if (rectFn) rectFn(&rc);
        std::string q = "P\t" + std::to_string(rc.left) + "\t" + std::to_string(rc.bottom) + "\t" + std::to_string(rc.bottom - rc.top) + "\t" + std::to_string(sel) + "\t" + ToUtf8(roman);
        for (const auto& c : list) q += "\t" + ToUtf8(c);
        std::string r; Call(q, r);
    }
    void HideList() override { std::string r; Call("H", r); }
    // the script the "All Languages" keyboard types now, as the Sulekhak program has it
    bool FetchScript(int* script, int* o) {
        std::string r;
        if (!Call("G", r) || r.size() < 3 || r[0] != 'T') return false;
        *script = atoi(r.c_str() + 2);
        size_t t = r.find('\t', 2);
        *o = t == std::string::npos ? 0 : atoi(r.c_str() + t + 1);
        return true;
    }
    void SetScript(int script, int o) { std::string r; Call("W\t" + std::to_string(script) + "\t" + std::to_string(o), r); }
    std::function<void(RECT*)> rectFn;
private:
    bool Open() {
        for (int i = 0; i < 2; i++) {
            h_ = CreateFileW(name_.c_str(), GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, nullptr);
            if (h_ != INVALID_HANDLE_VALUE) break;
            if (GetLastError() != ERROR_PIPE_BUSY || !WaitNamedPipeW(name_.c_str(), 50)) return false;
        }
        if (h_ == INVALID_HANDLE_VALUE) return false;
        DWORD mode = PIPE_READMODE_MESSAGE;
        SetNamedPipeHandleState(h_, &mode, nullptr, nullptr);
        return true;
    }
    void Close() { if (h_ != INVALID_HANDLE_VALUE) { CloseHandle(h_); h_ = INVALID_HANDLE_VALUE; } }
    void Down() { down_ = true; downUntil_ = GetTickCount() + 2500; }
    bool Wait(OVERLAPPED* ov, DWORD ms, DWORD* n) {
        DWORD w = WaitForSingleObject(ov->hEvent, ms);
        if (w != WAIT_OBJECT_0) { CancelIoEx(h_, ov); GetOverlappedResult(h_, ov, n, TRUE); return false; }
        return GetOverlappedResult(h_, ov, n, FALSE) != 0;
    }
    bool Transact(const std::string& req, std::string& resp) {
        HANDLE ev = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (!ev) return false;
        bool ok = false;
        OVERLAPPED ov = {}; ov.hEvent = ev;
        DWORD n = 0;
        if (!WriteFile(h_, req.data(), (DWORD)req.size(), nullptr, &ov) && GetLastError() != ERROR_IO_PENDING) goto done;
        if (!Wait(&ov, 300, &n)) goto done;
        resp.clear();
        for (;;) {
            char buf[8192];
            ResetEvent(ev); ov = OVERLAPPED(); ov.hEvent = ev;
            BOOL r = ReadFile(h_, buf, sizeof buf, nullptr, &ov);
            DWORD err = r ? 0 : GetLastError();
            if (!r && err != ERROR_IO_PENDING && err != ERROR_MORE_DATA) goto done;
            n = 0;
            if (!r && err == ERROR_IO_PENDING) { if (!Wait(&ov, 400, &n)) { if (GetLastError() != ERROR_MORE_DATA) goto done; } }
            else GetOverlappedResult(h_, &ov, &n, TRUE);
            resp.append(buf, n);
            if (r || err != ERROR_MORE_DATA) {
                if (!r && err == ERROR_IO_PENDING) { /* completed by Wait */ }
                ok = true; break;
            }
        }
    done:
        CloseHandle(ev);
        return ok;
    }
    std::wstring name_;
    HANDLE h_ = INVALID_HANDLE_VALUE;
    bool down_ = false;
    DWORD downUntil_ = 0;
};

// ---------------------------------------------------------------------------------------------------------------- display attribute (the underline)
class DisplayAttrInfo : public ITfDisplayAttributeInfo {
public:
    DisplayAttrInfo() { InterlockedIncrement(&g_objects); }
    virtual ~DisplayAttrInfo() { InterlockedDecrement(&g_objects); }
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        if (r == IID_IUnknown || r == IID_ITfDisplayAttributeInfo) { *p = static_cast<ITfDisplayAttributeInfo*>(this); AddRef(); return S_OK; }
        *p = nullptr; return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }
    STDMETHODIMP GetGUID(GUID* g) override { *g = GUID_DisplayAttrInput; return S_OK; }
    STDMETHODIMP GetDescription(BSTR* b) override { *b = SysAllocString(L"Sulekhak input"); return *b ? S_OK : E_OUTOFMEMORY; }
    STDMETHODIMP GetAttributeInfo(TF_DISPLAYATTRIBUTE* a) override {
        a->crText.type = TF_CT_NONE; a->crText.nIndex = 0;
        a->crBk.type = TF_CT_NONE; a->crBk.nIndex = 0;
        a->lsStyle = TF_LS_DOT; a->fBoldLine = FALSE;
        a->crLine.type = TF_CT_NONE; a->crLine.nIndex = 0;
        a->bAttr = TF_ATTR_INPUT;
        return S_OK;
    }
    STDMETHODIMP SetAttributeInfo(const TF_DISPLAYATTRIBUTE*) override { return E_NOTIMPL; }
    STDMETHODIMP Reset() override { return S_OK; }
private:
    LONG ref_ = 1;
};

class EnumDisplayAttr : public IEnumTfDisplayAttributeInfo {
public:
    EnumDisplayAttr() { InterlockedIncrement(&g_objects); }
    virtual ~EnumDisplayAttr() { InterlockedDecrement(&g_objects); }
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        if (r == IID_IUnknown || r == IID_IEnumTfDisplayAttributeInfo) { *p = static_cast<IEnumTfDisplayAttributeInfo*>(this); AddRef(); return S_OK; }
        *p = nullptr; return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }
    STDMETHODIMP Clone(IEnumTfDisplayAttributeInfo** pp) override { EnumDisplayAttr* e = new EnumDisplayAttr(); e->i_ = i_; *pp = e; return S_OK; }
    STDMETHODIMP Next(ULONG count, ITfDisplayAttributeInfo** pp, ULONG* fetched) override {
        ULONG n = 0;
        if (count > 0 && i_ == 0) { pp[0] = new DisplayAttrInfo(); n = 1; i_ = 1; }
        if (fetched) *fetched = n;
        return n == count ? S_OK : S_FALSE;
    }
    STDMETHODIMP Reset() override { i_ = 0; return S_OK; }
    STDMETHODIMP Skip(ULONG c) override { i_ = (i_ + c) > 1 ? 1 : i_ + c; return S_OK; }
private:
    LONG ref_ = 1;
    ULONG i_ = 0;
};

// ---------------------------------------------------------------------------------------------------------------- the text service
class TextService;

class EditSession : public ITfEditSession {
public:
    explicit EditSession(std::function<HRESULT(TfEditCookie)> f) : fn_(f) {}
    virtual ~EditSession() {}
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        if (r == IID_IUnknown || r == IID_ITfEditSession) { *p = static_cast<ITfEditSession*>(this); AddRef(); return S_OK; }
        *p = nullptr; return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }
    STDMETHODIMP DoEditSession(TfEditCookie ec) override { return fn_(ec); }
private:
    LONG ref_ = 1;
    std::function<HRESULT(TfEditCookie)> fn_;
};

// The document the typing logic writes to: valid only inside an edit session.
class TsfDoc : public sk::Doc {
public:
    TextService* svc = nullptr;
    ITfContext* ctx = nullptr;
    TfEditCookie ec = 0;
    sk::ustr Before(int n) override;
    void Compose(const sk::ustr& s) override;
    void Commit(const sk::ustr& s) override;
    void EndEmpty() override;
    void ReplaceBefore(int drop, const sk::ustr& s) override;
    void CaretRect(RECT* rc);
private:
    ITfRange* SelectionRange();
    void Caret(ITfRange* r);
    void Mark(ITfRange* r, bool on);
};

static int ScriptOf(REFGUID prof, int* opt, bool* all) {
    *opt = 0; *all = false;
    if (prof == GUID_ProfileOdia) return 0;
    if (prof == GUID_ProfileHindi) return 1;
    if (prof == GUID_ProfileMarathi) { *opt = 1; return 1; }
    if (prof == GUID_ProfileBangla) return 2;
    if (prof == GUID_ProfileAssamese) return 5;
    *all = true;
    return 0;
}

class TextService : public ITfTextInputProcessorEx, public ITfThreadMgrEventSink, public ITfKeyEventSink,
                    public ITfCompositionSink, public ITfActiveLanguageProfileNotifySink, public ITfDisplayAttributeProvider {
public:
    TextService() : core_(&doc_, &eng_) {
        InterlockedIncrement(&g_objects);
        doc_.svc = this;
        eng_.rectFn = [this](RECT* rc) { doc_.CaretRect(rc); };
    }
    virtual ~TextService() { InterlockedDecrement(&g_objects); }

    // IUnknown
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        *p = nullptr;
        if (r == IID_IUnknown || r == IID_ITfTextInputProcessor) *p = static_cast<ITfTextInputProcessorEx*>(this);
        else if (r == SK_IID_ITfTextInputProcessorEx) *p = static_cast<ITfTextInputProcessorEx*>(this);
        else if (r == IID_ITfThreadMgrEventSink) *p = static_cast<ITfThreadMgrEventSink*>(this);
        else if (r == IID_ITfKeyEventSink) *p = static_cast<ITfKeyEventSink*>(this);
        else if (r == IID_ITfCompositionSink) *p = static_cast<ITfCompositionSink*>(this);
        else if (r == IID_ITfActiveLanguageProfileNotifySink) *p = static_cast<ITfActiveLanguageProfileNotifySink*>(this);
        else if (r == SK_IID_ITfDisplayAttributeProvider) *p = static_cast<ITfDisplayAttributeProvider*>(this);
        if (!*p) return E_NOINTERFACE;
        AddRef();
        return S_OK;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return InterlockedIncrement(&ref_); }
    STDMETHODIMP_(ULONG) Release() override { ULONG n = InterlockedDecrement(&ref_); if (!n) delete this; return n; }

    // ITfTextInputProcessor(Ex)
    STDMETHODIMP Activate(ITfThreadMgr* ptim, TfClientId tid) override { return ActivateEx(ptim, tid, 0); }
    STDMETHODIMP ActivateEx(ITfThreadMgr* ptim, TfClientId tid, DWORD) override {
        SkLog("Activate");
        tm_ = ptim; tm_->AddRef(); cid_ = tid;
        HRESULT hr = S_OK;
        ITfSource* src = nullptr;
        if (SUCCEEDED(tm_->QueryInterface(IID_ITfSource, (void**)&src))) {
            src->AdviseSink(IID_ITfThreadMgrEventSink, static_cast<ITfThreadMgrEventSink*>(this), &cookieTm_);
            src->Release();
        }
        ITfKeystrokeMgr* km = nullptr;
        if (SUCCEEDED(tm_->QueryInterface(IID_ITfKeystrokeMgr, (void**)&km))) {
            hr = km->AdviseKeyEventSink(cid_, static_cast<ITfKeyEventSink*>(this), TRUE);
            km->Release();
        }
        ITfCategoryMgr* cm = nullptr;
        if (SUCCEEDED(CoCreateInstance(CLSID_TF_CategoryMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfCategoryMgr, (void**)&cm))) {
            cm->RegisterGUID(GUID_DisplayAttrInput, &atom_);
            cm->Release();
        }
        ITfInputProcessorProfileMgr* pm = nullptr;
        if (SUCCEEDED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfileMgr, (void**)&pm))) {
            TF_INPUTPROCESSORPROFILE prof;
            if (SUCCEEDED(pm->GetActiveProfile(GUID_TFCAT_TIP_KEYBOARD, &prof)) && prof.clsid == CLSID_SulekhakTip) SetProfile(prof.guidProfile);
            pm->Release();
        }
        ITfSource* src2 = nullptr;
        if (SUCCEEDED(tm_->QueryInterface(IID_ITfSource, (void**)&src2))) {
            // the profile in use changes when the user picks another keyboard in the list
            src2->AdviseSink(IID_ITfActiveLanguageProfileNotifySink, static_cast<ITfActiveLanguageProfileNotifySink*>(this), &cookieLp_);
            src2->Release();
        }
        return hr;
    }
    STDMETHODIMP Deactivate() override {
        SkLog("Deactivate");
        FlushComposition();
        if (tm_) {
            ITfSource* src = nullptr;
            if (SUCCEEDED(tm_->QueryInterface(IID_ITfSource, (void**)&src))) {
                if (cookieTm_ != TF_INVALID_COOKIE) src->UnadviseSink(cookieTm_);
                if (cookieLp_ != TF_INVALID_COOKIE) src->UnadviseSink(cookieLp_);
                src->Release();
            }
            cookieTm_ = cookieLp_ = TF_INVALID_COOKIE;
            ITfKeystrokeMgr* km = nullptr;
            if (SUCCEEDED(tm_->QueryInterface(IID_ITfKeystrokeMgr, (void**)&km))) { km->UnadviseKeyEventSink(cid_); km->Release(); }
            tm_->Release(); tm_ = nullptr;
        }
        eng_.HideList();
        return S_OK;
    }

    // ITfThreadMgrEventSink
    STDMETHODIMP OnInitDocumentMgr(ITfDocumentMgr*) override { return S_OK; }
    STDMETHODIMP OnUninitDocumentMgr(ITfDocumentMgr*) override { return S_OK; }
    STDMETHODIMP OnSetFocus(ITfDocumentMgr* now, ITfDocumentMgr* prev) override {
        if (core_.Composing() && prev != now) {
            // the word being typed is kept as it stands, in the document that lost the focus
            ITfContext* c = nullptr;
            if (prev && SUCCEEDED(prev->GetTop(&c)) && c) { RunOn(c, [this](TfEditCookie) { core_.Reset(); return S_OK; }); c->Release(); }
            core_.Lost();
            eng_.HideList();
        }
        return S_OK;
    }
    STDMETHODIMP OnPushContext(ITfContext*) override { return S_OK; }
    STDMETHODIMP OnPopContext(ITfContext*) override { return S_OK; }

    // ITfActiveLanguageProfileNotifySink
    STDMETHODIMP OnActivated(REFCLSID clsid, REFGUID prof, BOOL activated) override {
        if (clsid == CLSID_SulekhakTip && activated) SetProfile(prof);
        return S_OK;
    }

    // ITfCompositionSink
    STDMETHODIMP OnCompositionTerminated(TfEditCookie, ITfComposition*) override {
        // the program ended the word (a click elsewhere, for example): its text stays as typed
        if (comp_) { comp_->Release(); comp_ = nullptr; }
        if (compCtx_) { compCtx_->Release(); compCtx_ = nullptr; }
        core_.Lost();
        return S_OK;
    }

    // ITfKeyEventSink
    STDMETHODIMP OnSetFocus(BOOL fore) override { if (!fore) FlushComposition(); else RefreshScript(); return S_OK; }
    STDMETHODIMP OnTestKeyDown(ITfContext*, WPARAM wp, LPARAM lp, BOOL* eaten) override { *eaten = Handle(nullptr, wp, lp, true); return S_OK; }
    STDMETHODIMP OnKeyDown(ITfContext* pic, WPARAM wp, LPARAM lp, BOOL* eaten) override { *eaten = Handle(pic, wp, lp, false); return S_OK; }
    STDMETHODIMP OnTestKeyUp(ITfContext*, WPARAM, LPARAM, BOOL* eaten) override { *eaten = FALSE; return S_OK; }
    STDMETHODIMP OnKeyUp(ITfContext*, WPARAM, LPARAM, BOOL* eaten) override { *eaten = FALSE; return S_OK; }
    STDMETHODIMP OnPreservedKey(ITfContext*, REFGUID, BOOL* eaten) override { *eaten = FALSE; return S_OK; }

    // ITfDisplayAttributeProvider
    STDMETHODIMP EnumDisplayAttributeInfo(IEnumTfDisplayAttributeInfo** pp) override { *pp = new EnumDisplayAttr(); return S_OK; }
    STDMETHODIMP GetDisplayAttributeInfo(REFGUID g, ITfDisplayAttributeInfo** pp) override {
        if (g != GUID_DisplayAttrInput) { *pp = nullptr; return E_INVALIDARG; }
        *pp = new DisplayAttrInfo();
        return S_OK;
    }

    ITfComposition* comp_ = nullptr;
    ITfContext* compCtx_ = nullptr;
    TfGuidAtom atom_ = 0;
    TfClientId cid_ = 0;

private:
    friend class TsfDoc;
    HRESULT RunOn(ITfContext* c, std::function<HRESULT(TfEditCookie)> fn) {
        EditSession* s = new EditSession([this, c, fn](TfEditCookie ec) { doc_.ctx = c; doc_.ec = ec; HRESULT hr = fn(ec); doc_.ctx = nullptr; return hr; });
        HRESULT hrSession = E_FAIL;
        HRESULT hr = c->RequestEditSession(cid_, s, TF_ES_SYNC | TF_ES_READWRITE, &hrSession);
        s->Release();
        return SUCCEEDED(hr) ? hrSession : hr;
    }
    void FlushComposition() {
        if (core_.Composing() && compCtx_) {
            ITfContext* c = compCtx_; c->AddRef();
            RunOn(c, [this](TfEditCookie) { core_.Reset(); return S_OK; });
            c->Release();
        }
        if (core_.Composing()) core_.Lost();
        eng_.HideList();
    }
    void SetProfile(REFGUID prof) {
        int o; bool all;
        int s = ScriptOf(prof, &o, &all);
        all_ = all;
        if (!all) { core_.SetScript(s); eng_.opt = o; }
        else RefreshScript();
    }
    void RefreshScript() {
        if (!all_) return;
        int s, o;
        if (eng_.FetchScript(&s, &o)) { core_.SetScript(s); eng_.opt = o; }
    }
    sk::Key MakeKey(WPARAM wp, LPARAM lp) {
        sk::Key k{(uint32_t)wp, 0, false, false, false, false};
        k.shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
        k.ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
        k.alt = (GetKeyState(VK_MENU) & 0x8000) != 0;
        k.win = (GetKeyState(VK_LWIN) & 0x8000) != 0 || (GetKeyState(VK_RWIN) & 0x8000) != 0;
        if (!k.ctrl && !k.alt && !k.win) {
            BYTE st[256] = {};
            if (k.shift) st[VK_SHIFT] = 0x80;
            if (GetKeyState(VK_CAPITAL) & 1) st[VK_CAPITAL] = 1;
            WCHAR w[8] = {};
            UINT scan = (lp >> 16) & 0xFF;
            int n = ToUnicodeEx((UINT)wp, scan, st, w, 8, 0x4, GetKeyboardLayout(0));
            if (n == 1) k.ch = w[0];
        }
        return k;
    }
    bool Handle(ITfContext* pic, WPARAM wp, LPARAM lp, bool test) {
        sk::Key k = MakeKey(wp, lp);
        if (k.vk == VK_SHIFT || k.vk == VK_CONTROL || k.vk == VK_MENU || k.vk == VK_CAPITAL || k.vk == VK_LWIN || k.vk == VK_RWIN || k.vk == VK_NUMLOCK) return false;
        // Ctrl+Alt+1, 2, 3, 6 choose the script of the "All Languages" keyboard (as in the Sulekhak program)
        if (k.ctrl && k.alt && !k.shift && all_) {
            int s = k.vk == '1' ? 0 : k.vk == '2' ? 1 : k.vk == '3' ? 2 : k.vk == '6' ? 5 : -1;
            if (s >= 0) { if (!test) { FlushComposition(); eng_.SetScript(s, 0); core_.SetScript(s); eng_.opt = 0; } return true; }
        }
        if (test) return core_.WouldEat(k);
        if (!pic) return false;
        bool eaten = false;
        if (compCtx_ && compCtx_ != pic && core_.Composing()) FlushComposition();
        HRESULT hr = RunOn(pic, [&](TfEditCookie) { eaten = core_.OnKey(k); return S_OK; });
        SkLog("key vk=%x ch=%x eaten=%d hr=%x", (unsigned)wp, (unsigned)k.ch, (int)eaten, (unsigned)hr);
        return SUCCEEDED(hr) && eaten;
    }

    LONG ref_ = 1;
    ITfThreadMgr* tm_ = nullptr;
    DWORD cookieTm_ = TF_INVALID_COOKIE, cookieLp_ = TF_INVALID_COOKIE;
    bool all_ = true;
    TsfDoc doc_;
    PipeEngine eng_;
    sk::Core core_;
};

// ---------------------------------------------------------------------------------------------------------------- TsfDoc
ITfRange* TsfDoc::SelectionRange() {
    TF_SELECTION sel; ULONG fetched = 0;
    HRESULT hg = ctx->GetSelection(ec, TF_DEFAULT_SELECTION, 1, &sel, &fetched);
    if (FAILED(hg) || fetched != 1) { SkLog("GetSelection hr=%08lx fetched=%lu", (unsigned long)hg, (unsigned long)fetched); return nullptr; }
    return sel.range;                                                         // owned by the caller
}
void TsfDoc::Caret(ITfRange* r) {
    ITfRange* e = nullptr;
    if (FAILED(r->Clone(&e)) || !e) return;
    e->Collapse(ec, TF_ANCHOR_END);
    TF_SELECTION ts; ts.range = e; ts.style.ase = TF_AE_NONE; ts.style.fInterimChar = FALSE;
    ctx->SetSelection(ec, 1, &ts);
    e->Release();
}
void TsfDoc::Mark(ITfRange* r, bool on) {
    ITfProperty* prop = nullptr;
    if (FAILED(ctx->GetProperty(GUID_PROP_ATTRIBUTE, &prop)) || !prop) return;
    if (on) { VARIANT v; VariantInit(&v); v.vt = VT_I4; v.lVal = (LONG)svc->atom_; prop->SetValue(ec, r, &v); }
    else prop->Clear(ec, r);
    prop->Release();
}
sk::ustr TsfDoc::Before(int n) {
    ITfRange* s = SelectionRange();
    if (!s) return sk::ustr();
    ITfRange* r = nullptr;
    HRESULT hc = s->Clone(&r); s->Release();
    if (!r) { SkLog("Before: Clone hr=%08lx", (unsigned long)hc); return sk::ustr(); }
    HRESULT h1 = r->Collapse(ec, TF_ANCHOR_START);
    LONG shifted = 0;
    HRESULT h2 = r->ShiftStart(ec, -n, &shifted, nullptr);
    WCHAR buf[64] = {}; ULONG cch = 0;
    HRESULT h3 = r->GetText(ec, 0, buf, n < 63 ? n : 63, &cch);
    SkLog("Before(%d): collapse=%08lx shift=%08lx moved=%ld gettext=%08lx cch=%lu", n, (unsigned long)h1, (unsigned long)h2, (long)shifted, (unsigned long)h3, (unsigned long)cch);
    r->Release();
    return sk::ustr((const char16_t*)buf, cch);
}
void TsfDoc::Compose(const sk::ustr& s) {
    if (!svc->comp_) {
        ITfContextComposition* cc = nullptr;
        ITfInsertAtSelection* ias = nullptr;
        ITfRange* sel = nullptr;
        HRESULT hq = ctx->QueryInterface(IID_ITfContextComposition, (void**)&cc);
        if (SUCCEEDED(hq)) hq = ctx->QueryInterface(IID_ITfInsertAtSelection, (void**)&ias);
        if (SUCCEEDED(hq)) hq = ias->InsertTextAtSelection(ec, TF_IAS_QUERYONLY, nullptr, 0, &sel);   // where the word starts (a selection is replaced)
        if (ias) ias->Release();
        if (FAILED(hq) || !sel) { SkLog("Compose: cannot start (hr=%08lx)", (unsigned long)hq); if (sel) sel->Release(); if (cc) cc->Release(); return; }
        ITfComposition* comp = nullptr;
        HRESULT hs = cc->StartComposition(ec, sel, static_cast<ITfCompositionSink*>(svc), &comp);
        SkLog("StartComposition hr=%08lx comp=%p", (unsigned long)hs, (void*)comp);
        sel->Release(); cc->Release();
        if (!comp) return;
        svc->comp_ = comp;
        svc->compCtx_ = ctx; ctx->AddRef();
    }
    ITfRange* r = nullptr;
    if (FAILED(svc->comp_->GetRange(&r)) || !r) return;
    HRESULT hst = r->SetText(ec, 0, (const WCHAR*)s.data(), (LONG)s.size());
    SkLog("Compose SetText hr=%08lx len=%d", (unsigned long)hst, (int)s.size());
    Mark(r, true);
    Caret(r);
    r->Release();
}
void TsfDoc::Commit(const sk::ustr& s) {
    if (!svc->comp_) {
        ITfInsertAtSelection* ins = nullptr;
        if (SUCCEEDED(ctx->QueryInterface(IID_ITfInsertAtSelection, (void**)&ins))) {
            ITfRange* r = nullptr;
            ins->InsertTextAtSelection(ec, 0, (const WCHAR*)s.data(), (LONG)s.size(), &r);
            if (r) { Caret(r); r->Release(); }
            ins->Release();
        }
        return;
    }
    ITfRange* r = nullptr;
    if (SUCCEEDED(svc->comp_->GetRange(&r)) && r) {
        r->SetText(ec, 0, (const WCHAR*)s.data(), (LONG)s.size());
        Mark(r, false);
        Caret(r);
        r->Release();
    }
    svc->comp_->EndComposition(ec);
    svc->comp_->Release(); svc->comp_ = nullptr;
    if (svc->compCtx_) { svc->compCtx_->Release(); svc->compCtx_ = nullptr; }
}
void TsfDoc::EndEmpty() {
    if (!svc->comp_) return;
    ITfRange* r = nullptr;
    if (SUCCEEDED(svc->comp_->GetRange(&r)) && r) { r->SetText(ec, 0, L"", 0); Mark(r, false); r->Release(); }
    svc->comp_->EndComposition(ec);
    svc->comp_->Release(); svc->comp_ = nullptr;
    if (svc->compCtx_) { svc->compCtx_->Release(); svc->compCtx_ = nullptr; }
}
void TsfDoc::ReplaceBefore(int drop, const sk::ustr& s) {
    ITfRange* sel = SelectionRange();
    if (!sel) return;
    ITfRange* r = nullptr;
    sel->Clone(&r); sel->Release();
    if (!r) return;
    r->Collapse(ec, TF_ANCHOR_START);
    if (drop > 0) { LONG sh = 0; r->ShiftStart(ec, -drop, &sh, nullptr); }
    r->SetText(ec, 0, (const WCHAR*)s.data(), (LONG)s.size());
    Caret(r);
    r->Release();
}
void TsfDoc::CaretRect(RECT* rc) {
    ITfContextView* view = nullptr;
    if (FAILED(ctx->GetActiveView(&view)) || !view) return;
    ITfRange* r = nullptr;
    if (svc->comp_) svc->comp_->GetRange(&r); else r = SelectionRange();
    if (r) {
        BOOL clipped = FALSE;
        RECT t = {};
        if (SUCCEEDED(view->GetTextExt(ec, r, &t, &clipped))) *rc = t;
        r->Release();
    }
    view->Release();
}

// ---------------------------------------------------------------------------------------------------------------- COM plumbing
class ClassFactory : public IClassFactory {
public:
    STDMETHODIMP QueryInterface(REFIID r, void** p) override {
        if (r == IID_IUnknown || r == IID_IClassFactory) { *p = static_cast<IClassFactory*>(this); AddRef(); return S_OK; }
        *p = nullptr; return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return 2; }
    STDMETHODIMP_(ULONG) Release() override { return 1; }
    STDMETHODIMP CreateInstance(IUnknown* outer, REFIID r, void** p) override {
        *p = nullptr;
        if (outer) return CLASS_E_NOAGGREGATION;
        TextService* t = new TextService();
        HRESULT hr = t->QueryInterface(r, p);
        t->Release();
        return hr;
    }
    STDMETHODIMP LockServer(BOOL l) override { if (l) InterlockedIncrement(&g_locks); else InterlockedDecrement(&g_locks); return S_OK; }
};
static ClassFactory g_factory;

STDAPI DllGetClassObject(REFCLSID clsid, REFIID riid, void** ppv) {
    if (clsid != CLSID_SulekhakTip) { *ppv = nullptr; return CLASS_E_CLASSNOTAVAILABLE; }
    return g_factory.QueryInterface(riid, ppv);
}
STDAPI DllCanUnloadNow() { return (g_objects == 0 && g_locks == 0) ? S_OK : S_FALSE; }

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) { g_hInst = h; DisableThreadLibraryCalls(h); }
    return TRUE;
}
