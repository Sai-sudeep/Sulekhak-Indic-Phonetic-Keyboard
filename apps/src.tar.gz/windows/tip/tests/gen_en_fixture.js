// Writes en_fixture.txt: what the real English engine (shared/english.js with the real data) answers for the words the native tests type.
// usage: node gen_en_fixture.js <dir with en_lex.txt en_ng.txt en_fix.txt>      (the native tests then use the file, so the logic is checked against real answers)
const fs = require('fs'), path = require('path');
const SE = require(path.join(__dirname, '..', '..', '..', 'shared', 'english.js'));
const DIR = process.argv[2];
if (!DIR) { console.log('usage: node gen_en_fixture.js <data dir>'); process.exit(2); }
const rd = p => fs.readFileSync(path.join(DIR, p), 'utf8');
const E = SE.create(); E.load({ lex: rd('en_lex.txt'), ng: rd('en_ng.txt'), fix: rd('en_fix.txt') });
const words = ['t', 'th', 'the', 'teh', 'thw', 'hello', 'helo', 'recieve', 'dont', 'dont\'', 'cant', 'im', 'wanna', 'ashwini', 'covid', 'iitd', 'a', 'i', 'wich', 'definately', 'adress', 'tommorow', 'goin', 'goo', 'goodmorning', 'helllo', 'hlelo', 'qzx'];
const prevs = ['', '<s>', 'i', 'of'];
const out = [];
for (const w of words) for (const p of prevs) {
  const r = E.suggest(w, p || null);
  out.push([w, p, r.auto ? 1 : 0].concat(r.list.slice(0, 6)).join('\t'));
}
fs.writeFileSync(path.join(__dirname, 'en_fixture.txt'), out.join('\n') + '\n');
console.log(out.length + ' answers written');
