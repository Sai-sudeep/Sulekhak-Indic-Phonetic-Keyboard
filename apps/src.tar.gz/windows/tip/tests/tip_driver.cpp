// Drives the real text service through the real TSF: a thread manager, a document with a small text store, the Sulekhak profile activated,
// keys sent through ITfKeystrokeMgr, and a stand-in for the engine on the named pipe. It runs on Windows and under Wine:  tip_driver.exe <dll>
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <msctf.h>
#include <sddl.h>
#include <cstdio>
#include <string>
#include <vector>
#include "../guids.h"
#include "../tsfextra.h"

static std::wstring g_text; static LONG g_selStart = 0, g_selEnd = 0;

class TextStore : public ITextStoreACP {
public:
    STDMETHODIMP QueryInterface(REFIID r, void** p) override { if (r == IID_IUnknown || r == IID_ITextStoreACP) { *p = static_cast<ITextStoreACP*>(this); return S_OK; } *p = nullptr; return E_NOINTERFACE; }
    STDMETHODIMP_(ULONG) AddRef() override { return 2; }
    STDMETHODIMP_(ULONG) Release() override { return 1; }
    STDMETHODIMP AdviseSink(REFIID r, IUnknown* u, DWORD mask) override { if (r != IID_ITextStoreACPSink) return E_INVALIDARG; if (sink_) return ((HRESULT)0x80040201L); u->QueryInterface(IID_ITextStoreACPSink, (void**)&sink_); return S_OK; }
    STDMETHODIMP UnadviseSink(IUnknown*) override { if (sink_) { sink_->Release(); sink_ = nullptr; } return S_OK; }
    STDMETHODIMP RequestLock(DWORD flags, HRESULT* phr) override {
        if (locked_) { *phr = TS_E_SYNCHRONOUS; return S_OK; }
        locked_ = true; *phr = sink_->OnLockGranted(flags); locked_ = false; return S_OK;
    }
    STDMETHODIMP GetStatus(TS_STATUS* s) override { s->dwDynamicFlags = 0; s->dwStaticFlags = TS_SS_NOHIDDENTEXT; return S_OK; }
    STDMETHODIMP QueryInsert(LONG s, LONG e, ULONG cch, LONG* rs, LONG* re) override { *rs = s; *re = e; return S_OK; }
    STDMETHODIMP GetSelection(ULONG idx, ULONG cnt, TS_SELECTION_ACP* sel, ULONG* fetched) override {
        if (idx != 0 && idx != TS_DEFAULT_SELECTION) return E_INVALIDARG;
        sel[0].acpStart = g_selStart; sel[0].acpEnd = g_selEnd; sel[0].style.ase = TS_AE_END; sel[0].style.fInterimChar = FALSE; *fetched = 1; return S_OK;
    }
    STDMETHODIMP SetSelection(ULONG cnt, const TS_SELECTION_ACP* sel) override { g_selStart = sel[0].acpStart; g_selEnd = sel[0].acpEnd; return S_OK; }
    STDMETHODIMP GetText(LONG s, LONG e, WCHAR* plain, ULONG cch, ULONG* ret, TS_RUNINFO* ri, ULONG cri, ULONG* rri, LONG* next) override {
        LONG end = e == -1 ? (LONG)g_text.size() : e;
        if (s < 0 || end > (LONG)g_text.size() || s > end) return TS_E_INVALIDPOS;
        ULONG n = (ULONG)(end - s); if (n > cch) n = cch;
        if (plain) for (ULONG i = 0; i < n; i++) plain[i] = g_text[s + i];
        if (ret) *ret = n;
        if (ri && cri) { ri[0].uCount = n; ri[0].type = TS_RT_PLAIN; if (rri) *rri = 1; } else if (rri) *rri = 0;
        if (next) *next = s + n;
        return S_OK;
    }
    STDMETHODIMP SetText(DWORD, LONG s, LONG e, const WCHAR* t, ULONG cch, TS_TEXTCHANGE* ch) override {
        if (s < 0 || e > (LONG)g_text.size() || s > e) return TS_E_INVALIDPOS;
        g_text = g_text.substr(0, s) + std::wstring(t, cch) + g_text.substr(e);
        g_selStart = g_selEnd = s + (LONG)cch;
        if (ch) { ch->acpStart = s; ch->acpOldEnd = e; ch->acpNewEnd = s + (LONG)cch; }
        return S_OK;
    }
    STDMETHODIMP GetFormattedText(LONG, LONG, IDataObject**) override { return E_NOTIMPL; }
    STDMETHODIMP GetEmbedded(LONG, REFGUID, REFIID, IUnknown**) override { return E_NOTIMPL; }
    STDMETHODIMP QueryInsertEmbedded(const GUID*, const FORMATETC*, BOOL* ok) override { *ok = FALSE; return S_OK; }
    STDMETHODIMP InsertEmbedded(DWORD, LONG, LONG, IDataObject*, TS_TEXTCHANGE*) override { return E_NOTIMPL; }
    STDMETHODIMP InsertTextAtSelection(DWORD flags, const WCHAR* t, ULONG cch, LONG* s, LONG* e, TS_TEXTCHANGE* ch) override {
        LONG a = g_selStart, b = g_selEnd;
        if (flags & TS_IAS_QUERYONLY) { if (s) *s = a; if (e) *e = b; return S_OK; }
        g_text = g_text.substr(0, a) + std::wstring(t, cch) + g_text.substr(b);
        g_selStart = g_selEnd = a + (LONG)cch;
        if (s) *s = a; if (e) *e = a + (LONG)cch;
        if (ch) { ch->acpStart = a; ch->acpOldEnd = b; ch->acpNewEnd = a + (LONG)cch; }
        return S_OK;
    }
    STDMETHODIMP InsertEmbeddedAtSelection(DWORD, IDataObject*, LONG*, LONG*, TS_TEXTCHANGE*) override { return E_NOTIMPL; }
    STDMETHODIMP RequestSupportedAttrs(DWORD, ULONG, const TS_ATTRID*) override { return E_NOTIMPL; }
    STDMETHODIMP RequestAttrsAtPosition(LONG, ULONG, const TS_ATTRID*, DWORD) override { return E_NOTIMPL; }
    STDMETHODIMP RequestAttrsTransitioningAtPosition(LONG, ULONG, const TS_ATTRID*, DWORD) override { return E_NOTIMPL; }
    STDMETHODIMP FindNextAttrTransition(LONG, LONG, ULONG, const TS_ATTRID*, DWORD, LONG*, BOOL*, LONG*) override { return E_NOTIMPL; }
    STDMETHODIMP RetrieveRequestedAttrs(ULONG, TS_ATTRVAL*, ULONG* ret) override { *ret = 0; return S_OK; }
    STDMETHODIMP GetEndACP(LONG* a) override { *a = (LONG)g_text.size(); return S_OK; }
    STDMETHODIMP GetActiveView(TsViewCookie* v) override { *v = 1; return S_OK; }
    STDMETHODIMP GetACPFromPoint(TsViewCookie, const POINT*, DWORD, LONG* a) override { *a = 0; return S_OK; }
    STDMETHODIMP GetTextExt(TsViewCookie, LONG, LONG, RECT* rc, BOOL* clipped) override { *rc = {100, 100, 160, 130}; *clipped = FALSE; return S_OK; }
    STDMETHODIMP GetScreenExt(TsViewCookie, RECT* rc) override { *rc = {0, 0, 800, 600}; return S_OK; }
    STDMETHODIMP GetWnd(TsViewCookie, HWND* w) override { *w = GetDesktopWindow(); return S_OK; }
private:
    ITextStoreACPSink* sink_ = nullptr; bool locked_ = false;
};

// ---- a stand-in for the Sulekhak program's engine on the pipe
static std::wstring PipeName() {
    std::wstring sid = L"user"; HANDLE tok = nullptr;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) {
        DWORD n = 0; GetTokenInformation(tok, TokenUser, nullptr, 0, &n); std::vector<BYTE> b(n ? n : 1);
        if (n && GetTokenInformation(tok, TokenUser, b.data(), n, &n)) { wchar_t* s = nullptr; if (ConvertSidToStringSidW(((TOKEN_USER*)b.data())->User.Sid, &s)) { sid = s; LocalFree(s); } }
        CloseHandle(tok);
    }
    return L"\\\\.\\pipe\\SulekhakTip-" + sid;
}
static std::string W2U(const std::wstring& s) { int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), 0, 0, 0, 0); std::string o(n, 0); WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), &o[0], n, 0, 0); return o; }
static volatile LONG g_quit = 0, g_queries = 0, g_lists = 0, g_learned = 0;
static std::string Answer(const std::string& q) {
    if (q.empty()) return "K";
    if (q[0] == 'G') return "T\t0\t0";
    if (q[0] == 'P') { InterlockedIncrement(&g_lists); return "K"; }
    if (q[0] == 'L') { InterlockedIncrement(&g_learned); return "K"; }
    if (q[0] == 'Q') {
        InterlockedIncrement(&g_queries);
        size_t p = q.rfind('\t'); std::string buf = q.substr(p + 1);
        if (buf == "ba") return "C\t" + W2U(L"ବ") + "\t" + W2U(L"ା");
        if (buf == "badi") return "C\t" + W2U(L"ବଡି");
        if (buf == "bad") return "C\t" + W2U(L"ବଡ");
        if (buf == "ba`") return "C\t" + W2U(L"ବ୍");
        if (buf == ".") return "C\t" + W2U(L"।") + "\t.\t" + W2U(L"॥");
        return "C\t" + buf;
    }
    return "K";
}
static DWORD WINAPI PipeThread(LPVOID) {
    std::wstring name = PipeName();
    while (!g_quit) {
        HANDLE h = CreateNamedPipeW(name.c_str(), PIPE_ACCESS_DUPLEX, PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT, 8, 8192, 8192, 0, nullptr);
        if (h == INVALID_HANDLE_VALUE) { Sleep(50); continue; }
        if (ConnectNamedPipe(h, nullptr) || GetLastError() == ERROR_PIPE_CONNECTED) {
            for (;;) {
                char buf[8192]; DWORD n = 0;
                if (!ReadFile(h, buf, sizeof buf, &n, nullptr)) break;
                std::string a = Answer(std::string(buf, n)); DWORD w;
                if (!WriteFile(h, a.data(), (DWORD)a.size(), &w, nullptr)) break;
            }
        }
        DisconnectNamedPipe(h); CloseHandle(h);
    }
    return 0;
}

static ITfKeystrokeMgr* g_km = nullptr;
static ITfKeyEventSink* g_sink = nullptr;     // the text service's own key sink, called directly when the system's key manager cannot dispatch (Wine)
static ITfContext* g_ctx = nullptr;
static void Pump() { MSG m; while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); } }
static void SetMods(bool shift, bool ctrl = false) { BYTE st[256] = {}; if (shift) st[VK_SHIFT] = 0x80; if (ctrl) st[VK_CONTROL] = 0x80; SetKeyboardState(st); }
static bool Press(UINT vk, bool shift = false, bool ctrl = false) {
    SetMods(shift, ctrl);
    LPARAM lp = 1 | (MapVirtualKeyW(vk, MAPVK_VK_TO_VSC) << 16);
    BOOL t = FALSE, e = FALSE;
    if (g_sink) { g_sink->OnTestKeyDown(g_ctx, vk, lp, &t); if (t) g_sink->OnKeyDown(g_ctx, vk, lp, &e); }
    else { g_km->TestKeyDown(vk, lp, &t); if (t) g_km->KeyDown(vk, lp, &e); }
    Pump();
    SetMods(false);
    if (getenv("TIPDBG")) { printf("  key %02x t=%d e=%d text=", vk, (int)t, (int)e); for (wchar_t c : g_text) printf("%04X ", c); printf(" sel=%ld-%ld\n", g_selStart, g_selEnd); }
    return t && e;
}
static bool Chr(wchar_t c) {
    if (c >= L'a' && c <= L'z') return Press(c - 32);
    if (c >= L'A' && c <= L'Z') return Press(c, true);
    if (c >= L'0' && c <= L'9') return Press(c);
    switch (c) { case L'.': return Press(VK_OEM_PERIOD); case L'>': return Press(VK_OEM_PERIOD, true); case L',': return Press(VK_OEM_COMMA); case L'`': return Press(VK_OEM_3); case L'~': return Press(VK_OEM_3, true); }
    return false;
}
static void Str(const wchar_t* s) { for (; *s; s++) Chr(*s); }

static int g_bad = 0, g_total = 0, g_skipped = 0;
static bool g_wine = false;     // Wine's text services lack ITfRange::Clone and ITfContextComposition: those checks only run on Windows
static bool Skip(const char* name) { if (!g_wine) return false; g_skipped++; printf("skip %s (Wine)\n", name); return true; }
static void Check(const char* name, const std::wstring& got, const std::wstring& want) {
    g_total++;
    if (got != want) { g_bad++; printf("FAIL %s\n  expected:", name); for (wchar_t c : want) printf(" %04X", c); printf("\n  got:     "); for (wchar_t c : got) printf(" %04X", c); printf("\n"); }
    else printf("ok   %s\n", name);
}
static void Reset() { g_text.clear(); g_selStart = g_selEnd = 0; }

// ---- a stand-in for a program that draws the candidate list itself (the Start / Search box, store apps: "UI-less" mode)
static const GUID kIidCandUi = { 0xea1ea138, 0x19df, 0x11d7, { 0xa6, 0xd2, 0x00, 0x06, 0x5b, 0x84, 0x43, 0x5c } };
static ITfThreadMgr* g_uiTm = nullptr;
static std::vector<std::wstring> g_hostList; static UINT g_hostSel = 0, g_hostPages = 0; static int g_hostBegin = 0, g_hostUpdate = 0, g_hostEnd = 0; static bool g_hostShowAnswer = false;
class UiHost : public ITfUIElementSink {
public:
    STDMETHODIMP QueryInterface(REFIID r, void** p) override { if (r == IID_IUnknown || r == IID_ITfUIElementSink) { *p = static_cast<ITfUIElementSink*>(this); return S_OK; } *p = nullptr; return E_NOINTERFACE; }
    STDMETHODIMP_(ULONG) AddRef() override { return 2; }
    STDMETHODIMP_(ULONG) Release() override { return 1; }
    STDMETHODIMP BeginUIElement(DWORD id, BOOL* show) override { g_hostBegin++; *show = g_hostShowAnswer; Fetch(id); return S_OK; }
    STDMETHODIMP UpdateUIElement(DWORD id) override { g_hostUpdate++; Fetch(id); return S_OK; }
    STDMETHODIMP EndUIElement(DWORD) override { g_hostEnd++; return S_OK; }
private:
    static void Fetch(DWORD id) {
        ITfUIElementMgr* m = nullptr; ITfUIElement* e = nullptr; ITfCandidateListUIElement* c = nullptr;
        if (FAILED(g_uiTm->QueryInterface(IID_ITfUIElementMgr, (void**)&m)) || !m) return;
        if (SUCCEEDED(m->GetUIElement(id, &e)) && e && SUCCEEDED(e->QueryInterface(kIidCandUi, (void**)&c)) && c) {
            UINT n = 0, sel = 0, pages = 0; c->GetCount(&n); c->GetSelection(&sel); c->GetPageIndex(nullptr, 0, &pages);
            g_hostList.clear();
            for (UINT i = 0; i < n; i++) { BSTR b = nullptr; if (SUCCEEDED(c->GetString(i, &b)) && b) { g_hostList.push_back(std::wstring(b, SysStringLen(b))); SysFreeString(b); } }
            g_hostSel = sel; g_hostPages = pages;
            c->Release();
        }
        if (e) e->Release();
        m->Release();
    }
};

// a bare UI element the driver announces itself: tells apart "Windows never forwards UI elements to the program" from "it does not forward the keyboard's"
static const GUID kProbeGuid = { 0x5b1c0f10, 0x7a3e, 0x4c7a, { 0x9e, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77 } };
class DummyEl : public ITfUIElement {
public:
    STDMETHODIMP QueryInterface(REFIID r, void** p) override { if (r == IID_IUnknown || r == IID_ITfUIElement) { *p = static_cast<ITfUIElement*>(this); return S_OK; } *p = nullptr; return E_NOINTERFACE; }
    STDMETHODIMP_(ULONG) AddRef() override { return 2; }
    STDMETHODIMP_(ULONG) Release() override { return 1; }
    STDMETHODIMP GetDescription(BSTR* b) override { *b = SysAllocString(L"probe"); return S_OK; }
    STDMETHODIMP GetGUID(GUID* g) override { *g = kProbeGuid; return S_OK; }
    STDMETHODIMP Show(BOOL) override { return S_OK; }
    STDMETHODIMP IsShown(BOOL* p) override { *p = FALSE; return S_OK; }
};


// --list / --expect-none: counts the Sulekhak keyboards the system itself reports (the list Win+Space and Settings are built from).
static int ListProfiles(bool expectNone) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    ITfInputProcessorProfiles* pp = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfiles, (void**)&pp))) { printf("no profile manager\n"); return 4; }
    static const struct { LANGID lang; const GUID* g; const char* n; } want[] = {
        { 0x0409, &GUID_ProfileAll, "All Languages" }, { 0x0448, &GUID_ProfileOdia, "Odia" }, { 0x0439, &GUID_ProfileHindi, "Hindi" },
        { 0x044E, &GUID_ProfileMarathi, "Marathi" }, { 0x0445, &GUID_ProfileBangla, "Bangla" }, { 0x044D, &GUID_ProfileAssamese, "Assamese" } };
    int found = 0, enabled = 0;
    for (auto& w : want) {
        IEnumTfLanguageProfiles* en = nullptr;
        bool seen = false;
        if (SUCCEEDED(pp->EnumLanguageProfiles(w.lang, &en)) && en) {
            TF_LANGUAGEPROFILE lp; ULONG n = 0;
            while (en->Next(1, &lp, &n) == S_OK && n == 1) {
                if (IsEqualGUID(lp.clsid, CLSID_SulekhakTip) && IsEqualGUID(lp.guidProfile, *w.g)) seen = true;
            }
            en->Release();
        }
        BOOL en2 = FALSE;
        if (seen) { pp->IsEnabledLanguageProfile(CLSID_SulekhakTip, w.lang, *w.g, &en2); found++; if (en2) enabled++; }
        printf("%-14s lang %04X  %s%s\n", w.n, w.lang, seen ? "listed" : "absent", seen && en2 ? ", enabled" : "");
    }
    pp->Release();
    printf("%d of 6 Sulekhak keyboards listed, %d enabled\n", found, enabled);
    if (expectNone) return found == 0 ? 0 : 1;
    return found == 6 ? 0 : 1;
}


#ifndef TF_IPPMF_FORPROCESS
#define TF_IPPMF_FORPROCESS 0x10000000
#define TF_IPPMF_ENABLEPROFILE 0x00000001
#endif
// --activate: Windows itself activates one of the Sulekhak keyboards in this process (what choosing it in Win+Space does) and loads the DLL.
static int ActivateProfileTest() {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    ITfThreadMgr* tm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_ThreadMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfThreadMgr, (void**)&tm))) { printf("no thread manager\n"); return 4; }
    TfClientId tid = 0; tm->Activate(&tid);
    ITfDocumentMgr* dm = nullptr; tm->CreateDocumentMgr(&dm);
    TextStore ts; ITfContext* ctx = nullptr; TfEditCookie ec = 0;
    dm->CreateContext(tid, 0, static_cast<ITextStoreACP*>(&ts), &ctx, &ec); dm->Push(ctx); tm->SetFocus(dm);
    ITfInputProcessorProfileMgr* pm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfileMgr, (void**)&pm))) { printf("no profile manager (ITfInputProcessorProfileMgr)\n"); return 5; }
    HRESULT h = pm->ActivateProfile(TF_PROFILETYPE_INPUTPROCESSOR, 0x0448, CLSID_SulekhakTip, GUID_ProfileOdia, nullptr, TF_IPPMF_FORPROCESS | TF_IPPMF_ENABLEPROFILE);
    printf("ActivateProfile(Odia): %08lx\n", (unsigned long)h);
    DWORD t0 = GetTickCount(); MSG m;
    while (GetTickCount() - t0 < 3000) { while (PeekMessage(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessage(&m); } Sleep(20); }
    TF_INPUTPROCESSORPROFILE act; ZeroMemory(&act, sizeof act);
    HRESULT g = pm->GetActiveProfile(GUID_TFCAT_TIP_KEYBOARD, &act);
    bool ours = SUCCEEDED(g) && IsEqualGUID(act.clsid, CLSID_SulekhakTip) && IsEqualGUID(act.guidProfile, GUID_ProfileOdia);
    HMODULE mod = GetModuleHandleW(L"sulekhak_tip_x64.dll"); if (!mod) mod = GetModuleHandleW(L"sulekhak_tip_x86.dll");
    printf("GetActiveProfile: %08lx, active is Sulekhak Odia: %s\n", (unsigned long)g, ours ? "yes" : "no");
    printf("Windows loaded the text service DLL into this process: %s\n", mod ? "yes" : "no");
    return (SUCCEEDED(h) && ours && mod) ? 0 : 1;
}

// --launch <dll>: no program is running. A key typed in a Sulekhak keyboard must make the text service start the program named in
// HKLM\Software\Sulekhak\InstallDir (here: a copy of this executable called Sulekhak.exe, which only writes a marker file), but not after the user chose Exit.
static std::wstring MarkerPath() { wchar_t t[MAX_PATH]; GetTempPathW(MAX_PATH, t); return std::wstring(t) + L"sk_host_launched.txt"; }
static bool WaitMarker(DWORD ms) {
    DWORD t0 = GetTickCount();
    while (GetTickCount() - t0 < ms) { Pump(); if (GetFileAttributesW(MarkerPath().c_str()) != INVALID_FILE_ATTRIBUTES) return true; Sleep(100); }
    return false;
}
static int LaunchTest(const char* dllPath) {
    int bad = 0;
    auto chk = [&](bool c, const char* m) { printf("%s  %s\n", c ? "ok  " : "FAIL", m); if (!c) bad++; };
    wchar_t dirbuf[MAX_PATH]; GetTempPathW(MAX_PATH, dirbuf);
    std::wstring dir = std::wstring(dirbuf) + L"sk_fake_install"; CreateDirectoryW(dir.c_str(), nullptr);
    wchar_t self[MAX_PATH]; GetModuleFileNameW(nullptr, self, MAX_PATH);
    CopyFileW(self, (dir + L"\\Sulekhak.exe").c_str(), FALSE);
    DeleteFileW(MarkerPath().c_str());
    HKEY k; RegCreateKeyExW(HKEY_LOCAL_MACHINE, L"Software\\Sulekhak", 0, nullptr, 0, KEY_WRITE | KEY_WOW64_64KEY, nullptr, &k, nullptr);
    RegSetValueExW(k, L"InstallDir", 0, REG_SZ, (const BYTE*)dir.c_str(), (DWORD)((dir.size() + 1) * sizeof(wchar_t)));
    RegCloseKey(k);
    SetEnvironmentVariableW(L"SULEKHAK_TIP_ALLOW_ELEVATED", L"1");
    DWORD one = 1;
    RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Sulekhak", 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr);
    RegSetValueExW(k, L"UserExit", 0, REG_DWORD, (const BYTE*)&one, sizeof one);       // the user chose Exit: nothing may be started
    RegCloseKey(k);

    HINSTANCE dll = LoadLibraryA(dllPath);
    if (!dll) { printf("cannot load the DLL\n"); return 2; }
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    typedef HRESULT (STDAPICALLTYPE *Reg)();
    if (FAILED(((Reg)GetProcAddress(dll, "DllRegisterServer"))())) { printf("DllRegisterServer failed\n"); return 3; }
    ITfThreadMgr* tm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_ThreadMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfThreadMgr, (void**)&tm))) { printf("no thread manager\n"); return 4; }
    TfClientId tid = 0; tm->Activate(&tid);
    ITfDocumentMgr* dm = nullptr; tm->CreateDocumentMgr(&dm);
    TextStore ts; ITfContext* ctx = nullptr; TfEditCookie ec = 0;
    dm->CreateContext(tid, 0, static_cast<ITextStoreACP*>(&ts), &ctx, &ec); dm->Push(ctx); tm->SetFocus(dm);
    ITfInputProcessorProfiles* pp = nullptr;
    CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfiles, (void**)&pp);
    pp->EnableLanguageProfile(CLSID_SulekhakTip, 0x0448, GUID_ProfileOdia, TRUE);
    pp->ActivateLanguageProfile(CLSID_SulekhakTip, 0x0448, GUID_ProfileOdia);
    Pump();
    tm->QueryInterface(IID_ITfKeystrokeMgr, (void**)&g_km);
    g_ctx = ctx;
    ITfTextInputProcessor* tip = nullptr;
    if (FAILED(CoCreateInstance(CLSID_SulekhakTip, nullptr, CLSCTX_INPROC_SERVER, IID_ITfTextInputProcessor, (void**)&tip))) { printf("create text service failed\n"); return 6; }
    tip->Activate(tm, tid);
    tip->QueryInterface(IID_ITfKeyEventSink, (void**)&g_sink);

    Reset(); Str(L"ba");
    chk(!WaitMarker(3000), "after Exit in the tray menu the text service does not start the program");
    RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Sulekhak", 0, KEY_WRITE, &k); RegDeleteValueW(k, L"UserExit"); RegCloseKey(k);
    Sleep(2800);                      // the text service waits a moment after a failed attempt to reach the engine
    Press(VK_ESCAPE);
    Str(L"ba");
    chk(WaitMarker(8000), "a key typed while the program is not running starts it (Sulekhak.exe --from-text-service)");
    bool again = false;
    DeleteFileW(MarkerPath().c_str());
    for (int i = 0; i < 6; i++) { Press(VK_ESCAPE); Str(L"ba"); Sleep(500); }
    again = GetFileAttributesW(MarkerPath().c_str()) != INVALID_FILE_ATTRIBUTES;
    chk(!again, "it is not started again and again (at most once every 20 seconds)");

    RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"Software\\Sulekhak", 0, KEY_WRITE | KEY_WOW64_64KEY, &k); RegDeleteValueW(k, L"InstallDir"); RegCloseKey(k);
    DeleteFileW(MarkerPath().c_str());
    ((HRESULT (STDAPICALLTYPE *)())GetProcAddress(dll, "DllUnregisterServer"))();
    printf("%s\n", bad ? "launch test FAILED" : "launch test passed");
    return bad ? 1 : 0;
}


// ---- --gui <outdir>: a real window with a real edit box, real key presses (SendInput) and screenshots, with the installed text service and program.
//      Run it after the installer: it activates the Sulekhak Odia keyboard for this process and types into the window like a person would.
static void SaveBmp(HWND w, const wchar_t* path) {
    RECT r; GetWindowRect(w, &r);
    int cw = r.right - r.left, ch = r.bottom - r.top;
    HDC sc = GetDC(nullptr), mem = CreateCompatibleDC(sc);
    HBITMAP bm = CreateCompatibleBitmap(sc, cw, ch); HGDIOBJ old = SelectObject(mem, bm);
    BitBlt(mem, 0, 0, cw, ch, sc, r.left, r.top, SRCCOPY | CAPTUREBLT);
    BITMAPINFOHEADER bi = { sizeof bi, cw, ch, 1, 24, BI_RGB, 0, 0, 0, 0, 0 };
    int stride = ((cw * 3 + 3) / 4) * 4; std::vector<BYTE> px((size_t)stride * ch);
    GetDIBits(mem, bm, 0, ch, px.data(), (BITMAPINFO*)&bi, DIB_RGB_COLORS);
    BITMAPFILEHEADER fh = { 0x4D42, (DWORD)(sizeof fh + sizeof bi + px.size()), 0, 0, (DWORD)(sizeof fh + sizeof bi) };
    HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
    if (f != INVALID_HANDLE_VALUE) { DWORD n; WriteFile(f, &fh, sizeof fh, &n, nullptr); WriteFile(f, &bi, sizeof bi, &n, nullptr); WriteFile(f, px.data(), (DWORD)px.size(), &n, nullptr); CloseHandle(f); }
    SelectObject(mem, old); DeleteObject(bm); DeleteDC(mem); ReleaseDC(nullptr, sc);
}
static void KeyEv(WORD vk, bool up) {
    INPUT in = {}; in.type = INPUT_KEYBOARD; in.ki.wVk = vk; in.ki.wScan = (WORD)MapVirtualKeyW(vk, MAPVK_VK_TO_VSC);
    in.ki.dwFlags = (up ? KEYEVENTF_KEYUP : 0) | ((vk == VK_LEFT || vk == VK_RIGHT || vk == VK_UP || vk == VK_DOWN || vk == VK_DELETE) ? KEYEVENTF_EXTENDEDKEY : 0);
    SendInput(1, &in, sizeof in);
}
static void Wait(DWORD ms) { DWORD t0 = GetTickCount(); while (GetTickCount() - t0 < ms) { Pump(); Sleep(10); } }
static void RealKey(WORD vk) { KeyEv(vk, false); Wait(30); KeyEv(vk, true); Wait(160); }
static void RealText(const char* s) { for (; *s; s++) { SHORT v = VkKeyScanA(*s); bool sh = (v & 0x100) != 0; if (sh) KeyEv(VK_SHIFT, false); RealKey((WORD)(v & 0xFF)); if (sh) KeyEv(VK_SHIFT, true); } }
static std::wstring EditText(HWND e) { wchar_t b[512] = {}; GetWindowTextW(e, b, 511); return b; }
static void Hex(const std::wstring& t) { for (wchar_t c : t) printf(" %04X", c); }
static bool HasOdia(const std::wstring& t) { for (wchar_t c : t) if (c >= 0x0B00 && c <= 0x0B7F) return true; return false; }
static volatile const char* g_stage = "start";
static DWORD WINAPI Watchdog(LPVOID) { for (int i = 1; ; i++) { Sleep(20000); printf("watchdog: %d s, still in stage: %s\n", i * 20, g_stage); } return 0; }
static int GuiTest(const wchar_t* outDir) {
    CreateThread(nullptr, 0, Watchdog, nullptr, 0, nullptr);
    g_stage = "COM init"; printf("stage: COM init\n");
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    WNDCLASSW wc = {}; wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"SkGuiTest"; wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1); RegisterClassW(&wc);
    g_stage = "creating the window"; printf("stage: creating the window\n");
    HWND w = CreateWindowExW(WS_EX_TOPMOST, L"SkGuiTest", L"Sulekhak keyboard test (a real window, real key presses)", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 60, 60, 760, 360, nullptr, nullptr, wc.hInstance, nullptr);
    HWND e = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL, 12, 12, 720, 120, w, nullptr, wc.hInstance, nullptr);
    HFONT f = CreateFontW(34, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Nirmala UI"); SendMessageW(e, WM_SETFONT, (WPARAM)f, TRUE);
    ShowWindow(w, SW_SHOW); Wait(500);
    g_stage = "taking the foreground"; printf("stage: window shown\n");
    // let this process take the foreground without pressing Alt: a lone Alt press opens the window's system menu and its modal loop (this is what stalled the test)
    SystemParametersInfoW(SPI_SETFOREGROUNDLOCKTIMEOUT, 0, (PVOID)0, SPIF_SENDCHANGE); AllowSetForegroundWindow(ASFW_ANY);
    SetForegroundWindow(w); SetFocus(e); Wait(500);
    g_stage = "profile manager"; printf("stage: foreground done (foreground window is ours: %d)\n", (int)(GetForegroundWindow() == w));
    int bad = 0, total = 0;
    auto check = [&](bool ok, const char* what) { total++; if (!ok) bad++; printf("%s  %s\n", ok ? "ok  " : "FAIL", what); };
    ITfInputProcessorProfileMgr* pm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfileMgr, (void**)&pm))) { printf("no profile manager\n"); return 5; }
    g_stage = "ActivateProfile"; printf("stage: activating the profile\n");
    HRESULT h = pm->ActivateProfile(TF_PROFILETYPE_INPUTPROCESSOR, 0x0448, CLSID_SulekhakTip, GUID_ProfileOdia, nullptr, 0x10000000 | 1);
    printf("ActivateProfile(Odia): %08lx\n", (unsigned long)h);
    Wait(2500); SetForegroundWindow(w); SetFocus(e); Wait(300);
    std::wstring dir = outDir;
    auto shot = [&](const wchar_t* name) { SaveBmp(w, (dir + L"\\" + name).c_str()); };
    shot(L"0-start.bmp");
    g_stage = "typing namaste"; printf("stage: typing\n");
    RealText("namaste"); Wait(700);
    std::wstring t1 = EditText(e); printf("typed 'namaste':"); Hex(t1); printf("\n");
    check(HasOdia(t1), "typing namaste shows Odia letters in the edit box");
    shot(L"1-typed-namaste.bmp");
    RealKey(VK_SPACE); Wait(400);
    std::wstring t2 = EditText(e); printf("after Space:"); Hex(t2); printf("\n");
    check(HasOdia(t2) && !t2.empty() && t2.back() == L' ', "Space commits the Odia word and adds a space");
    shot(L"2-after-space.bmp");
    RealKey(VK_BACK); Wait(300);
    std::wstring t3 = EditText(e); printf("Backspace 1:"); Hex(t3); printf("\n");
    check(t3.size() + 1 == t2.size(), "Backspace removes the space");
    RealKey(VK_BACK); Wait(300);
    std::wstring t4 = EditText(e); printf("Backspace 2:"); Hex(t4); printf("\n");
    check(t4.size() + 1 == t3.size() || (t4.size() < t3.size()), "Backspace again removes one more letter (it still works after the word)");
    shot(L"3-after-backspaces.bmp");
    // typing a word and taking letters back while it is still being typed
    SetWindowTextW(e, L""); Wait(200);
    RealText("kala"); Wait(500);
    std::wstring a = EditText(e); printf("typed 'kala':"); Hex(a); printf("\n");
    RealKey(VK_BACK); Wait(400);
    std::wstring b = EditText(e); printf("Backspace in the word:"); Hex(b); printf("\n");
    check(a != b && !b.empty(), "Backspace while typing a word changes the word");
    RealKey(VK_BACK); RealKey(VK_BACK); Wait(400);
    std::wstring c = EditText(e); printf("Backspace x2 more:"); Hex(c); printf("\n");
    check(c.empty(), "the last Backspace leaves the box empty");
    shot(L"4-backspace-in-word.bmp");
    RealText("ba"); Wait(600); shot(L"5-candidates-visible.bmp");
    printf("%d/%d passed (a real window, the installed text service, real key presses)\n", total - bad, total);
    DestroyWindow(w);
    return bad ? 1 : 0;
}

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);
    {   // started by the text service as the program (see --launch): leave a mark and go
        wchar_t me[MAX_PATH]; GetModuleFileNameW(nullptr, me, MAX_PATH);
        std::wstring m = me; size_t sl = m.find_last_of(L"\\/");
        bool fake = _wcsicmp(m.c_str() + (sl == std::wstring::npos ? 0 : sl + 1), L"Sulekhak.exe") == 0;
        if (fake && argc > 1 && std::string(argv[1]) == "--from-text-service") {
            HANDLE f = CreateFileW(MarkerPath().c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
            if (f != INVALID_HANDLE_VALUE) { DWORD w; WriteFile(f, "started\n", 8, &w, nullptr); CloseHandle(f); }
            return 0;
        }
    }
    if (argc > 2 && std::string(argv[1]) == "--launch") return LaunchTest(argv[2]);
    if (argc > 2 && std::string(argv[1]) == "--gui") { int n = MultiByteToWideChar(CP_UTF8, 0, argv[2], -1, nullptr, 0); std::wstring d(n, 0); MultiByteToWideChar(CP_UTF8, 0, argv[2], -1, &d[0], n); d.resize(n - 1); return GuiTest(d.c_str()); }
    if (argc > 1 && std::string(argv[1]) == "--activate") return ActivateProfileTest();
    if (argc > 1 && std::string(argv[1]) == "--list") return ListProfiles(false);
    if (argc > 1 && std::string(argv[1]) == "--expect-none") return ListProfiles(true);
    bool noReg = false;
    for (int i = 2; i < argc; i++) if (std::string(argv[i]) == "--no-reg") noReg = true;
    g_wine = (argc > 2 && std::string(argv[2]) == "--wine") || GetProcAddress(GetModuleHandleA("ntdll.dll"), "wine_get_version") != nullptr;
    HINSTANCE dll = argc > 1 ? LoadLibraryA(argv[1]) : nullptr;
    if (!dll) { printf("cannot load the DLL\n"); return 2; }
    typedef HRESULT (STDAPICALLTYPE *Reg)();
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (!noReg && FAILED(((Reg)GetProcAddress(dll, "DllRegisterServer"))())) { printf("DllRegisterServer failed\n"); return 3; }
    HANDLE pt = CreateThread(nullptr, 0, PipeThread, nullptr, 0, nullptr);
    ITfThreadMgr* tm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_ThreadMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfThreadMgr, (void**)&tm))) { printf("no thread manager\n"); return 4; }
    TfClientId tid = 0;
    {   // a program that can draw UI elements itself (the Start / Search box) activates its thread this way; without the flag Windows does not pass UI elements on to the program's sink
        ITfThreadMgrEx* tex = nullptr; HRESULT hx = E_FAIL;
        if (SUCCEEDED(tm->QueryInterface(IID_ITfThreadMgrEx, (void**)&tex)) && tex) { hx = tex->ActivateEx(&tid, 0x4 /* TF_TMAE_UIELEMENTENABLEDONLY */); DWORD fl = 0; tex->GetActiveFlags(&fl); printf("thread manager ActivateEx(UIELEMENTENABLEDONLY): %08lx, active flags %08lx\n", (unsigned long)hx, (unsigned long)fl); tex->Release(); }
        if (FAILED(hx)) tm->Activate(&tid);
    }
    ITfDocumentMgr* dm = nullptr; tm->CreateDocumentMgr(&dm);
    TextStore ts; ITfContext* ctx = nullptr; TfEditCookie ec = 0;
    if (FAILED(dm->CreateContext(tid, 0, static_cast<ITextStoreACP*>(&ts), &ctx, &ec))) { printf("no context\n"); return 5; }
    dm->Push(ctx);
    ITfDocumentMgr* prev = nullptr; tm->SetFocus(dm);
    ITfInputProcessorProfiles* pp = nullptr;
    CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfiles, (void**)&pp);
    pp->EnableLanguageProfile(CLSID_SulekhakTip, 0x0448, GUID_ProfileOdia, TRUE);
    HRESULT ha = pp->ActivateLanguageProfile(CLSID_SulekhakTip, 0x0448, GUID_ProfileOdia);
    printf("activate profile: %08lx\n", (unsigned long)ha);
    Pump();
    tm->QueryInterface(IID_ITfKeystrokeMgr, (void**)&g_km);
    g_ctx = ctx;
    // the text service itself, created and activated as the system would do it
    ITfTextInputProcessor* tip = nullptr;
    HRESULT hc = CoCreateInstance(CLSID_SulekhakTip, nullptr, CLSCTX_INPROC_SERVER, IID_ITfTextInputProcessor, (void**)&tip);
    printf("create text service: %08lx\n", (unsigned long)hc);
    if (FAILED(hc)) return 6;
    HRESULT hact = tip->Activate(tm, tid);
    printf("activate text service: %08lx\n", (unsigned long)hact);
    if (FAILED(tip->QueryInterface(IID_ITfKeyEventSink, (void**)&g_sink))) { printf("no key sink\n"); return 7; }
    Sleep(100);

    // a word and a space
    Reset(); Str(L"ba"); Press(VK_SPACE);
    Check("ba + Space types the word and a space", g_text, L"ବ ");
    // Enter picks with a space
    Reset(); Str(L"badi"); Press(VK_RETURN);
    Check("badi + Enter", g_text, L"ବଡି ");
    // the nukta key after it
    Chr(L'>');
    if (!Skip("a lone > after the word marks the ଡ")) Check("a lone > after the word marks the ଡ", g_text, L"ବଡ଼ି ");
    // composing is visible while typing
    Reset(); Str(L"ba");
    if (!Skip("while typing the first word is shown")) Check("while typing the first word is shown", g_text, L"ବ");
    Press(VK_ESCAPE);
    Check("Esc throws it away", g_text, L"");
    // punctuation ends the word
    Reset(); Str(L"bad,");
    Check("punctuation ends the word", g_text, L"ବଡ,");
    // a dot opens the list, 1 picks the danda
    Reset(); Chr(L'.'); Chr(L'1');
    Check(". then 1 types the danda", g_text, L"। ");
    // halant word: Space still types a space
    Reset(); Str(L"ba`"); Press(VK_SPACE);
    Check("a word ending in halant: Space types a space", g_text, L"ବ୍ ");
    // Backspace over typed Odia removes one code point
    Reset(); g_text = L"କ୍ଷି"; g_selStart = g_selEnd = 4;
    bool eaten = Press(VK_BACK);
    if (!Skip("Backspace removes the vowel sign only")) {
        Check("Backspace removes the vowel sign only", g_text, L"କ୍ଷ");
        g_total++; if (!eaten) { g_bad++; printf("FAIL that Backspace was used up\n"); } else printf("ok   Backspace was used up\n");
    }
    Reset(); g_text = L"abc"; g_selStart = g_selEnd = 3;
    eaten = Press(VK_BACK);
    g_total++; if (eaten || g_text != L"abc") { g_bad++; printf("FAIL Backspace over other text goes to the program\n"); } else printf("ok   Backspace over other text goes to the program\n");
    // arrow with a word: the word is typed, the key is the program's
    Reset(); Str(L"ba"); eaten = Press(VK_LEFT);
    if (!Skip("Left types the word")) Check("Left types the word", g_text, L"ବ");
    g_total++; if (eaten) { g_bad++; printf("FAIL Left is the program's\n"); } else printf("ok   Left is the program's\n");

    // the program draws the candidate list itself (the Start / Search box): Sulekhak hands it the words and draws nothing of its own
    if (!Skip("a program that draws the list itself (UI-less mode)")) {
        g_uiTm = tm;
        static UiHost host; ITfSource* usrc = nullptr; DWORD ucookie = 0;
        bool advised = SUCCEEDED(tm->QueryInterface(IID_ITfSource, (void**)&usrc)) && usrc && SUCCEEDED(usrc->AdviseSink(IID_ITfUIElementSink, static_cast<ITfUIElementSink*>(&host), &ucookie));
        g_total++; if (!advised) { g_bad++; printf("FAIL cannot advise an ITfUIElementSink\n"); } else printf("ok   a program can listen to UI elements\n");
        if (advised) {
            g_hostShowAnswer = false;            // "I draw the list"
            {   // diagnosis: does Windows pass an element the driver announces itself to the sink?
                ITfUIElementMgr* um = nullptr; DummyEl de; BOOL sh = TRUE; DWORD uid = 0; int b0 = g_hostBegin;
                if (SUCCEEDED(tm->QueryInterface(IID_ITfUIElementMgr, (void**)&um)) && um) {
                    HRESULT hb = um->BeginUIElement(&de, &sh, &uid);
                    printf("probe: the driver's own BeginUIElement hr=%08lx show=%d sink calls=%d\n", (unsigned long)hb, (int)sh, g_hostBegin - b0);
                    um->EndUIElement(uid); um->Release();
                    g_hostBegin = 0; g_hostEnd = 0; g_hostUpdate = 0;
                }
            }
            // keys now go through the system's key manager to the keyboard Windows itself loaded (the directly created one is not a registered, active service)
            ITfKeyEventSink* directSink = g_sink;
            {   BOOL tt = FALSE; g_km->TestKeyDown('B', 1 | (MapVirtualKeyW('B', MAPVK_VK_TO_VSC) << 16), &tt); printf("probe: ITfKeystrokeMgr::TestKeyDown(B) -> %d\n", (int)tt); }
            long listsBefore = (long)g_lists;
            Reset(); Str(L"ba");
            printf("counters after 'ba': begin=%d update=%d end=%d words=%zu\n", g_hostBegin, g_hostUpdate, g_hostEnd, g_hostList.size());
            g_total++; if (g_hostBegin < 1) { g_bad++; printf("FAIL the keyboard did not announce its candidate list (BeginUIElement)\n"); } else printf("ok   the keyboard announced its candidate list\n");
            g_total++; if (g_hostList.size() < 2) { g_bad++; printf("FAIL the program got %zu words (want several)\n", g_hostList.size()); } else { printf("ok   the program got %zu words, first:", g_hostList.size()); for (wchar_t c : g_hostList[0]) printf(" %04X", c); printf("\n"); }
            g_total++; if (g_hostList.empty() || g_hostList[0].empty()) { g_bad++; printf("FAIL the first word is empty\n"); } else printf("ok   the first word is not empty\n");
            g_total++; if ((long)g_lists != listsBefore) { g_bad++; printf("FAIL Sulekhak still drew its own list although the program draws it\n"); } else printf("ok   Sulekhak drew no list of its own\n");
            Chr(L'd'); Chr(L'i');
            printf("counters after 'badi': begin=%d update=%d end=%d words=%zu\n", g_hostBegin, g_hostUpdate, g_hostEnd, g_hostList.size());
            g_total++; if (g_hostUpdate < 1) { g_bad++; printf("FAIL no UpdateUIElement while typing\n"); } else printf("ok   the program was told about every change (%d updates)\n", g_hostUpdate);
            Press(VK_ESCAPE);
            printf("counters after Esc: begin=%d update=%d end=%d\n", g_hostBegin, g_hostUpdate, g_hostEnd);
            g_total++; if (g_hostEnd < 1) { g_bad++; printf("FAIL the list was never ended (EndUIElement)\n"); } else printf("ok   the list was ended when the word was finished\n");
            // a program that wants Sulekhak to draw: answers "show"
            g_hostShowAnswer = true; listsBefore = (long)g_lists;
            Reset(); Str(L"ba"); Sleep(50);
            g_total++; if ((long)g_lists == listsBefore) { g_bad++; printf("FAIL Sulekhak drew no list although the program asked for it\n"); } else printf("ok   Sulekhak draws its own list when the program does not\n");
            Press(VK_ESCAPE);
            g_sink = directSink;
            usrc->UnadviseSink(ucookie); usrc->Release();
        }
    }
    g_total++; if (g_queries == 0) { g_bad++; printf("FAIL the engine pipe was never used\n"); } else printf("ok   the engine pipe was used (%ld queries, %ld candidate lists, %ld learned)\n", (long)g_queries, (long)g_lists, (long)g_learned);

    g_quit = 1;
    printf("%d/%d passed, %d skipped (real TSF, Sulekhak text service%s)\n", g_total - g_bad, g_total, g_skipped, g_wine ? ", under Wine" : "");
    if (!noReg) ((HRESULT (STDAPICALLTYPE *)())GetProcAddress(dll, "DllUnregisterServer"))();
    return g_bad ? 1 : 0;
}
