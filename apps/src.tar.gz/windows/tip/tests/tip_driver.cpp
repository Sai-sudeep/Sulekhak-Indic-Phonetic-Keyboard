// Drives the real text service through the real TSF: a thread manager, a document with a small text store, the Sulekhak profile activated,
// keys sent through ITfKeystrokeMgr, and a stand-in for the engine on the named pipe. It runs on Windows and under Wine:  tip_driver.exe <dll>
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <msctf.h>
#include <sddl.h>
#include <cstdio>
#include <string>
#include <vector>
#include "../guids.h"

static std::wstring g_text; static LONG g_selStart = 0, g_selEnd = 0;

class TextStore : public ITextStoreACP {
public:
    STDMETHODIMP QueryInterface(REFIID r, void** p) override { if (r == IID_IUnknown || r == IID_ITextStoreACP) { *p = static_cast<ITextStoreACP*>(this); return S_OK; } *p = nullptr; return E_NOINTERFACE; }
    STDMETHODIMP_(ULONG) AddRef() override { return 2; }
    STDMETHODIMP_(ULONG) Release() override { return 1; }
    STDMETHODIMP AdviseSink(REFIID r, IUnknown* u, DWORD mask) override { if (r != IID_ITextStoreACPSink) return E_INVALIDARG; if (sink_) return ((HRESULT)0x80040201L); u->QueryInterface(IID_ITextStoreACPSink, (void**)&sink_); return S_OK; }
    STDMETHODIMP UnadviseSink(IUnknown*) override { if (sink_) { sink_->Release(); sink_ = nullptr; } return S_OK; }
    STDMETHODIMP RequestLock(DWORD flags, HRESULT* phr) override {
        if (locked_) { *phr = TS_E_SYNCHRONOUS; return S_OK; }
        locked_ = true; *phr = sink_->OnLockGranted(flags); locked_ = false; return S_OK;
    }
    STDMETHODIMP GetStatus(TS_STATUS* s) override { s->dwDynamicFlags = 0; s->dwStaticFlags = TS_SS_NOHIDDENTEXT; return S_OK; }
    STDMETHODIMP QueryInsert(LONG s, LONG e, ULONG cch, LONG* rs, LONG* re) override { *rs = s; *re = e; return S_OK; }
    STDMETHODIMP GetSelection(ULONG idx, ULONG cnt, TS_SELECTION_ACP* sel, ULONG* fetched) override {
        if (idx != 0 && idx != TS_DEFAULT_SELECTION) return E_INVALIDARG;
        sel[0].acpStart = g_selStart; sel[0].acpEnd = g_selEnd; sel[0].style.ase = TS_AE_END; sel[0].style.fInterimChar = FALSE; *fetched = 1; return S_OK;
    }
    STDMETHODIMP SetSelection(ULONG cnt, const TS_SELECTION_ACP* sel) override { g_selStart = sel[0].acpStart; g_selEnd = sel[0].acpEnd; return S_OK; }
    STDMETHODIMP GetText(LONG s, LONG e, WCHAR* plain, ULONG cch, ULONG* ret, TS_RUNINFO* ri, ULONG cri, ULONG* rri, LONG* next) override {
        LONG end = e == -1 ? (LONG)g_text.size() : e;
        if (s < 0 || end > (LONG)g_text.size() || s > end) return TS_E_INVALIDPOS;
        ULONG n = (ULONG)(end - s); if (n > cch) n = cch;
        if (plain) for (ULONG i = 0; i < n; i++) plain[i] = g_text[s + i];
        if (ret) *ret = n;
        if (ri && cri) { ri[0].uCount = n; ri[0].type = TS_RT_PLAIN; if (rri) *rri = 1; } else if (rri) *rri = 0;
        if (next) *next = s + n;
        return S_OK;
    }
    STDMETHODIMP SetText(DWORD, LONG s, LONG e, const WCHAR* t, ULONG cch, TS_TEXTCHANGE* ch) override {
        if (s < 0 || e > (LONG)g_text.size() || s > e) return TS_E_INVALIDPOS;
        g_text = g_text.substr(0, s) + std::wstring(t, cch) + g_text.substr(e);
        g_selStart = g_selEnd = s + (LONG)cch;
        if (ch) { ch->acpStart = s; ch->acpOldEnd = e; ch->acpNewEnd = s + (LONG)cch; }
        return S_OK;
    }
    STDMETHODIMP GetFormattedText(LONG, LONG, IDataObject**) override { return E_NOTIMPL; }
    STDMETHODIMP GetEmbedded(LONG, REFGUID, REFIID, IUnknown**) override { return E_NOTIMPL; }
    STDMETHODIMP QueryInsertEmbedded(const GUID*, const FORMATETC*, BOOL* ok) override { *ok = FALSE; return S_OK; }
    STDMETHODIMP InsertEmbedded(DWORD, LONG, LONG, IDataObject*, TS_TEXTCHANGE*) override { return E_NOTIMPL; }
    STDMETHODIMP InsertTextAtSelection(DWORD flags, const WCHAR* t, ULONG cch, LONG* s, LONG* e, TS_TEXTCHANGE* ch) override {
        LONG a = g_selStart, b = g_selEnd;
        if (flags & TS_IAS_QUERYONLY) { if (s) *s = a; if (e) *e = b; return S_OK; }
        g_text = g_text.substr(0, a) + std::wstring(t, cch) + g_text.substr(b);
        g_selStart = g_selEnd = a + (LONG)cch;
        if (s) *s = a; if (e) *e = a + (LONG)cch;
        if (ch) { ch->acpStart = a; ch->acpOldEnd = b; ch->acpNewEnd = a + (LONG)cch; }
        return S_OK;
    }
    STDMETHODIMP InsertEmbeddedAtSelection(DWORD, IDataObject*, LONG*, LONG*, TS_TEXTCHANGE*) override { return E_NOTIMPL; }
    STDMETHODIMP RequestSupportedAttrs(DWORD, ULONG, const TS_ATTRID*) override { return E_NOTIMPL; }
    STDMETHODIMP RequestAttrsAtPosition(LONG, ULONG, const TS_ATTRID*, DWORD) override { return E_NOTIMPL; }
    STDMETHODIMP RequestAttrsTransitioningAtPosition(LONG, ULONG, const TS_ATTRID*, DWORD) override { return E_NOTIMPL; }
    STDMETHODIMP FindNextAttrTransition(LONG, LONG, ULONG, const TS_ATTRID*, DWORD, LONG*, BOOL*, LONG*) override { return E_NOTIMPL; }
    STDMETHODIMP RetrieveRequestedAttrs(ULONG, TS_ATTRVAL*, ULONG* ret) override { *ret = 0; return S_OK; }
    STDMETHODIMP GetEndACP(LONG* a) override { *a = (LONG)g_text.size(); return S_OK; }
    STDMETHODIMP GetActiveView(TsViewCookie* v) override { *v = 1; return S_OK; }
    STDMETHODIMP GetACPFromPoint(TsViewCookie, const POINT*, DWORD, LONG* a) override { *a = 0; return S_OK; }
    STDMETHODIMP GetTextExt(TsViewCookie, LONG, LONG, RECT* rc, BOOL* clipped) override { *rc = {100, 100, 160, 130}; *clipped = FALSE; return S_OK; }
    STDMETHODIMP GetScreenExt(TsViewCookie, RECT* rc) override { *rc = {0, 0, 800, 600}; return S_OK; }
    STDMETHODIMP GetWnd(TsViewCookie, HWND* w) override { *w = GetDesktopWindow(); return S_OK; }
private:
    ITextStoreACPSink* sink_ = nullptr; bool locked_ = false;
};

// ---- a stand-in for the Sulekhak program's engine on the pipe
static std::wstring PipeName() {
    std::wstring sid = L"user"; HANDLE tok = nullptr;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) {
        DWORD n = 0; GetTokenInformation(tok, TokenUser, nullptr, 0, &n); std::vector<BYTE> b(n ? n : 1);
        if (n && GetTokenInformation(tok, TokenUser, b.data(), n, &n)) { wchar_t* s = nullptr; if (ConvertSidToStringSidW(((TOKEN_USER*)b.data())->User.Sid, &s)) { sid = s; LocalFree(s); } }
        CloseHandle(tok);
    }
    return L"\\\\.\\pipe\\SulekhakTip-" + sid;
}
static std::string W2U(const std::wstring& s) { int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), 0, 0, 0, 0); std::string o(n, 0); WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), &o[0], n, 0, 0); return o; }
static volatile LONG g_quit = 0, g_queries = 0, g_lists = 0, g_learned = 0;
static std::string Answer(const std::string& q) {
    if (q.empty()) return "K";
    if (q[0] == 'G') return "T\t0\t0";
    if (q[0] == 'P') { InterlockedIncrement(&g_lists); return "K"; }
    if (q[0] == 'L') { InterlockedIncrement(&g_learned); return "K"; }
    if (q[0] == 'Q') {
        InterlockedIncrement(&g_queries);
        size_t p = q.rfind('\t'); std::string buf = q.substr(p + 1);
        if (buf == "ba") return "C\t" + W2U(L"ବ") + "\t" + W2U(L"ା");
        if (buf == "badi") return "C\t" + W2U(L"ବଡି");
        if (buf == "bad") return "C\t" + W2U(L"ବଡ");
        if (buf == "ba`") return "C\t" + W2U(L"ବ୍");
        if (buf == ".") return "C\t" + W2U(L"।") + "\t.\t" + W2U(L"॥");
        return "C\t" + buf;
    }
    return "K";
}
static DWORD WINAPI PipeThread(LPVOID) {
    std::wstring name = PipeName();
    while (!g_quit) {
        HANDLE h = CreateNamedPipeW(name.c_str(), PIPE_ACCESS_DUPLEX, PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT, 8, 8192, 8192, 0, nullptr);
        if (h == INVALID_HANDLE_VALUE) { Sleep(50); continue; }
        if (ConnectNamedPipe(h, nullptr) || GetLastError() == ERROR_PIPE_CONNECTED) {
            for (;;) {
                char buf[8192]; DWORD n = 0;
                if (!ReadFile(h, buf, sizeof buf, &n, nullptr)) break;
                std::string a = Answer(std::string(buf, n)); DWORD w;
                if (!WriteFile(h, a.data(), (DWORD)a.size(), &w, nullptr)) break;
            }
        }
        DisconnectNamedPipe(h); CloseHandle(h);
    }
    return 0;
}

static ITfKeystrokeMgr* g_km = nullptr;
static ITfKeyEventSink* g_sink = nullptr;     // the text service's own key sink, called directly when the system's key manager cannot dispatch (Wine)
static ITfContext* g_ctx = nullptr;
static void Pump() { MSG m; while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); } }
static void SetMods(bool shift, bool ctrl = false) { BYTE st[256] = {}; if (shift) st[VK_SHIFT] = 0x80; if (ctrl) st[VK_CONTROL] = 0x80; SetKeyboardState(st); }
static bool Press(UINT vk, bool shift = false, bool ctrl = false) {
    SetMods(shift, ctrl);
    LPARAM lp = 1 | (MapVirtualKeyW(vk, MAPVK_VK_TO_VSC) << 16);
    BOOL t = FALSE, e = FALSE;
    if (g_sink) { g_sink->OnTestKeyDown(g_ctx, vk, lp, &t); if (t) g_sink->OnKeyDown(g_ctx, vk, lp, &e); }
    else { g_km->TestKeyDown(vk, lp, &t); if (t) g_km->KeyDown(vk, lp, &e); }
    Pump();
    SetMods(false);
    if (getenv("TIPDBG")) { printf("  key %02x t=%d e=%d text=", vk, (int)t, (int)e); for (wchar_t c : g_text) printf("%04X ", c); printf(" sel=%ld-%ld\n", g_selStart, g_selEnd); }
    return t && e;
}
static bool Chr(wchar_t c) {
    if (c >= L'a' && c <= L'z') return Press(c - 32);
    if (c >= L'A' && c <= L'Z') return Press(c, true);
    if (c >= L'0' && c <= L'9') return Press(c);
    switch (c) { case L'.': return Press(VK_OEM_PERIOD); case L'>': return Press(VK_OEM_PERIOD, true); case L',': return Press(VK_OEM_COMMA); case L'`': return Press(VK_OEM_3); case L'~': return Press(VK_OEM_3, true); }
    return false;
}
static void Str(const wchar_t* s) { for (; *s; s++) Chr(*s); }

static int g_bad = 0, g_total = 0, g_skipped = 0;
static bool g_wine = false;     // Wine's text services lack ITfRange::Clone and ITfContextComposition: those checks only run on Windows
static bool Skip(const char* name) { if (!g_wine) return false; g_skipped++; printf("skip %s (Wine)\n", name); return true; }
static void Check(const char* name, const std::wstring& got, const std::wstring& want) {
    g_total++;
    if (got != want) { g_bad++; printf("FAIL %s\n  expected:", name); for (wchar_t c : want) printf(" %04X", c); printf("\n  got:     "); for (wchar_t c : got) printf(" %04X", c); printf("\n"); }
    else printf("ok   %s\n", name);
}
static void Reset() { g_text.clear(); g_selStart = g_selEnd = 0; }

// --list / --expect-none: counts the Sulekhak keyboards the system itself reports (the list Win+Space and Settings are built from).
static int ListProfiles(bool expectNone) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    ITfInputProcessorProfiles* pp = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfiles, (void**)&pp))) { printf("no profile manager\n"); return 4; }
    static const struct { LANGID lang; const GUID* g; const char* n; } want[] = {
        { 0x0409, &GUID_ProfileAll, "All Languages" }, { 0x0448, &GUID_ProfileOdia, "Odia" }, { 0x0439, &GUID_ProfileHindi, "Hindi" },
        { 0x044E, &GUID_ProfileMarathi, "Marathi" }, { 0x0445, &GUID_ProfileBangla, "Bangla" }, { 0x044D, &GUID_ProfileAssamese, "Assamese" } };
    int found = 0, enabled = 0;
    for (auto& w : want) {
        IEnumTfLanguageProfiles* en = nullptr;
        bool seen = false;
        if (SUCCEEDED(pp->EnumLanguageProfiles(w.lang, &en)) && en) {
            TF_LANGUAGEPROFILE lp; ULONG n = 0;
            while (en->Next(1, &lp, &n) == S_OK && n == 1) {
                if (IsEqualGUID(lp.clsid, CLSID_SulekhakTip) && IsEqualGUID(lp.guidProfile, *w.g)) seen = true;
            }
            en->Release();
        }
        BOOL en2 = FALSE;
        if (seen) { pp->IsEnabledLanguageProfile(CLSID_SulekhakTip, w.lang, *w.g, &en2); found++; if (en2) enabled++; }
        printf("%-14s lang %04X  %s%s\n", w.n, w.lang, seen ? "listed" : "absent", seen && en2 ? ", enabled" : "");
    }
    pp->Release();
    printf("%d of 6 Sulekhak keyboards listed, %d enabled\n", found, enabled);
    if (expectNone) return found == 0 ? 0 : 1;
    return found == 6 ? 0 : 1;
}


#ifndef TF_IPPMF_FORPROCESS
#define TF_IPPMF_FORPROCESS 0x10000000
#define TF_IPPMF_ENABLEPROFILE 0x00000001
#endif
// --activate: Windows itself activates one of the Sulekhak keyboards in this process (what choosing it in Win+Space does) and loads the DLL.
static int ActivateProfileTest() {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    ITfThreadMgr* tm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_ThreadMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfThreadMgr, (void**)&tm))) { printf("no thread manager\n"); return 4; }
    TfClientId tid = 0; tm->Activate(&tid);
    ITfDocumentMgr* dm = nullptr; tm->CreateDocumentMgr(&dm);
    TextStore ts; ITfContext* ctx = nullptr; TfEditCookie ec = 0;
    dm->CreateContext(tid, 0, static_cast<ITextStoreACP*>(&ts), &ctx, &ec); dm->Push(ctx); tm->SetFocus(dm);
    ITfInputProcessorProfileMgr* pm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfileMgr, (void**)&pm))) { printf("no profile manager (ITfInputProcessorProfileMgr)\n"); return 5; }
    HRESULT h = pm->ActivateProfile(TF_PROFILETYPE_INPUTPROCESSOR, 0x0448, CLSID_SulekhakTip, GUID_ProfileOdia, nullptr, TF_IPPMF_FORPROCESS | TF_IPPMF_ENABLEPROFILE);
    printf("ActivateProfile(Odia): %08lx\n", (unsigned long)h);
    DWORD t0 = GetTickCount(); MSG m;
    while (GetTickCount() - t0 < 3000) { while (PeekMessage(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessage(&m); } Sleep(20); }
    TF_INPUTPROCESSORPROFILE act; ZeroMemory(&act, sizeof act);
    HRESULT g = pm->GetActiveProfile(GUID_TFCAT_TIP_KEYBOARD, &act);
    bool ours = SUCCEEDED(g) && IsEqualGUID(act.clsid, CLSID_SulekhakTip) && IsEqualGUID(act.guidProfile, GUID_ProfileOdia);
    HMODULE mod = GetModuleHandleW(L"sulekhak_tip_x64.dll"); if (!mod) mod = GetModuleHandleW(L"sulekhak_tip_x86.dll");
    printf("GetActiveProfile: %08lx, active is Sulekhak Odia: %s\n", (unsigned long)g, ours ? "yes" : "no");
    printf("Windows loaded the text service DLL into this process: %s\n", mod ? "yes" : "no");
    return (SUCCEEDED(h) && ours && mod) ? 0 : 1;
}

int main(int argc, char** argv) {
    if (argc > 1 && std::string(argv[1]) == "--activate") return ActivateProfileTest();
    if (argc > 1 && std::string(argv[1]) == "--list") return ListProfiles(false);
    if (argc > 1 && std::string(argv[1]) == "--expect-none") return ListProfiles(true);
    bool noReg = false;
    for (int i = 2; i < argc; i++) if (std::string(argv[i]) == "--no-reg") noReg = true;
    g_wine = (argc > 2 && std::string(argv[2]) == "--wine") || GetProcAddress(GetModuleHandleA("ntdll.dll"), "wine_get_version") != nullptr;
    HINSTANCE dll = argc > 1 ? LoadLibraryA(argv[1]) : nullptr;
    if (!dll) { printf("cannot load the DLL\n"); return 2; }
    typedef HRESULT (STDAPICALLTYPE *Reg)();
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (!noReg && FAILED(((Reg)GetProcAddress(dll, "DllRegisterServer"))())) { printf("DllRegisterServer failed\n"); return 3; }
    HANDLE pt = CreateThread(nullptr, 0, PipeThread, nullptr, 0, nullptr);
    ITfThreadMgr* tm = nullptr;
    if (FAILED(CoCreateInstance(CLSID_TF_ThreadMgr, nullptr, CLSCTX_INPROC_SERVER, IID_ITfThreadMgr, (void**)&tm))) { printf("no thread manager\n"); return 4; }
    TfClientId tid = 0; tm->Activate(&tid);
    ITfDocumentMgr* dm = nullptr; tm->CreateDocumentMgr(&dm);
    TextStore ts; ITfContext* ctx = nullptr; TfEditCookie ec = 0;
    if (FAILED(dm->CreateContext(tid, 0, static_cast<ITextStoreACP*>(&ts), &ctx, &ec))) { printf("no context\n"); return 5; }
    dm->Push(ctx);
    ITfDocumentMgr* prev = nullptr; tm->SetFocus(dm);
    ITfInputProcessorProfiles* pp = nullptr;
    CoCreateInstance(CLSID_TF_InputProcessorProfiles, nullptr, CLSCTX_INPROC_SERVER, IID_ITfInputProcessorProfiles, (void**)&pp);
    pp->EnableLanguageProfile(CLSID_SulekhakTip, 0x0448, GUID_ProfileOdia, TRUE);
    HRESULT ha = pp->ActivateLanguageProfile(CLSID_SulekhakTip, 0x0448, GUID_ProfileOdia);
    printf("activate profile: %08lx\n", (unsigned long)ha);
    Pump();
    tm->QueryInterface(IID_ITfKeystrokeMgr, (void**)&g_km);
    g_ctx = ctx;
    // the text service itself, created and activated as the system would do it
    ITfTextInputProcessor* tip = nullptr;
    HRESULT hc = CoCreateInstance(CLSID_SulekhakTip, nullptr, CLSCTX_INPROC_SERVER, IID_ITfTextInputProcessor, (void**)&tip);
    printf("create text service: %08lx\n", (unsigned long)hc);
    if (FAILED(hc)) return 6;
    HRESULT hact = tip->Activate(tm, tid);
    printf("activate text service: %08lx\n", (unsigned long)hact);
    if (FAILED(tip->QueryInterface(IID_ITfKeyEventSink, (void**)&g_sink))) { printf("no key sink\n"); return 7; }
    Sleep(100);

    // a word and a space
    Reset(); Str(L"ba"); Press(VK_SPACE);
    Check("ba + Space types the word and a space", g_text, L"ବ ");
    // Enter picks with a space
    Reset(); Str(L"badi"); Press(VK_RETURN);
    Check("badi + Enter", g_text, L"ବଡି ");
    // the nukta key after it
    Chr(L'>');
    if (!Skip("a lone > after the word marks the ଡ")) Check("a lone > after the word marks the ଡ", g_text, L"ବଡ଼ି ");
    // composing is visible while typing
    Reset(); Str(L"ba");
    if (!Skip("while typing the first word is shown")) Check("while typing the first word is shown", g_text, L"ବ");
    Press(VK_ESCAPE);
    Check("Esc throws it away", g_text, L"");
    // punctuation ends the word
    Reset(); Str(L"bad,");
    Check("punctuation ends the word", g_text, L"ବଡ,");
    // a dot opens the list, 1 picks the danda
    Reset(); Chr(L'.'); Chr(L'1');
    Check(". then 1 types the danda", g_text, L"। ");
    // halant word: Space still types a space
    Reset(); Str(L"ba`"); Press(VK_SPACE);
    Check("a word ending in halant: Space types a space", g_text, L"ବ୍ ");
    // Backspace over typed Odia removes one code point
    Reset(); g_text = L"କ୍ଷି"; g_selStart = g_selEnd = 4;
    bool eaten = Press(VK_BACK);
    if (!Skip("Backspace removes the vowel sign only")) {
        Check("Backspace removes the vowel sign only", g_text, L"କ୍ଷ");
        g_total++; if (!eaten) { g_bad++; printf("FAIL that Backspace was used up\n"); } else printf("ok   Backspace was used up\n");
    }
    Reset(); g_text = L"abc"; g_selStart = g_selEnd = 3;
    eaten = Press(VK_BACK);
    g_total++; if (eaten || g_text != L"abc") { g_bad++; printf("FAIL Backspace over other text goes to the program\n"); } else printf("ok   Backspace over other text goes to the program\n");
    // arrow with a word: the word is typed, the key is the program's
    Reset(); Str(L"ba"); eaten = Press(VK_LEFT);
    if (!Skip("Left types the word")) Check("Left types the word", g_text, L"ବ");
    g_total++; if (eaten) { g_bad++; printf("FAIL Left is the program's\n"); } else printf("ok   Left is the program's\n");
    g_total++; if (g_queries == 0) { g_bad++; printf("FAIL the engine pipe was never used\n"); } else printf("ok   the engine pipe was used (%ld queries, %ld candidate lists, %ld learned)\n", (long)g_queries, (long)g_lists, (long)g_learned);

    g_quit = 1;
    printf("%d/%d passed, %d skipped (real TSF, Sulekhak text service%s)\n", g_total - g_bad, g_total, g_skipped, g_wine ? ", under Wine" : "");
    if (!noReg) ((HRESULT (STDAPICALLTYPE *)())GetProcAddress(dll, "DllUnregisterServer"))();
    return g_bad ? 1 : 0;
}
