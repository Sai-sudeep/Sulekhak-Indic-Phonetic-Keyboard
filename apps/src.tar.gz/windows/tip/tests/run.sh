#!/bin/sh
set -e
cd "$(dirname "$0")/.."
${CXX:-g++} -std=c++17 -Wall -Wextra -O1 -o /tmp/sk_tip_tests tests/core_tests.cpp tipcore.cpp
/tmp/sk_tip_tests
