// Native tests of the text service's logic: build and run with  sh tests/run.sh   (any C++17 compiler, no Windows needed).
#include "../tipcore.h"
#include <cstdio>
#include <fstream>
#include <map>
#include <sstream>
using namespace sk;

static std::string U8(const ustr& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); i++) {
        unsigned c = s[i];
        if (c < 0x80) o += (char)c; else if (c < 0x800) { o += (char)(0xC0 | (c >> 6)); o += (char)(0x80 | (c & 63)); }
        else { o += (char)(0xE0 | (c >> 12)); o += (char)(0x80 | ((c >> 6) & 63)); o += (char)(0x80 | (c & 63)); }
    }
    return o;
}
// A document that is a string with a caret at its end and at most one composition.
struct StrDoc : Doc {
    ustr text, comp; bool composing = false;
    ustr Before(int n) override { return text.size() > (size_t)n ? text.substr(text.size() - n) : text; }
    void Compose(const ustr& s) override { composing = true; comp = s; }
    void Commit(const ustr& s) override { text += s; comp.clear(); composing = false; }
    void EndEmpty() override { comp.clear(); composing = false; }
    void ReplaceBefore(int drop, const ustr& s) override { text = text.substr(0, text.size() - drop) + s; }
    ustr Shown() const { return text + (composing ? u"«" + comp + u"»" : ustr()); }
};
// An engine whose words are fixed: "ba" -> ବ, "bad" -> ବଡ, "ba." etc.
struct StubEngine : Engine {
    std::map<ustr, std::vector<ustr>> words; bool up = true; std::vector<std::string> learned;
    bool Query(int, const ustr& buf, const ustr&, std::vector<ustr>& out) override {
        if (!up) return false;
        auto it = words.find(buf);
        if (it != words.end()) out = it->second; else out = {buf};
        return true;
    }
    void Learn(int, const ustr& r, const ustr& w) override { learned.push_back(U8(r) + "=" + U8(w)); }
};

// The English engine: answers recorded from the real engine and the real data (tests/en_fixture.txt, made by gen_en_fixture.js).
struct EnEngine : Engine {
    std::map<std::string, std::vector<ustr>> ans; std::vector<std::string> learned; std::vector<std::string> prevs; std::vector<int> scripts; int shown = 0, hidden = 0;
    static ustr W(const std::string& u) { ustr o; for (size_t i = 0; i < u.size(); ) { unsigned c = (unsigned char)u[i]; int n = c < 0x80 ? 1 : c < 0xE0 ? 2 : 3; unsigned v = n == 1 ? c : n == 2 ? (c & 31) : (c & 15); for (int j = 1; j < n; j++) v = (v << 6) | ((unsigned char)u[i + j] & 63); o += (char16_t)v; i += n; } return o; }
    EnEngine() {
        std::ifstream f("tests/en_fixture.txt"); std::string line;
        while (std::getline(f, line)) {
            std::vector<std::string> p; size_t a = 0;
            while (true) { size_t b = line.find('\t', a); p.push_back(line.substr(a, b == std::string::npos ? std::string::npos : b - a)); if (b == std::string::npos) break; a = b + 1; }
            if (p.size() < 4) continue;
            std::vector<ustr> l; for (size_t i = 3; i < p.size(); i++) l.push_back(W(p[i]));
            ans[p[0] + "\t" + p[1]] = l;
        }
    }
    bool Query(int script, const ustr& buf, const ustr& prev, std::vector<ustr>& out) override {
        scripts.push_back(script); std::string t = U8(buf), pv = U8(prev); prevs.push_back(pv);
        auto it = ans.find(t + "\t" + pv);
        if (it == ans.end()) it = ans.find(t + "\t");
        if (it != ans.end()) out = it->second; else out = {buf};
        return true;
    }
    void ShowList(const std::vector<ustr>&, int, const ustr&) override { shown++; }
    void HideList() override { hidden++; }
    void LearnEnglish(const ustr& t, const ustr& w, const ustr& pv, const std::string& how, const ustr& passed) override {
        learned.push_back(U8(t) + ">" + U8(w) + "|" + U8(pv) + "|" + how + "|" + U8(passed));
    }
};
static Key K(char16_t ch) {
    Key k{0, ch, false, false, false, false};
    if (ch >= u'a' && ch <= u'z') k.vk = ch - 32; else if (ch >= u'A' && ch <= u'Z') { k.vk = ch; k.shift = true; }
    else if (ch == u'>') { k.vk = 0xBE; k.shift = true; } else if (ch == u'.') k.vk = 0xBE; else if (ch >= u'0' && ch <= u'9') k.vk = ch;
    else if (ch == u'|') { k.vk = 0xDC; k.shift = true; } else if (ch == u'*') { k.vk = 0x38; k.shift = true; } else if (ch == u'~') { k.vk = 0xC0; k.shift = true; }
    else if (ch == u',') k.vk = 0xBC; else if (ch == u';') k.vk = 0xBA; else if (ch == u'\'') k.vk = 0xDE; else if (ch == u'`') k.vk = 0xC0;
    return k;
}
static Key V(uint32_t vk, bool shift = false) { return Key{vk, 0, shift, false, false, false}; }

static int bad = 0, total = 0;
static void Expect(const char* name, const ustr& got, const char* want) {
    total++;
    if (U8(got) != want) { bad++; printf("FAIL %s\n  expected %s\n  got      %s\n", name, want, U8(got).c_str()); }
}
static void Expect(const char* name, bool got, bool want) { total++; if (got != want) { bad++; printf("FAIL %s: %d, expected %d\n", name, got, want); } }

struct Rig {
    StrDoc d; StubEngine e; Core c{&d, &e};
    Rig() {
        e.words[u"ba"] = {u"ବ", u"ା"};                                  // ବ
        e.words[u"bad"] = {u"ବଡ", u"ବଦ"};                    // ବଡ, ବଦ
        e.words[u"badi"] = {u"ବଡି"};                              // ବଡି
        e.words[u"5"] = {u"୫", u"5"};                                        // ୫
        e.words[u"."] = {u"।", u".", u"॥"};
        e.words[u"ka`"] = {u"କ୍"};                                      // କ୍ (ends in halant: the word goes on)
    }
    bool Type(const char16_t* s) { bool r = true; for (; *s; s++) r = c.OnKey(K(*s)); return r; }
};

struct EnRig {
    StrDoc d; EnEngine e; Core c{&d, &e};
    EnRig() { c.SetScript(6); }
    void Type(const char16_t* s) { for (; *s; s++) c.OnKey(K(*s)); }
};

int main() {
    // 1. every decision agrees with the reference (tests/decisions.txt is written by keymap/dump_decisions.js)
    {
        std::ifstream f("tests/decisions.txt");
        std::string line;
        static const char* names[] = {"letter","mark","gt","digit0","digit19","dot","bar","star","punct","space","enter","esc","bksp","tab","shtab","up","down","left","right","pgup","pgdn","nav","selnav","chord","chordDiscard"};
        while (std::getline(f, line)) {
            std::istringstream is(line);
            std::string st, cl, ch, eff; int n, sel;
            is >> st >> cl >> n >> sel >> ch; std::getline(is, eff); if (!eff.empty() && eff[0] == ' ') eff = eff.substr(1);
            Cls c = Cls::Nav; bool found = false;
            for (int i = 0; i < 25; i++) if (cl == names[i]) { c = (Cls)i; found = true; }
            total++;
            if (!found) { bad++; printf("FAIL unknown class %s\n", cl.c_str()); continue; }
            std::vector<std::string> d = Decide(st, c, n, sel, ch[0]);
            std::string got; for (size_t i = 0; i < d.size(); i++) { if (i) got += ","; got += d[i]; }
            if (got != eff) { bad++; printf("FAIL decision %s\n  expected %s\n  got      %s\n", line.substr(0, line.find_last_of(' ')).c_str(), eff.c_str(), got.c_str()); }
        }
    }
    // 2. whole typing sequences against a document
    { Rig r; r.Type(u"ba"); Expect("composing shows the first word", r.d.Shown(), "\xC2\xAB\xE0\xAC\xAC\xC2\xBB"); }
    { Rig r; r.Type(u"ba"); r.c.OnKey(V(0x20)); Expect("space types the word and a space", r.d.Shown(), "\xE0\xAC\xAC "); Expect("learned", r.e.learned.size() == 1 && r.e.learned[0] == "ba=\xE0\xAC\xAC", true); }
    { Rig r; r.Type(u"ba"); r.c.OnKey(V(0x0D)); Expect("enter picks with a space and is used up", r.d.Shown(), "\xE0\xAC\xAC "); }
    { Rig r; bool eaten = r.c.OnKey(V(0x0D)); Expect("enter with no word goes to the program", eaten, false); }
    { Rig r; r.Type(u"ba"); r.c.OnKey(V(0x09)); Expect("tab highlights the next word", r.d.Shown(), "\xC2\xAB\xE0\xAC\xBE\xC2\xBB"); r.c.OnKey(V(0x20)); Expect("and space types that one", r.d.Shown(), "\xE0\xAC\xBE "); }
    { Rig r; r.Type(u"ba"); r.Type(u"2"); Expect("digit picks the second word", r.d.Shown(), "\xE0\xAC\xBE "); }
    { Rig r; r.Type(u"ba"); r.Type(u"9"); Expect("no ninth word: ignored", r.d.Shown(), "\xC2\xAB\xE0\xAC\xAC\xC2\xBB"); }
    { Rig r; r.Type(u"ba,"); Expect("punctuation ends the word", r.d.Shown(), "\xE0\xAC\xAC,"); }
    { Rig r; r.Type(u"ba"); r.c.OnKey(V(0x1B)); Expect("escape throws the word away", r.d.Shown(), ""); }
    { Rig r; r.Type(u"bad"); r.c.OnKey(V(0x08)); Expect("backspace drops one letter of the buffer", r.d.Shown(), "\xC2\xAB\xE0\xAC\xAC\xC2\xBB"); r.c.OnKey(V(0x08)); r.c.OnKey(V(0x08)); Expect("and the last one ends the word", r.d.Shown(), ""); }
    { Rig r; r.Type(u"ba"); bool eaten = r.c.OnKey(V(0x25)); Expect("left arrow, one page: word typed", r.d.Shown(), "\xE0\xAC\xAC"); Expect("left arrow is then the program's", eaten, false); }
    { Rig r; r.Type(u"ba"); bool eaten = r.c.OnKey(V(0x25, true)); Expect("shift+left types the word", r.d.Shown(), "\xE0\xAC\xAC"); Expect("and goes on to select", eaten, false); }
    { Rig r; r.Type(u"ba"); Key k = V(0x08); k.ctrl = true; r.c.OnKey(k); Expect("ctrl+backspace throws the word away", r.d.Shown(), ""); }
    { Rig r; r.Type(u"ba"); Key k = K(u'c'); k.ctrl = true; bool eaten = r.c.OnKey(k); Expect("a shortcut types the word first", r.d.Shown(), "\xE0\xAC\xAC"); Expect("and is the program's", eaten, false); }
    { Rig r; r.Type(u"."); Expect("a dot opens the list", r.d.Shown(), "\xC2\xAB\xE0\xA5\xA4\xC2\xBB"); }
    { Rig r; r.Type(u".1"); Expect("1 picks the danda", r.d.Shown().substr(0, 1) == u"।" ? ustr(u"ok") : r.d.Shown(), "ok"); }
    { Rig r; r.Type(u"5"); Expect("a digit alone starts a number", r.d.Shown(), "\xC2\xAB\xE0\xAD\xAB\xC2\xBB"); }
    // 3. the nukta key
    { Rig r; r.d.text = u"ବଡି"; bool eaten = r.c.OnKey(K(u'>')); Expect("lone > marks the ଡ of the word before", r.d.Shown(), "\xE0\xAC\xAC\xE0\xAC\xA1\xE0\xAC\xBC\xE0\xAC\xBF"); Expect("and is used up", eaten, true); }
    { Rig r; r.d.text = u"କ"; r.c.OnKey(K(u'>')); Expect("with no ଡ a lone nukta is typed", r.d.Shown(), "\xE0\xAC\x95\xE0\xAC\xBC"); }
    { Rig r; r.d.text = u"ବଡି "; r.c.OnKey(K(u'>')); Expect("also after the space the pick added", r.d.Shown(), "\xE0\xAC\xAC\xE0\xAC\xA1\xE0\xAC\xBC\xE0\xAC\xBF "); }
    { Rig r; r.Type(u"bad>"); Expect("inside a word > goes to the buffer", r.d.Shown().size() > 0 && r.c.Buffer() == u"bad>", true); }
    // 4. backspace over the text already typed: one code point
    { Rig r; r.d.text = u"କ୍ଷି"; r.c.OnKey(V(0x08)); Expect("backspace removes the vowel sign only", r.d.Shown(), "\xE0\xAC\x95\xE0\xAD\x8D\xE0\xAC\xB7"); }
    { Rig r; r.d.text = u"ab"; bool eaten = r.c.OnKey(V(0x08)); Expect("other text: the program deletes", eaten, false); Expect("and nothing was removed", r.d.Shown(), "ab"); }
    // 5. words that go on, and an engine that is not there
    { Rig r; r.Type(u"ka`"); r.c.OnKey(V(0x0D)); Expect("a word ending in halant gets no space from Enter", r.d.Shown(), "\xE0\xAC\x95\xE0\xAD\x8D"); }
    { Rig r; r.Type(u"ka`"); r.c.OnKey(V(0x20)); Expect("but Space always types one", r.d.Shown(), "\xE0\xAC\x95\xE0\xAD\x8D "); }
    { Rig r; r.e.up = false; r.Type(u"ba"); r.c.OnKey(V(0x20)); Expect("engine away: the letters are typed as they are", r.d.Shown(), "ba "); }
    { Rig r; r.Type(u"ba"); r.c.Reset(); Expect("losing focus keeps the word", r.d.Shown(), "\xE0\xAC\xAC"); }

    // 6. English (script 6): the letters stay as typed; only Space corrects; Backspace right after a correction takes it back
    { EnRig r; r.Type(u"teh"); Expect("English: the typed letters stay in the document", r.d.Shown(), "\xC2\xABteh\xC2\xBB"); Expect("English: asks the engine as script 6", r.e.scripts.back() == 6, true); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x20)); Expect("English: Space applies the clear correction and adds a space", r.d.Shown(), "the "); Expect("English: learned as an automatic correction", r.e.learned.size() == 1 && r.e.learned[0] == "teh>the|<s>|auto|", true); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x20)); bool eaten = r.c.OnKey(V(0x08)); Expect("English: Backspace right after puts the typed letters back", r.d.Shown(), "teh "); Expect("English: and is used up", eaten, true); Expect("English: the refusal is learned", r.e.learned.size() == 2 && r.e.learned[1] == "teh>teh|<s>|revert|the", true); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x20)); r.c.OnKey(V(0x08)); bool eaten = r.c.OnKey(V(0x08)); Expect("English: a second Backspace is the program's", eaten, false); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x20)); r.Type(u"x"); bool eaten = r.c.OnKey(V(0x08)); r.c.OnKey(V(0x08)); Expect("English: after more typing Backspace only edits the word", r.d.Shown(), "the "); Expect("English: and nothing is taken back", eaten, true); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x20)); r.d.text = u"the elsewhere"; bool eaten = r.c.OnKey(V(0x08)); Expect("English: if the text changed the key goes to the program", eaten, false); Expect("English: and nothing is replaced", r.d.Shown(), "the elsewhere"); }
    { EnRig r; r.Type(u"hello"); r.c.OnKey(V(0x20)); Expect("English: a good word goes in as typed", r.d.Shown(), "hello "); bool eaten = r.c.OnKey(V(0x08)); Expect("English: nothing to take back after a good word", eaten, false); Expect("English: learned as typed", r.e.learned.size() == 1 && r.e.learned[0] == "hello>hello|<s>|typed|", true); }
    { EnRig r; r.Type(u"teh,"); Expect("English: a comma ends the word as typed (no correction)", r.d.Shown(), "teh,"); }
    { EnRig r; r.Type(u"teh1"); Expect("English: a digit ends the word as typed", r.d.Shown(), "teh1"); }
    { EnRig r; r.Type(u"abc."); r.Type(u"teh"); Expect("English: after a full stop the next word starts a sentence", r.e.prevs.back() == "<s>", true); }
    { EnRig r; r.Type(u"of"); r.c.OnKey(V(0x20)); r.Type(u"teh"); Expect("English: the word before is passed on (lower case)", r.e.prevs.back() == "of", true); }
    { EnRig r; r.Type(u"Of"); r.c.OnKey(V(0x20)); r.Type(u"t"); Expect("English: lower-cased", r.e.prevs.back() == "of", true); }
    { EnRig r; r.Type(u"teh"); bool eaten = r.c.OnKey(V(0x0D)); Expect("English: Enter types the word as typed", r.d.Shown(), "teh"); Expect("English: and then goes on to the program", eaten, false); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x1B)); Expect("English: Escape keeps what was typed", r.d.Shown(), "teh"); }
    { EnRig r; r.Type(u"th"); r.c.OnKey(V(0x09)); Expect("English: Tab shows the next word of the list", r.d.Shown(), "\xC2\xABthe\xC2\xBB"); r.c.OnKey(V(0x20)); Expect("English: Space types the chosen word", r.d.Shown(), "the "); Expect("English: learned as a pick", r.e.learned.size() == 1 && r.e.learned[0] == "th>the|<s>|pick|", true); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x09)); r.c.OnKey(V(0x20)); Expect("English: picking the typed word over a correction is learned with the refused correction", r.e.learned.size() == 1 && r.e.learned[0] == "teh>teh|<s>|pick|the", true); }
    { EnRig r; r.Type(u"th"); r.c.OnKey(V(0x09)); r.c.OnKey(V(0x09)); r.c.OnKey(V(0x09, true)); Expect("English: Shift+Tab goes back", r.d.Shown(), "\xC2\xABthe\xC2\xBB"); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x09)); r.c.OnKey(V(0x20)); Expect("English: a hand-picked word is not offered for taking back", r.d.Shown(), "teh "); bool eaten = r.c.OnKey(V(0x08)); Expect("English: so Backspace is the program's", eaten, false); }
    { EnRig r; r.Type(u"teh"); r.c.Reset(); Expect("English: losing focus keeps the typed word, uncorrected", r.d.Shown(), "teh"); }
    { EnRig r; r.Type(u"teh"); bool eaten = r.c.OnKey(V(0x25)); Expect("English: Left types the word as typed", r.d.Shown(), "teh"); Expect("English: and goes on", eaten, false); }
    { EnRig r; r.Type(u"teh"); Key k = K(u'c'); k.ctrl = true; bool eaten = r.c.OnKey(k); Expect("English: a shortcut types the word first", r.d.Shown(), "teh"); Expect("English: and is the program's", eaten, false); }
    { EnRig r; r.Type(u"teh"); Key k = V(0x08); k.ctrl = true; r.c.OnKey(k); Expect("English: Ctrl+Backspace throws the word away", r.d.Shown(), ""); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x08)); r.c.OnKey(V(0x08)); r.c.OnKey(V(0x08)); Expect("English: Backspace shortens the word and the last one ends it", r.d.Shown(), ""); }
    { EnRig r; r.Type(u"don't"); r.c.OnKey(V(0x20)); Expect("English: an apostrophe inside a word belongs to it", r.d.Shown(), "don't "); }
    { EnRig r; bool eaten = r.c.OnKey(K(u'\'')); Expect("English: an opening quote is typed by the program", eaten, false); r.Type(u"hi'"); r.c.OnKey(V(0x20)); Expect("English: a closing quote stays after the word", r.d.Shown(), "hi' "); Expect("English: the word was asked without it", r.e.prevs.size() >= 2, true); }
    { EnRig r; r.Type(u"dont"); r.c.OnKey(V(0x20)); Expect("English: dont becomes don't", r.d.Shown(), "don't "); }
    { EnRig r; r.Type(u"qzx"); r.c.OnKey(V(0x20)); Expect("English: an unknown word is left as typed", r.d.Shown(), "qzx "); }
    { EnRig r; r.e.ans.clear(); r.Type(u"teh"); r.c.OnKey(V(0x20)); Expect("English: with no answer the letters go in as typed", r.d.Shown(), "teh "); }
    { EnRig r; Expect("English: idle space is the program's", r.c.WouldEat(V(0x20)), false); Expect("English: a letter starts a word", r.c.WouldEat(K(u'a')), true); r.Type(u"a"); Expect("English: while typing every key is ours", r.c.WouldEat(V(0x25)), true); }
    { EnRig r; r.Type(u"teh"); r.c.OnKey(V(0x20)); Expect("English: after a correction Backspace is ours", r.c.WouldEat(V(0x08)), true); r.c.OnKey(V(0x08)); Expect("English: and afterwards it is not", r.c.WouldEat(V(0x08)), false); }
    { EnRig r; r.Type(u"teh"); r.c.Lost(); Expect("English: when the program ends the composition its text stays as typed", r.d.Shown(), "\xC2\xABteh\xC2\xBB"); Expect("English: and nothing is composing", r.c.Composing(), false); }
    { Rig r; r.c.SetScript(0); r.Type(u"ba"); r.c.OnKey(V(0x20)); Expect("Odia typing is not touched by the English mode", r.d.Shown(), "\xE0\xAC\xAC "); }
    printf("%d/%d passed (native tests of the text service logic)\n", total - bad, total);
    return bad ? 1 : 0;
}
