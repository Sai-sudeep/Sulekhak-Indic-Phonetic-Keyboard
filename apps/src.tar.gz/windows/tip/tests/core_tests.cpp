// Native tests of the text service's logic: build and run with  sh tests/run.sh   (any C++17 compiler, no Windows needed).
#include "../tipcore.h"
#include <cstdio>
#include <fstream>
#include <map>
#include <sstream>
using namespace sk;

static std::string U8(const ustr& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); i++) {
        unsigned c = s[i];
        if (c < 0x80) o += (char)c; else if (c < 0x800) { o += (char)(0xC0 | (c >> 6)); o += (char)(0x80 | (c & 63)); }
        else { o += (char)(0xE0 | (c >> 12)); o += (char)(0x80 | ((c >> 6) & 63)); o += (char)(0x80 | (c & 63)); }
    }
    return o;
}
// A document that is a string with a caret at its end and at most one composition.
struct StrDoc : Doc {
    ustr text, comp; bool composing = false;
    ustr Before(int n) override { return text.size() > (size_t)n ? text.substr(text.size() - n) : text; }
    void Compose(const ustr& s) override { composing = true; comp = s; }
    void Commit(const ustr& s) override { text += s; comp.clear(); composing = false; }
    void EndEmpty() override { comp.clear(); composing = false; }
    void ReplaceBefore(int drop, const ustr& s) override { text = text.substr(0, text.size() - drop) + s; }
    ustr Shown() const { return text + (composing ? u"«" + comp + u"»" : ustr()); }
};
// An engine whose words are fixed: "ba" -> ବ, "bad" -> ବଡ, "ba." etc.
struct StubEngine : Engine {
    std::map<ustr, std::vector<ustr>> words; bool up = true; std::vector<std::string> learned;
    bool Query(int, const ustr& buf, const ustr&, std::vector<ustr>& out) override {
        if (!up) return false;
        auto it = words.find(buf);
        if (it != words.end()) out = it->second; else out = {buf};
        return true;
    }
    void Learn(int, const ustr& r, const ustr& w) override { learned.push_back(U8(r) + "=" + U8(w)); }
};

static Key K(char16_t ch) {
    Key k{0, ch, false, false, false, false};
    if (ch >= u'a' && ch <= u'z') k.vk = ch - 32; else if (ch >= u'A' && ch <= u'Z') { k.vk = ch; k.shift = true; }
    else if (ch == u'>') { k.vk = 0xBE; k.shift = true; } else if (ch == u'.') k.vk = 0xBE; else if (ch >= u'0' && ch <= u'9') k.vk = ch;
    else if (ch == u'|') { k.vk = 0xDC; k.shift = true; } else if (ch == u'*') { k.vk = 0x38; k.shift = true; } else if (ch == u'~') { k.vk = 0xC0; k.shift = true; }
    else if (ch == u',') k.vk = 0xBC; else if (ch == u';') k.vk = 0xBA; else if (ch == u'\'') k.vk = 0xDE; else if (ch == u'`') k.vk = 0xC0;
    return k;
}
static Key V(uint32_t vk, bool shift = false) { return Key{vk, 0, shift, false, false, false}; }

static int bad = 0, total = 0;
static void Expect(const char* name, const ustr& got, const char* want) {
    total++;
    if (U8(got) != want) { bad++; printf("FAIL %s\n  expected %s\n  got      %s\n", name, want, U8(got).c_str()); }
}
static void Expect(const char* name, bool got, bool want) { total++; if (got != want) { bad++; printf("FAIL %s: %d, expected %d\n", name, got, want); } }

struct Rig {
    StrDoc d; StubEngine e; Core c{&d, &e};
    Rig() {
        e.words[u"ba"] = {u"ବ", u"ା"};                                  // ବ
        e.words[u"bad"] = {u"ବଡ", u"ବଦ"};                    // ବଡ, ବଦ
        e.words[u"badi"] = {u"ବଡି"};                              // ବଡି
        e.words[u"5"] = {u"୫", u"5"};                                        // ୫
        e.words[u"."] = {u"।", u".", u"॥"};
        e.words[u"ka`"] = {u"କ୍"};                                      // କ୍ (ends in halant: the word goes on)
    }
    bool Type(const char16_t* s) { bool r = true; for (; *s; s++) r = c.OnKey(K(*s)); return r; }
};

int main() {
    // 1. every decision agrees with the reference (tests/decisions.txt is written by keymap/dump_decisions.js)
    {
        std::ifstream f("tests/decisions.txt");
        std::string line;
        static const char* names[] = {"letter","mark","gt","digit0","digit19","dot","bar","star","punct","space","enter","esc","bksp","tab","shtab","up","down","left","right","pgup","pgdn","nav","selnav","chord","chordDiscard"};
        while (std::getline(f, line)) {
            std::istringstream is(line);
            std::string st, cl, ch, eff; int n, sel;
            is >> st >> cl >> n >> sel >> ch; std::getline(is, eff); if (!eff.empty() && eff[0] == ' ') eff = eff.substr(1);
            Cls c = Cls::Nav; bool found = false;
            for (int i = 0; i < 25; i++) if (cl == names[i]) { c = (Cls)i; found = true; }
            total++;
            if (!found) { bad++; printf("FAIL unknown class %s\n", cl.c_str()); continue; }
            std::vector<std::string> d = Decide(st, c, n, sel, ch[0]);
            std::string got; for (size_t i = 0; i < d.size(); i++) { if (i) got += ","; got += d[i]; }
            if (got != eff) { bad++; printf("FAIL decision %s\n  expected %s\n  got      %s\n", line.substr(0, line.find_last_of(' ')).c_str(), eff.c_str(), got.c_str()); }
        }
    }
    // 2. whole typing sequences against a document
    { Rig r; r.Type(u"ba"); Expect("composing shows the first word", r.d.Shown(), "\xC2\xAB\xE0\xAC\xAC\xC2\xBB"); }
    { Rig r; r.Type(u"ba"); r.c.OnKey(V(0x20)); Expect("space types the word and a space", r.d.Shown(), "\xE0\xAC\xAC "); Expect("learned", r.e.learned.size() == 1 && r.e.learned[0] == "ba=\xE0\xAC\xAC", true); }
    { Rig r; r.Type(u"ba"); r.c.OnKey(V(0x0D)); Expect("enter picks with a space and is used up", r.d.Shown(), "\xE0\xAC\xAC "); }
    { Rig r; bool eaten = r.c.OnKey(V(0x0D)); Expect("enter with no word goes to the program", eaten, false); }
    { Rig r; r.Type(u"ba"); r.c.OnKey(V(0x09)); Expect("tab highlights the next word", r.d.Shown(), "\xC2\xAB\xE0\xAC\xBE\xC2\xBB"); r.c.OnKey(V(0x20)); Expect("and space types that one", r.d.Shown(), "\xE0\xAC\xBE "); }
    { Rig r; r.Type(u"ba"); r.Type(u"2"); Expect("digit picks the second word", r.d.Shown(), "\xE0\xAC\xBE "); }
    { Rig r; r.Type(u"ba"); r.Type(u"9"); Expect("no ninth word: ignored", r.d.Shown(), "\xC2\xAB\xE0\xAC\xAC\xC2\xBB"); }
    { Rig r; r.Type(u"ba,"); Expect("punctuation ends the word", r.d.Shown(), "\xE0\xAC\xAC,"); }
    { Rig r; r.Type(u"ba"); r.c.OnKey(V(0x1B)); Expect("escape throws the word away", r.d.Shown(), ""); }
    { Rig r; r.Type(u"bad"); r.c.OnKey(V(0x08)); Expect("backspace drops one letter of the buffer", r.d.Shown(), "\xC2\xAB\xE0\xAC\xAC\xC2\xBB"); r.c.OnKey(V(0x08)); r.c.OnKey(V(0x08)); Expect("and the last one ends the word", r.d.Shown(), ""); }
    { Rig r; r.Type(u"ba"); bool eaten = r.c.OnKey(V(0x25)); Expect("left arrow, one page: word typed", r.d.Shown(), "\xE0\xAC\xAC"); Expect("left arrow is then the program's", eaten, false); }
    { Rig r; r.Type(u"ba"); bool eaten = r.c.OnKey(V(0x25, true)); Expect("shift+left types the word", r.d.Shown(), "\xE0\xAC\xAC"); Expect("and goes on to select", eaten, false); }
    { Rig r; r.Type(u"ba"); Key k = V(0x08); k.ctrl = true; r.c.OnKey(k); Expect("ctrl+backspace throws the word away", r.d.Shown(), ""); }
    { Rig r; r.Type(u"ba"); Key k = K(u'c'); k.ctrl = true; bool eaten = r.c.OnKey(k); Expect("a shortcut types the word first", r.d.Shown(), "\xE0\xAC\xAC"); Expect("and is the program's", eaten, false); }
    { Rig r; r.Type(u"."); Expect("a dot opens the list", r.d.Shown(), "\xC2\xAB\xE0\xA5\xA4\xC2\xBB"); }
    { Rig r; r.Type(u".1"); Expect("1 picks the danda", r.d.Shown().substr(0, 1) == u"।" ? ustr(u"ok") : r.d.Shown(), "ok"); }
    { Rig r; r.Type(u"5"); Expect("a digit alone starts a number", r.d.Shown(), "\xC2\xAB\xE0\xAD\xAB\xC2\xBB"); }
    // 3. the nukta key
    { Rig r; r.d.text = u"ବଡି"; bool eaten = r.c.OnKey(K(u'>')); Expect("lone > marks the ଡ of the word before", r.d.Shown(), "\xE0\xAC\xAC\xE0\xAC\xA1\xE0\xAC\xBC\xE0\xAC\xBF"); Expect("and is used up", eaten, true); }
    { Rig r; r.d.text = u"କ"; r.c.OnKey(K(u'>')); Expect("with no ଡ a lone nukta is typed", r.d.Shown(), "\xE0\xAC\x95\xE0\xAC\xBC"); }
    { Rig r; r.d.text = u"ବଡି "; r.c.OnKey(K(u'>')); Expect("also after the space the pick added", r.d.Shown(), "\xE0\xAC\xAC\xE0\xAC\xA1\xE0\xAC\xBC\xE0\xAC\xBF "); }
    { Rig r; r.Type(u"bad>"); Expect("inside a word > goes to the buffer", r.d.Shown().size() > 0 && r.c.Buffer() == u"bad>", true); }
    // 4. backspace over the text already typed: one code point
    { Rig r; r.d.text = u"କ୍ଷି"; r.c.OnKey(V(0x08)); Expect("backspace removes the vowel sign only", r.d.Shown(), "\xE0\xAC\x95\xE0\xAD\x8D\xE0\xAC\xB7"); }
    { Rig r; r.d.text = u"ab"; bool eaten = r.c.OnKey(V(0x08)); Expect("other text: the program deletes", eaten, false); Expect("and nothing was removed", r.d.Shown(), "ab"); }
    // 5. words that go on, and an engine that is not there
    { Rig r; r.Type(u"ka`"); r.c.OnKey(V(0x0D)); Expect("a word ending in halant gets no space from Enter", r.d.Shown(), "\xE0\xAC\x95\xE0\xAD\x8D"); }
    { Rig r; r.Type(u"ka`"); r.c.OnKey(V(0x20)); Expect("but Space always types one", r.d.Shown(), "\xE0\xAC\x95\xE0\xAD\x8D "); }
    { Rig r; r.e.up = false; r.Type(u"ba"); r.c.OnKey(V(0x20)); Expect("engine away: the letters are typed as they are", r.d.Shown(), "ba "); }
    { Rig r; r.Type(u"ba"); r.c.Reset(); Expect("losing focus keeps the word", r.d.Shown(), "\xE0\xAC\xAC"); }
    printf("%d/%d passed (native tests of the text service logic)\n", total - bad, total);
    return bad ? 1 : 0;
}
