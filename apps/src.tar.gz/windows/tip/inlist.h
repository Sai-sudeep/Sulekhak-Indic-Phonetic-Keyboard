// The candidate list drawn inside the program that is being typed in (not by the Sulekhak tray program).
//
// The Start menu / Search box, the taskbar search and other store-style windows run in a higher window layer than an ordinary program's window, so a list
// drawn by the tray program is hidden behind them, and those programs do not draw a third-party list themselves either: the words were there, but
// nobody saw them, and only the first spelling (in the chosen script) was typed. A window made by the text service in the same program is in the same layer
// and is seen. It is used only where the tray program's list cannot be seen (see InProcessHost); everywhere else the tray program draws the list as before.
#pragma once
#include <windows.h>
#include <string>
#include <vector>

class InList {
public:
    ~InList() { Destroy(); }

    // Programs whose windows the tray program's list cannot be seen above: the Start / Search family, and anything running as a store (AppContainer) app.
    static bool InProcessHost() {
        static int cached = -1;
        if (cached >= 0) return cached != 0;
        bool yes = false;
        wchar_t path[MAX_PATH] = {};
        if (GetModuleFileNameW(nullptr, path, MAX_PATH)) {
            const wchar_t* base = wcsrchr(path, L'\\'); base = base ? base + 1 : path;
            static const wchar_t* names[] = { L"searchhost.exe", L"searchapp.exe", L"searchui.exe", L"startmenuexperiencehost.exe", L"shellexperiencehost.exe", L"textinputhost.exe", L"lockapp.exe" };
            for (const wchar_t* n : names) if (_wcsicmp(base, n) == 0) yes = true;
        }
        if (!yes) {
            HANDLE tok = nullptr;
            if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) {
                DWORD isApp = 0, n = 0;
                if (GetTokenInformation(tok, (TOKEN_INFORMATION_CLASS)29 /* TokenIsAppContainer */, &isApp, sizeof isApp, &n) && isApp) yes = true;
                CloseHandle(tok);
            }
        }
        // HKCU\Software\Sulekhak\InProcList: 0 never, 1 only in those programs (the default), 2 in every program
        DWORD v = 1, sz = sizeof v, type = 0; HKEY k;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Sulekhak", 0, KEY_READ, &k) == ERROR_SUCCESS) {
            if (RegQueryValueExW(k, L"InProcList", nullptr, &type, (BYTE*)&v, &sz) != ERROR_SUCCESS || type != REG_DWORD) v = 1;
            RegCloseKey(k);
        }
        if (v == 0) yes = false; else if (v == 2) yes = true;
        cached = yes ? 1 : 0;
        return yes;
    }

    // list: the candidates, sel: the one chosen now, caret: where the word is on the screen (all zero when the program does not say)
    void Show(const std::vector<std::wstring>& list, int sel, RECT caret) {
        if (list.empty()) { Hide(); return; }
        items_ = list; sel_ = sel < 0 ? 0 : (sel >= (int)list.size() ? (int)list.size() - 1 : sel);
        if (!Make()) return;
        Layout(caret);
        InvalidateRect(hw_, nullptr, TRUE);
        UpdateWindow(hw_);
    }
    void Hide() { if (hw_ && IsWindowVisible(hw_)) ShowWindow(hw_, SW_HIDE); }
    void Destroy() {
        if (hw_) { DestroyWindow(hw_); hw_ = nullptr; }
        if (font_) { DeleteObject(font_); font_ = nullptr; }
        if (fontS_) { DeleteObject(fontS_); fontS_ = nullptr; }
    }

    // How a candidate is written in the list: a lone joiner or halant is not visible, so it gets a name. kind: 0 normal, 1 joiner (blue), 2 sign (violet).
    static std::wstring Label(const std::wstring& x, int* kind) {
        *kind = 0;
        if (x.empty()) return x;
        auto halant = [](wchar_t c) { return c == 0x094D || c == 0x09CD || c == 0x0B4D; };
        if (x.size() == 1 && x[0] == 0x200C) { *kind = 1; return L"ZWNJ"; }
        if (x.size() == 1 && x[0] == 0x200D) { *kind = 1; return L"ZWJ"; }
        if (x.size() == 2 && halant(x[0]) && x[1] == 0x200C) { *kind = 1; return std::wstring(L"◌") + x[0] + L" + ┊"; }
        if (x.size() == 2 && halant(x[0]) && x[1] == 0x200D) { *kind = 1; return std::wstring(L"◌") + x[0] + L" + ["; }
        if (x.size() == 1 && halant(x[0])) { *kind = 1; return std::wstring(L"◌") + x; }
        if (x.find(L'‌') != std::wstring::npos || x.find(L'‍') != std::wstring::npos) { *kind = 1; return x; }
        if (x.size() == 1) {
            WORD t = 0;
            if (GetStringTypeW(CT_CTYPE3, x.c_str(), 1, &t) && (t & (C3_NONSPACING | C3_DIACRITIC | C3_VOWELMARK)) && !(t & C3_ALPHA)) { *kind = 2; return std::wstring(L"◌") + x; }
        }
        return x;
    }

private:
    HWND hw_ = nullptr;
    HFONT font_ = nullptr, fontS_ = nullptr;
    std::vector<std::wstring> items_;
    int sel_ = 0, w_ = 0, h_ = 0, rowH_ = 0;
    static const int kPage = 9;

    static bool SystemDark() {
        DWORD v = 1, sz = sizeof v, type = 0; HKEY k;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", 0, KEY_READ, &k) != ERROR_SUCCESS) return false;
        if (RegQueryValueExW(k, L"AppsUseLightTheme", nullptr, &type, (BYTE*)&v, &sz) != ERROR_SUCCESS || type != REG_DWORD) v = 1;
        RegCloseKey(k);
        return v == 0;
    }
    static bool Dark() {                              // the tray menu's "Candidate box colour": 0 follow Windows, 1 light, 2 dark
        DWORD v = 0, sz = sizeof v, type = 0; HKEY k;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Sulekhak", 0, KEY_READ, &k) == ERROR_SUCCESS) {
            if (RegQueryValueExW(k, L"CandTheme", nullptr, &type, (BYTE*)&v, &sz) != ERROR_SUCCESS || type != REG_DWORD) v = 0;
            RegCloseKey(k);
        }
        return v == 2 || (v != 1 && SystemDark());
    }
    bool Make() {
        if (hw_) return true;
        static bool reg = false;
        extern HINSTANCE g_hInst;
        if (!reg) {
            WNDCLASSEXW wc = {}; wc.cbSize = sizeof wc; wc.style = CS_DROPSHADOW | CS_NOCLOSE; wc.lpfnWndProc = Proc; wc.hInstance = g_hInst;
            wc.hCursor = LoadCursorW(nullptr, IDC_ARROW); wc.lpszClassName = L"SulekhakInProcList";
            if (!RegisterClassExW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) return false;
            reg = true;
        }
        hw_ = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"SulekhakInProcList", L"", WS_POPUP, 0, 0, 10, 10, nullptr, nullptr, g_hInst, this);
        return hw_ != nullptr;
    }
    void Fonts(HDC dc) {
        if (font_) return;
        int dpi = GetDeviceCaps(dc, LOGPIXELSY); if (dpi <= 0) dpi = 96;
        font_ = CreateFontW(-MulDiv(15, dpi, 72), 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Nirmala UI");
        fontS_ = CreateFontW(-MulDiv(10, dpi, 72), 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    }
    int PageStart() const { return (sel_ / kPage) * kPage; }
    int PageCount() const { return ((int)items_.size() + kPage - 1) / kPage; }
    void Layout(RECT caret) {
        HDC dc = GetDC(hw_);
        Fonts(dc);
        HGDIOBJ old = SelectObject(dc, font_);
        TEXTMETRICW tm = {}; GetTextMetricsW(dc, &tm);
        rowH_ = tm.tmHeight + tm.tmHeight / 2;
        int num = tm.tmAveCharWidth * 3, pad = tm.tmAveCharWidth, widest = 0;
        int a = PageStart(), b = std::min((int)items_.size(), a + kPage);
        for (int i = a; i < b; i++) { int kind; std::wstring l = Label(items_[i], &kind); SIZE s = {}; GetTextExtentPoint32W(dc, l.c_str(), (int)l.size(), &s); if (s.cx > widest) widest = s.cx; }
        w_ = num + widest + pad * 3; if (w_ < tm.tmAveCharWidth * 12) w_ = tm.tmAveCharWidth * 12;
        h_ = (b - a) * rowH_ + (PageCount() > 1 ? rowH_ * 3 / 4 : 0) + 4;
        SelectObject(dc, old); ReleaseDC(hw_, dc);

        POINT p = { caret.left, caret.bottom };
        if (caret.left == 0 && caret.right == 0 && caret.top == 0 && caret.bottom == 0) {       // the program did not say where the word is
            GUITHREADINFO gi = {}; gi.cbSize = sizeof gi;
            if (GetGUIThreadInfo(0, &gi) && gi.hwndCaret && (gi.rcCaret.right || gi.rcCaret.bottom)) { p.x = gi.rcCaret.left; p.y = gi.rcCaret.bottom; ClientToScreen(gi.hwndCaret, &p); caret.top = p.y - (gi.rcCaret.bottom - gi.rcCaret.top); }
            else { HWND fg = GetForegroundWindow(); RECT fr = {}; if (fg && GetWindowRect(fg, &fr)) { p.x = fr.left + 24; p.y = fr.bottom - 8; caret.top = fr.top; } else { GetCursorPos(&p); caret.top = p.y; } }
        }
        MONITORINFO mi = {}; mi.cbSize = sizeof mi;
        HMONITOR mon = MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST);
        if (GetMonitorInfoW(mon, &mi)) {
            if (p.x + w_ > mi.rcWork.right) p.x = mi.rcWork.right - w_;
            if (p.x < mi.rcWork.left) p.x = mi.rcWork.left;
            if (p.y + h_ > mi.rcWork.bottom) { int above = caret.top - h_ - 2; p.y = above >= mi.rcWork.top ? above : mi.rcWork.bottom - h_; }
        }
        SetWindowPos(hw_, HWND_TOPMOST, p.x, p.y + 2, w_, h_, SWP_NOACTIVATE | SWP_SHOWWINDOW);
    }
    void Paint(HDC dc) {
        bool dk = Dark();
        COLORREF bg = dk ? RGB(36, 36, 38) : RGB(255, 255, 255), fg = dk ? RGB(236, 236, 236) : RGB(28, 28, 28), dim = dk ? RGB(150, 150, 155) : RGB(110, 110, 115);
        COLORREF selBg = dk ? RGB(55, 94, 168) : RGB(0, 103, 192), edge = dk ? RGB(90, 90, 95) : RGB(170, 170, 175);
        RECT cr; GetClientRect(hw_, &cr);
        HBRUSH bb = CreateSolidBrush(bg); FillRect(dc, &cr, bb); DeleteObject(bb);
        HBRUSH eb = CreateSolidBrush(edge); FrameRect(dc, &cr, eb); DeleteObject(eb);
        Fonts(dc);
        SetBkMode(dc, TRANSPARENT);
        TEXTMETRICW tm = {}; SelectObject(dc, font_); GetTextMetricsW(dc, &tm);
        int num = tm.tmAveCharWidth * 3, pad = tm.tmAveCharWidth;
        int a = PageStart(), b = std::min((int)items_.size(), a + kPage), y = 2;
        for (int i = a; i < b; i++, y += rowH_) {
            RECT row = { 2, y, cr.right - 2, y + rowH_ };
            bool on = i == sel_;
            if (on) { HBRUSH sb = CreateSolidBrush(selBg); FillRect(dc, &row, sb); DeleteObject(sb); }
            int kind; std::wstring l = Label(items_[i], &kind);
            COLORREF c = on ? RGB(255, 255, 255) : kind == 1 ? (dk ? RGB(140, 180, 255) : RGB(20, 70, 200)) : kind == 2 ? (dk ? RGB(210, 160, 245) : RGB(120, 40, 170)) : fg;
            wchar_t d[4] = { (wchar_t)(L'1' + (i - a)), 0, 0, 0 };
            SelectObject(dc, fontS_); SetTextColor(dc, on ? RGB(255, 255, 255) : dim);
            RECT nr = { row.left + pad, y, row.left + num, y + rowH_ }; DrawTextW(dc, d, 1, &nr, DT_SINGLELINE | DT_VCENTER | DT_LEFT | DT_NOPREFIX);
            SelectObject(dc, font_); SetTextColor(dc, c);
            RECT tr = { row.left + num, y, row.right - pad, y + rowH_ }; DrawTextW(dc, l.c_str(), (int)l.size(), &tr, DT_SINGLELINE | DT_VCENTER | DT_LEFT | DT_NOPREFIX);
        }
        if (PageCount() > 1) {
            wchar_t pg[24]; wsprintfW(pg, L"%d / %d", PageStart() / kPage + 1, PageCount());
            SelectObject(dc, fontS_); SetTextColor(dc, dim);
            RECT pr = { 2, y, cr.right - pad, cr.bottom - 2 }; DrawTextW(dc, pg, -1, &pr, DT_SINGLELINE | DT_VCENTER | DT_RIGHT | DT_NOPREFIX);
        }
    }
    static LRESULT CALLBACK Proc(HWND h, UINT m, WPARAM w, LPARAM l) {
        if (m == WM_NCCREATE) { SetWindowLongPtrW(h, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCTW*)l)->lpCreateParams); }
        InList* self = (InList*)GetWindowLongPtrW(h, GWLP_USERDATA);
        switch (m) {
        case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
        case WM_ERASEBKGND: return 1;
        case WM_PAINT: { PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); if (self) { self->hw_ = h; self->Paint(dc); } EndPaint(h, &ps); return 0; }
        }
        return DefWindowProcW(h, m, w, l);
    }
};
