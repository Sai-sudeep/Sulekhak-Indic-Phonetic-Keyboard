using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;

namespace Sulekhak
{
    static class Native
    {
        public const int WH_KEYBOARD_LL = 13;
        public const int WM_KEYDOWN = 0x100, WM_KEYUP = 0x101, WM_SYSKEYDOWN = 0x104, WM_SYSKEYUP = 0x105;
        public const uint KEYEVENTF_EXTENDEDKEY = 1, KEYEVENTF_KEYUP = 2, KEYEVENTF_UNICODE = 4;
        public const int MAGIC = 0x534B4C4B;     // marks the keys this program sends itself

        public delegate IntPtr LowLevelProc(int code, IntPtr wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        public struct KBDLLHOOKSTRUCT { public uint vkCode, scanCode, flags, time; public IntPtr dwExtraInfo; }

        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT { public int dx, dy; public uint mouseData, dwFlags, time; public IntPtr dwExtraInfo; }

        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr dwExtraInfo; }

        [StructLayout(LayoutKind.Explicit)]
        public struct InputUnion { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }

        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT { public uint type; public InputUnion U; }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT { public int X, Y; }

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT { public int left, top, right, bottom; }

        [StructLayout(LayoutKind.Sequential)]
        public struct GUITHREADINFO
        {
            public int cbSize, flags;
            public IntPtr hwndActive, hwndFocus, hwndCapture, hwndMenuOwner, hwndMoveSize, hwndCaret;
            public RECT rcCaret;
        }

        [DllImport("user32.dll", SetLastError = true)] public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelProc lpfn, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll")] public static extern bool UnhookWindowsHookEx(IntPtr hhk);
        [DllImport("user32.dll")] public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr GetModuleHandle(string lpModuleName);
        [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vKey);
        [DllImport("user32.dll")] public static extern short GetKeyState(int nVirtKey);
        [DllImport("user32.dll", SetLastError = true)] public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
        [DllImport("user32.dll")] public static extern IntPtr GetKeyboardLayout(uint idThread);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int ToUnicodeEx(uint wVirtKey, uint wScanCode, byte[] lpKeyState, [Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pwszBuff, int cchBuff, uint wFlags, IntPtr dwhkl);
        [DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint idThread, ref GUITHREADINFO lpgui);
        [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr hWnd, ref POINT lpPoint);
        [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT lpPoint);
        [DllImport("user32.dll")] public static extern bool DestroyIcon(IntPtr hIcon);
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
        [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
        [DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint objectId, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object obj);

        [ComImport, Guid("618736E0-3C3D-11CF-810C-00AA00389B71"), InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
        interface IAcc
        {
            [DispId(-5004)] void accLocation(out int left, out int top, out int width, out int height, [In, MarshalAs(UnmanagedType.Struct)] object child);
        }

        static INPUT Key(ushort vk, ushort scan, uint flags)
        {
            var i = new INPUT();
            i.type = 1;
            i.U.ki.wVk = vk;
            i.U.ki.wScan = scan;
            i.U.ki.dwFlags = flags;
            i.U.ki.time = 0;
            i.U.ki.dwExtraInfo = (IntPtr)MAGIC;
            return i;
        }

        /// <summary>Types text into the focused window (Unicode, so Odia letters work in any normal program).</summary>
        public static void SendText(string s)
        {
            if (string.IsNullOrEmpty(s)) return;
            var a = new INPUT[s.Length * 2];
            int n = 0;
            foreach (char c in s)
            {
                a[n++] = Key(0, c, KEYEVENTF_UNICODE);
                a[n++] = Key(0, c, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP);
            }
            SendInput((uint)n, a, Marshal.SizeOf(typeof(INPUT)));
        }

        /// <summary>Presses and releases a virtual key (used to pass a key on after the pending word was typed).</summary>
        public static void SendVk(ushort vk, bool extended)
        {
            uint ex = extended ? KEYEVENTF_EXTENDEDKEY : 0;
            var a = new INPUT[2];
            a[0] = Key(vk, 0, ex);
            a[1] = Key(vk, 0, ex | KEYEVENTF_KEYUP);
            SendInput(2, a, Marshal.SizeOf(typeof(INPUT)));
        }

        static byte[] KeyState()
        {
            var s = new byte[256];
            if ((GetAsyncKeyState(0x10) & 0x8000) != 0) s[0x10] = 0x80;
            if ((GetKeyState(0x14) & 1) != 0) s[0x14] = 1;
            return s;
        }

        /// <summary>The character the key would type on the current layout (empty for dead keys and non-characters).</summary>
        public static string CharFor(uint vk, uint scan)
        {
            var sb = new StringBuilder(8);
            uint pid;
            uint tid = GetWindowThreadProcessId(GetForegroundWindow(), out pid);
            IntPtr hkl = GetKeyboardLayout(tid);
            int n = ToUnicodeEx(vk, scan, KeyState(), sb, sb.Capacity, 4, hkl);
            if (n <= 0) return "";
            return sb.ToString(0, n);
        }

        public static bool IsDown(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }

        static Rectangle MsaaCaret(IntPtr hwnd)
        {
            try
            {
                if (hwnd == IntPtr.Zero) return Rectangle.Empty;
                Guid iid = new Guid("618736E0-3C3D-11CF-810C-00AA00389B71");
                object o;
                if (AccessibleObjectFromWindow(hwnd, 0xFFFFFFF8u, ref iid, out o) != 0 || o == null) return Rectangle.Empty;
                var acc = (IAcc)o;
                int l, t, w, h;
                acc.accLocation(out l, out t, out w, out h, 0);
                if (h > 0 && h < 400 && (l != 0 || t != 0)) return new Rectangle(l, t, Math.Max(w, 1), h);
            }
            catch { }
            return Rectangle.Empty;
        }

        /// <summary>The text cursor of the program you are typing in, in screen pixels. Tries the classic caret, then the
        /// accessibility caret (browsers, Office, Electron), and finally the mouse pointer.</summary>
        public static Rectangle CaretRect()
        {
            IntPtr fg = GetForegroundWindow();
            try
            {
                uint pid;
                uint tid = GetWindowThreadProcessId(fg, out pid);
                var gi = new GUITHREADINFO();
                gi.cbSize = Marshal.SizeOf(typeof(GUITHREADINFO));
                if (GetGUIThreadInfo(tid, ref gi))
                {
                    if (gi.hwndCaret != IntPtr.Zero && (gi.rcCaret.bottom - gi.rcCaret.top) > 0)
                    {
                        var p = new POINT { X = gi.rcCaret.left, Y = gi.rcCaret.top };
                        var q = new POINT { X = gi.rcCaret.right, Y = gi.rcCaret.bottom };
                        if (ClientToScreen(gi.hwndCaret, ref p) && ClientToScreen(gi.hwndCaret, ref q))
                            return new Rectangle(p.X, p.Y, Math.Max(1, q.X - p.X), Math.Max(1, q.Y - p.Y));
                    }
                    var r = MsaaCaret(gi.hwndFocus != IntPtr.Zero ? gi.hwndFocus : fg);
                    if (!r.IsEmpty) return r;
                }
            }
            catch { }
            POINT m;
            GetCursorPos(out m);
            return new Rectangle(m.X, m.Y, 1, 20);
        }
    }
}
