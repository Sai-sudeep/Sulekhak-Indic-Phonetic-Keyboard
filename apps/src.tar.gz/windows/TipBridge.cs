using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace Sulekhak
{
    /// <summary>
    /// The engine side of the Sulekhak text service. The text service (a DLL that Windows loads into every program that takes text) cannot run the
    /// word engine itself, so it asks this program through a named pipe: one message in, one message out (tab-separated fields, UTF-8):
    ///   Q script opt prev buf  -> C word word ...      the words for the letters typed so far
    ///   L script roman word    -> K                    the user chose this word: remember it
    ///   P x y h sel roman words... -> K                show the word list at this spot of the screen
    ///   H                      -> K                    hide the word list
    ///   G                      -> T script opt         the script the All Languages keyboard types now
    ///   W script opt           -> K                    the user switched script with Ctrl+Alt+1..6 (8: English, script 6)
    ///   E typed word prev how passed -> K              English: a word went in (how: typed, auto, pick, revert)
    ///   S                      -> K                    self-test of the pipe (this program asks itself)
    /// </summary>
    sealed class TipBridge
    {
        public static readonly Guid TipClsid = new Guid("96DB1CE7-2FD4-45AD-BD63-BE53EF2753E6");

        /// <summary>Is the text service registered on this computer? (Then Windows itself does the typing and the keyboard hook stays off.)</summary>
        public static bool Registered()
        {
            try
            {
                string k = @"SOFTWARE\Microsoft\CTF\TIP\{" + TipClsid.ToString().ToUpperInvariant() + "}";
                using (RegistryKey r = Registry.LocalMachine.OpenSubKey(k)) { if (r != null) return true; }
                using (RegistryKey r = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey(k)) { if (r != null) return true; }
            }
            catch { }
            return false;
        }

        /// <summary>The DLL path the computer has registered for the text service (the 64-bit registry view), or null.</summary>
        public static string RegisteredDll()
        {
            try
            {
                string k = @"SOFTWARE\Classes\CLSID\{" + TipClsid.ToString().ToUpperInvariant() + @"}\InprocServer32";
                using (RegistryKey b = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
                using (RegistryKey r = b.OpenSubKey(k)) { if (r != null) return r.GetValue(null) as string; }
            }
            catch { }
            return null;
        }

        /// <summary>Did the installer put Sulekhak on this computer (even when it could not or need not register the text service)?</summary>
        public static bool InstalledByInstaller()
        {
            try
            {
                using (RegistryKey b = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
                using (RegistryKey r = b.OpenSubKey(@"SOFTWARE\Sulekhak")) return r != null && r.GetValue("InstallDir") != null;
            }
            catch { }
            return false;
        }

        /// <summary>Asks this program's own pipe a question the way the text service does (message mode, one request, one answer).
        /// Returns null when the pipe answered, otherwise what went wrong. This is what tells "the keyboard can reach its words" from "it cannot".</summary>
        public static string SelfTest()
        {
            try
            {
                string pn = "SulekhakTip-" + WindowsIdentity.GetCurrent().User.Value;
                using (var c = new System.IO.Pipes.NamedPipeClientStream(".", pn, PipeDirection.InOut, PipeOptions.None))
                {
                    c.Connect(2000);
                    c.ReadMode = PipeTransmissionMode.Message;
                    byte[] q = Encoding.UTF8.GetBytes("S");
                    c.Write(q, 0, q.Length);
                    c.Flush();
                    var buf = new byte[512];
                    var t = c.ReadAsync(buf, 0, buf.Length);
                    if (!t.Wait(3000)) return "the pipe did not answer within 3 seconds";
                    string a = Encoding.UTF8.GetString(buf, 0, t.Result);
                    return a.StartsWith("K") ? null : "unexpected answer '" + a + "'";
                }
            }
            catch (Exception e) { return e.GetBaseException().Message; }
        }

        readonly EngineHost host;
        readonly CandPopup popup;
        readonly Control ui;
        readonly Action<int> setScript;
        readonly Func<int[]> getScript;
        readonly ConcurrentDictionary<int, TaskCompletionSource<List<string>>> pending = new ConcurrentDictionary<int, TaskCompletionSource<List<string>>>();
        int nextId = 1000000;
        volatile bool stop;
        readonly string name;

        public TipBridge(Control ui, EngineHost host, CandPopup popup, Action<int> setScript, Func<int[]> getScript)
        {
            this.ui = ui; this.host = host; this.popup = popup; this.setScript = setScript; this.getScript = getScript;
            name = "SulekhakTip-" + WindowsIdentity.GetCurrent().User.Value;
            host.Candidates += OnCandidates;
            host.NextWords += OnNext;
        }

        readonly ConcurrentDictionary<int, TaskCompletionSource<List<string>>> pendingNext = new ConcurrentDictionary<int, TaskCompletionSource<List<string>>>();
        void OnNext(int id, List<string> list)
        {
            TaskCompletionSource<List<string>> t;
            if (id >= 1000000 && pendingNext.TryRemove(id, out t)) t.TrySetResult(list);
        }

        void OnCandidates(int id, string b, List<string> list)
        {
            TaskCompletionSource<List<string>> t;
            if (id >= 1000000 && pending.TryRemove(id, out t)) t.TrySetResult(list);
        }

        /// <summary>A safety net: a candidate that carries letters of another Indic script than the keyboard's own never reaches the screen
        /// (Odia typing never shows a Devanagari word, English never shows an Indic one). The danda signs and the joiners are common to all.</summary>
        public static List<string> ScriptFilter(int sc, List<string> list)
        {
            if (list == null || list.Count == 0) return list;
            var o = new List<string>(list.Count);
            foreach (string w in list) if (ScriptOk(sc, w)) o.Add(w);
            return o;
        }
        static bool ScriptOk(int sc, string w)
        {
            foreach (char c in w)
            {
                if (c < 0x0900 || c > 0x0DFF) continue;                         // Latin, punctuation, joiners (U+200C / U+200D are outside the range)
                if (c == '\u0964' || c == '\u0965') continue;                  // danda, double danda: shared
                if (sc == 6) return false;                                      // English: no Indic letter at all
                bool deva = c <= 0x097F, beng = c >= 0x0980 && c <= 0x09FF, odia = c >= 0x0B00 && c <= 0x0B7F;
                if (sc == 0 && !odia) return false;
                if (sc == 1 && !deva) return false;
                if ((sc == 2 || sc == 5) && !beng) return false;
            }
            return true;
        }

        /// <summary>Raised when the text service itself (not the self-test) talks to this program: it is live for this user, so Windows is the one that types.</summary>
        public event Action TipContact;

        public void Start() { for (int i = 0; i < 2; i++) Task.Run(() => Serve()); }
        public void Stop() { stop = true; }

        // ---- the pipe: reachable by this user's programs of every kind, including the sandboxed (AppContainer, low integrity) ones such as Edge
        [StructLayout(LayoutKind.Sequential)] struct SECURITY_ATTRIBUTES { public int nLength; public IntPtr lpSecurityDescriptor; public int bInheritHandle; }
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(string sddl, uint revision, out IntPtr sd, out uint size);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern SafePipeHandle CreateNamedPipe(string pipeName, uint openMode, uint pipeMode, uint maxInstances, uint outBuffer, uint inBuffer, uint defaultTimeout, ref SECURITY_ATTRIBUTES sa);
        [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr h);

        NamedPipeServerStream NewPipe()
        {
            string sid = WindowsIdentity.GetCurrent().User.Value;
            // SYSTEM and this user: full; every app package: read/write; mandatory label "low": a low-integrity program may write to it
            string sddl = "D:(A;;GA;;;SY)(A;;GA;;;" + sid + ")(A;;GRGW;;;S-1-15-2-1)(A;;GRGW;;;S-1-15-2-2)S:(ML;;NW;;;LW)";
            IntPtr sd; uint n;
            if (!ConvertStringSecurityDescriptorToSecurityDescriptor(sddl, 1, out sd, out n)) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            try
            {
                var sa = new SECURITY_ATTRIBUTES { nLength = Marshal.SizeOf(typeof(SECURITY_ATTRIBUTES)), lpSecurityDescriptor = sd, bInheritHandle = 0 };
                // PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED ; PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT
                SafePipeHandle h = CreateNamedPipe(@"\\.\pipe\" + name, 3u | 0x40000000u, 6u, 16, 8192, 8192, 0, ref sa);
                if (h.IsInvalid) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
                return new NamedPipeServerStream(PipeDirection.InOut, true, false, h);
            }
            finally { LocalFree(sd); }
        }

        async Task Serve()
        {
            while (!stop)
            {
                NamedPipeServerStream p = null;
                try
                {
                    p = NewPipe();
                    await p.WaitForConnectionAsync();
                    var spare = Task.Run(() => Serve());           // the next client can connect while this one is served
                    await Talk(p);
                    return;
                }
                catch { await Task.Delay(500); }
                finally { try { if (p != null) p.Dispose(); } catch { } }
            }
        }

        async Task Talk(NamedPipeServerStream p)
        {
            var buf = new byte[8192];
            // A stream made around a pipe handle does not know the pipe is in message mode, and IsMessageComplete then throws (the client saw the pipe close
            // with no answer at all). Say so explicitly; if that is refused, one read is one message (every request is far smaller than the buffer).
            bool msgMode = false;
            try { p.ReadMode = PipeTransmissionMode.Message; msgMode = true; } catch { }
            while (!stop && p.IsConnected)
            {
                var all = new System.IO.MemoryStream();
                do
                {
                    int n = await p.ReadAsync(buf, 0, buf.Length);
                    if (n <= 0) return;
                    all.Write(buf, 0, n);
                } while (msgMode && !MessageDone(p));
                string req = Encoding.UTF8.GetString(all.ToArray());
                string resp;
                try { resp = await Handle(req); } catch { resp = "E"; }
                byte[] o = Encoding.UTF8.GetBytes(resp);
                await p.WriteAsync(o, 0, o.Length);
            }
        }

        static bool MessageDone(NamedPipeServerStream p) { try { return p.IsMessageComplete; } catch { return true; } }

        public async Task<string> Handle(string req)
        {
            string[] f = req.Split('\t');
            if (f[0] != "S") { var c = TipContact; if (c != null) { try { c(); } catch { } } }
            switch (f[0])
            {
                case "S":
                    return "K";
                case "Q":
                {
                    if (f.Length < 5) return "E";
                    int sc = int.Parse(f[1]), op = int.Parse(f[2]);
                    string prev = f[3], b = f[4];
                    ui.Invoke(new Action(delegate { if (host.Scr != sc || host.Sopt != op) host.SetScript(sc, op); }));
                    int id = Interlocked.Increment(ref nextId);
                    var tcs = new TaskCompletionSource<List<string>>();
                    pending[id] = tcs;
                    ui.BeginInvoke(new Action(delegate { if (sc == 6) host.EnQuery(id, b, prev); else host.Query(id, b, prev); }));
                    Task done = await Task.WhenAny(tcs.Task, Task.Delay(1500));
                    List<string> list;
                    if (done != tcs.Task) { TaskCompletionSource<List<string>> x; pending.TryRemove(id, out x); return "E"; }
                    list = ScriptFilter(sc, tcs.Task.Result);
                    if (list.Count == 0) return "E";
                    var sb = new StringBuilder("C");
                    foreach (string w in list) sb.Append('\t').Append(w);
                    return sb.ToString();
                }
                case "N":                         // English next words: N <previous word or <s>>  ->  C <word>...
                {
                    if (f.Length < 2) return "E";
                    int id = Interlocked.Increment(ref nextId);
                    var tcs = new TaskCompletionSource<List<string>>();
                    pendingNext[id] = tcs;
                    string pv = f[1];
                    ui.BeginInvoke(new Action(delegate { host.EnNext(id, pv); }));
                    Task done = await Task.WhenAny(tcs.Task, Task.Delay(900));
                    if (done != tcs.Task) { TaskCompletionSource<List<string>> x; pendingNext.TryRemove(id, out x); return "E"; }
                    var sb = new StringBuilder("C");
                    foreach (string w in tcs.Task.Result) sb.Append('\t').Append(w);
                    return sb.ToString();
                }
                case "X":                         // show the next words: X x y h sel word...
                {
                    if (f.Length < 6) return "K";
                    int x = int.Parse(f[1]), bottom = int.Parse(f[2]), h = int.Parse(f[3]), sel = int.Parse(f[4]);
                    var words = new List<string>();
                    for (int i = 5; i < f.Length; i++) words.Add(f[i]);
                    ui.BeginInvoke(new Action(delegate
                    {
                        try { popup.Numbers = false; popup.ShowCands("next \u25B8 Tab", words, sel, new System.Drawing.Rectangle(x, bottom - h, 1, h), true); } catch { }
                    }));
                    return "K";
                }
                case "L":
                    if (f.Length >= 4) { string r = f[2], w = f[3]; ui.BeginInvoke(new Action(delegate { host.Learn(r, w); })); }
                    return "K";
                case "E":
                    if (f.Length >= 6) { string ty = f[1], wd = f[2], pv = f[3], how = f[4], ps = f[5]; ui.BeginInvoke(new Action(delegate { host.EnCommit(ty, wd, pv, how, ps); })); }
                    return "K";
                case "P":
                {
                    if (f.Length < 7) return "K";
                    int x = int.Parse(f[1]), bottom = int.Parse(f[2]), h = int.Parse(f[3]), sel = int.Parse(f[4]);
                    string roman = f[5];
                    var words = new List<string>();
                    for (int i = 6; i < f.Length; i++) words.Add(f[i]);
                    ui.BeginInvoke(new Action(delegate
                    {
                        try { popup.Numbers = true; popup.ShowCands(roman, words, sel, new System.Drawing.Rectangle(x, bottom - h, 1, h), sel == 0); } catch { }
                    }));
                    return "K";
                }
                case "H":
                    ui.BeginInvoke(new Action(delegate { try { popup.HidePopup(); } catch { } }));
                    return "K";
                case "G":
                {
                    int[] cur = null;
                    ui.Invoke(new Action(delegate { cur = getScript(); }));
                    return "T\t" + cur[0] + "\t" + cur[1];
                }
                case "W":
                    if (f.Length >= 2) { int sc = int.Parse(f[1]); ui.BeginInvoke(new Action(delegate { setScript(sc); })); }
                    return "K";
            }
            return "E";
        }
    }
}
