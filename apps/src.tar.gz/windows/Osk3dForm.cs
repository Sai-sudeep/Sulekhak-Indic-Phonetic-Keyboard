using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace Sulekhak
{
    /// <summary>
    /// The 3D on-screen keyboard (the same SVG keyboard as the web tool, with Mac / Windows / iPad / Android styles), shown in a
    /// WebView2 inside a window that never takes the focus. A key click arrives as text: a character, or SPACE / ENTER / BACK / TAB /
    /// ESC / Delete / ArrowLeft / ArrowRight / ArrowUp / ArrowDown / PageUp / PageDown.
    /// </summary>
    class Osk3dForm : Form
    {
        public event Action<string> KeyPressed;
        public event Action<int, bool> SuggestPicked;   // a suggested word was clicked: (index, true when it is a next-word suggestion)
        public event Action<string> TextPicked;      // a ready-made piece of Odia chosen from the long-press popup
        public bool Ready;

        readonly WebView2 wv = new WebView2();
        readonly string dir;
        bool dragging;
        Point dragStart, formStart;

        public Osk3dForm(string dataDir)
        {
            dir = dataDir;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            BackColor = Color.FromArgb(29, 35, 49);
            ClientSize = new Size(S(820), S(376));
            wv.Dock = DockStyle.Fill;
            wv.DefaultBackgroundColor = Color.FromArgb(29, 35, 49);
            Controls.Add(wv);
            var scr = Screen.PrimaryScreen.WorkingArea;
            Location = new Point(scr.Left + (scr.Width - Width) / 2, scr.Bottom - Height - S(12));
        }

        int S(int px) { return (int)Math.Round(px * DeviceDpi / 96.0); }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= 0x08000000 | 0x00000080 | 0x00000008;   // NOACTIVATE | TOOLWINDOW | TOPMOST
                return cp;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int pref = 2; Native.DwmSetWindowAttribute(Handle, 33, ref pref, 4); } catch { }      // rounded corners on Windows 11
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0021) { m.Result = (IntPtr)3; return; }       // WM_MOUSEACTIVATE: never take the focus
            base.WndProc(ref m);
        }

        /// <summary>Starts the page. The window is created off-screen and hidden again, because the WebView2 needs a window handle first.</summary>
        public async Task StartAsync()
        {
            var home = Location;
            Location = new Point(-32000, -32000);
            Show();
            try
            {
                var env = await CoreWebView2Environment.CreateAsync(null, Path.Combine(dir, "webview2"));
                await wv.EnsureCoreWebView2Async(env);
                var core = wv.CoreWebView2;
                core.SetVirtualHostNameToFolderMapping("sulekhak.local", dir, CoreWebView2HostResourceAccessKind.Allow);
                core.Settings.AreDefaultContextMenusEnabled = false;
                core.Settings.AreDevToolsEnabled = false;
                core.Settings.IsZoomControlEnabled = false;
                core.Settings.IsStatusBarEnabled = false;
                core.Settings.AreBrowserAcceleratorKeysEnabled = false;
                core.WebMessageReceived += OnMessage;
                core.Navigate("https://sulekhak.local/osk.html");
            }
            finally
            {
                Hide();
                Location = home;
            }
        }

        static string MapKey(string k)
        {
            switch (k)
            {
                case " ": return "SPACE";
                case "Enter": return "ENTER";
                case "Backspace": return "BACK";
                case "Tab": return "TAB";
                case "Escape": return "ESC";
                default: return k;
            }
        }

        string sugScript = null;

        /// <summary>The suggested-word strip above the keys: choices for the word being typed, or the words that usually come next.</summary>
        public void SetSuggestions(List<string> items, int sel, bool next)
        {
            var o = new System.Collections.Generic.Dictionary<string, object>();
            o["kind"] = next ? "n" : "c";
            o["items"] = items ?? new List<string>();
            o["sel"] = Math.Max(sel, 0);
            sugScript = "window.oskSuggest && window.oskSuggest(" + JsonSerializer.Serialize(o) + ")";
            PushSuggestions();
        }

        string scriptJs = null;

        /// <summary>The key legends follow the language: 0 Odia, 4 Phonetic (IPA).</summary>
        public void SetScript(int sc)
        {
            scriptJs = "window.oskScript && window.oskScript(" + sc + ",0)";
            PushScript();
        }

        void PushScript()
        {
            try { if (Ready && scriptJs != null && wv.CoreWebView2 != null) wv.CoreWebView2.ExecuteScriptAsync(scriptJs); }
            catch { }
        }

        void PushSuggestions()
        {
            try { if (Ready && sugScript != null && wv.CoreWebView2 != null) wv.CoreWebView2.ExecuteScriptAsync(sugScript); }
            catch { }
        }

        void OnMessage(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            string j;
            try { j = e.TryGetWebMessageAsString(); } catch { return; }
            try
            {
                using (var d = JsonDocument.Parse(j))
                {
                    var r = d.RootElement;
                    string t = r.GetProperty("t").GetString();
                    if (t == "key")
                    {
                        string k = r.GetProperty("k").GetString();
                        if (!string.IsNullOrEmpty(k) && KeyPressed != null) KeyPressed(MapKey(k));
                    }
                    else if (t == "text")
                    {
                        string tx = r.GetProperty("s").GetString();
                        if (!string.IsNullOrEmpty(tx) && TextPicked != null) TextPicked(tx);
                    }
                    else if (t == "size")
                    {
                        int w = (int)Math.Round(r.GetProperty("w").GetDouble()), h = (int)Math.Round(r.GetProperty("h").GetDouble());
                        if (w > 100 && h > 60)
                        {
                            var bottom = Bottom;
                            ClientSize = new Size(S(w), S(h));
                            var scr = Screen.FromControl(this).WorkingArea;
                            int x = Math.Max(scr.Left, Math.Min(Left, scr.Right - Width));
                            int y = Math.Max(scr.Top, Math.Min(bottom - Height, scr.Bottom - Height));
                            Location = new Point(x, y);
                        }
                    }
                    else if (t == "sug")
                    {
                        if (SuggestPicked != null) SuggestPicked(r.GetProperty("i").GetInt32(), r.GetProperty("kind").GetString() == "n");
                    }
                    else if (t == "hide") Hide();
                    else if (t == "ready") { Ready = true; PushSuggestions(); PushScript(); }
                    else if (t == "drag")
                    {
                        int s = r.GetProperty("s").GetInt32();
                        if (s == 1) { dragging = true; dragStart = Cursor.Position; formStart = Location; }
                        else if (s == 2 && dragging)
                        {
                            var c = Cursor.Position;
                            Location = new Point(formStart.X + c.X - dragStart.X, formStart.Y + c.Y - dragStart.Y);
                        }
                        else dragging = false;
                    }
                }
            }
            catch { }
        }
    }
}
