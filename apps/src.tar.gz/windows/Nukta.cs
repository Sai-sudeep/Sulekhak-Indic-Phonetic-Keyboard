using System;

namespace Sulekhak
{
    /// <summary>
    /// A lone  >  puts a nukta on the ଡ / ଢ of the word just typed. A port of the macOS input method's nuktaBack: (the reference), kept in step with
    /// keymap/nukta.js through the shared vectors. Works on the text before the caret; the keyboard hook supplies what it typed last.
    /// </summary>
    static class Nukta
    {
        static int Nrm(int c)
        {
            if (c >= 0x0900 && c <= 0x097F && c != 0x0964 && c != 0x0965) return c + 0x200;
            if (c == 0x09F0) return 0x0B30;
            if (c == 0x09F1) return 0x0B71;
            if (c >= 0x0980 && c <= 0x09FF) return c + 0x180;
            return c;
        }
        static bool Mark(int c) { c = Nrm(c); return (c >= 0x0B3E && c <= 0x0B44) || c == 0x0B47 || c == 0x0B48 || c == 0x0B4B || c == 0x0B4C || c == 0x0B56 || c == 0x0B57 || c == 0x0B62 || c == 0x0B63 || c == 0x0B3C || (c >= 0x0B01 && c <= 0x0B03) || c == 0x0B4D || c == 0x200C || c == 0x200D; }
        static bool Lett(int c) { c = Nrm(c); return (c >= 0x0B05 && c <= 0x0B39) || c == 0x0B5C || c == 0x0B5D || c == 0x0B5F || c == 0x0B60 || c == 0x0B61 || c == 0x0B71; }

        /// <summary>The nukta of a script (0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese).</summary>
        public static string Lone(int script) { return ((char)(script == 1 ? 0x093C : (script == 2 || script == 5) ? 0x09BC : 0x0B3C)).ToString(); }

        /// <summary>Null when there is no ଡ/ଢ to mark; otherwise drop = how many code units before the caret to remove, text = what to type instead.</summary>
        public static bool Edit(string before, int script, out int drop, out string text)
        {
            drop = 0; text = null;
            if (string.IsNullOrEmpty(before)) return false;
            int len = before.Length, n = Math.Min(14, len), end = n, i, j, cs;
            string s = before.Substring(len - n);
            bool space = false;
            if (end >= 2 && s[end - 1] == ' ' && (Mark(s[end - 2]) || Lett(s[end - 2]))) { space = true; end--; }
            i = end - 1;
            while (i > 0 && Mark(s[i])) i--;
            if (i < 0 || !Lett(s[i])) return false;
            cs = i;
            while (cs > 0 && Nrm(s[cs - 1]) == 0x0B4D) { cs--; if (cs > 0 && Lett(s[cs - 1])) cs--; else break; }
            int at = -1; string nuk = Lone(script);
            for (j = end - 1; j >= cs; j--)
            {
                int u = s[j];
                if ((Nrm(u) == 0x0B21 || Nrm(u) == 0x0B22) && !(j + 1 < end && Nrm(s[j + 1]) == 0x0B3C)) { at = j + 1; nuk = ((char)(0x0B3C + (u - Nrm(u)))).ToString(); break; }
            }
            if (at < 0) return false;
            string seg = s.Substring(cs, end - cs);
            seg = seg.Substring(0, at - cs) + nuk + seg.Substring(at - cs);
            if (space) seg += " ";
            drop = n - cs; text = seg;
            return true;
        }
    }
}
