$ErrorActionPreference = 'Stop'
$clsid = '{96DB1CE7-2FD4-45AD-BD63-BE53EF2753E6}'
$map = @(
  @('en-US','0409','{247AD1A0-5475-4EFD-A145-E98534721942}'),
  @('or-IN','0448','{7658630A-EA26-4BBC-A217-683F8AF6A72D}'),
  @('hi-IN','0439','{2EC164E4-DAC0-41C0-B3AC-539678AA7D42}'),
  @('mr-IN','044E','{D4F9A6A4-9099-4BAF-8BDE-ACCD53A78C28}'),
  @('bn-IN','0445','{DB803BB1-C7A9-4A21-BEB8-E51ABA1AFF80}'),
  @('as-IN','044D','{1423AD18-CFFA-4959-9D75-0DFCFAB192F5}'))
$list = Get-WinUserLanguageList
foreach ($m in $map) {
  $l = $list | Where-Object { $_.LanguageTag -eq $m[0] } | Select-Object -First 1
  if (-not $l) { $l = New-WinUserLanguage $m[0]; $list.Add($l) }
  $tip = $m[1] + ':' + $clsid + $m[2]
  if ($l.InputMethodTips -notcontains $tip) { [void]$l.InputMethodTips.Add($tip) }
}
Set-WinUserLanguageList $list -Force
