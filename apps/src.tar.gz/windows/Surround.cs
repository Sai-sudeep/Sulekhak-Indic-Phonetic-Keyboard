using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace Sulekhak
{
    /// <summary>
    /// Auto-surround: with text selected, typing ( [ { " ' ` or &lt; wraps the selection instead of replacing it.
    /// The selected text is read through Windows UI Automation (the TextPattern that Notepad, Word, browsers' text boxes,
    /// WordPad, VS Code and most modern editors offer); programs that do not offer it simply behave as before.
    /// Only the vtable slots that are used are named; the others are placeholders that keep the order right.
    /// </summary>
    static class Surround
    {
        public const string Open = "([{\"'`<", Close = ")]}\"'`>";

        [ComImport, Guid("30CBE57D-D9D0-452A-AB13-7AC5AC4825EE"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IUIAutomation
        {
            void CompareElements(); void CompareRuntimeIds(); void GetRootElement(); void ElementFromHandle(); void ElementFromPoint();
            [return: MarshalAs(UnmanagedType.Interface)] IUIAutomationElement GetFocusedElement();
        }

        [ComImport, Guid("D22108AA-8AC5-49A5-837B-37BBB3D7591E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IUIAutomationElement
        {
            void SetFocus(); void GetRuntimeId(); void FindFirst(); void FindAll(); void FindFirstBuildCache(); void FindAllBuildCache(); void BuildUpdatedCache();
            void GetCurrentPropertyValue(); void GetCurrentPropertyValueEx(); void GetCachedPropertyValue(); void GetCachedPropertyValueEx();
            void GetCurrentPatternAs(); void GetCachedPatternAs();
            [return: MarshalAs(UnmanagedType.IUnknown)] object GetCurrentPattern(int patternId);
        }

        [ComImport, Guid("32EBA289-3583-42C9-9C59-3B6D9A1E9B6A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IUIAutomationTextPattern
        {
            void RangeFromPoint(); void RangeFromChild();
            [return: MarshalAs(UnmanagedType.Interface)] IUIAutomationTextRangeArray GetSelection();
        }

        [ComImport, Guid("CE4AE76A-E717-4C98-81EA-47371D028EB6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IUIAutomationTextRangeArray
        {
            int Length { get; }
            [return: MarshalAs(UnmanagedType.Interface)] IUIAutomationTextRange GetElement(int index);
        }

        [ComImport, Guid("A543CC6A-F4AE-494B-8239-C814481187A8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IUIAutomationTextRange
        {
            void Clone(); void Compare(); void CompareEndpoints(); void ExpandToEnclosingUnit(); void FindAttribute(); void FindText(); void GetAttributeValue();
            void GetBoundingRectangles(); void GetEnclosingElement();
            [return: MarshalAs(UnmanagedType.BStr)] string GetText(int maxLength);
        }

        const int UIA_TextPatternId = 10014;

        /// <summary>The text selected in the focused control, or null (nothing selected, a password box, a program without TextPattern, or too slow).</summary>
        public static string Selection()
        {
            try
            {
                var t = Task.Run(delegate { return Read(); });
                return t.Wait(250) ? t.Result : null;          // never hold the keyboard hook for long
            }
            catch { return null; }
        }

        static string Read()
        {
            try
            {
                var uia = (IUIAutomation)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("FF48DBA4-60EF-4201-AA87-54103EEF594E")));
                var el = uia.GetFocusedElement();
                if (el == null) return null;
                var tp = el.GetCurrentPattern(UIA_TextPatternId) as IUIAutomationTextPattern;
                if (tp == null) return null;
                var arr = tp.GetSelection();
                if (arr == null || arr.Length != 1) return null;               // several separate selections: leave it to the program
                string s = arr.GetElement(0).GetText(20000);
                return string.IsNullOrEmpty(s) ? null : s;
            }
            catch { return null; }
        }

        /// <summary>Plain one-line text whose caret positions are unambiguous (so Shift+Left can select exactly it again).</summary>
        public static bool Simple(string s)
        {
            if (string.IsNullOrEmpty(s) || s.Length > 4000) return false;
            foreach (char c in s) if (c < 0x20 || c >= 0x0300) return false;
            return true;
        }
    }
}
