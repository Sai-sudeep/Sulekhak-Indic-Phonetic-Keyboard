const fs=require('fs'),path=require('path');const SE=require(path.join(__dirname,'..','..','..','shared','english.js'));
const D=process.argv[2];if(!D){console.log('usage: node eval_swipe.js <data dir>');process.exit(2);}const E=SE.create();const R=[];
E.load({lex:fs.readFileSync(D+'/en_lex.txt','utf8'),ng:fs.readFileSync(D+'/en_ng.txt','utf8'),fix:''});
if(process.env.TUNE)E.tune(JSON.parse(process.env.TUNE));
let seed=777;function rnd(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
function gauss(){let u=0,v=0;while(!u)u=rnd();while(!v)v=rnd();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}
// key centres in key-widths: rows are 1.3 key-widths apart; row 2 starts half a key in, row 3 one and a half keys in
const K={};['qwertyuiop','asdfghjkl','zxcvbnm'].forEach((r,ri)=>{for(let i=0;i<r.length;i++)K[r[i]]=[0.5+i+[0,0.5,1.5][ri],0.65+1.3*ri];});
const keys={};for(const c in K)keys[c]=K[c];
function catmull(P,per){const out=[];const n=P.length;for(let i=0;i<n-1;i++){const p0=P[Math.max(0,i-1)],p1=P[i],p2=P[i+1],p3=P[Math.min(n-1,i+2)];
 for(let s=0;s<per;s++){const t=s/per,t2=t*t,t3=t2*t;out.push([0.5*((2*p1[0])+(-p0[0]+p2[0])*t+(2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2+(-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),0.5*((2*p1[1])+(-p0[1]+p2[1])*t+(2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2+(-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)]);}}
 out.push(P[n-1]);return out;}
function makePath(w,sigma,skip){let L=[];for(const ch of w){if(L.length&&L[L.length-1]===ch)continue;L.push(ch);}
 // interior letters may be cut (the finger passes beside the key)
 const W=[];L.forEach((c,i)=>{const end=i===0||i===L.length-1;if(!end&&rnd()<skip){W.push([K[c][0]+gauss()*sigma*2.2,K[c][1]+gauss()*sigma*2.2]);}else W.push([K[c][0]+gauss()*sigma,K[c][1]+gauss()*sigma*1.2]);});
 if(W.length<2)return null;
 const dense=catmull(W,12);// resample to ~ every 0.15 key-width with time
 const pts=[];let t=0,acc=0;pts.push([dense[0][0],dense[0][1],0]);
 for(let i=1;i<dense.length;i++){const d=Math.hypot(dense[i][0]-dense[i-1][0],dense[i][1]-dense[i-1][1]);acc+=d;t+=d*55;if(acc>=0.15){pts.push([dense[i][0],dense[i][1],Math.round(t)]);acc=0;}}
 pts.push([dense[dense.length-1][0],dense[dense.length-1][1],Math.round(t+20)]);return pts;}
const lines=fs.readFileSync(D+'/en_lex.txt','utf8').split('\n').filter(Boolean).map(l=>{const p=l.split('\t');return {w:p[0].toLowerCase(),z:+p[1]};});
const pool=lines.filter(x=>/^[a-z]+$/.test(x.w)&&x.z>=300&&x.w.length>=3&&x.w.length<=12);
const cum=[];let tot=0;for(const x of pool){tot+=Math.pow(10,x.z/100-3);cum.push(tot);}
function samp(){const r=rnd()*tot;let lo=0,hi=cum.length-1;while(lo<hi){const m=(lo+hi)>>1;if(cum[m]<r)lo=m+1;else hi=m;}return pool[lo].w;}
const N=+process.env.N||2000;
for(const [sigma,skip] of [[0.12,0.05],[0.22,0.10],[0.32,0.15]]){
 let h1=0,h3=0,h5=0,n=0,ms=0,mx=0;const miss=[];
 for(let i=0;i<N;i++){const w=samp();const p=makePath(w,sigma,skip);if(!p)continue;n++;
  const t0=process.hrtime.bigint();const r=E.swipe({k:keys,p},null,10).map(s=>s.toLowerCase());const d=Number(process.hrtime.bigint()-t0)/1e6;ms+=d;if(d>mx)mx=d;
  const k=r.indexOf(w);if(k===0)h1++;if(k>=0&&k<3)h3++;if(k>=0&&k<5)h5++;if(k<0&&miss.length<10)miss.push(w+'>'+r.slice(0,2).join('/'));}
 R.push([sigma,100*h1/n,100*h3/n]);console.log('swipe sim noise',sigma,'skip',skip,'n='+n,'top1',(100*h1/n).toFixed(1)+'%','top3',(100*h3/n).toFixed(1)+'%','top5',(100*h5/n).toFixed(1)+'%','avg',(ms/n).toFixed(1)+'ms worst',mx.toFixed(0)+'ms','| misses',miss.slice(0,6).join(' '));
}

const ok1=R[0][2]>=98&&R[1][1]>=88&&R[1][2]>=96&&R[2][2]>=90;
console.log(ok1?'swipe gates passed':'swipe gates FAILED (top3 >=98 / >=96 / >=90 and top1 >=88 at noise 0.22)');process.exit(ok1?0:1);
