// Held-out measurement of next-word prediction and in-word completion with context.
//   node eval_lm.js <heldout.txt> <label=dir> [<label=dir> ...]        (dir has en_lex.txt en_ng.txt en_fix.txt)
// Each sentence of heldout.txt is in none of the counts (build_lm.py leaves every 200th sentence out).  For every word of it the engine is asked
//   N  what comes next, given the one / two words before  (top-1 / top-3 / top-5)
//   C  the first 2 letters of the word, given the context (is the word among the first 3 suggestions)
// "1 word" = only the previous word is given; "2 words" = the two previous words.  The numbers are percentages of the words asked.
const fs = require('fs'), path = require('path');
const SE = require(path.join(__dirname, '..', '..', '..', 'shared', 'english.js'));
const hold = process.argv[2], dirs = process.argv.slice(3).map(a => a.split('='));
const LIM = +(process.env.LIM || 4000);
const TOK = /[a-z]+(?:'[a-z]+)?/g;
let lines = fs.readFileSync(hold, 'utf8').split('\n').filter(Boolean);
let seed = 7; const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
lines = lines.map(l => [rnd(), l]).sort((a, b) => a[0] - b[0]).slice(0, LIM).map(x => x[1]);
const rd = p => fs.readFileSync(p, 'utf8');
for (const [label, dir] of dirs) {
  const E = SE.create(); E.load({ lex: rd(dir + '/en_lex.txt'), ng: rd(dir + '/en_ng.txt'), fix: rd(dir + '/en_fix.txt') });
  const R = { n1: [0, 0, 0, 0], n2: [0, 0, 0, 0], c1: [0, 0, 0], c2: [0, 0, 0] };
  const t0 = Date.now();
  for (const line of lines) {
    const t = (line.replace(/’/g, "'").toLowerCase().match(TOK) || []).map(w => (E._find(w) >= 0 ? w : null));
    for (let i = 0; i < t.length; i++) {
      const w = t[i]; if (!w || E.zipf(w) < 230) continue;
      const p1 = i === 0 ? '<s>' : t[i - 1]; if (!p1) continue;
      const p2 = i >= 2 ? t[i - 2] : (i === 1 ? '<s>' : null);
      const two = p2 && p1 !== '<s>' ? p2 + ' ' + p1 : p1;
      const hit = (list) => { const l = list.map(x => x.toLowerCase()); const k = l.indexOf(w); return k; };
      for (const [tag, ctx] of [['1', p1], ['2', two]]) {
        const r = R['n' + tag]; r[3]++;
        const k = hit(E.next(ctx, 5)); if (k === 0) r[0]++; if (k >= 0 && k < 3) r[1]++; if (k >= 0) r[2]++;
      }
      if (w.length >= 4) for (const [tag, ctx] of [['1', p1], ['2', two]]) {
        const r = R['c' + tag]; r[2]++;
        const res = E.suggest(w.slice(0, 2), ctx, { noCorrect: true }).list.slice(1).map(x => x.toLowerCase()); // list[0] is what was typed
        const k = res.indexOf(w); if (k >= 0 && k < 3) r[0]++; if (k === 0) r[1]++;
      }
    }
  }
  const pc = (a, b) => (100 * a / b).toFixed(1).padStart(5);
  console.log(`${label.padEnd(14)} next-word 1 word: top1 ${pc(R.n1[0], R.n1[3])} top3 ${pc(R.n1[1], R.n1[3])} top5 ${pc(R.n1[2], R.n1[3])} | 2 words: top1 ${pc(R.n2[0], R.n2[3])} top3 ${pc(R.n2[1], R.n2[3])} top5 ${pc(R.n2[2], R.n2[3])} (n=${R.n1[3]})`);
  console.log(`${''.padEnd(14)} 2 letters + context, words >= 4 letters: 1 word: in top3 ${pc(R.c1[0], R.c1[2])}  top1 ${pc(R.c1[1], R.c1[2])} | 2 words: in top3 ${pc(R.c2[0], R.c2[2])}  top1 ${pc(R.c2[1], R.c2[2])} (n=${R.c1[2]})   ${((Date.now() - t0) / 1000).toFixed(0)}s`);
}
