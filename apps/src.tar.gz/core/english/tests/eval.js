const fs=require('fs'),path=require('path');const SE=require(path.join(__dirname,'..','..','..','shared','english.js'));const M={};
const DIR=process.argv[2];
if(!DIR){console.log('usage: node eval.js <dir with en_lex.txt en_ng.txt en_fix.txt>');process.exit(2);}
const rd=p=>fs.readFileSync(p,'utf8');
let seed=12345;function rnd(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
function gauss(){let u=0,v=0;while(!u)u=rnd();while(!v)v=rnd();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}
const lexLines=rd(DIR+'/en_lex.txt').split('\n').filter(Boolean).map(l=>{const p=l.split('\t');return {f:p[0],w:p[0].toLowerCase(),z:+p[1]};});
const lexSet=new Map(lexLines.map(x=>[x.w,x]));
const fixAll=rd(DIR+'/en_fix.txt').split('\n').filter(Boolean).map(l=>l.split('\t'));
// held-out typos: 3000 random fix entries removed from the engine's fix table
const shuffled=fixAll.filter(([a,b])=>/^[a-z]+$/.test(a)&&/^[a-z]+$/.test(b)&&lexSet.has(b)&&lexSet.get(b).z>=250).sort(()=>rnd()-0.5);
const heldFix=shuffled.slice(0,3000), heldSet=new Set(heldFix.map(x=>x[0]));
const fixTrain=fixAll.filter(([a])=>!heldSet.has(a)).map(x=>x.join('\t')).join('\n');
function mk(dir,fix){const E=SE.create();E.load({lex:rd(dir+'/en_lex.txt'),ng:rd(dir+'/en_ng.txt'),fix:fix});return E;}
const E=mk(DIR,fixTrain);
if(process.env.TUNE)E.tune(JSON.parse(process.env.TUNE));
const ABBR='pls plz thnx thx tmrw tmr bcoz cuz gud nyc luv abt bday ppl msg pic info insta fb tbh imo idk lmk brb ttyl omw ily gm gn np ty yw ok okk okay hmm hmmm yess noooo sooo veryy thankss helloo heyy hii byee'.split(' ');
const pool=lexLines.filter(x=>/^[a-z]+$/.test(x.w)&&x.z>=300&&x.w.length>=4);
function pickByFreq(arr,n){ // frequency weighted (10^zipf)
  const cum=[];let t=0;for(const x of arr){t+=Math.pow(10,x.z/100-3);cum.push(t);}
  const out=[];for(let i=0;i<n;i++){const r=rnd()*t;let lo=0,hi=cum.length-1;while(lo<hi){const m=(lo+hi)>>1;if(cum[m]<r)lo=m+1;else hi=m;}out.push(arr[lo]);}return out;}
function pct(a,b){return (100*a/b).toFixed(1)+'%';}
// ---------- A. completion
{const ws=pickByFreq(pool,3000);let h1=0,h3=0,h5=0;
 for(const x of ws){const w=x.w;const n=Math.max(2,Math.min(w.length-1,Math.round(w.length*(0.35+0.3*rnd()))));const pre=w.slice(0,n);
  const r=E.suggest(pre,null);const rest=r.list.map(s=>s.toLowerCase()).filter((s,i)=>!(i===0&&r.auto===0));
  const i=rest.indexOf(w);if(i===0)h1++;if(i>=0&&i<3)h3++;if(i>=0&&i<5)h5++;}
 console.log('A completion (freq-weighted words, prefix 35-65%): top1',pct(h1,3000),'top3',pct(h3,3000),'top5',pct(h5,3000));M.A5=100*h5/3000;}
// ---------- B. held-out real misspellings
{let a1=0,t3=0,any=0;const bad=[];
 for(const [typ,tgt] of heldFix){const r=E.suggest(typ,null);const l=r.list.map(s=>s.toLowerCase());
  if(r.auto&&l[0]===tgt)a1++;else if(bad.length<12)bad.push(typ+'>'+tgt+' got '+l.slice(0,3).join(','));
  if(l.slice(0,3).includes(tgt))t3++;if(l.includes(tgt))any++;}
 console.log('B held-out real misspellings (3000): auto-corrected right',pct(a1,3000),'in top3',pct(t3,3000),'anywhere',pct(any,3000));M.Bauto=100*a1/3000;M.B3=100*t3/3000;console.log('  misses e.g.',bad.slice(0,8).join(' | '));}
// ---------- C. synthetic keyboard typos
{const N=3000, ws=pickByFreq(pool,N);const kinds=['sub','del','ins','swap'];let st={};kinds.forEach(k=>st[k]={n:0,auto:0,top3:0});
 const near=SE.KX;const nb={};for(const a in SE.KX){nb[a]=[];for(const b in SE.KX)if(a!==b&&SE.adjacent(a,b))nb[a].push(b);}
 for(const x of ws){const w=x.w;const k=kinds[Math.floor(rnd()*4)];let t=w;const p=1+Math.floor(rnd()*(w.length-1));
  if(k==='sub'){const c=w[p];const o=nb[c];t=w.slice(0,p)+o[Math.floor(rnd()*o.length)]+w.slice(p+1);}
  else if(k==='del'){t=w.slice(0,p)+w.slice(p+1);}
  else if(k==='ins'){const c=w[p];const o=nb[c];t=w.slice(0,p)+o[Math.floor(rnd()*o.length)]+w.slice(p);}
  else{if(w[p]===w[p-1])continue;t=w.slice(0,p-1)+w[p]+w[p-1]+w.slice(p+1);}
  if(t===w||lexSet.has(t)&&lexSet.get(t).z>=230)continue;
  const r=E.suggest(t,null);const l=r.list.map(s=>s.toLowerCase());st[k].n++;if(r.auto&&l[0]===w)st[k].auto++;if(l.slice(0,3).includes(w))st[k].top3++;}
 console.log('C synthetic typos on frequent words (typo is not itself a word):');for(const k of kinds){console.log('  ',k,'n='+st[k].n,'auto-right',pct(st[k].auto,st[k].n),'top3',pct(st[k].top3,st[k].n));M['C3'+k]=100*st[k].top3/st[k].n;M['Cauto'+k]=100*st[k].auto/st[k].n;}}
// ---------- D. false autocorrection
{const ws=pickByFreq(lexLines.filter(x=>/^[a-z']+$/.test(x.w)&&x.z>=200&&x.w.length>=2),6000);let bad=0;const ex=[];
 for(const x of ws){const r=E.suggest(x.w,null);if(r.auto&&r.list[0].toLowerCase()!==x.w){bad++;if(ex.length<8)ex.push(x.w+'>'+r.list[0]);}}
 M.Dbad=bad;console.log('D correctly typed words changed by autocorrect:',bad,'of 6000 ('+pct(bad,6000)+')',ex.join(' '));
 const unk=('yaar bruhhh sudeep odisha bhubaneswar kolkata mumbaikar haanji arre wahh lolll omggg bestie sksksk rizzler sigma aura bhai didi chai samosa kurta saree dhoti lassi paneer biryani bhaiya anna akka amma appa thambi macha ayyo nandri dhanyavad shukriya pranam namaskar jai hind vande mataram swachh aadhaar paytm phonepe gpay zomato swiggy ola uber flipkart myntra nykaa byju unacademy jio airtel vodafone infosys wipro tcs reliance tata birla adani ambani modi rahul sonia mamata nitish yogi kejriwal stalin naidu jagan revanth pinarayi siddaramaiah ashwini vaidya pratik snehasish sulekhak lekhani odia oriya kui kondh santali ho mundari bodo dogri maithili konkani manipuri kashmiri sindhi nepali ghibli kubernetes pytorch numpy pandas xlsx docx pptx readme config repo devops prod kasu').split(' ');
 let ub=0;const ue=[];for(const w of unk){const r=E.suggest(w,null);if(r.auto&&r.list[0].toLowerCase()!==w){ub++;ue.push(w+'>'+r.list[0]);}}
 M.D2=ub;console.log('D2 plausible words/names missing from the list changed by autocorrect:',ub,'of',unk.length,ue.join(' '));}
{let ab=0,ae=[];for(const w of ABBR){const r=E.suggest(w,null);if(r.auto&&r.list[0].toLowerCase()!==w){ab++;ae.push(w+'>'+r.list[0]);}}M.D3=ab;console.log('D3 chat abbreviations changed by autocorrect:',ab,'of',ABBR.length,ae.join(' '));}
// ---------- E. next word, held-out text (Brown+Reuters left out of the model)

// ---------- G. speed
{const ws=pickByFreq(pool,300);let t0=process.hrtime.bigint();let mx=0;for(const x of ws){const a=process.hrtime.bigint();E.suggest(x.w.slice(0,3),'the');E.suggest(x.w.slice(0,x.w.length-1)+'q',null);const d=Number(process.hrtime.bigint()-a)/1e6;if(d>mx)mx=d;}
 M.Gavg=Number(process.hrtime.bigint()-t0)/1e6/600;console.log('G speed: avg',(Number(process.hrtime.bigint()-t0)/1e6/600).toFixed(2),'ms per suggest, worst pair',mx.toFixed(1),'ms');}

// ---------- regression gates (set from the measured values, with a margin: these catch a change that makes things worse, they are not accuracy claims)
const G=[['A5>=72',M.A5>=72],['B top3>=88',M.B3>=88],['B auto>=60',M.Bauto>=60],['C sub auto>=80',M.Cautosub>=80],['C ins auto>=85',M.Cautoins>=85],['C top3 sub/del/ins/swap>=80',['sub','del','ins','swap'].every(k=>M['C3'+k]>=80)],
  ['D <=8 of 6000',M.Dbad<=8],['D2 <=5 of 117',M.D2<=5],['D3 <=10 of 46',M.D3<=10],['G avg<=15ms',M.Gavg<=15]];
let bad=0;for(const [n,ok] of G){if(!ok){bad++;console.log('GATE FAILED',n);}}
console.log(G.length-bad+' gates passed, '+bad+' failed');process.exit(bad?1:0);
