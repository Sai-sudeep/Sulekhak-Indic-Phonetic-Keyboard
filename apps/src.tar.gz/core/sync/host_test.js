/* The calls the native apps (Mac, iPhone/iPad) make into host.js, run in a plain JavaScript context with the same shims the apps provide (see mac/src/personal/prelude.js).
   usage: node host_test.js <folder with prelude.js english.js learning.js drive.js personal.js host.js>                                                                 */
const fs = require('fs'), vm = require('vm'), path = require('path');
const dir = process.argv[2];
let bad = 0;
function check(what, ok, extra) { console.log((ok ? 'ok   ' : 'FAIL ') + what + (ok ? '' : '  ' + (extra || ''))); if (!ok) bad++; }
function device(did) {
  const posts = [], learned = [];
  const timers = new Set();
  const sandbox = {
    __log: s => {}, __timer: (fn, ms, rep) => { const t = rep ? setInterval(fn, ms) : setTimeout(fn, ms); timers.add(t); t.unref && t.unref(); return t; },
    __untimer: t => clearTimeout(t), __fetch: (m, u, h, b, done) => setTimeout(() => done(0, '{}', ''), 0),
    __post: j => posts.push(JSON.parse(j)), __learnAdd: j => learned.push(JSON.parse(j))
  };
  const ctx = vm.createContext(sandbox);
  for (const f of ['prelude', 'english', 'learning', 'drive', 'personal', 'host']) vm.runInContext(fs.readFileSync(path.join(dir, f + '.js'), 'utf8'), ctx, { filename: f + '.js' });
  const SKM = vm.runInContext('SKM', ctx);
  return { SKM, posts, learned, ctx, stop: () => timers.forEach(t => { clearTimeout(t); clearInterval(t); }) };
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const A = device('a'), B = device('b');
  A.SKM.init('iA1', 'A', '[]', 'ios'); B.SKM.init('iB1', 'B', '[]', 'ios');
  A.SKM.setMode(0, 0, false);
  await sleep(50);
  const need = A.posts.find(p => p.t === 'sk-need' && p.lang === 'or');
  check('setMode asks the app for the Odia file', !!need);
  A.SKM.hostLoad('or', '');
  await sleep(50);
  A.SKM.pick('namaskar', 'ନମସ୍କାର', '');
  A.SKM.pick('namaskar', 'ନମସ୍କାର', '');
  A.SKM.swipe('ନମସ୍କାର', true, '');
  A.SKM.word('ନମସ୍କାର', '');
  await sleep(2600);
  const sv = A.posts.filter(p => p.t === 'sk-save' && p.lang === 'or').pop();
  check('learning is saved to the app a couple of seconds later', !!sv && sv.text.indexOf('namaskar') > 0);
  const ser = A.SKM.serialize('or');
  check('serialize() gives the language file', ser && ser.charAt(0) === '{' && ser === (sv && sv.text), ser && ser.slice(0, 60));
  // device B takes in what A saved (the keyboard re-reading what the app merged)
  B.SKM.setMode(0, 0, false); await sleep(50);
  B.SKM.hostLoad('or', ser);
  await sleep(50);
  check('another device merges it', B.SKM.serialize('or').indexOf('namaskar') > 0);
  check('...and the engine is fed the pairs', B.learned.length > 0 && JSON.stringify(B.learned).indexOf('namaskar') > 0, JSON.stringify(B.learned).slice(0, 100));
  // English
  const lex = ['the\t900', 'receive\t700', 'hello\t800', 'teh\t0'].filter(l => !l.startsWith('teh')).join('\n') + '\n';
  const ng = '<s>\tthe:10 hello:20\nthe:\n'.replace('the:\n', '');
  const fix = 'teh\tthe\nrecieve\treceive\n';
  check('enLoad accepts the word lists', A.SKM.enLoad(lex, ng, fix) === true);
  A.SKM.setMode(0, 0, true); await sleep(50);
  const r = JSON.parse(A.SKM.enQuery('teh', '<s>'));
  check('enQuery corrects teh', r.list[0] === 'the' && r.auto === 1, JSON.stringify(r));
  for (let i = 0; i < 3; i++) A.SKM.enCommit('zorbatrix', 'zorbatrix', '<s>', 'typed', '');
  await sleep(2600);
  const en = A.posts.filter(p => p.t === 'sk-save' && p.lang === 'en').pop();
  check('English learning is saved too', !!en && en.text.indexOf('zorbatrix') > 0);
  check('enUnload drops the word lists', A.SKM.enUnload() === true && A.SKM.enReady() === false);
  // the app: sync all languages when signed out ends cleanly
  B.posts.length = 0;
  B.SKM.syncEvery();
  await sleep(1500);
  const done = B.posts.find(p => p.t === 'sk-every-done');
  check('syncEvery reports when it is finished', !!done, JSON.stringify(B.posts.slice(-3)));
  const asked = B.posts.filter(p => p.t === 'sk-need').map(p => p.lang).sort().join(',');
  check('syncEvery looked at every language', asked === 'as,bn,en,hi,mr', asked);
  A.stop(); B.stop();
  console.log(bad ? 'HOST TEST FAILED (' + bad + ')' : 'HOST TEST PASSED');
  process.exit(bad ? 1 : 0);
})();
