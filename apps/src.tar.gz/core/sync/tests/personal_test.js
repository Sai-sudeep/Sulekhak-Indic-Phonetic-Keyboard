'use strict';
/* The page-side glue (personal.js) run in a sandbox that looks like a WebView: window, timers, localStorage, fetch -> the fake Drive.
   Two "pages" (two devices) with their own sandbox share one fake Drive. */
var vm = require('vm'), fs = require('fs'), path = require('path'), FakeDrive = require('./fakedrive.js');
var src = ['../learning.js', '../drive.js', '../personal.js'].map(function (f) { return fs.readFileSync(path.join(__dirname, f), 'utf8'); });
var passed = 0, failed = 0;
function ok(c, n, x) { if (c) passed++; else { failed++; console.log('FAIL ' + n + (x ? ' :: ' + x : '')); } }
var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

function page(fd, did, files) {
  var posts = [], ls = {}, timers = [], sandbox = {
    console: console, URL: URL, Promise: Promise, JSON: JSON, Math: Math, Date: Date, Object: Object, Array: Array,
    setTimeout: function (f, ms) { return setTimeout(f, Math.min(ms || 0, 50)); }, clearTimeout: clearTimeout,
    setInterval: function () { return 0; }, clearInterval: function () {},
    navigator: { userAgent: 'Chrome/1.0' }, localStorage: { getItem: function (k) { return k in ls ? ls[k] : null; }, setItem: function (k, v) { ls[k] = String(v); } },
    fetch: function (u, i) { return fd.fetch(u, i); }
  };
  sandbox.window = sandbox; sandbox.self = sandbox;
  vm.createContext(sandbox);
  src.forEach(function (s, i) { vm.runInContext(s, sandbox, { filename: ['learning', 'drive', 'personal'][i] }); });
  var imeAdds = [];
  sandbox.imeLearnAdd = function (p) { imeAdds.push(p); };
  return { w: sandbox, posts: posts, ls: ls, imeAdds: imeAdds, files: files || {} };
}
function hostInit(p, did, allowed) {
  var SKP = p.w.SKP, files = p.files;
  SKP.initHost({ did: did, name: did, platform: 'test', allowed: allowed, debounceMs: 5,
    post: function (m) {
      p.posts.push(m);
      if (m.t === 'sk-need') setTimeout(function () { SKP.hostLoad(m.lang, files[m.lang] || ''); }, 1);
      if (m.t === 'sk-save') files[m.lang] = m.text;
      if (m.t === 'sk-token') setTimeout(function () { SKP.setToken('good', 3600, 'me@example.com'); }, 1);
    } });
}
(async function () {
  var fd = new FakeDrive();
  var A = page(fd, 'dA'), B = page(fd, 'dB');
  hostInit(A, 'dA', ['me@example.com']); hostInit(B, 'dB', ['me@example.com']);
  A.w.SKP.setToken('good', 3600, 'me@example.com'); B.w.SKP.setToken('good', 3600, 'me@example.com');   // the host signed in at start-up
  ok(A.w.SKP.ready, 'glue ready');

  // typing in Odia on page A
  A.w.SKP.setMode(0, 0, false); await sleep(30);
  ok(A.w.SKP.lang === 'or', 'script 0 -> Odia');
  A.w.SKP.prev('ମୋ');
  for (var i = 0; i < 4; i++) A.w.SKP.onPick('ghara', 'ଘର');
  var list = A.w.SKP.rerank('ghara', 'ମୋ', ['ଘାର', 'ghara', 'ଘରା', 'ଘର']);
  ok(list[1] === 'ghara', 'typed text stays in slot 2', list.join(' '));
  ok(list[0] === 'ଘର', 'the word picked four times is first', list.join(' '));
  await sleep(2300);                                        // local save fires
  ok(A.files.or && JSON.parse(A.files.or).pick.ghara, 'local copy handed to the host');
  ok(!A.files.hi && !A.files.en, 'nothing written for other languages');

  // switching to Hindi: Odia history must not affect it
  A.w.SKP.setMode(1, 0, false); await sleep(30);
  ok(A.w.SKP.lang === 'hi', 'script 1 -> Hindi');
  ok(A.w.SKP.rerank('ghara', null, ['घाट', 'ghara', 'घर', 'घरा']).join() === ['घाट', 'ghara', 'घर', 'घरा'].join(), 'no Odia history leaks into the Hindi list');
  A.w.SKP.setMode(1, 1, false); ok(A.w.SKP.lang === 'mr', 'Marathi option -> mr');
  A.w.SKP.setMode(2, 0, false); ok(A.w.SKP.lang === 'bn', 'Bangla'); A.w.SKP.setMode(5, 0, false); ok(A.w.SKP.lang === 'as', 'Assamese');
  A.w.SKP.setMode(3, 0, false); ok(A.w.SKP.lang === null, 'IPA / unknown script: nothing is learned');
  A.w.SKP.onPick('x', 'y'); ok(!A.w.SKP.stats(), 'no stats, nothing recorded for IPA');
  A.w.SKP.setMode(0, 0, false);

  // sign-in (token comes from the host), sync
  var before = fd.uploads;
  await A.w.SKP.syncNow(); await sleep(50);
  ok(A.w.SKP.state === 'synced' || A.w.SKP.state === 'signed-in', 'state after sync: ' + A.w.SKP.state + ' ' + A.w.SKP.detail);
  ok(fd.fileTexts('sulekhak-learning-or.json').length === 1, 'Odia file in the cloud');
  ok(fd.fileTexts('sulekhak-learning-hi.json').length === 0, 'no Hindi file because nothing was learned in Hindi');

  // second device
  B.w.SKP.setMode(0, 0, false); await sleep(30);
  await B.w.SKP.syncNow(); await sleep(50);
  ok(B.w.SKP.stats() && B.w.SKP.stats().picks === 1, 'device B got the pick', JSON.stringify(B.w.SKP.stats()));
  ok(B.imeAdds.length >= 1 && B.imeAdds[0][0][1] === 'ଘର', 'and the engine page was told to learn it', JSON.stringify(B.imeAdds));
  B.w.SKP.onPick('pani', 'ପାଣି'); B.w.SKP.onSwipe('ପାଣି', true); B.w.SKP.onSwipe('ଘର', false); B.w.SKP.onCorrection('paani', 'ପାଣି');
  await B.w.SKP.syncNow(); await A.w.SKP.syncNow(); await sleep(50);
  var sa = A.w.SKP.stats(); ok(sa.picks === 2 && sa.swipes === 2 && sa.corrections === 1, 'A sees B\'s picks, swipes and corrections', JSON.stringify(sa));

  // refused account
  var fd2 = new FakeDrive(), E = page(fd2, 'dE'); hostInit(E, 'dE', ['someone.else@gmail.com']); E.w.SKP.setToken('good', 3600, 'me@example.com');
  E.w.SKP.setMode(0, 0, false); E.w.SKP.onPick('a', 'b'); await sleep(30);
  await E.w.SKP.syncNow(); await sleep(50);
  ok(E.w.SKP.state === 'refused', 'wrong account -> refused (' + E.w.SKP.state + ')');
  ok(fd2.calls.length === 0, 'nothing was sent to Drive', String(fd2.calls.length));
  ok(E.posts.some(function (m) { return m.t === 'sk-signout'; }), 'the host was told to sign out');

  // web page flavour (localStorage)
  var fd3 = new FakeDrive(), W = page(fd3, 'w'); W.w.SKP.initWeb({ clientId: 'x', allowed: ['me@example.com'], script: 0 }); await sleep(30);
  W.w.SKP.onPick('kal', 'କଲ'); await sleep(2300);
  ok(W.ls['sulekhak-learn-or'] && JSON.parse(W.ls['sulekhak-learn-or']).pick.kal, 'web: local copy in localStorage');
  ok(!W.ls['sulekhak-learn-hi'], 'web: no Hindi copy');

  console.log(passed + ' passed, ' + failed + ' failed'); process.exit(failed ? 1 : 0);
})().catch(function (e) { console.log('CRASH', e && e.stack || e); process.exit(2); });
