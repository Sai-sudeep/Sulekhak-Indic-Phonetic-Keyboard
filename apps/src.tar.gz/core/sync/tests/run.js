'use strict';
/* node core/sync/tests/run.js  — exits non-zero on any failure */
var L = require('../learning.js'), S = require('../drive.js'), FakeDrive = require('./fakedrive.js');
var passed = 0, failed = 0, failures = [];
function ok(cond, name, extra) { if (cond) passed++; else { failed++; failures.push(name + (extra ? ' :: ' + extra : '')); console.log('FAIL ' + name + (extra ? ' :: ' + extra : '')); } }
function eq(a, b, name) { ok(L.stableString(a) === L.stableString(b), name, L.stableString(a).slice(0, 120) + ' != ' + L.stableString(b).slice(0, 120)); }
function section(s) { console.log('\n# ' + s); }
/* seeded PRNG so a failure can be replayed */
function rng(seed) { var s = seed >>> 0; return function () { s = (s + 0x6D2B79F5) >>> 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function clockFrom(start) { var t = start; return function () { return t++; }; }

var ROM = ['kal', 'kala', 'ama', 'bhal', 'jibana', 'pani', 'ghara', 'desa', 'nama', 'sahara'];
var WORDS = ['କଲ', 'କଳା', 'ଆମ', 'ଭଲ', 'ଜୀବନ', 'ପାଣି', 'ଘର', 'ଦେଶ', 'ନାମ', 'ସହର', 'ବାଗ‌ଦେବୀ', 'ତଦ୍‌ବ୍ୟତୀତ'];
function randomOps(store, lang, r, n) {
  for (var i = 0; i < n; i++) {
    var k = Math.floor(r() * 7), ro = ROM[Math.floor(r() * ROM.length)], w = WORDS[Math.floor(r() * WORDS.length)], pv = WORDS[Math.floor(r() * WORDS.length)];
    if (k === 0 || k === 1) store.recordPick(lang, ro, w, r() < 0.5 ? pv : null);
    else if (k === 2) store.recordWord(lang, w, pv);
    else if (k === 3) store.recordCorrection(lang, w + 'x', w);
    else if (k === 4) store.recordSwipe(lang, w, r() < 0.7, pv);
    else if (k === 5) store.recordSkip(lang, ro, w);
    else store.addDictWord(lang, ro + i, w, 6);
  }
}
function sumCounts(doc) { var t = 0, a, b; ['pick', 'next', 'corr', 'skip'].forEach(function (m) { for (a in doc[m]) for (b in doc[m][a]) t += L.total(doc[m][a][b]); }); ['uni', 'swipe'].forEach(function (m) { for (a in doc[m]) t += L.total(doc[m][a]); }); return t; }

/* ------------------------------------------------------------------ */
section('merge is commutative, associative, idempotent');
(function () {
  for (var seed = 1; seed <= 60; seed++) {
    var r = rng(seed), mk = function (id) { return new L.Store({ deviceId: id, clock: clockFrom(1e9 + seed * 1000 + id.charCodeAt(1) * 100000) }); };
    var a = mk('dA'), b = mk('dB'), c = mk('dC');
    randomOps(a, 'or', r, 40); randomOps(b, 'or', r, 40); randomOps(c, 'or', r, 40);
    var A = a.doc('or'), B = b.doc('or'), C = c.doc('or');
    var ab = L.mergeDoc(A, B), ba = L.mergeDoc(B, A);
    if (L.stableString(ab) !== L.stableString(ba)) { ok(false, 'commutative seed ' + seed); continue; }
    var l = L.mergeDoc(L.mergeDoc(A, B), C), rr = L.mergeDoc(A, L.mergeDoc(B, C));
    if (L.stableString(l) !== L.stableString(rr)) { ok(false, 'associative seed ' + seed); continue; }
    if (L.stableString(L.mergeDoc(ab, ab)) !== L.stableString(ab)) { ok(false, 'idempotent seed ' + seed); continue; }
    if (L.stableString(L.mergeDoc(ab, A)) !== L.stableString(ab)) { ok(false, 're-merging an old copy changes nothing, seed ' + seed); continue; }
    ok(sumCounts(l) === sumCounts(A) + sumCounts(B) + sumCounts(C), 'no counts lost or double counted, seed ' + seed, sumCounts(l) + ' vs ' + (sumCounts(A) + sumCounts(B) + sumCounts(C)));
  }
  ok(true, '60 random seeds');
})();

section('ties: two devices change the same thing at the same instant (found by a failing stress run: the merge must not depend on the order)');
(function () {
  var rr = rng(4242), bad = 0, n = 0, i;
  function mkdoc(by, stamp, wt, devName, rem) {
    var d = L.emptyDoc('or');
    d.dict['ama\tଆମ'] = { w: 'ଆମ', r: 'ama', wt: wt, a: stamp, d: rem ? stamp + 1 : 0, by: by };
    d.devices[by] = { n: devName, p: 'test', s: stamp };
    d.devices.shared = { n: devName, p: 'test', s: 5 };      /* the same device record seen with the same stamp but different text */
    return d;
  }
  for (i = 0; i < 300; i++) {
    var st = 1 + Math.floor(rr() * 3);                         /* a tiny range: ties are the common case */
    var A = mkdoc('dA', st, 1 + Math.floor(rr() * 3), 'phone A', rr() < 0.2), B = mkdoc('dB', st, 1 + Math.floor(rr() * 3), 'phone B', rr() < 0.2), C = mkdoc('dC', st, 1 + Math.floor(rr() * 3), 'phone C', rr() < 0.2);
    var ab = L.stableString(L.mergeDoc(A, B)), ba = L.stableString(L.mergeDoc(B, A));
    var l = L.stableString(L.mergeDoc(L.mergeDoc(A, B), C)), r2 = L.stableString(L.mergeDoc(A, L.mergeDoc(B, C))), r3 = L.stableString(L.mergeDoc(L.mergeDoc(C, A), B));
    n++; if (ab !== ba || l !== r2 || l !== r3) bad++;
  }
  ok(bad === 0, 'dictionary entries and device names merge the same in every order, even on equal time stamps (' + bad + ' of ' + n + ' differ)');
})();

section('a stale copy can never lower anyone\'s counter');
(function () {
  var a = new L.Store({ deviceId: 'dA', clock: clockFrom(1000) });
  a.recordPick('or', 'kal', 'କଲ', null);
  var old = JSON.parse(a.serialize('or'));
  a.recordPick('or', 'kal', 'କଲ', null); a.recordPick('or', 'kal', 'କଲ', null);
  a.load('or', JSON.stringify(old));                          // an old upload arrives later
  eq(L.total(a.doc('or').pick.kal['କଲ']), 3, 'still 3 after merging the 1-pick copy');
})();

section('languages never mix');
(function () {
  var s = new L.Store({ deviceId: 'dA', clock: clockFrom(1000) });
  s.recordPick('or', 'kal', 'କଲ', null); s.recordPick('hi', 'kal', 'कल', null); s.recordPick('en', 'kal', 'call', null);
  ok(!s.doc('hi').pick.kal['କଲ'] && !s.doc('or').pick.kal['कल'], 'or and hi pick tables are separate');
  ok(s.serialize('or').indexOf('कल') < 0 && s.serialize('or').indexOf('call') < 0, 'the Odia file has no Hindi or English words');
  ok(s.serialize('en').indexOf('କଲ') < 0, 'the English file has no Odia words');
  var r = s.merge('hi', JSON.parse(s.serialize('or')));
  ok(!r.ok && /language mismatch/.test(r.reason), 'an Odia file offered for Hindi is refused: ' + r.reason);
  eq([L.langFor(0, 0, false), L.langFor(1, 0, false), L.langFor(1, 1, false), L.langFor(2, 0, false), L.langFor(5, 0, false), L.langFor(0, 0, true), L.langFor(3, 0, false)],
     ['or', 'hi', 'mr', 'bn', 'as', 'en', null], 'typing mode -> language (IPA learns nothing)');
  var threw = false; try { s.recordPick('xx', 'a', 'b', null); } catch (e) { threw = true; }
  ok(threw, 'unknown language rejected');
  // a pick in Hindi must not change Odia suggestions
  var list = ['କଲ', 'କଳା', 'କଲା'];
  eq(s.rerank('hi', 'kal', null, list.slice()), list, 'Hindi history does not reorder an Odia list');
})();

section('what is learned changes the order, gently');
(function () {
  var s = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  var list = ['କଲ', 'କଳା', 'କଲା', 'କାଳ'];
  eq(s.rerank('or', 'kala', null, list.slice()), list, 'nothing learned: same order');
  for (var i = 0; i < 6; i++) s.recordPick('or', 'kala', 'କଲା', null);
  var out = s.rerank('or', 'kala', null, list.slice());
  ok(out[0] === 'କଲା', 'a word picked six times comes first', out.join(' '));
  eq(out.slice().sort(), list.slice().sort(), 'nothing added or dropped');
  var s2 = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  for (i = 0; i < 40; i++) s2.recordPick('or', 'kala', 'କାଳ', null);
  ok(s2.rerank('or', 'kala', null, list.slice())[0] === 'କାଳ', 'a word picked forty times overtakes even from fourth place');
  var s2b = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  s2b.recordPick('or', 'kala', 'କାଳ', null); s2b.recordPick('or', 'kala', 'କାଳ', null);
  ok(s2b.rerank('or', 'kala', null, list.slice())[0] === 'କଲ', 'two picks are not enough to jump from fourth to first');
  var s3 = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  for (i = 0; i < 5; i++) s3.recordSkip('or', 'kala', 'କଲ');
  ok(s3.rerank('or', 'kala', null, list.slice()).indexOf('କଲ') > 0, 'a word passed over again and again slips down');
  // next-word context
  var s4 = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  for (i = 0; i < 5; i++) s4.recordPick('or', 'ghara', 'ଘର', 'ମୋ');
  var l2 = ['ଘାର', 'ଘର', 'ଘରା'];
  ok(s4.rerank('or', 'ghara', 'ମୋ', l2.slice())[0] === 'ଘର', 'previous word context is used');
  ok(s4.rerank('or', 'ghara', 'ତୁମ', l2.slice())[0] === 'ଘର', 'and the pick itself still helps without that context');
  // recency
  var t = 1e9, s5 = new L.Store({ deviceId: 'dA', clock: function () { return t; } });
  for (i = 0; i < 8; i++) s5.recordPick('or', 'kala', 'କଲା', null);
  var fresh = s5.score('or', 'kala', 'କଲା', null, t), old = s5.score('or', 'kala', 'କଲା', null, t + 400 * 86400);
  ok(old < fresh && old > 0.2 * fresh, 'old history counts less but is not forgotten', fresh + ' ' + old);
})();

section('words and corrections for the engine');
(function () {
  var s = new L.Store({ deviceId: 'A', clock: clockFrom(1000) });
  s.recordWord('en', 'sudeep', 'hello'); s.recordWord('en', 'sudeep', 'hi'); s.recordWord('en', 'tea', null);
  s.recordCorrection('en', 'teh', 'the'); s.recordCorrection('en', 'teh', 'the'); s.recordCorrection('en', 'adn', 'and');
  eq(s.words('en', 2), [['sudeep', 2], ['the', 2]], 'words used twice (a correction counts as a use of the fixed word)');
  eq(s.words('en', 1).length, 4, 'words used once or more (sudeep, tea, the, and)');
  eq(s.corrections('en', 2), [['teh', 'the', 2]], 'corrections made twice');
  eq(s.words('hi', 1), [], 'other language: nothing');
  s.recordPick('en', 'th', 'thanks', 'many'); s.recordPick('en', 'th', 'thanks', 'many'); s.recordWord('en', 'thing', 'many');
  eq(s.nextWords('en', 'many').map(function (x) { return x[0]; }), ['thanks', 'thing'], 'next words after a word, strongest first');
  eq(s.nextWords('en', 'zzz'), [], 'nothing after an unseen word');
  var cp = s.completions('en', 'th', 5).map(function (x) { return x[0]; });
  ok(cp[0] === 'thanks' && cp.indexOf('thing') > 0 && cp.indexOf('sudeep') < 0, 'own words that begin with these letters, picked ones first', JSON.stringify(cp));
  eq(s.completions('en', 'q'), [], 'no own word begins with q');
})();

section('replay for the engine');
(function () {
  var s = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  s.recordPick('or', 'a', 'x', null); for (var i = 0; i < 5; i++) s.recordPick('or', 'b', 'y', null); s.recordPick('or', 'c', 'z', null);
  var rp = s.replay('or'); eq(rp[rp.length - 1], ['b', 'y'], 'strongest pick is last'); eq(s.replay('or', 2).length, 2, 'limit');
  eq(s.replay('hi'), [], 'other language: empty');
})();

section('dictionary: add, remove, concurrent add/remove');
(function () {
  var t = 1000, A = new L.Store({ deviceId: 'dA', clock: function () { return ++t; } }), B = new L.Store({ deviceId: 'dB', clock: function () { return ++t; } });
  A.addDictWord('or', 'iitdelhi', 'ଆଇଆଇଟି ଦିଲ୍ଲୀ', 6);
  B.load('or', A.serialize('or'));
  ok(B.dictionary('or').length === 1, 'B has the entry');
  B.removeDictWord('or', 'iitdelhi', 'ଆଇଆଇଟି ଦିଲ୍ଲୀ');
  A.load('or', B.serialize('or'));
  ok(A.dictionary('or').length === 0, 'removal travels');
  A.addDictWord('or', 'iitdelhi', 'ଆଇଆଇଟି ଦିଲ୍ଲୀ', 6);          // added again later: wins over the older removal
  B.load('or', A.serialize('or'));
  ok(B.dictionary('or').length === 1, 're-adding after a removal wins');
  var C = new L.Store({ deviceId: 'dC', clock: function () { return ++t; } });
  C.load('or', JSON.stringify(JSON.parse(A.serialize('or'))));
  ok(C.dictionary('or').length === 1, 'third device agrees');
})();

section('compaction does not let old single uses come back');
(function () {
  var t = 1e9, A = new L.Store({ deviceId: 'dA', clock: function () { return t; } }), B = new L.Store({ deviceId: 'dB', clock: function () { return t; } });
  A.recordPick('or', 'old', 'ପୁରୁଣା', null); B.load('or', A.serialize('or'));
  t += 500 * 86400;
  A.recordPick('or', 'new', 'ନୂଆ', null);
  var removed = A.compact('or', 365); ok(removed >= 2, 'single old use removed', String(removed));
  var stale = B.serialize('or');                                      // B still holds it
  A.load('or', stale);
  ok(!A.doc('or').pick.old, 'the stale copy does not bring it back');
  B.load('or', A.serialize('or'));
  ok(!B.doc('or').pick.old && B.doc('or').pick['new'], 'and B drops it after seeing the floor');
})();

section('import of what older versions kept');
(function () {
  var s = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  var n = s.importHistoryTsv('or', 'kal\tକଲ\nkal\tକଲ\nbad line\nama\tଆମ\n');
  eq(n, 3, 'history.tsv: three picks'); eq(L.total(s.doc('or').pick.kal['କଲ']), 2, 'repeats counted');
  var mac = { format: 'sulekhak-learn', version: 1, picks: { kala: [{ w: 'କଳା', n: 4, first: 1000, last: 2000, sc: 2 }, { w: 'କଲା', n: 2, first: 1000, last: 2000, sc: 3 }] },
    dict: [{ w: 'ଆଇଆଇଟି', roman: 'iit', wt: 6, added: 1500 }], next: { 'ମୋ': { 'ଘର': 3 } } };
  var s2 = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  var r = s2.importMacV1(mac, function (w, sc) { return sc === 1 ? '«' + w + '»' : w; });
  ok(L.total(s2.doc('or').pick.kala['କଲା']) === 2 && s2.doc('hi').pick.kala['«କଲା»'] && s2.doc('hi').pick.kala['«କଳା»'], 'Mac cache split by the script it was typed in', JSON.stringify(r));
  ok(!s2.doc('or').pick.kala['କଳା'] && !s2.doc('or').pick.kala['«କଳା»'], 'Devanagari-only pick did not leak into Odia');
  ok(s2.dictionary('or').length === 1 && s2.doc('or').next['ମୋ']['ଘର'], 'dictionary and next-word pairs');
  var again = new L.Store({ deviceId: 'dA', clock: clockFrom(2e9) });
  again.load('or', s2.serialize('or')); again.importMacV1(mac);                  // importing twice by the SAME device must not inflate: caller guards with a marker
  ok(true, 'second import is the host\'s job to prevent (marker file); documented');
})();

section('newer file format is never overwritten');
(function () {
  var s = new L.Store({ deviceId: 'dA', clock: clockFrom(1e9) });
  var r = s.load('or', JSON.stringify({ f: L.FORMAT, v: 99, lang: 'or', pick: {} }));
  ok(!r.ok && r.newer === 99 && s.readOnly.or === 99, 'flagged read-only');
  ok(!s.load('or', 'not json').ok && !s.load('or', '{"f":"other"}').ok, 'garbage refused');
})();

/* ------------------------------------------------------------------ the sync loop against the fake Drive */
function mkDevice(drive, id, extra) {
  var store = new L.Store({ deviceId: id, platform: 'test', clock: clockFrom(1e9 + id.charCodeAt(1) * 10) });
  var tokens = drive.tokens(extra && extra.tokens);
  var d = new S.Drive(tokens, { fetch: drive.fetch.bind(drive), sleep: function () { return Promise.resolve(); }, random: (extra && extra.random) || Math.random });
  var saved = {};
  var sync = new S.Sync(store, d, { allowedEmails: (extra && extra.allowed) || ['me@example.com'], debounceMs: 0, auto: !!(extra && extra.auto), persist: { write: function (l, t) { saved[l] = t; return Promise.resolve(); } } });
  return { id: id, store: store, drive: d, sync: sync, tokens: tokens, saved: saved };
}
async function main() {
  section('first sign-in on a fresh Drive');
  var fd = new FakeDrive();
  var a = mkDevice(fd, 'dA');
  a.store.recordPick('or', 'kal', 'କଲ', null);
  var res = await a.sync.syncLang('or');
  ok(res.state === 'ok', 'state ok', JSON.stringify(res));
  ok(fd.fileTexts('sulekhak-learning-or.json').length === 1, 'one Odia file created in appDataFolder');
  ok(fd.fileTexts('sulekhak-learning-hi.json').length === 0, 'no Hindi file created by an Odia sync');
  ok(!!a.saved.or, 'local copy persisted');
  var b = mkDevice(fd, 'dB');
  await b.sync.syncLang('or');
  ok(b.store.doc('or').pick.kal && b.store.doc('or').pick.kal['କଲ'], 'a second device receives it');
  var before = fd.uploads; await b.sync.syncLang('or'); ok(fd.uploads === before, 'an unchanged sync uploads nothing');

  section('a different Google account is refused and signed out');
  var fd2 = new FakeDrive(), evil = mkDevice(fd2, 'dX', { tokens: { email: 'someone.else@gmail.com' }, allowed: ['me@example.com'] });
  evil.store.recordPick('or', 'kal', 'କଲ', null);
  var thrown = null; try { await evil.sync.syncLang('or'); } catch (e) { thrown = e; }
  ok(thrown && thrown.code === 'account-not-allowed', 'refused', thrown && thrown.code);
  ok(evil.tokens.state.signOutCalls === 1 && fd2.calls.length === 0, 'signed out, and not one request was sent', fd2.calls.length + ' calls');

  section('token expiry and flaky network');
  var fd3 = new FakeDrive(), c = mkDevice(fd3, 'dC', { tokens: { token: 'expired' } });
  c.store.recordPick('or', 'kal', 'କଲ', null);
  var r3 = await c.sync.syncLang('or'); ok(r3.state === 'ok' && fd3.refreshes === 1, 'refresh once on 401', JSON.stringify(r3) + ' refreshes=' + fd3.refreshes);
  var fd4 = new FakeDrive(); fd4.failures.push({ match: /PATCH|POST|GET/, status: 503, times: 4 }); fd4.failures.push({ match: /POST/, network: true, times: 2 });
  var d4 = mkDevice(fd4, 'dD'); d4.store.recordPick('or', 'kal', 'କଲ', null);
  var r4 = await d4.sync.syncLang('or'); ok(r4.state === 'ok' && fd4.fileTexts('sulekhak-learning-or.json').length === 1, 'recovers from 503s and dropped connections', JSON.stringify(r4));
  var fd5 = new FakeDrive(); fd5.failures.push({ match: /.*/, status: 429, times: 2, headers: { 'Retry-After': '1' } });
  var d5 = mkDevice(fd5, 'dE'); d5.store.recordPick('or', 'kal', 'କଲ', null);
  ok((await d5.sync.syncLang('or')).state === 'ok', '429 with Retry-After honoured');
  var fd6 = new FakeDrive(); fd6.failures.push({ match: /.*/, status: 500, times: 100 });
  var d6 = mkDevice(fd6, 'dF'); d6.store.recordPick('or', 'kal', 'କଲ', null);
  var t6 = null; try { await d6.sync.syncLang('or'); } catch (e) { t6 = e; }
  ok(t6 && t6.code === 'http', 'a dead server is an error, not a silent success', t6 && t6.code);
  ok(d6.store.doc('or').pick.kal['କଲ'] && d6.store.dirty.or, 'local data kept and still marked unsynced');
  var fd7 = new FakeDrive(); var d7 = mkDevice(fd7, 'dG'); d7.tokens.state.signedOut = true; d7.store.recordPick('or', 'kal', 'କଲ', null);
  var t7 = null; try { await d7.sync.syncLang('or'); } catch (e) { t7 = e; }
  ok(t7 && t7.code === 'signed-out' && d7.sync.status.or.state === 'signed-out', 'signed out is reported as such');

  section('two devices create the file at the same moment');
  var fd8 = new FakeDrive({ maxDelay: 5 }), p = mkDevice(fd8, 'dP'), q = mkDevice(fd8, 'dQ');
  p.store.recordPick('or', 'kal', 'କଲ', null); q.store.recordPick('or', 'ama', 'ଆମ', null);
  fd8.failures = [];
  // force the race: both list (empty) before either creates
  var origList = S.Drive.prototype.list, gate = 0, wait = [];
  [p, q].forEach(function (x) { var ol = x.drive.list.bind(x.drive); x.drive.list = function (n) { return ol(n).then(function (files) { if (gate < 2 && files.length === 0) { gate++; return new Promise(function (res) { wait.push(function () { res(files); }); if (wait.length === 2) wait.forEach(function (f) { f(); }); }); } return files; }); }; });
  await Promise.all([p.sync.syncLang('or'), q.sync.syncLang('or')]);
  await p.sync.syncLang('or'); await q.sync.syncLang('or');
  ok(fd8.fileTexts('sulekhak-learning-or.json').length === 1, 'duplicates folded into one file', String(fd8.fileTexts('sulekhak-learning-or.json').length));
  var f8 = JSON.parse(fd8.fileTexts('sulekhak-learning-or.json')[0]);
  ok(f8.pick.kal && f8.pick.ama, 'nothing lost from either device');
  eq(p.store.doc('or').pick, q.store.doc('or').pick, 'both devices hold the same picks');

  section('lost update: B overwrites A between A\'s read and A\'s verify');
  var fd9 = new FakeDrive(), A9 = mkDevice(fd9, 'dA'), B9 = mkDevice(fd9, 'dB');
  A9.store.recordPick('or', 'kal', 'କଲ', null); await A9.sync.syncLang('or');
  B9.store.load('or', fd9.fileTexts('sulekhak-learning-or.json')[0]);
  A9.store.recordPick('or', 'ama', 'ଆମ', null); B9.store.recordPick('or', 'ghara', 'ଘର', null);
  // B reads the old copy, A writes, then B writes its (older base) copy over A's file: the classic lost update
  var fid = Object.keys(fd9.files)[0], staleBase = fd9.files[fid].text;
  await A9.sync.syncLang('or');
  ok(JSON.parse(fd9.files[fid].text).pick.ama, 'A\'s pick is in the cloud');
  var bDoc = B9.store.serialize('or');                                   // B's copy knows nothing of A's new pick
  fd9.files[fid].text = bDoc; fd9.files[fid].version++;                  // the overwrite
  ok(!JSON.parse(fd9.files[fid].text).pick.ama, 'A\'s pick has been overwritten in the cloud (simulated)');
  await A9.sync.syncLang('or');                                          // A syncs again: it still holds its own picks
  ok(JSON.parse(fd9.files[fid].text).pick.ama && JSON.parse(fd9.files[fid].text).pick.ghara, 'A restores its pick and keeps B\'s');
  await B9.sync.syncLang('or'); eq(A9.store.doc('or').pick, B9.store.doc('or').pick, 'A and B agree');

  section('verify-after-write catches a concurrent writer inside one sync');
  var fd10 = new FakeDrive(), A10 = mkDevice(fd10, 'dA'), B10 = mkDevice(fd10, 'dB');
  A10.store.recordPick('or', 'kal', 'କଲ', null); await A10.sync.syncLang('or');
  B10.store.recordPick('or', 'bhal', 'ଭଲ', null); A10.store.recordPick('or', 'ama', 'ଆମ', null);
  var injected = false, origUpdate = A10.drive.update.bind(A10.drive);
  A10.drive.update = function (id, text) { return origUpdate(id, text).then(function (r) { if (!injected) { injected = true; return B10.drive.update(id, B10.store.serialize('or')).then(function () { return r; }); } return r; }); };
  var rr = await A10.sync.syncLang('or');
  var final = JSON.parse(fd10.fileTexts('sulekhak-learning-or.json')[0]);
  ok(rr.state === 'ok' && final.pick.kal && final.pick.ama, 'A\'s picks survive B\'s overwrite of the same file (retry), state ' + rr.state);
  await B10.sync.syncLang('or'); final = JSON.parse(fd10.fileTexts('sulekhak-learning-or.json')[0]);
  ok(final.pick.bhal && final.pick.ama && final.pick.kal, 'and after B syncs once more, all three are in the file');

  section('five devices, hundreds of operations, random interleaving, delays, failures');
  for (var seed = 1; seed <= 8; seed++) {
    var r = rng(seed * 7919), fdz = new FakeDrive({ maxDelay: 4, rand: r }), devs = [], expected = 0, ds, i, langs = ['or', 'hi', 'en'];
    for (i = 0; i < 5; i++) devs.push(mkDevice(fdz, 'd' + String.fromCharCode(65 + i), { random: r, auto: seed % 2 === 0 }));
    fdz.failures.push({ match: /.*/, status: 503, times: 6 });
    var rounds = 6;
    for (var round = 0; round < rounds; round++) {
      var jobs = devs.map(function (dv, di) {
        return (async function () {
          for (var k = 0; k < 3; k++) {
            var lang = langs[Math.floor(r() * langs.length)];
            randomOps(dv.store, lang, r, 5 + Math.floor(r() * 10));
            if (r() < 0.8) { try { await dv.sync.syncLang(lang); } catch (e) { /* tolerated: data stays local and dirty */ } }
          }
        })();
      });
      await Promise.all(jobs);
    }
    // final settle: everybody syncs everything twice, sequentially
    for (var pass = 0; pass < 2; pass++) for (i = 0; i < devs.length; i++) for (var li = 0; li < langs.length; li++) { try { await devs[i].sync.syncLang(langs[li]); } catch (e) { ok(false, 'settle sync failed ' + e.code); } }
    var allEq = true, lostOps = false;
    langs.forEach(function (lang) {
      var first = L.stableString(L.mergeDoc(devs[0].store.doc(lang), devs[0].store.doc(lang)));
      var union = devs.reduce(function (acc, dv) { return L.mergeDoc(acc, dv.store.doc(lang)); }, L.emptyDoc(lang));
      var cloud = fdz.fileTexts('sulekhak-learning-' + lang + '.json');
      if (cloud.length !== 1) { allEq = false; return; }
      var cd = L.normalizeDoc(JSON.parse(cloud[0]), lang);
      if (!L.covers(cd, union)) lostOps = true;
      devs.forEach(function (dv) { var m = L.mergeDoc(dv.store.doc(lang), cd); if (L.stableString(m) !== L.stableString(L.mergeDoc(cd, cd))) allEq = false; });
    });
    ok(allEq && !lostOps, 'seed ' + seed + ': one file per language, every device equals the cloud, nothing lost');
    // language isolation in the cloud
    ['or', 'hi', 'en'].forEach(function (lang) { var d = JSON.parse(fdz.fileTexts('sulekhak-learning-' + lang + '.json')[0]); if (d.lang !== lang) ok(false, 'file lang field wrong ' + lang); });
  }

  section('upgrade: an old build is not allowed to wipe a newer cloud file');
  var fd11 = new FakeDrive(), N = mkDevice(fd11, 'dN');
  await N.drive.create('sulekhak-learning-or.json', JSON.stringify({ f: L.FORMAT, v: 99, lang: 'or', pick: { x: {} } }));
  N.store.recordPick('or', 'kal', 'କଲ', null);
  var tN = null; try { await N.sync.syncLang('or'); } catch (e) { tN = e; }
  ok(tN && tN.code === 'newer-format', 'reports newer-format', tN && tN.code);
  ok(JSON.parse(fd11.fileTexts('sulekhak-learning-or.json')[0]).v === 99, 'cloud file left untouched');
  ok(N.store.doc('or').pick.kal, 'local learning kept');

  section('an install from before (v2 file from an earlier build) is read unchanged, then extended');
  var fd12 = new FakeDrive(), O = mkDevice(fd12, 'dO');
  O.store.recordPick('or', 'kal', 'କଲ', null); await O.sync.syncLang('or');
  var snapshotV2 = fd12.fileTexts('sulekhak-learning-or.json')[0];
  var Nn = mkDevice(fd12, 'dQ'); await Nn.sync.syncLang('or');                 // "new version of the app" on another phone
  Nn.store.recordPick('or', 'ama', 'ଆମ', null); await Nn.sync.syncLang('or');
  var restored = new L.Store({ deviceId: 'dZ', clock: clockFrom(5e9) }); restored.load('or', snapshotV2);
  ok(restored.doc('or').pick.kal, 'file written by an older build loads');
  var reinstall = mkDevice(fd12, 'dR'); await reinstall.sync.syncLang('or');   // fresh install, new device id: everything comes back
  ok(reinstall.store.doc('or').pick.kal && reinstall.store.doc('or').pick.ama, 'a fresh install after sign-in recovers everything learned');

  console.log('\n' + passed + ' passed, ' + failed + ' failed');
  if (failed) { console.log(failures.join('\n')); process.exit(1); }
}
main().catch(function (e) { console.log('CRASH', e && e.stack || e); process.exit(2); });
