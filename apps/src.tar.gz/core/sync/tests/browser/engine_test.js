'use strict';
/* The real engine page (ime.html + ime.js + engine.js + the Odia language pack + the sync scripts) in headless Chromium, the way a phone's WebView runs it.
   The "host" (what the Android app or the Windows app does) is played by this script: it answers the page's sk-* messages and supplies a token.
   Google Drive is the in-memory fake, reached through request interception. Usage: node engine_test.js <dir with cfg.gz lex.gz rom.gz ...> */
var fs = require('fs'), path = require('path'), zlib = require('zlib'), http = require('http');
var FakeDrive = require('../fakedrive.js');
var chromium = require('playwright').chromium;
var pack = process.argv[2], enDir = process.argv[3];
if (!pack) { console.log('usage: node engine_test.js <pack dir>'); process.exit(2); }
var SHARED = path.join(__dirname, '..', '..', '..', '..', 'shared');
if (!fs.existsSync(SHARED)) SHARED = path.join(__dirname, '..', '..', '..', '..', 'shared');   // same place in the repo layout
var passed = 0, failed = 0;
function ok(c, n, x) { if (c) passed++; else { failed++; console.log('FAIL ' + n + (x ? ' :: ' + x : '')); } }
var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
async function until(fn, ms, what) { var t = Date.now(); while (Date.now() - t < (ms || 8000)) { var v = await fn(); if (v) return v; await sleep(25); } throw new Error('timeout: ' + (what || '')); }

/* the files an Android app would serve from its assets */
var site = {};
['ime.html', 'ime.js', 'engine.js', 'sulekhak.js', 'learning.js', 'drive.js', 'personal.js', 'english.js'].forEach(function (f) { site['/' + f] = fs.readFileSync(path.join(SHARED, f)); });
site['/skel.dat'] = zlib.gunzipSync(fs.readFileSync(path.join(SHARED, 'skel.dat.gz')));
site['/sulekhak/cfg.json'] = zlib.gunzipSync(fs.readFileSync(path.join(pack, 'cfg.gz')));
['lex', 'rom', 'clus', 'syl_uni', 'syl_bi', 'syl_chan'].forEach(function (f) { site['/sulekhak/' + f + '.txt'] = zlib.gunzipSync(fs.readFileSync(path.join(pack, f + '.gz'))); });
site['/sulekhak/ng.bin'] = zlib.gunzipSync(fs.readFileSync(path.join(pack, 'ng.gz')));
site['/sulekhak/idx.bin'] = zlib.gunzipSync(fs.readFileSync(path.join(pack, 'idx.gz')));
if (enDir) ['en_lex.txt', 'en_ng.txt', 'en_fix.txt'].forEach(function (f) { site['/sulekhak/en/' + f] = fs.readFileSync(path.join(enDir, f)); });
var server = http.createServer(function (req, res) {
  var p = req.url.split('?')[0], b = site[p];
  if (!b) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { 'Content-Type': /\.html$/.test(p) ? 'text/html' : /\.js$/.test(p) ? 'text/javascript' : /\.bin$/.test(p) ? 'application/octet-stream' : 'text/plain; charset=utf-8' });
  res.end(b);
});

/* one "device": a page + the host's behaviour */
async function device(browser, port, fd, did, localFiles, email) {
  var ctx = await browser.newContext();
  await ctx.route('https://www.googleapis.com/**', async function (route) {
    var rq = route.request(), cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*' };
    if (rq.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: cors });
    var h = rq.headers(), init = { method: rq.method(), headers: { Authorization: h.authorization }, body: rq.postData() };
    var r = await fd.fetch(rq.url(), init), text = await r.text();
    route.fulfill({ status: r.status, headers: Object.assign({ 'content-type': 'application/json' }, cors), body: text });
  });
  await ctx.addInitScript(function () { window.__msgs = []; window.Android = { post: function (s) { window.__msgs.push(s); } }; });
  var page = await ctx.newPage(), errors = [];
  page.on('pageerror', function (e) { errors.push(String(e)); });
  var dev = { page: page, files: localFiles || {}, errors: errors, saves: [], list: {}, meta: {}, nlist: {}, seq: 0, email: email || 'me@example.com', ready: false, tokens: 0 };
  async function pump() {
    var msgs = await page.evaluate(function () { var m = window.__msgs; window.__msgs = []; return m; }).catch(function () { return []; });
    for (var i = 0; i < msgs.length; i++) {
      var m = JSON.parse(msgs[i]);
      if (m.t === 'ready') dev.ready = true;
      else if (m.t === 'c') { dev.list[m.id] = m.list; dev.meta[m.id] = m; }
      else if (m.t === 'n') dev.nlist[m.id] = m.list;
      else if (m.t === 'sk-need') await page.evaluate(function (a) { SKP.hostLoad(a[0], a[1]); }, [m.lang, dev.files[m.lang] || '']);
      else if (m.t === 'sk-save') { dev.files[m.lang] = m.text; dev.saves.push(m.lang); }
      else if (m.t === 'sk-token') { dev.tokens++; await page.evaluate(function (a) { SKP.setToken('good', 3600, a); }, dev.email); }
      else if (m.t === 'sk-signout') dev.signedOut = true;
      else if (m.t === 'sk-state') dev.state = m.state;
    }
  }
  dev.timer = setInterval(function () { pump().catch(function () {}); }, 20);
  await page.goto('http://localhost:' + port + '/ime.html');
  await until(function () { return dev.ready; }, 60000, 'engine ready');
  await page.evaluate(function (a) {
    SKP.initHost({ did: a[0], name: a[0], platform: 'test', allowed: ['saisudeep.das.iitd@gmail.com', 'saisudeep.das@gmail.com', 'me@example.com'], debounceMs: 20,
      post: function (m) { window.Android.post(JSON.stringify(m)); } });
  }, [did]);
  dev.query = async function (roman, prev) {
    var id = ++dev.seq;
    await page.evaluate(function (a) { imeQuery(a[0], a[1], a[2]); }, [id, roman, prev || '<s>']);
    await until(function () { return dev.list[id]; }, 8000, 'candidates for ' + roman);
    return dev.list[id];
  };
  dev.enOn = function (on) { return page.evaluate(function (o) { imeSetEnglish(o); }, on); };
  dev.enQuery = async function (typed, prev) {
    var id = ++dev.seq;
    await page.evaluate(function (a) { imeEnQuery(a[0], a[1], a[2]); }, [id, typed, prev || '<s>']);
    await until(function () { return dev.meta[id]; }, 20000, 'English candidates for ' + typed);
    return dev.meta[id];
  };
  dev.enNext = async function (prev) {
    var id = ++dev.seq;
    await page.evaluate(function (a) { imeEnNext(a[0], a[1]); }, [id, prev]);
    await until(function () { return dev.nlist[id]; }, 20000, 'English next words');
    return dev.nlist[id];
  };
  dev.enSwipe = async function (spec, guesses, prev) {
    var id = ++dev.seq;
    await page.evaluate(function (a) { imeEnSwipe(a[0], a[1], a[2], a[3]); }, [id, spec, guesses, prev || '<s>']);
    await until(function () { return dev.meta[id]; }, 20000, 'English swipe');
    return dev.meta[id];
  };
  dev.enCommit = function (typed, word, prev, how, passed) { return page.evaluate(function (a) { imeEnCommit(a[0], a[1], a[2], a[3], a[4]); }, [typed, word, prev || '<s>', how, passed || null]); };
  dev.script = function (sc, opt) { return page.evaluate(function (a) { imeSetScript(a[0], a[1]); }, [sc, opt || 0]); };
  dev.commit = function (r, w) { return page.evaluate(function (a) { imeCommit(a[0], a[1]); }, [r, w]); };
  dev.signIn = function () { return page.evaluate(function (e) { SKP.setToken('good', 3600, e); }, dev.email); };
  dev.syncNow = function () { return page.evaluate(function () { return SKP.syncNow().then(function () { return SKP.state; }); }); };
  dev.stats = function () { return page.evaluate(function () { return SKP.stats(); }); };
  dev.close = async function () { clearInterval(dev.timer); await ctx.close(); };
  return dev;
}

(async function () {
  await new Promise(function (r) { server.listen(0, r); });
  var port = server.address().port, browser = await chromium.launch(), fd = new FakeDrive();
  try {
    /* ---- phone A: type in Odia, pick a word that is not the engine's first guess, four times ---- */
    var A = await device(browser, port, fd, 'phoneA');
    ok(A.errors.length === 0, 'no script error while the page loads', A.errors.join(' | '));
    await A.script(0, 0); await sleep(100);
    var base = await A.query('ghara', '<s>');
    ok(base.length >= 4 && base[1] === 'ghara', 'engine answers; the typed text is in slot 2', JSON.stringify(base.slice(0, 5)));
    var target = base.filter(function (w, i) { return i !== 1 && i !== 0 && /[^\x00-\x7f]/.test(w); })[1] || base[2];
    for (var i = 0; i < 4; i++) await A.commit('ghara', target);
    var after = await A.query('ghara', '<s>');
    ok(after[0] === target && after[1] === 'ghara', 'the word you keep choosing comes first, slot 2 untouched', JSON.stringify(after.slice(0, 4)) + ' wanted ' + target);
    await until(function () { return A.files.or; }, 8000, 'local copy of the Odia learning');
    var doc = JSON.parse(A.files.or);
    ok(doc.pick && doc.pick.ghara, 'the pick is in the Odia learning file');
    ok(!A.files.hi && !A.files.mr && !A.files.bn && !A.files.as && !A.files.en, 'no other language file was written');

    /* ---- Hindi on the same phone: separate book ---- */
    await A.script(1, 0); await sleep(100);
    var hi = await A.query('ghara', '<s>');
    var hiBase = hi.slice();
    await A.commit('ghara', hi[0]);   // one pick in Hindi
    var st = await A.stats();
    ok(st && st.picks === 1, 'Hindi has its own count (1), not Odia\'s', JSON.stringify(st));
    await A.script(0, 0); await sleep(100);
    var st0 = await A.stats();
    ok(st0 && st0.picks === 1 && Object.keys(JSON.parse(A.files.or).pick).length === 1, 'Odia book unchanged by the Hindi pick', JSON.stringify(st0));

    /* ---- sync to the cloud ---- */
    await A.signIn(); var s1 = await A.syncNow();
    ok(s1 === 'synced', 'sync finished: ' + s1);
    ok(fd.fileTexts('sulekhak-learning-or.json').length === 1, 'one Odia file in the cloud');
    ok(fd.fileTexts('sulekhak-learning-hi.json').length === 1, 'one Hindi file in the cloud (a pick was made in Hindi)');
    ok(fd.fileTexts('sulekhak-learning-en.json').length === 0 && fd.fileTexts('sulekhak-learning-bn.json').length === 0, 'no files for languages that were not used');
    var cloudOr = fd.fileTexts('sulekhak-learning-or.json')[0], cloudHi = fd.fileTexts('sulekhak-learning-hi.json')[0];
    ok(cloudOr.indexOf(target) >= 0 && cloudOr.indexOf(hiBase[0]) < 0 || hiBase[0] === target, 'Odia file holds the Odia word and not the Hindi one');
    ok(cloudHi.indexOf(hiBase[0]) >= 0, 'Hindi file holds the Hindi word');

    /* ---- phone B: new install, empty, signs in: the engine page must rank like A after the pull ---- */
    var B = await device(browser, port, fd, 'phoneB');
    var B0 = await B.query('ghara', '<s>');
    await B.script(0, 0); await B.signIn(); var s2 = await B.syncNow(); await sleep(300);
    var B1 = await B.query('ghara', '<s>');
    ok(s2 === 'synced', 'B synced: ' + s2);
    ok(B1[0] === target, 'phone B ranks the word first after the first sync (it never saw the picks)', JSON.stringify(B0.slice(0, 3)) + ' -> ' + JSON.stringify(B1.slice(0, 3)));
    ok(B1[1] === 'ghara', 'slot 2 still the typed text on B');
    var bs = await B.stats(); ok(bs && bs.picks === 1, 'B holds the picks of A', JSON.stringify(bs));
    ok(!B.files.hi || JSON.parse(B.files.hi).pick, 'B stored nothing it should not');

    /* ---- B and A both learn at the same time, then sync: nothing lost ---- */
    var other = base.filter(function (w, i) { return i !== 1 && w !== target && /[^\x00-\x7f]/.test(w); })[0];
    for (i = 0; i < 3; i++) { await A.commit('ghara', target); await B.commit('ghara', other); }
    await Promise.all([A.syncNow(), B.syncNow()]); await A.syncNow(); await B.syncNow();
    function totalPicks(doc) { var n = 0; Object.keys(doc.pick).forEach(function (r) { Object.keys(doc.pick[r]).forEach(function (w) { var c = doc.pick[r][w].c; Object.keys(c).forEach(function (d) { n += c[d]; }); }); }); return n; }
    await A.syncNow(); await B.syncNow(); await sleep(200);
    var dA = JSON.parse(A.files.or), dB = JSON.parse(B.files.or);
    ok(totalPicks(dA) === 10 && totalPicks(dB) === 10, 'simultaneous learning on two phones: both hold all 10 picks (4+3 from A, 3 from B)', totalPicks(dA) + ' / ' + totalPicks(dB));
    ok(JSON.stringify(dA.pick) === JSON.stringify(dB.pick), 'the two phones hold identical pick tables');

    /* ---- phone C: another account is refused, nothing is sent ---- */
    var calls = fd.calls.length;
    var C = await device(browser, port, new FakeDrive(), 'phoneC', {}, 'stranger@example.org');
    await C.script(0, 0); await C.commit('ghara', target);
    await C.page.evaluate(function () { SKP.setToken('good', 3600, 'stranger@example.org'); });
    var s3 = await C.syncNow();
    ok(C.signedOut === true || s3 === 'refused', 'a stranger\'s account is refused and signed out', s3);


    /* ================= English (needs the English data directory as the third argument) ================= */
    if (enDir) {
      var EA = await device(browser, port, fd, 'phoneEA');
      await EA.enOn(true); await sleep(200);
      var r1 = await EA.enQuery('teh', 'in');
      ok(r1.auto === 1 && r1.list[0] === 'the' && r1.list[1] === 'teh', 'English: "teh" is corrected to "the", the typed text stays in slot 2', JSON.stringify(r1.list.slice(0, 4)));
      var r2 = await EA.enQuery('hello', '<s>');
      ok(r2.auto === 0 && r2.list[0] === 'hello', 'English: a correct word is left alone', JSON.stringify(r2.list.slice(0, 3)));
      var r3 = await EA.enQuery('recieve', '<s>');
      ok(r3.auto === 1 && r3.list[0] === 'receive', 'English: "recieve" -> "receive"');
      var r4 = await EA.enQuery('indi', '<s>');
      ok(r4.list.indexOf('india') > 0 || r4.list.indexOf('India') > 0, 'English: "indi" offers India', JSON.stringify(r4.list.slice(0, 6)));
      var nx = await EA.enNext('thank');
      ok(nx.indexOf('you') >= 0, 'English: "you" follows "thank"', JSON.stringify(nx));
      var nxs = await EA.enNext('<s>');
      ok(nxs.length > 0 && /^[A-Z]/.test(nxs[0]), 'English: sentence-start words begin with a capital', JSON.stringify(nxs));
      /* a swipe over h-e-l-l-o on a QWERTY layout (lengths in key-widths) */
      var KEYS = {}; ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'].forEach(function (row, ri) { for (var q = 0; q < row.length; q++) KEYS[row[q]] = [0.5 + q + [0, 0.5, 1.5][ri], 0.65 + 1.3 * ri]; });
      function swipePath(word) { var pts = [], t = 0, prevK = null; word.split('').forEach(function (c) { if (c === prevK) return; prevK = c; pts.push(KEYS[c]); }); var out = []; for (var a = 0; a < pts.length - 1; a++) for (var s2 = 0; s2 < 8; s2++) out.push([pts[a][0] + (pts[a + 1][0] - pts[a][0]) * s2 / 8 + 0.05 * Math.sin(a + s2), pts[a][1] + (pts[a + 1][1] - pts[a][1]) * s2 / 8, (t += 20)]); out.push(pts[pts.length - 1].concat([t + 20])); return { k: KEYS, p: out }; }
      var sw = await EA.enSwipe(swipePath('hello'), ['hello'], '<s>');
      ok(sw.list[0] === 'hello', 'English swipe: a path over h-e-l-l-o gives "hello" first', JSON.stringify(sw.list.slice(0, 4)));
      var sw2 = await EA.enSwipe(swipePath('keyboard'), ['keyboard'], 'my');
      ok(sw2.list[0] === 'keyboard', 'English swipe: "keyboard"', JSON.stringify(sw2.list.slice(0, 4)));

      /* learning: a name the engine does not know, typed twice, becomes a word; a refused correction is not made again */
      var u0 = await EA.enQuery('zorbaxx', '<s>');
      ok(u0.auto === 0 && u0.list[0] === 'zorbaxx', 'English: an unknown word is left as typed');
      await EA.enCommit('zorbaxx', 'zorbaxx', 'my', 'typed'); await EA.enCommit('zorbaxx', 'zorbaxx', 'my', 'typed');
      var u1 = await EA.enQuery('zorb', '<s>');
      ok(u1.list.indexOf('zorbaxx') > 0, 'English: a word typed twice is offered from then on', JSON.stringify(u1.list.slice(0, 5)));
      var f0 = await EA.enQuery('arre', '<s>');
      if (f0.auto === 1) {
        await EA.enCommit('arre', 'arre', '<s>', 'revert', f0.list[0]);
        var f1 = await EA.enQuery('arre', '<s>');
        ok(f1.auto === 0 && f1.list[0] === 'arre', 'English: after you undo a correction it is not made again', JSON.stringify(f1.list.slice(0, 3)));
      } else ok(true, 'English: "arre" was not corrected in the first place');
      /* a suggestion picked again and again moves up; a correction made twice becomes automatic */
      var p0 = await EA.enQuery('th', 'many'); var p0i = p0.list.indexOf('thanks');
      for (i = 0; i < 4; i++) await EA.enCommit('th', 'thanks', 'many', 'pick', p0.list[1]);
      var p1 = await EA.enQuery('th', 'many'); var p1i = p1.list.indexOf('thanks');
      ok(p1i >= 1 && (p0i < 0 || p1i < p0i) && p1i <= 2, 'English: a suggestion you keep choosing moves up', JSON.stringify(p0.list.slice(0, 6)) + ' -> ' + JSON.stringify(p1.list.slice(0, 6)));
      var g0 = await EA.enQuery('gonn', '<s>');
      await EA.enCommit('gonn', 'gone', '<s>', 'pick'); await EA.enCommit('gonn', 'gone', '<s>', 'pick');
      await sleep(2300);
      var enDoc = JSON.parse(EA.files.en || '{}');
      ok(enDoc.lang === 'en' && enDoc.uni && enDoc.uni.gone, 'English learning is kept in its own file (en)');
      ok(JSON.stringify(Object.keys(JSON.parse(A.files.or).pick)) === JSON.stringify(['ghara']), 'the Odia file did not receive any English');
      ok(!EA.files.or && !EA.files.hi, 'the English phone wrote no Indic file');
      /* sync to the cloud and to a second phone */
      await EA.signIn(); var es = await EA.syncNow();
      ok(es === 'synced' && fd.fileTexts('sulekhak-learning-en.json').length === 1, 'English file synced to the cloud', es);
      var EB = await device(browser, port, fd, 'phoneEB');
      await EB.enOn(true); await EB.signIn(); var eb = await EB.syncNow(); await sleep(600);
      var b1 = await EB.enQuery('th', 'many'); var b1i = b1.list.indexOf('thanks');
      ok(eb === 'synced' && b1i >= 1 && b1i <= 2, 'English: the second phone ranks like the first after one sync', JSON.stringify(b1.list.slice(0, 6)));
      var b2 = await EB.enQuery('zorb', '<s>');
      ok(b2.list.indexOf('zorbaxx') > 0, 'English: the second phone knows the first phone\'s word', JSON.stringify(b2.list.slice(0, 5)));
      var b3 = await EB.enQuery('gonn', '<s>');
      ok(b3.auto === 1 && b3.list[0] === 'gone', 'English: the second phone applies the correction learned on the first', JSON.stringify(b3.list.slice(0, 3)));
      ok(EA.errors.length === 0 && EB.errors.length === 0, 'no script errors in the English pages', EA.errors.concat(EB.errors).join(' | '));
      await EA.close(); await EB.close();
    } else console.log('(English tests skipped: no data directory given)');

    ok(A.errors.length === 0 && B.errors.length === 0, 'no script errors on A or B', A.errors.concat(B.errors).join(' | '));
    await A.close(); await B.close(); await C.close();
  } catch (e) { failed++; console.log('CRASH', e && e.stack || e); }
  await browser.close(); server.close();
  console.log(passed + ' passed, ' + failed + ' failed'); process.exit(failed ? 1 : 0);
})();
