/* A small stand-in for the Drive appDataFolder REST API, good enough to exercise the sync loop: list, media download, multipart create,
   media update, delete; plus switches for the things that go wrong on a real network. Files are held in memory; every call can be
   delayed by a random number of "ticks" so that several devices really interleave. */
'use strict';
function FakeDrive(opts) {
  opts = opts || {};
  this.files = {};           // id -> {id,name,createdTime,modifiedTime,version,text}
  this.nextId = 1; this.clock = 1000;
  this.calls = []; this.failures = [];     // failures: [{match:/regex of "METHOD url"/, status, times, headers}]
  this.maxDelay = opts.maxDelay || 0; this.rand = opts.rand || Math.random;
  this.expectToken = 'good'; this.refreshes = 0; this.uploads = 0;
  this.account = opts.account || 'me@example.com';
}
FakeDrive.prototype.delay = function () { var n = Math.floor(this.rand() * (this.maxDelay + 1)); return new Promise(function (r) { setTimeout(r, n); }); };
FakeDrive.prototype.res = function (status, body, headers) {
  var text = typeof body === 'string' ? body : JSON.stringify(body);
  return { status: status, headers: { get: function (k) { return headers && headers[k] || null; } }, text: function () { return Promise.resolve(text); }, json: function () { return Promise.resolve(JSON.parse(text)); } };
};
FakeDrive.prototype.fetch = function (url, init) {
  var self = this, method = (init && init.method) || 'GET', key = method + ' ' + url;
  this.calls.push(key);
  return this.delay().then(function () {
    var auth = init && init.headers && init.headers.Authorization;
    if (auth !== 'Bearer ' + self.expectToken) return self.res(401, { error: { code: 401 } });
    for (var i = 0; i < self.failures.length; i++) {
      var f = self.failures[i];
      if (f.times > 0 && f.match.test(key)) { f.times--; if (f.network) return Promise.reject(new Error('socket hang up')); return self.res(f.status, { error: { errors: [{ reason: f.reason || '' }] } }, f.headers); }
    }
    var u = new URL(url), p = u.pathname, id, f2;
    if (method === 'GET' && p === '/drive/v3/files') {
      var q = decodeURIComponent(u.searchParams.get('q')), m = /name='(.*)' and trashed=false/.exec(q);
      var name = m && m[1].replace(/\\'/g, "'");
      var out = Object.keys(self.files).map(function (k) { return self.files[k]; }).filter(function (x) { return x.name === name; })
        .sort(function (a, b) { return a.createdTime < b.createdTime ? -1 : 1; })
        .map(function (x) { return { id: x.id, name: x.name, createdTime: x.createdTime, modifiedTime: x.modifiedTime, version: String(x.version) }; });
      return self.res(200, { files: out });
    }
    if (method === 'GET' && /^\/drive\/v3\/files\/[^/]+$/.test(p) && u.searchParams.get('alt') === 'media') {
      id = p.split('/').pop(); f2 = self.files[id];
      if (!f2) return self.res(404, { error: { code: 404 } });
      return self.res(200, f2.text);
    }
    if (method === 'POST' && p === '/upload/drive/v3/files') {
      var body = String(init.body), parts = body.split(/\r\n--[^\r\n]+/);
      var meta = JSON.parse(/\r\n\r\n(\{[\s\S]*?\})\r\n--/.exec(body)[1]);
      var data = body.split('\r\n\r\n')[2].replace(/\r\n--[^\r\n]*--\s*$/, '');
      if (!meta.parents || meta.parents[0] !== 'appDataFolder') return self.res(400, { error: 'must live in appDataFolder' });
      id = 'f' + (self.nextId++); self.clock += 1;
      self.files[id] = { id: id, name: meta.name, createdTime: new Date(self.clock * 1000).toISOString(), modifiedTime: new Date(self.clock * 1000).toISOString(), version: 1, text: data };
      self.uploads++;
      return self.res(200, { id: id });
    }
    if (method === 'PATCH' && /^\/upload\/drive\/v3\/files\/[^/]+$/.test(p)) {
      id = p.split('/').pop(); f2 = self.files[id];
      if (!f2) return self.res(404, { error: { code: 404 } });
      f2.text = String(init.body); f2.version++; self.clock += 1; f2.modifiedTime = new Date(self.clock * 1000).toISOString(); self.uploads++;
      return self.res(200, { id: id, version: f2.version });
    }
    if (method === 'DELETE' && /^\/drive\/v3\/files\/[^/]+$/.test(p)) {
      id = p.split('/').pop(); if (!self.files[id]) return self.res(404, {});
      delete self.files[id]; return self.res(204, '');
    }
    return self.res(400, { error: 'unsupported ' + key });
  });
};
FakeDrive.prototype.tokens = function (opts) {
  var self = this; opts = opts || {}; var st = { token: opts.token || 'good', signedOut: false, signOutCalls: 0 };
  return {
    state: st,
    access: function () { return Promise.resolve(st.signedOut ? null : st.token); },
    refresh: function () { self.refreshes++; st.token = 'good'; return Promise.resolve(st.token); },
    email: function () { return Promise.resolve(opts.email || self.account); },
    signOut: function () { st.signedOut = true; st.signOutCalls++; return Promise.resolve(); }
  };
};
FakeDrive.prototype.fileTexts = function (name) { var self = this; return Object.keys(this.files).map(function (k) { return self.files[k]; }).filter(function (x) { return x.name === name; }).map(function (x) { return x.text; }); };
module.exports = FakeDrive;
