/* Sulekhak personal sync: the Google Drive "app data folder" client and the sync loop.
   The app data folder is a hidden folder of the signed-in person's own Drive that only this Google Cloud project's apps can see
   (scope https://www.googleapis.com/auth/drive.appdata). One file per language: sulekhak-learning-<lang>.json.

   Nothing here knows how to sign in. The host gives a `tokens` object:
     tokens.access()   -> Promise<string>  a valid access token (null when signed out)
     tokens.refresh()  -> Promise<string>  get a fresh one after a 401
     tokens.email()    -> Promise<string>  the signed-in Google account
     tokens.signOut()  -> Promise
   and optionally `fetch`, `sleep`, `random` for tests. */
(function (root, factory) {
  var m = factory(typeof require === 'function' && typeof module === 'object' ? require('./learning.js') : root.SulekhakLearn);
  if (typeof module === 'object' && module.exports) module.exports = m;
  root.SulekhakSync = m;
})(typeof self !== 'undefined' ? self : this, function (L) {
  'use strict';
  var API = 'https://www.googleapis.com/drive/v3/files', UP = 'https://www.googleapis.com/upload/drive/v3/files';
  var SCOPES = 'openid email https://www.googleapis.com/auth/drive.appdata';

  function fileName(lang) { return 'sulekhak-learning-' + lang + '.json'; }
  function SyncError(code, msg, extra) { var e = new Error(msg || code); e.code = code; if (extra) for (var k in extra) e[k] = extra[k]; return e; }

  function Drive(tokens, opts) {
    opts = opts || {};
    this.tokens = tokens;
    this.fetch = opts.fetch || (typeof fetch === 'function' ? fetch.bind(typeof self !== 'undefined' ? self : this) : null);
    this.sleep = opts.sleep || function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    this.random = opts.random || Math.random;
    this.maxTries = opts.maxTries || 5;
  }
  /* one HTTP call with: bearer token, refresh once on 401, back-off on 429 / 5xx / rate-limit 403 / network errors */
  Drive.prototype.req = function (method, url, headers, body) {
    var self = this, tries = 0, refreshed = false;
    function once() {
      return self.tokens.access().then(function (tok) {
        if (!tok) throw SyncError('signed-out', 'not signed in');
        var h = { Authorization: 'Bearer ' + tok }, k;
        for (k in (headers || {})) h[k] = headers[k];
        return self.fetch(url, { method: method, headers: h, body: body }).then(function (r) {
          if (r.status >= 200 && r.status < 300) return r;
          return r.text().then(function (t) {
            var info = {}; try { info = JSON.parse(t); } catch (e) {}
            var reason = info && info.error && info.error.errors && info.error.errors[0] && info.error.errors[0].reason || '';
            if (r.status === 401 && !refreshed) { refreshed = true; return self.tokens.refresh().then(once); }
            if (r.status === 401) throw SyncError('signed-out', 'token refused');
            var retryable = r.status === 429 || r.status >= 500 || (r.status === 403 && /rateLimit|quota/i.test(reason));
            if (retryable && ++tries < self.maxTries) {
              var ra = parseFloat(r.headers && r.headers.get && r.headers.get('Retry-After'));
              var wait = (isFinite(ra) ? ra * 1000 : 500 * Math.pow(2, tries)) * (0.75 + 0.5 * self.random());
              return self.sleep(wait).then(once);
            }
            throw SyncError(r.status === 404 ? 'not-found' : (r.status === 403 ? 'forbidden' : 'http'), 'HTTP ' + r.status + ' ' + reason, { status: r.status, body: t.slice(0, 300) });
          });
        }, function (netErr) {
          if (++tries < self.maxTries) return self.sleep(500 * Math.pow(2, tries) * (0.75 + 0.5 * self.random())).then(once);
          throw SyncError('network', String(netErr && netErr.message || netErr));
        });
      });
    }
    return once();
  };
  Drive.prototype.list = function (name) {
    var q = "name='" + name.replace(/'/g, "\\'") + "' and trashed=false";
    var url = API + '?spaces=appDataFolder&q=' + encodeURIComponent(q) + '&fields=' + encodeURIComponent('files(id,name,createdTime,modifiedTime,version)') + '&orderBy=createdTime&pageSize=20';
    return this.req('GET', url).then(function (r) { return r.json(); }).then(function (j) { return j.files || []; });
  };
  Drive.prototype.download = function (id) { return this.req('GET', API + '/' + id + '?alt=media').then(function (r) { return r.text(); }); };
  Drive.prototype.create = function (name, text) {
    var b = '----sulekhak' + Math.floor(this.random() * 1e9);
    var meta = JSON.stringify({ name: name, parents: ['appDataFolder'], mimeType: 'application/json' });
    var body = '--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + meta + '\r\n--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + text + '\r\n--' + b + '--';
    return this.req('POST', UP + '?uploadType=multipart&fields=id', { 'Content-Type': 'multipart/related; boundary=' + b }, body).then(function (r) { return r.json(); });
  };
  Drive.prototype.update = function (id, text) {
    return this.req('PATCH', UP + '/' + id + '?uploadType=media&fields=id,version', { 'Content-Type': 'application/json; charset=UTF-8' }, text).then(function (r) { return r.json(); });
  };
  Drive.prototype.remove = function (id) { return this.req('DELETE', API + '/' + id).then(function () { return true; }); };

  /* ================================ the sync loop ================================ */
  function Sync(store, drive, opts) {
    opts = opts || {};
    this.store = store; this.drive = drive;
    this.allowed = (opts.allowedEmails || []).map(function (s) { return String(s).toLowerCase(); });
    this.persist = opts.persist || null;                       /* { write(lang, text) -> Promise } keeps the local copy */
    this.auto = opts.auto !== false;                           /* sync a moment after every change (hosts); tests switch it off */
    this.setTimer = opts.setTimeout || (typeof setTimeout === 'function' ? setTimeout : null);
    this.clearTimer = opts.clearTimeout || (typeof clearTimeout === 'function' ? clearTimeout : null);
    this.debounceMs = opts.debounceMs == null ? 15000 : opts.debounceMs;
    this.rounds = opts.rounds || 5;
    this.onStatus = opts.onStatus || function () {};
    this.onMerged = opts.onMerged || function () {};          /* (lang) the cloud brought something new: re-feed the engine */
    this.busy = {}; this.queued = {}; this.timers = {}; this.status = {}; this.accountChecked = null;
    var self = this;
    store.onChange(function (lang) { self.schedule(lang); });
  }
  Sync.prototype.setStatus = function (lang, s, detail) { this.status[lang] = { state: s, detail: detail || '', at: Date.now() }; try { this.onStatus(lang, this.status[lang]); } catch (e) {} };
  Sync.prototype.schedule = function (lang) {
    var self = this; if (!this.setTimer || !this.auto) return;
    if (this.timers[lang]) this.clearTimer(this.timers[lang]);
    this.timers[lang] = this.setTimer(function () { self.timers[lang] = null; self.syncLang(lang).catch(function () {}); }, this.debounceMs);
  };
  /* the only account allowed to sync is one on the list; anything else is signed out on the spot and nothing is sent */
  Sync.prototype.checkAccount = function () {
    var self = this;
    if (!this.allowed.length) return Promise.resolve('');
    return this.drive.tokens.email().then(function (email) {
      email = String(email || '').toLowerCase();
      if (self.allowed.indexOf(email) < 0) {
        return Promise.resolve(self.drive.tokens.signOut('account-not-allowed', email)).then(function () { throw SyncError('account-not-allowed', email + ' is not an authorised account'); });
      }
      return email;
    });
  };
  Sync.prototype.syncLang = function (lang) {
    var self = this;
    if (this.busy[lang]) { this.queued[lang] = true; return this.busy[lang]; }
    this.setStatus(lang, 'syncing');
    var p = this.checkAccount().then(function () { return self._round(lang, 0); }).then(function (r) {
      self.setStatus(lang, r.state, r.detail); return r;
    }, function (e) {
      var st = e.code === 'signed-out' ? 'signed-out' : (e.code === 'account-not-allowed' ? 'refused' : 'error');
      self.setStatus(lang, st, e.message); throw e;
    }).then(function (r) { self.busy[lang] = null; if (self.queued[lang]) { self.queued[lang] = false; return self.syncLang(lang); } return r; },
            function (e) { self.busy[lang] = null; self.queued[lang] = false; throw e; });
    this.busy[lang] = p; return p;
  };
  Sync.prototype.syncAll = function () {
    var self = this;
    return L.LANGS.reduce(function (chain, lang) {
      return chain.then(function (acc) {
        if (!self.store.docs[lang] && !self.store.hasRemoteHint) { /* never touched here: still pull, the cloud may have it */ }
        return self.syncLang(lang).then(function (r) { acc[lang] = r; return acc; }, function (e) { acc[lang] = { state: 'error', detail: e.code || e.message }; if (e.code === 'signed-out' || e.code === 'account-not-allowed') throw e; return acc; });
      });
    }, Promise.resolve({}));
  };
  Sync.prototype._merge = function (lang, text) {
    var before = L.stableString(this.store.doc(lang));
    var res = this.store.load(lang, text);
    if (!res.ok && res.newer) throw SyncError('newer-format', 'cloud file is format ' + res.newer + ', this app understands ' + L.VERSION);
    if (!res.ok) throw SyncError('bad-remote', res.reason);
    return L.stableString(this.store.doc(lang)) !== before;
  };
  Sync.prototype._round = function (lang, n) {
    var self = this, drive = this.drive, name = fileName(lang), store = this.store, gotNew = false;
    return drive.list(name).then(function (files) {
      if (!files.length) {
        if (store.isEmpty(lang)) { store.dirty[lang] = false; return { state: 'ok', detail: 'nothing learned yet' }; }      /* never create an empty file */
        var text = store.serialize(lang);
        return drive.create(name, text).then(function () { return self._verify(lang, name, n); });
      }
      files.sort(function (a, b) { return a.createdTime < b.createdTime ? -1 : a.createdTime > b.createdTime ? 1 : (a.id < b.id ? -1 : 1); });
      var canon = files[0], dups = files.slice(1);
      /* two devices created the file at the same moment: fold every copy into the oldest one, then drop the others */
      return files.reduce(function (chain, f) { return chain.then(function () { return drive.download(f.id).then(function (t) { if (self._merge(lang, t)) gotNew = true; }); }); }, Promise.resolve())
        .then(function () {
          var remoteText; return drive.download(canon.id).then(function (t) { remoteText = t; }).then(function () {
            var remoteDoc = L.normalizeDoc(JSON.parse(remoteText), lang);
            var needsWrite = dups.length > 0 || L.stableString(store.doc(lang)) !== L.stableString(L.mergeDoc(remoteDoc, remoteDoc));
            if (gotNew) { try { self.onMerged(lang); } catch (e) {} }
            if (!needsWrite) { store.dirty[lang] = false; return self._saveLocal(lang).then(function () { return { state: 'ok', detail: 'up to date' }; }); }
            return drive.update(canon.id, store.serialize(lang)).then(function () {
              return dups.reduce(function (c, f) { return c.then(function () { return drive.remove(f.id).catch(function () {}); }); }, Promise.resolve());
            }).then(function () { return self._verify(lang, name, n); });
          });
        });
    });
  };
  /* read it back: if another device wrote in between and our changes are not in there, merge theirs and write again */
  Sync.prototype._verify = function (lang, name, n) {
    var self = this, drive = this.drive, store = this.store;
    return drive.list(name).then(function (files) {
      if (!files.length) throw SyncError('lost', 'file missing after write');
      files.sort(function (a, b) { return a.createdTime < b.createdTime ? -1 : 1; });
      return drive.download(files[0].id);
    }).then(function (t) {
      var remote = L.normalizeDoc(JSON.parse(t), lang), mine = store.doc(lang);
      if (L.covers(remote, mine)) {
        store.dirty[lang] = false;
        return self._saveLocal(lang).then(function () { return { state: 'ok', detail: 'synced' }; });
      }
      if (n + 1 >= self.rounds) throw SyncError('contended', 'too many simultaneous writers; will retry');
      return drive.sleep(300 * (n + 1) * (0.5 + drive.random())).then(function () { return self._round(lang, n + 1); });
    });
  };
  Sync.prototype._saveLocal = function (lang) { return this.persist ? Promise.resolve(this.persist.write(lang, this.store.serialize(lang))) : Promise.resolve(); };

  return { Drive: Drive, Sync: Sync, SyncError: SyncError, fileName: fileName, SCOPES: SCOPES };
});
