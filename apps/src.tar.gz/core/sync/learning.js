/* Sulekhak personal learning store.
   One document per language (or, hi, mr, bn, as, en). Every number in it is a per-device counter (a G-counter), every time is a
   max/min, every set is add-wins with a removal stamp. Merging two copies is therefore commutative, associative and idempotent:
   any number of devices can change their copy at the same time, merge in any order, any number of times, and end identical,
   with nothing lost. A device only ever raises its OWN slot, so a stale upload can never lower another device's contribution.

   No input/output in this file (it runs in browsers, WebView2, Android WebView, iOS/macOS JavaScriptCore and node).
   Persistence and the network are plugged in from outside (see drive.js and the host shims). */
(function (root, factory) {
  var m = factory();
  if (typeof module === 'object' && module.exports) module.exports = m;
  root.SulekhakLearn = m;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var FORMAT = 'sulekhak-learn-sync', VERSION = 2;
  var LANGS = ['or', 'hi', 'mr', 'bn', 'as', 'en'];
  var LIMITS = { roman: 64, word: 120, perKey: 40 };
  var DAY = 86400, HALF_LIFE = 90 * DAY;

  function now() { return Math.floor(Date.now() / 1000); }
  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function isLang(l) { return LANGS.indexOf(l) >= 0; }

  /* the language a typing mode belongs to; script ids as the engine uses them: 0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese. IPA learns nothing. */
  function langFor(script, opt, english) {
    if (english) return 'en';
    if (script === 0) return 'or';
    if (script === 1) return (opt & 1) ? 'mr' : 'hi';
    if (script === 2) return 'bn';
    if (script === 5) return 'as';
    return null;
  }

  function emptyDoc(lang) {
    return { f: FORMAT, v: VERSION, lang: lang, floor: 0, devices: {}, pick: {}, uni: {}, next: {}, corr: {}, swipe: {}, skip: {}, dict: {} };
  }

  /* ---- entries: { c: {device: n}, t: lastTime, f: firstTime } ---- */
  function newEntry(t) { return { c: {}, t: t, f: t }; }
  function total(e) { var s = 0, k; for (k in e.c) if (has(e.c, k)) s += e.c[k]; return s; }
  function bump(e, did, t, by) { e.c[did] = (e.c[did] || 0) + (by || 1); if (t > e.t) e.t = t; if (t < e.f) e.f = t; }
  function maxInto(o, key, src) { var k; if (!src) return; if (!o[key]) o[key] = {}; for (k in src) if (has(src, k)) o[key][k] = Math.max(o[key][k] || 0, src[k]); }
  function mergeEntry(a, b) {
    var o = { c: {}, t: Math.max(a.t, b.t), f: Math.min(a.f, b.f) }, k;
    for (k in a.c) if (has(a.c, k)) o.c[k] = a.c[k];
    for (k in b.c) if (has(b.c, k)) o.c[k] = Math.max(o.c[k] || 0, b.c[k]);
    maxInto(o, 'r', a.r); maxInto(o, 'r', b.r);
    return o;
  }
  function entryOK(e) { return e && typeof e === 'object' && e.c && typeof e.c === 'object' && typeof e.t === 'number'; }
  function cloneEntry(e) { var o = { c: {}, t: e.t, f: typeof e.f === 'number' ? e.f : e.t }, k; for (k in e.c) if (has(e.c, k)) o.c[k] = e.c[k]; maxInto(o, 'r', e.r); return o; }

  /* two-level maps (pick: roman -> word -> entry), one-level maps (uni, swipe: word -> entry) */
  function merge2(a, b, floor) {
    var o = {}, k, w;
    function put(src) {
      for (k in src) if (has(src, k)) {
        var inner = src[k];
        for (w in inner) if (has(inner, w)) {
          var e = inner[w]; if (!entryOK(e)) continue;
          if (floor && e.t < floor && total(e) <= 1) continue;
          if (!o[k]) o[k] = {};
          o[k][w] = o[k][w] ? mergeEntry(o[k][w], e) : cloneEntry(e);
        }
      }
    }
    put(a); put(b); return o;
  }
  function merge1(a, b, floor) {
    var o = {}, k;
    function put(src) {
      for (k in src) if (has(src, k)) {
        var e = src[k]; if (!entryOK(e)) continue;
        if (floor && e.t < floor && total(e) <= 1) continue;
        o[k] = o[k] ? mergeEntry(o[k], e) : cloneEntry(e);
      }
    }
    put(a); put(b); return o;
  }
  /* dictionary: key "roman\tword" -> {w, r, wt, a: added, d: removed(0 = present), by}. Latest stamp (add or removal) wins; ties go to "present". */
  function stamp(e) { return Math.max(e.a || 0, e.d || 0); }
  function dictNewer(e, cur) {
    var ea = e.a || 0, ca = cur.a || 0;
    if (ea !== ca) return ea > ca ? e : cur;
    var eb = String(e.by), cb = String(cur.by);
    if (eb !== cb) return eb > cb ? e : cur;
    return (e.wt || 0) > (cur.wt || 0) ? e : cur;
  }
  function mergeDict(a, b) {
    var o = {}, k;
    function put(src) {
      for (k in src) if (has(src, k)) {
        var e = src[k]; if (!e || typeof e.w !== 'string') continue;
        var cur = o[k];
        if (!cur) { o[k] = { w: e.w, r: e.r, wt: e.wt, a: e.a || 0, d: e.d || 0, by: e.by }; continue; }
        var ea = Math.max(cur.a, e.a || 0), ed = Math.max(cur.d, e.d || 0);
        /* the later add wins; when two devices added the same entry at the same moment the winner must not depend on the order of the merge,
           or two devices would keep rewriting each other's copy for ever: break the tie by device id, then by weight */
        var newer = dictNewer(e, cur);
        o[k] = { w: cur.w, r: cur.r, wt: newer.wt, a: ea, d: ed, by: newer.by };
      }
    }
    put(a); put(b);
    return o;
  }
  function dictLive(e) { return !(e.d && e.d > e.a); }

  function mergeDoc(a, b) {
    var lang = a.lang || b.lang, o = emptyDoc(lang), k, floor = Math.max(a.floor || 0, b.floor || 0);
    o.floor = floor;
    for (k in a.devices) if (has(a.devices, k)) o.devices[k] = a.devices[k];
    for (k in b.devices) if (has(b.devices, k)) {
      var x = o.devices[k], y = b.devices[k];
      if (x) { var yw = (y.s || 0) > (x.s || 0) || ((y.s || 0) === (x.s || 0) && String(y.n) + '\t' + String(y.p) > String(x.n) + '\t' + String(x.p)); o.devices[k] = { n: yw ? y.n : x.n, p: yw ? y.p : x.p, s: Math.max(x.s || 0, y.s || 0) }; } else o.devices[k] = y;
    }
    o.pick = merge2(a.pick, b.pick, floor);
    o.next = merge2(a.next, b.next, floor);
    o.corr = merge2(a.corr, b.corr, floor);
    o.skip = merge2(a.skip, b.skip, floor);
    o.uni = merge1(a.uni, b.uni, floor);
    o.swipe = merge1(a.swipe, b.swipe, floor);
    o.dict = mergeDict(a.dict, b.dict);
    return o;
  }

  /* does `big` contain everything in `small`? (used to check a write really landed) */
  function covers(big, small) {
    var m = mergeDoc(big, small);
    return stableString(m) === stableString(mergeDoc(big, big));
  }
  function stableString(v) {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return '[' + v.map(stableString).join(',') + ']';
    var ks = Object.keys(v).sort(), i, parts = [];
    for (i = 0; i < ks.length; i++) parts.push(JSON.stringify(ks[i]) + ':' + stableString(v[ks[i]]));
    return '{' + parts.join(',') + '}';
  }

  /* ---- validation of a document that came from outside (a file, the network) ---- */
  function normalizeDoc(raw, lang) {
    if (!raw || typeof raw !== 'object' || raw.f !== FORMAT) return null;
    if (typeof raw.v !== 'number') return null;
    var d = emptyDoc(raw.lang || lang);
    d.v = raw.v; d.floor = +raw.floor || 0;
    var maps2 = ['pick', 'next', 'corr', 'skip'], maps1 = ['uni', 'swipe'], i, k, w;
    for (i = 0; i < maps2.length; i++) {
      var s2 = raw[maps2[i]] || {};
      for (k in s2) if (has(s2, k) && s2[k] && typeof s2[k] === 'object') for (w in s2[k]) if (has(s2[k], w) && entryOK(s2[k][w])) {
        if (!d[maps2[i]][k]) d[maps2[i]][k] = {}; d[maps2[i]][k][w] = cloneEntry(s2[k][w]);
      }
    }
    for (i = 0; i < maps1.length; i++) {
      var s1 = raw[maps1[i]] || {};
      for (k in s1) if (has(s1, k) && entryOK(s1[k])) d[maps1[i]][k] = cloneEntry(s1[k]);
    }
    var sd = raw.dict || {};
    for (k in sd) if (has(sd, k) && sd[k] && typeof sd[k].w === 'string') d.dict[k] = { w: sd[k].w, r: sd[k].r, wt: sd[k].wt, a: sd[k].a || 0, d: sd[k].d || 0, by: sd[k].by };
    var sv = raw.devices || {};
    for (k in sv) if (has(sv, k) && sv[k] && typeof sv[k] === 'object') d.devices[k] = { n: String(sv[k].n || ''), p: String(sv[k].p || ''), s: +sv[k].s || 0 };
    return d;
  }

  /* =============================== the store =============================== */
  function Store(opts) {
    opts = opts || {};
    this.did = opts.deviceId || ('d' + Math.random().toString(16).slice(2, 10));
    this.deviceName = opts.deviceName || ''; this.platform = opts.platform || '';
    this.docs = {}; this.dirty = {}; this.listeners = []; this.clock = opts.clock || now;
    this.readOnly = {};            /* languages whose cloud file is of a newer format than this build understands: kept, never overwritten */
  }
  Store.prototype.doc = function (lang) {
    if (!isLang(lang)) throw new Error('unknown language ' + lang);
    if (!this.docs[lang]) this.docs[lang] = emptyDoc(lang);
    return this.docs[lang];
  };
  Store.prototype._touch = function (lang) {
    var d = this.doc(lang), t = this.clock();
    d.devices[this.did] = { n: this.deviceName, p: this.platform, s: t };
    this.dirty[lang] = true;
    for (var i = 0; i < this.listeners.length; i++) try { this.listeners[i](lang); } catch (e) {}
  };
  Store.prototype.onChange = function (fn) { this.listeners.push(fn); };
  function okRoman(r) { return typeof r === 'string' && r.length > 0 && r.length <= LIMITS.roman; }
  function okWord(w) { return typeof w === 'string' && w.length > 0 && w.length <= LIMITS.word; }
  function slot2(m, a, b, t) { if (!m[a]) m[a] = {}; if (!m[a][b]) m[a][b] = newEntry(t); return m[a][b]; }
  function slot1(m, a, t) { if (!m[a]) m[a] = newEntry(t); return m[a]; }

  /* the user chose `word` for the letters `roman` (from the suggestion strip or the list); `prev` = the word before it */
  Store.prototype.recordPick = function (lang, roman, word, prev) {
    if (!okRoman(roman) || !okWord(word)) return false;
    var d = this.doc(lang), t = this.clock();
    bump(slot2(d.pick, roman, word, t), this.did, t);
    bump(slot1(d.uni, word, t), this.did, t);
    if (okWord(prev)) bump(slot2(d.next, prev, word, t), this.did, t);
    this._touch(lang); return true;
  };
  /* a word that went in without letters (a prediction tapped, a word pasted from the dictionary) */
  Store.prototype.recordWord = function (lang, word, prev) {
    if (!okWord(word)) return false;
    var d = this.doc(lang), t = this.clock();
    bump(slot1(d.uni, word, t), this.did, t);
    if (okWord(prev)) bump(slot2(d.next, prev, word, t), this.did, t);
    this._touch(lang); return true;
  };
  /* the user replaced `typed` by `fixed` (spelling correction accepted, or an edit after the fact) */
  Store.prototype.recordCorrection = function (lang, typed, fixed) {
    if (!okWord(typed) || !okWord(fixed) || typed === fixed) return false;
    var d = this.doc(lang), t = this.clock();
    bump(slot2(d.corr, typed, fixed, t), this.did, t);
    bump(slot1(d.uni, fixed, t), this.did, t);
    this._touch(lang); return true;
  };
  /* a swipe gave the list `shown` and the user took `word` (accepted:true) or replaced it (accepted:false -> a rejection of `word`) */
  Store.prototype.recordSwipe = function (lang, word, accepted, prev) {
    if (!okWord(word)) return false;
    var d = this.doc(lang), t = this.clock(), e = slot1(d.swipe, word, t);
    bump(e, this.did, t);
    if (!accepted) { e.r = e.r || {}; e.r[this.did] = (e.r[this.did] || 0) + 1; }
    if (accepted) { bump(slot1(d.uni, word, t), this.did, t); if (okWord(prev)) bump(slot2(d.next, prev, word, t), this.did, t); }
    this._touch(lang); return true;
  };
  /* the user passed over `word` for the letters `roman` and took something lower down the list (a soft "not this one") */
  Store.prototype.recordSkip = function (lang, roman, word) {
    if (!okRoman(roman) || !okWord(word)) return false;
    var d = this.doc(lang), t = this.clock();
    bump(slot2(d.skip, roman, word, t), this.did, t);
    this._touch(lang); return true;
  };
  Store.prototype.addDictWord = function (lang, roman, word, weight) {
    if (!okRoman(roman) || !okWord(word)) return false;
    var d = this.doc(lang), k = roman + '\t' + word, t = this.clock();
    var cur = d.dict[k], a = Math.max(t, cur ? Math.max(cur.a, cur.d || 0) + 1 : 0);
    d.dict[k] = { w: word, r: roman, wt: weight || 6, a: a, d: 0, by: this.did };
    this._touch(lang); return true;
  };
  Store.prototype.removeDictWord = function (lang, roman, word) {
    var d = this.doc(lang), k = roman + '\t' + word, cur = d.dict[k]; if (!cur) return false;
    cur.d = Math.max(this.clock(), Math.max(cur.a, cur.d || 0) + 1);
    this._touch(lang); return true;
  };

  /* ---- reading what was learned ---- */
  function decay(t, nowT) { var age = Math.max(0, nowT - t); return Math.max(0.25, Math.pow(0.5, age / HALF_LIFE)); }
  /* how strongly the history prefers `word` here: roman letters, previous word. Returns a number >= 0; 0 = nothing learned. */
  Store.prototype.score = function (lang, roman, word, prev, nowT) {
    var d = this.docs[lang]; if (!d) return 0; nowT = nowT || this.clock();
    var s = 0, e, g;
    e = d.pick[roman] && d.pick[roman][word];
    if (e) s += 1.6 * Math.log(1 + total(e)) * decay(e.t, nowT);
    if (prev) { e = d.next[prev] && d.next[prev][word]; if (e) s += 1.0 * Math.log(1 + total(e)) * decay(e.t, nowT); }
    e = d.uni[word]; if (e) s += 0.5 * Math.log(1 + total(e)) * decay(e.t, nowT);
    e = d.swipe[word];
    if (e) { var rej = 0, k; if (e.r) for (k in e.r) if (has(e.r, k)) rej += e.r[k]; s += 0.4 * Math.log(1 + Math.max(0, total(e) - 2 * rej)) * decay(e.t, nowT); }
    g = d.skip[roman] && d.skip[roman][word];
    if (g) s -= 0.7 * Math.log(1 + total(g)) * decay(g.t, nowT);
    return s;
  };
  /* reorder an engine list [word, ...] (or [[word,...],...]) so that what you chose before comes earlier; never drops or adds words, moves at most 4 places */
  Store.prototype.rerank = function (lang, roman, prev, list) {
    var self = this, nowT = this.clock(), items = list.map(function (x, i) {
      var w = Array.isArray(x) ? x[0] : x;
      return { x: x, i: i, v: -i + Math.max(-2, Math.min(4, self.score(lang, roman, w, prev, nowT))) };
    });
    items.sort(function (a, b) { return b.v - a.v || a.i - b.i; });
    return items.map(function (o) { return o.x; });
  };
  /* what to feed the engine's own memory at start-up and after a sync: [[roman, word], ...] strongest last (the engine weights recent entries) */
  Store.prototype.replay = function (lang, limit) {
    var d = this.docs[lang]; if (!d) return [];
    var out = [], r, w, nowT = this.clock();
    for (r in d.pick) if (has(d.pick, r)) for (w in d.pick[r]) if (has(d.pick[r], w)) {
      var e = d.pick[r][w]; out.push([r, w, Math.log(1 + total(e)) * decay(e.t, nowT), e.t]);
    }
    out.sort(function (a, b) { return a[2] - b[2] || a[3] - b[3]; });
    if (limit && out.length > limit) out = out.slice(out.length - limit);
    return out.map(function (x) { return [x[0], x[1]]; });
  };
  /* the words this person has used `min` times or more, and the corrections they have made `min` times or more: [[word, n], ...], [[typed, fixed, n], ...] */
  Store.prototype.words = function (lang, min) {
    var d = this.docs[lang], out = [], k, n; if (!d) return out; min = min || 1;
    for (k in d.uni) if (has(d.uni, k)) { n = total(d.uni[k]); if (n >= min) out.push([k, n]); }
    return out;
  };
  Store.prototype.corrections = function (lang, min) {
    var d = this.docs[lang], out = [], a, b, n; if (!d) return out; min = min || 1;
    for (a in d.corr) if (has(d.corr, a)) for (b in d.corr[a]) if (has(d.corr[a], b)) { n = total(d.corr[a][b]); if (n >= min) out.push([a, b, n]); }
    return out;
  };
  /* the words this person has used that begin with `prefix`, strongest first: [[word, weight], ...]; a word picked for exactly these letters counts more */
  Store.prototype.completions = function (lang, prefix, limit) {
    var d = this.docs[lang], out = [], k, nowT = this.clock(), seen = {}, w; if (!d || !prefix) return out;
    if (d.pick[prefix]) for (w in d.pick[prefix]) if (has(d.pick[prefix], w)) { seen[w] = 1; out.push([w, 1.6 * Math.log(1 + total(d.pick[prefix][w])) * decay(d.pick[prefix][w].t, nowT) + 0.5 * Math.log(1 + (d.uni[w] ? total(d.uni[w]) : 0))]); }
    for (k in d.uni) if (has(d.uni, k) && !seen[k] && k.length > prefix.length && k.indexOf(prefix) === 0) out.push([k, 0.5 * Math.log(1 + total(d.uni[k])) * decay(d.uni[k].t, nowT)]);
    out.sort(function (x, y) { return y[1] - x[1]; });
    return limit ? out.slice(0, limit) : out;
  };
  /* what this person has typed after `prev`, strongest first: [[word, weight], ...] */
  Store.prototype.nextWords = function (lang, prev, limit) {
    var d = this.docs[lang], out = [], b, nowT = this.clock(); if (!d || !d.next[prev]) return out;
    for (b in d.next[prev]) if (has(d.next[prev], b)) out.push([b, Math.log(1 + total(d.next[prev][b])) * decay(d.next[prev][b].t, nowT)]);
    out.sort(function (x, y) { return y[1] - x[1]; });
    return limit ? out.slice(0, limit) : out;
  };
  Store.prototype.dictionary = function (lang) {
    var d = this.docs[lang], out = [], k; if (!d) return out;
    for (k in d.dict) if (has(d.dict, k) && dictLive(d.dict[k])) out.push({ roman: d.dict[k].r, word: d.dict[k].w, weight: d.dict[k].wt });
    return out;
  };
  Store.prototype.isEmpty = function (lang) {
    var d = this.docs[lang]; if (!d) return true;
    return !Object.keys(d.pick).length && !Object.keys(d.uni).length && !Object.keys(d.next).length && !Object.keys(d.corr).length &&
           !Object.keys(d.swipe).length && !Object.keys(d.skip).length && !Object.keys(d.dict).length;
  };
  Store.prototype.stats = function (lang) {
    var d = this.docs[lang]; if (!d) return { picks: 0, words: 0, next: 0, corrections: 0, swipes: 0, dict: 0 };
    function n2(m) { var c = 0, a, b; for (a in m) if (has(m, a)) for (b in m[a]) if (has(m[a], b)) c++; return c; }
    return { picks: n2(d.pick), words: Object.keys(d.uni).length, next: n2(d.next), corrections: n2(d.corr), swipes: Object.keys(d.swipe).length, dict: this.dictionary(lang).length };
  };

  /* ---- merging a copy that came from elsewhere ---- */
  Store.prototype.merge = function (lang, remote) {
    var r = normalizeDoc(remote, lang);
    if (!r) return { ok: false, reason: 'not a Sulekhak learning file' };
    if (r.lang && r.lang !== lang) return { ok: false, reason: 'language mismatch (' + r.lang + ' file offered for ' + lang + ')' };
    if (r.v > VERSION) { this.readOnly[lang] = r.v; return { ok: false, reason: 'newer format', newer: r.v }; }
    var before = stableString(this.doc(lang));
    this.docs[lang] = mergeDoc(this.doc(lang), r); this.docs[lang].v = VERSION;
    var changed = stableString(this.docs[lang]) !== before;
    if (changed) this.dirty[lang] = true;
    return { ok: true, changed: changed };
  };
  Store.prototype.serialize = function (lang) { var d = this.doc(lang); d.v = VERSION; return JSON.stringify(d); };
  Store.prototype.load = function (lang, text) {
    var raw; try { raw = JSON.parse(text); } catch (e) { return { ok: false, reason: 'unreadable' }; }
    return this.merge(lang, raw);
  };

  /* drop the old single-use entries (older than `days`) and move the floor up so that a stale device cannot bring them back */
  Store.prototype.compact = function (lang, days) {
    var d = this.doc(lang), floor = this.clock() - (days || 365) * DAY, k, w, removed = 0;
    function sweep2(m) { for (k in m) if (has(m, k)) { for (w in m[k]) if (has(m[k], w)) { var e = m[k][w]; if (e.t < floor && total(e) <= 1) { delete m[k][w]; removed++; } } if (!Object.keys(m[k]).length) delete m[k]; } }
    function sweep1(m) { for (k in m) if (has(m, k)) { var e = m[k]; if (e.t < floor && total(e) <= 1) { delete m[k]; removed++; } } }
    sweep2(d.pick); sweep2(d.next); sweep2(d.corr); sweep2(d.skip); sweep1(d.uni); sweep1(d.swipe);
    if (floor > d.floor) d.floor = floor;
    if (removed) this.dirty[lang] = true;
    return removed;
  };

  /* ---- importing what older versions kept (so nothing learned before is lost) ---- */
  /* history.tsv: "roman<TAB>word" one pick per line (Windows, Android, web) */
  Store.prototype.importHistoryTsv = function (lang, text, assumedTime) {
    var lines = String(text || '').split('\n'), n = 0, i, t = assumedTime || this.clock(), prev = null;
    var d = this.doc(lang);
    for (i = 0; i < lines.length; i++) {
      var p = lines[i].replace(/\r$/, '').split('\t');
      if (p.length < 2 || !okRoman(p[0]) || !okWord(p[1])) continue;
      bump(slot2(d.pick, p[0], p[1], t), this.did, t); bump(slot1(d.uni, p[1], t), this.did, t);
      n++;
    }
    if (n) this._touch(lang);
    return n;
  };
  /* the Mac cache sulekhak-learn.json, format 1: {picks:{roman:[{w,n,first,last,sc}]}, dict:[{w,roman,wt,added}], next:{prev:{word:n}}}
     Words there are in the engine's own form (Odia); sc is a bit set of the scripts they were typed in (0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese).
     `toScript(word, scriptId)` carries a word into a script (the host passes the engine's converter); without it only Odia entries are imported. */
  Store.prototype.importMacV1 = function (json, toScript, importTime) {
    var res = { or: 0, hi: 0, bn: 0, as: 0, skipped: 0 }, self = this, r, i, scMap = { 0: 'or', 1: 'hi', 2: 'bn', 5: 'as' };
    var picks = json && json.picks || {}, dict = json && json.dict || [], nx = json && json.next || {};
    var t0 = importTime || this.clock();
    for (r in picks) if (has(picks, r)) for (i = 0; i < picks[r].length; i++) {
      var e = picks[r][i]; if (!okRoman(r) || !okWord(e.w)) continue;
      var bit;
      for (bit in scMap) if (has(scMap, bit) && ((e.sc | 0) & (1 << +bit) || (+bit === 0 && !(e.sc | 0)))) {
        var lang = scMap[bit], w = e.w;
        if (+bit !== 0) { if (!toScript) { res.skipped++; continue; } w = toScript(e.w, +bit); if (!okWord(w)) { res.skipped++; continue; } }
        var d = this.doc(lang), n = Math.max(1, e.n | 0), t = e.last || t0, f = e.first || t;
        var en = slot2(d.pick, r, w, f), un = slot1(d.uni, w, f);
        bump(en, this.did, t, n); en.f = Math.min(en.f, f); bump(un, this.did, t, n);
        this._touch(lang); res[lang]++;
      }
    }
    for (i = 0; i < dict.length; i++) if (dict[i] && okRoman(dict[i].roman) && okWord(dict[i].w)) {
      var dd = this.doc('or'), k = dict[i].roman + '\t' + dict[i].w;
      if (!dd.dict[k]) dd.dict[k] = { w: dict[i].w, r: dict[i].roman, wt: dict[i].wt || 6, a: dict[i].added || t0, d: 0, by: this.did };
      this._touch('or'); res.or++;
    }
    for (var prev in nx) if (has(nx, prev)) for (var w2 in nx[prev]) if (has(nx[prev], w2)) {
      if (!okWord(prev) || !okWord(w2)) continue;
      var d2 = this.doc('or'); bump(slot2(d2.next, prev, w2, t0), this.did, t0, Math.max(1, nx[prev][w2] | 0)); this._touch('or');
    }
    return res;
  };

  return { FORMAT: FORMAT, VERSION: VERSION, LANGS: LANGS, langFor: langFor, Store: Store, mergeDoc: mergeDoc, normalizeDoc: normalizeDoc,
           emptyDoc: emptyDoc, covers: covers, stableString: stableString, total: total, isLang: isLang };
});
