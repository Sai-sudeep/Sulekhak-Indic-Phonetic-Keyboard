/* Sulekhak personal learning: the glue between an engine page (ime.js on Windows and Android, the web typist) and the sync core.
   It decides which language is active, records what you pick, correct and swipe, re-orders suggestions from that history, keeps a local
   copy, and (when you are signed in with an allowed Google account) syncs one file per language with your hidden Drive app-data folder.

   Hosts talk to it in two ways:
   - web page:     SKP.initWeb({ clientId, allowed })           sign-in with Google Identity Services, local copy in the browser
   - native host:  SKP.initHost({ did, name, platform, allowed, post })   the app does the sign-in and the files; messages go through post()
       page -> host   {t:'sk-need',lang}  {t:'sk-save',lang,text}  {t:'sk-token'}  {t:'sk-state',state,detail,lang}
       host -> page   SKP.hostLoad(lang,text)  SKP.setToken(access, expiresInSeconds, email)  SKP.signedOut()  SKP.syncNow()          */
(function () {
  'use strict';
  var L = window.SulekhakLearn, S = window.SulekhakSync;
  if (!L || !S) return;
  var SKP = window.SKP = { ready: false, lang: null, state: 'off', detail: '', listeners: [] };
  var store = null, sync = null, io = null, cfg = null, loaded = {}, saveTimer = null, tok = { access: null, exp: 0, email: '', waiters: [] };
  var lastPrev = '', engineReplay = null, synced = {};

  function emit() { for (var i = 0; i < SKP.listeners.length; i++) try { SKP.listeners[i](SKP.state, SKP.detail, SKP.lang); } catch (e) {} }
  function setState(s, d) { SKP.state = s; SKP.detail = d || ''; emit(); if (cfg && cfg.post) try { cfg.post({ t: 'sk-state', state: s, detail: d || '', lang: SKP.lang }); } catch (e) {} }
  SKP.onState = function (fn) { SKP.listeners.push(fn); fn(SKP.state, SKP.detail, SKP.lang); };

  /* ---------------- tokens ---------------- */
  var tokens = {
    access: function () {
      if (tok.access && Date.now() < tok.exp - 60000) return Promise.resolve(tok.access);
      if (!cfg) return Promise.resolve(null);
      return SKP._needToken();
    },
    refresh: function () { tok.access = null; return SKP._needToken(); },
    email: function () { return Promise.resolve(tok.email); },
    signOut: function (why, who) { tok.access = null; tok.email = ''; setState(why === 'account-not-allowed' ? 'refused' : 'signed-out', who || ''); try { if (cfg.signOut) cfg.signOut(); else if (cfg.post) cfg.post({ t: 'sk-signout' }); } catch (e) {} return Promise.resolve(); }
  };
  SKP._needToken = function () {
    return new Promise(function (res) {
      tok.waiters.push(res);
      if (tok.waiters.length === 1) { try { if (cfg.requestToken) cfg.requestToken(); else cfg.post({ t: 'sk-token' }); } catch (e) {} }
      setTimeout(function () { var i = tok.waiters.indexOf(res); if (i >= 0) { tok.waiters.splice(i, 1); res(null); } }, 30000);
    });
  };
  SKP.setToken = function (access, expiresIn, email) {
    tok.access = access || null; tok.exp = Date.now() + (expiresIn || 3000) * 1000; if (email) tok.email = String(email).toLowerCase();
    var w = tok.waiters; tok.waiters = []; for (var i = 0; i < w.length; i++) w[i](tok.access);
    if (tok.access) { setState('signed-in', tok.email); SKP.syncNow(); } else setState('signed-out', '');
  };
  SKP.signedOut = function () { tok.access = null; tok.email = ''; var w = tok.waiters; tok.waiters = []; for (var i = 0; i < w.length; i++) w[i](null); setState('signed-out', ''); };

  /* ---------------- local copy ---------------- */
  function persistWrite(lang, text) { return io.write(lang, text); }
  function scheduleSave(lang) {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(function () { saveTimer = null; L.LANGS.forEach(function (l) { if (store.docs[l] && store.dirty[l + ':local']) { store.dirty[l + ':local'] = false; persistWrite(l, store.serialize(l)); } }); }, 2000);
  }
  function loadLang(lang) {
    if (loaded[lang]) return loaded[lang];
    loaded[lang] = Promise.resolve(io.read(lang)).then(function (text) {
      if (text) { var r = store.load(lang, text); if (!r.ok && !r.newer) try { console.log('learning file for ' + lang + ' unreadable: ' + r.reason); } catch (e) {} }
      if (SKP.lang === lang) feedEngine(lang);
      return true;
    }, function () { return false; });
    return loaded[lang];
  }

  /* ---------------- engine feed ---------------- */
  function feedEngine(lang) {
    if (lang !== SKP.lang) return;
    var pairs = store.replay(lang, 4000);
    if (!pairs.length && lang !== 'en') return;
    try { if (lang === 'en' && window.imeEnLearn) window.imeEnLearn(); else if (window.imeLearnAdd) window.imeLearnAdd(pairs); else if (engineReplay) engineReplay(pairs); } catch (e) {}
  }

  /* ---------------- public: what the engine page calls ---------------- */
  SKP.setMode = function (script, opt, english) {
    var lang = L.langFor(script, opt | 0, !!english);
    if (lang === SKP.lang) return;
    SKP.lang = lang;
    if (lang && store) loadLang(lang).then(function () { if (tok.email && !synced[lang]) { synced[lang] = true; SKP.syncNow(); } });
  };
  SKP.prev = function (p) { lastPrev = p || ''; };
  SKP.onPick = function (roman, word, prev) { if (store && SKP.lang) { if (store.recordPick(SKP.lang, roman, word, prev || lastPrev)) scheduleLocal(); } };
  SKP.onWord = function (word, prev) { if (store && SKP.lang) { if (store.recordWord(SKP.lang, word, prev || lastPrev)) scheduleLocal(); } };
  SKP.onCorrection = function (typed, fixed) { if (store && SKP.lang) { if (store.recordCorrection(SKP.lang, typed, fixed)) scheduleLocal(); } };
  SKP.onSwipe = function (word, accepted, prev) { if (store && SKP.lang) { if (store.recordSwipe(SKP.lang, word, accepted, prev || lastPrev)) scheduleLocal(); } };
  SKP.onSkip = function (roman, word) { if (store && SKP.lang) { if (store.recordSkip(SKP.lang, roman, word)) scheduleLocal(); } };
  SKP.addWord = function (roman, word) { if (store && SKP.lang && store.addDictWord(SKP.lang, roman, word, 6)) { scheduleLocal(); return true; } return false; };
  SKP.nextFor = function (prev, limit) { return store && SKP.lang && prev ? store.nextWords(SKP.lang, prev, limit || 6) : []; };
  SKP.completionsFor = function (prefix, limit) { return store && SKP.lang && prefix ? store.completions(SKP.lang, prefix, limit || 6) : []; };
  SKP.learnedWords = function (min) { return store && SKP.lang ? store.words(SKP.lang, min || 2) : []; };
  SKP.learnedCorrections = function (min) { return store && SKP.lang ? store.corrections(SKP.lang, min || 2) : []; };
  /* reorder a whole list by what was chosen before (no slot is kept fixed): used by the English strip, where the caller decides what stays in front */
  SKP.rerankRaw = function (roman, prev, list) { if (!store || !SKP.lang || !list || list.length < 2) return list; try { return store.rerank(SKP.lang, roman, prev || lastPrev, list); } catch (e) { return list; } };
  SKP.dictionary = function () { return store && SKP.lang ? store.dictionary(SKP.lang) : []; };
  SKP.stats = function () { return store && SKP.lang ? store.stats(SKP.lang) : null; };
  function scheduleLocal() { if (!store || !SKP.lang) return; store.dirty[SKP.lang + ':local'] = true; scheduleSave(SKP.lang); }
  /* re-order a list of candidates (the typed text in slot 2 stays where it is) */
  SKP.rerank = function (roman, prev, list) {
    if (!store || !SKP.lang || !list || list.length < 3) return list;
    try {
      var keep = list[1], rest = [list[0]].concat(list.slice(2));
      var r = store.rerank(SKP.lang, roman, prev || lastPrev, rest);
      return [r[0], keep].concat(r.slice(1));
    } catch (e) { return list; }
  };

  /* ---------------- sync ---------------- */
  SKP.syncNow = function () {
    if (!sync) return Promise.resolve(null);
    if (!tok.email && !tok.access) return Promise.resolve(null);
    setState('syncing', '');
    var langs = L.LANGS.filter(function (l) { return l === SKP.lang || store.docs[l]; });      /* the active language and any already used here; others are pulled when you switch to them */
    return langs.reduce(function (c, l) { return c.then(function () { return loadLang(l).then(function () { return sync.syncLang(l); }); }); }, Promise.resolve())
      .then(function () { setState('synced', new Date().toLocaleTimeString()); },
            function (e) { setState(e && e.code === 'signed-out' ? 'signed-out' : (e && e.code === 'account-not-allowed' ? 'refused' : 'error'), e && (e.message || e.code)); });
  };

  function build(c) {
    cfg = c;
    store = new L.Store({ deviceId: c.did, deviceName: c.name || '', platform: c.platform || '' });
    var drive = new S.Drive(tokens, c.driveOptions || {});
    sync = new S.Sync(store, drive, {
      allowedEmails: c.allowed || [], debounceMs: c.debounceMs == null ? 20000 : c.debounceMs,
      persist: { write: function (l, t) { return persistWrite(l, t); } },
      onMerged: function (l) { feedEngine(l); }, onStatus: function () {}
    });
    window.setInterval(function () { if (tok.access || tok.email) SKP.syncNow(); }, 5 * 60 * 1000);
    SKP.ready = true;
    setState(tok.email ? 'signed-in' : 'signed-out', tok.email);
    if (SKP.lang) loadLang(SKP.lang);                    /* a script was chosen before the history was ready */
  }

  /* native host (Android WebView, WebView2): the app signs in and keeps the files */
  SKP.initHost = function (c) {
    io = { read: function (lang) { return new Promise(function (res) { var done = false; SKP._hostReads = SKP._hostReads || {}; SKP._hostReads[lang] = function (t) { if (!done) { done = true; res(t); } }; c.post({ t: 'sk-need', lang: lang }); setTimeout(function () { if (!done) { done = true; res(null); } }, 4000); }); },
            write: function (lang, text) { c.post({ t: 'sk-save', lang: lang, text: text }); return Promise.resolve(); } };
    build(c);
  };
  /* host -> page: the stored text of a language (empty when there is none) */
  SKP.hostLoad = function (lang, text) {
    if (SKP._hostReads && SKP._hostReads[lang]) { SKP._hostReads[lang](text || null); delete SKP._hostReads[lang]; return; }
    if (store && text) store.load(lang, text);
    if (SKP.lang === lang) feedEngine(lang);
  };

  /* web page: Google Identity Services token flow, copy in localStorage */
  SKP.initWeb = function (c) {
    var key = function (l) { return 'sulekhak-learn-' + l; };
    io = { read: function (l) { try { return Promise.resolve(localStorage.getItem(key(l))); } catch (e) { return Promise.resolve(null); } },
           write: function (l, t) { try { localStorage.setItem(key(l), t); } catch (e) {} return Promise.resolve(); } };
    var did; try { did = localStorage.getItem('sulekhak-learn-device'); } catch (e) {}
    if (!did) { did = 'w' + Math.random().toString(16).slice(2, 10); try { localStorage.setItem('sulekhak-learn-device', did); } catch (e) {} }
    var client = null;
    c.did = did; c.platform = 'web'; c.name = c.name || (navigator.userAgent.match(/(Chrome|Firefox|Safari|Edg)\/[\d.]+/) || ['browser'])[0];
    c.requestToken = function () {
      if (!client) { SKP.setToken(null); return; }
      client.requestAccessToken({ prompt: '' });
    };
    c.signOut = function () { try { if (tok.access && window.google && google.accounts) google.accounts.oauth2.revoke(tok.access, function () {}); } catch (e) {} };
    build(c);
    function boot() {
      if (!(window.google && google.accounts && google.accounts.oauth2)) return false;
      client = google.accounts.oauth2.initTokenClient({
        client_id: c.clientId, scope: S.SCOPES,
        callback: function (r) {
          if (r && r.access_token) {
            fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: 'Bearer ' + r.access_token } })
              .then(function (x) { return x.json(); }).then(function (u) { SKP.setToken(r.access_token, +r.expires_in || 3000, u.email); },
                                                               function () { SKP.setToken(null); });
          } else SKP.setToken(null);
        },
        error_callback: function () { SKP.setToken(null); }
      });
      return true;
    }
    var tries = 0, iv = setInterval(function () { if (boot() || ++tries > 60) clearInterval(iv); }, 500);
    SKP.signIn = function () { if (client) client.requestAccessToken({ prompt: 'select_account' }); };
    SKP.signOut = function () { tokens.signOut(); };
    SKP.setMode(c.script || 0, c.opt || 0, false);
  };
  /* test hook */
  SKP._internals = function () { return { store: store, sync: sync, tokens: tokens }; };
})();
