'use strict';
/* node analyze_failures.js dataset.json perg.json [pack]  -> accuracy by how the gesture's spelling relates to the word's alias list */
const fs=require('fs'),zlib=require('zlib');
const PACK=(process.argv[4]||'/tmp/pack/compact').replace(/\/?$/,'/');
const gz=f=>zlib.gunzipSync(fs.readFileSync(PACK+f+'.gz')).toString('utf8');
const lex=gz('lex').split('\n').filter(Boolean).map(l=>l.slice(0,l.indexOf('\t')));
const rom=gz('rom').split('\n').slice(0,lex.length);
const wid=new Map();lex.forEach((w,i)=>wid.set(w,i));
const col=s=>s.replace(/~/g,'').replace(/(.)\1+/g,'$1');
const D=JSON.parse(fs.readFileSync(process.argv[2],'utf8')),P=new Map(JSON.parse(fs.readFileSync(process.argv[3],'utf8')));
const by={};
for(const g of D.gestures){
  if(!P.has(g.id))continue;
  const r=P.get(g.id),i=wid.get(g.word);
  const strip=s=>s.replace(/‌/g,'');
  let st;
  if(i===undefined){
    const j=lex.findIndex(w=>strip(w)===strip(g.word));st=j<0?'word not in lexicon':null;
    if(st===null){}
  }
  if(!st){
    const idx=i!==undefined?i:lex.findIndex(w=>strip(w)===strip(g.word));
    const al=rom[idx].split(' ').map(col),q=col(g.roman.toLowerCase());
    const sch=q.charAt(0)+q.slice(1,-1).replace(/a/g,'')+q.charAt(q.length-1);
    const alSch=al.map(a=>a.charAt(0)+a.slice(1,-1).replace(/a/g,'')+a.charAt(a.length-1));
    st=al.includes(q)?'spelling is an alias':alSch.includes(sch)?'differs from an alias only by inner a':'spelling NOT an alias (novel)';
    if(idx>=120000)st='word beyond the 120k swipe index';
  }
  const b=by[st]=by[st]||{n:0,h1:0,h3:0,h8:0,miss:0};b.n++;if(r===0)b.h1++;if(r>=0&&r<3)b.h3++;if(r>=0&&r<8)b.h8++;if(r<0)b.miss++;
}
for(const k in by){const b=by[k];console.log(k.padEnd(44),String(b.n).padStart(5),'top1',(100*b.h1/b.n).toFixed(1).padStart(5),'top3',(100*b.h3/b.n).toFixed(1).padStart(5),'top8',(100*b.h8/b.n).toFixed(1).padStart(5),'not in 8:',(100*(b.n-b.h8)/b.n).toFixed(1))}
