#!/usr/bin/env node
/* node ablate.js feats_train.jsonl feats_test.jsonl
   Leave-one-feature-out ablation of the ranking model. For every feature subset the weights are re-fitted on the TRAIN words only and the
   top-1 / top-3 / MRR are measured on the held-out TEST words, within the same retrieved candidate pool (so only the ranking differs). */
'use strict';
const fs=require('fs');
const FE=['loc','dtw','shp','cov','sal','ed','lenr','vpen','lm','cc0','cc1'];
const rd=f=>fs.readFileSync(f,'utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l).rows);
const TR=rd(process.argv[2]).filter(r=>r.some(x=>x[0]===1)),TE=rd(process.argv[3]);
function fit(use,lists,ep=250){
  const idx=use.map(f=>FE.indexOf(f)),D=idx.length;
  const mu=new Array(D).fill(0),sd=new Array(D).fill(0);let c=0;
  for(const rows of lists)for(const r of rows){idx.forEach((k,j)=>mu[j]+=r[1+k]);c++}
  mu.forEach((_,j)=>mu[j]/=c);
  for(const rows of lists)for(const r of rows)idx.forEach((k,j)=>sd[j]+=(r[1+k]-mu[j])**2);
  sd.forEach((_,j)=>sd[j]=Math.sqrt(sd[j]/c)||1);
  const w=new Array(D).fill(0),m=new Array(D).fill(0),v=new Array(D).fill(0);let t=0;
  for(let e=0;e<ep;e++){
    const g=new Array(D).fill(0);
    for(const rows of lists){
      let mx=-1e18;const sc=rows.map(r=>{let s=0;idx.forEach((k,j)=>s+=w[j]*(r[1+k]-mu[j])/sd[j]);if(s>mx)mx=s;return s});
      let Z=0;for(const s of sc)Z+=Math.exp(s-mx);
      rows.forEach((r,i)=>{const p=Math.exp(sc[i]-mx)/Z,cc=p-(r[0]===1?1:0);idx.forEach((k,j)=>g[j]+=cc*(r[1+k]-mu[j])/sd[j])});
    }
    t++;for(let j=0;j<D;j++){g[j]=g[j]/lists.length+1e-3*w[j];m[j]=0.9*m[j]+0.1*g[j];v[j]=0.999*v[j]+0.001*g[j]*g[j];w[j]-=0.05*(m[j]/(1-0.9**t))/(Math.sqrt(v[j]/(1-0.999**t))+1e-8)}
  }
  return {idx,w,mu,sd};
}
function evalM(M,lists){
  let n=0,h1=0,h3=0,mrr=0,miss=0;
  for(const rows of lists){
    const gi=rows.findIndex(r=>r[0]===1);n++;if(gi<0){miss++;continue}
    const sc=rows.map(r=>{let s=0;M.idx.forEach((k,j)=>s+=M.w[j]*(r[1+k]-M.mu[j])/M.sd[j]);return s});
    let rank=0;for(let i=0;i<sc.length;i++)if(i!==gi&&sc[i]>sc[gi])rank++;
    if(rank===0)h1++;if(rank<3)h3++;mrr+=1/(rank+1);
  }
  return {n,top1:(100*h1/n).toFixed(1),top3:(100*h3/n).toFixed(1),mrr:(mrr/n).toFixed(3),retrievalMiss:(100*miss/n).toFixed(1)};
}
const runs=[['all features',FE],...FE.map(f=>['without '+f,FE.filter(x=>x!==f)]),['geometry only (loc,shp,cov,sal) + LM',['loc','shp','cov','sal','lm','cc0','cc1']],['geometry only, no LM',['loc','shp','cov','sal']],['LM + cluster only (no gesture)',['lm','cc0','cc1']]];
console.log('model'.padEnd(42),'top1','top3','MRR','(retrieval miss)');
for(const [name,use] of runs){const M=fit(use,TR);const r=evalM(M,TE);console.log(name.padEnd(42),r.top1.padStart(5),r.top3.padStart(5),r.mrr,' ',r.retrievalMiss+'%')}
