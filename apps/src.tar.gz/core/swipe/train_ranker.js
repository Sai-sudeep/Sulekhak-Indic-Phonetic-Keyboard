#!/usr/bin/env node
/* node train_ranker.js feats.jsonl [out.json]
   Fits the log-linear ranking weights by maximising the log-likelihood of the gold word against the other
   candidates of the same gesture (a listwise softmax, L2-regularised, Adam). Only gestures whose gold word was
   retrieved take part (retrieval misses are reported separately by run_eval). The 'bias' feature is constant and is dropped. */
'use strict';
const fs=require('fs');
const FE=['loc','dtw','shp','cov','sal','ed','lenr','vpen','lm','cc0','cc1','bias'];
const lines=fs.readFileSync(process.argv[2],'utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l));
const L2=+(process.env.L2||1e-3),EPOCHS=+(process.env.EPOCHS||300);
const USE=(process.env.USE||'').split(',').filter(Boolean);        /* optional feature subset; the others get weight 0 */
const D=FE.length-1;                          /* without bias */
const data=lines.map(o=>o.rows).filter(r=>r.some(x=>x[0]===1));
console.error('lists',data.length,'features',D);
/* scale: divide every feature by its std so one learning rate fits all */
const sd=new Array(D).fill(0),mu=new Array(D).fill(0);let cnt=0;
for(const rows of data)for(const r of rows){for(let k=0;k<D;k++)mu[k]+=r[1+k];cnt++}
for(let k=0;k<D;k++)mu[k]/=cnt;
for(const rows of data)for(const r of rows)for(let k=0;k<D;k++)sd[k]+=(r[1+k]-mu[k])**2;
for(let k=0;k<D;k++)sd[k]=Math.sqrt(sd[k]/cnt)||1;
let w=new Array(D).fill(0);const init={loc:-3.5,dtw:-12,shp:-0.9,cov:-12,sal:-14,ed:-4,lenr:-1.5,vpen:-1.2,lm:0.8,cc0:-0.8,cc1:-4.8};
for(let k=0;k<D;k++)w[k]=USE.length&&!USE.includes(FE[k])?0:(init[FE[k]]||0)*sd[k];                       /* start from the hand-set weights, expressed in scaled units */
const m=new Array(D).fill(0),v=new Array(D).fill(0);let t=0;
function lossGrad(){
  let loss=0;const g=new Array(D).fill(0);let top1=0;
  for(const rows of data){
    let mx=-1e18;const sc=rows.map(r=>{let s=0;for(let k=0;k<D;k++)s+=w[k]*(r[1+k]-mu[k])/sd[k];if(s>mx)mx=s;return s});
    let Z=0;for(const s of sc)Z+=Math.exp(s-mx);
    let gi=-1,best=-1e18,bi=0;rows.forEach((r,i)=>{if(r[0]===1)gi=i;if(sc[i]>best){best=sc[i];bi=i}});
    if(bi===gi)top1++;
    loss+=-(sc[gi]-mx-Math.log(Z));
    rows.forEach((r,i)=>{const p=Math.exp(sc[i]-mx)/Z,c=p-(i===gi?1:0);for(let k=0;k<D;k++)g[k]+=c*(r[1+k]-mu[k])/sd[k]});
  }
  const N=data.length;for(let k=0;k<D;k++){g[k]=g[k]/N+L2*w[k]}
  return {loss:loss/N,g,top1:top1/N};
}
for(let ep=1;ep<=EPOCHS;ep++){
  const {loss,g,top1}=lossGrad();t++;
  for(let k=0;k<D;k++){if(USE.length&&!USE.includes(FE[k])){g[k]=0;w[k]=0;continue}m[k]=0.9*m[k]+0.1*g[k];v[k]=0.999*v[k]+0.001*g[k]*g[k];w[k]-=0.05*(m[k]/(1-0.9**t))/(Math.sqrt(v[k]/(1-0.999**t))+1e-8)}
  if(ep%50===0||ep===1)console.error('epoch',ep,'loss',loss.toFixed(4),'train top1',(100*top1).toFixed(1));
}
/* back to raw feature units; the constant shift from mu cancels in the softmax so bias stays 0 */
const out={};for(let k=0;k<D;k++)out[FE[k]]=+(w[k]/sd[k]).toFixed(4);out.bias=0;
console.log(JSON.stringify(out));
if(process.argv[3])fs.writeFileSync(process.argv[3],JSON.stringify({weights:out,features:FE,lists:data.length,l2:L2,epochs:EPOCHS},null,1));
