'use strict';
const fs=require('fs'),zlib=require('zlib'),path=require('path');
const A=process.argv.slice(2),opt=(k,d)=>{const i=A.indexOf('--'+k);return i>=0?A[i+1]:d};
const PACK='/tmp/pack/compact/',LIM=+opt('limit',600);
const txt=f=>zlib.gunzipSync(fs.readFileSync(PACK+f+'.gz')).toString('utf8');
const buf=f=>{const b=zlib.gunzipSync(fs.readFileSync(PACK+f+'.gz'));return b.buffer.slice(b.byteOffset,b.byteOffset+b.length)};
const M=require('/tmp/c7/sulekhak10.js');const W=M.Sulekhak.create();
W.load({cfg:txt('cfg'),lex:txt('lex'),rom:txt('rom'),clus:txt('clus'),syl_uni:txt('syl_uni'),syl_bi:txt('syl_bi'),syl_chan:txt('syl_chan'),idx:buf('idx'),ng:[buf('ng')]});
function h32(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0}return h}
const D=JSON.parse(fs.readFileSync('dataset.json','utf8'));
const ROWS=['qwertyuiop','asdfghjkl','zxcvbnm'],OFF=[0,0.5,1.5],ASP=D.meta.geoms,KC={};
const keyset=g=>KC[g]||(KC[g]=(()=>{const K={};ROWS.forEach((r,y)=>[...r].forEach((c,i)=>K[c]=[i+0.5+OFF[y],(y+0.5)*ASP[g]]));return K})());
const strip=s=>s.replace(/‌/g,'');
const rk=(l,w)=>{for(let i=0;i<l.length;i++)if(strip(l[i])===strip(w))return i;return -1};
function nearest(K,x,y){let b=null,d1=1e9;for(const c in K){const d=Math.hypot(K[c][0]-x,K[c][1]-y);if(d<d1){d1=d;b=c}}return b}
function keystr(K,pts,minRun){const r=[];let last=null,run=0;for(const p of pts){const c=nearest(K,p[0],p[1]);if(c===last)run++;else{if(last&&run>=minRun)r.push(last);last=c;run=1}}if(last)r.push(last);return r.join('')}
const G=D.gestures.filter((g,i)=>h32('split|'+g.word)%5===0&&i%2===0).slice(0,LIM);
const modes={verts:(K,p)=>W.engine.swipeKeys({k:K,p:p}),all:(K,p)=>keystr(K,p,1),run2:(K,p)=>keystr(K,p,2),run3:(K,p)=>keystr(K,p,3)};
const res={};for(const m in modes)res[m]={n:0,h1:0,h3:0,h8:0};res.swipe10={n:0,h1:0,h3:0,h8:0};
for(const g of G){
  const K=keyset(g.geom);
  for(const m in modes){
    const s=modes[m](K,g.pts);
    const l=W.engine.suggest(s,g.prev||'<s>',g.prev2||null,6,6).map(x=>x[0]);
    const r=rk(l,g.word);const o=res[m];o.n++;if(r===0)o.h1++;if(r>=0&&r<3)o.h3++;if(r>=0&&r<8)o.h8++;
  }
  const l=W.engine.swipe({k:K,p:g.pts},g.prev||'<s>',g.prev2||null,8,{}).map(x=>x[0]);const r=rk(l,g.word);const o=res.swipe10;o.n++;if(r===0)o.h1++;if(r>=0&&r<3)o.h3++;if(r>=0&&r<8)o.h8++;
}
for(const m in res){const o=res[m];console.log(m.padEnd(8),'n',o.n,'top1',(100*o.h1/o.n).toFixed(1),'top3',(100*o.h3/o.n).toFixed(1),'top8',(100*o.h8/o.n).toFixed(1))}
