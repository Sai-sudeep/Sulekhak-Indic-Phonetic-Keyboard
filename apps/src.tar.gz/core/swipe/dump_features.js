#!/usr/bin/env node
/* node dump_features.js --engine sulekhak10.js --pack compact --data dataset.json --out feats.jsonl [--limit N] [--w '{...}']
   Runs the decoder over the TRAINING words (the ones not held out) and writes, per gesture, the feature vectors of the
   candidate pool (top 60 plus the gold word if it was retrieved). */
'use strict';
const fs=require('fs'),zlib=require('zlib'),path=require('path');
const A=process.argv.slice(2),opt=(k,d)=>{const i=A.indexOf('--'+k);return i>=0?A[i+1]:d};
const ENG=opt('engine'),PACK=opt('pack','/tmp/pack/compact').replace(/\/?$/,'/'),DATA=opt('data','dataset.json'),OUT=opt('out','feats.jsonl'),LIMIT=+opt('limit',0),EV=JSON.parse(opt('opts','{}')),STEP=+opt('step',1);
const txt=f=>zlib.gunzipSync(fs.readFileSync(PACK+f+'.gz')).toString('utf8');
const buf=f=>{const b=zlib.gunzipSync(fs.readFileSync(PACK+f+'.gz'));return b.buffer.slice(b.byteOffset,b.byteOffset+b.length)};
const M=require(path.resolve(ENG));const W=M.Sulekhak.create();
W.load({cfg:txt('cfg'),lex:txt('lex'),rom:txt('rom'),clus:txt('clus'),syl_uni:txt('syl_uni'),syl_bi:txt('syl_bi'),syl_chan:txt('syl_chan'),idx:buf('idx'),ng:[buf('ng')]});
W.engine.swipeWords=120000;
function h32(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0}return h}
const isTest=w=>h32('split|'+w)%5===0;
const D=JSON.parse(fs.readFileSync(DATA,'utf8'));
const ROWS=['qwertyuiop','asdfghjkl','zxcvbnm'],OFF=[0,0.5,1.5],ASP=D.meta.geoms,KC={};
const keyset=g=>KC[g]||(KC[g]=(()=>{const K={};ROWS.forEach((r,y)=>[...r].forEach((c,i)=>K[c]=[i+0.5+OFF[y],(y+0.5)*ASP[g]]));return K})());
const FE=W.engine.swipeFeatures;
const out=fs.openSync(OUT,'w');let n=0,withGold=0;
const SPL=opt('split','train');let G=D.gestures.filter(g=>SPL==='test'?isTest(g.word):!isTest(g.word));if(LIMIT)G=G.filter((g,i)=>i%Math.max(1,Math.floor(G.length/LIMIT))===0);if(STEP>1)G=G.filter((g,i)=>i%STEP===0);
for(const g of G){
  const gi=W.engine.wordIndex(g.word),dump={};
  W.engine.swipe({k:keyset(g.geom),p:g.pts},g.prev||'<s>',g.prev2||null,8,Object.assign({dump,goldIdx:gi,dumpN:60},EV));
  if(!dump.cands)continue;
  const rows=dump.cands.map(c=>[c.gold,...FE.map(k=>+(c.f[k]||0).toFixed(5))]);
  if(rows.some(r=>r[0]))withGold++;
  fs.writeSync(out,JSON.stringify({id:g.id,rows,ncand:dump.ncand})+'\n');n++;
}
fs.closeSync(out);console.error('gestures',n,'with gold in pool',withGold,'(recall',(100*withGold/n).toFixed(1)+'%)');
