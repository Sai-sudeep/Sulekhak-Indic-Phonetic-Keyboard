#!/usr/bin/env node
/* node run_eval.js --engine sulekhak9.js --pack /tmp/pack/compact --data dataset.json [--words 120000] [--opts '{"sch":0.12}'] [--out res.json] [--limit N] [--shard i/n]
   Prints and writes: top-1/3/5/8, MRR@8, word error rate (WER = 1 - top-1, i.e. the word the keyboard would auto-pick is wrong),
   WER@3 (gold not among the 3 chips), per-stratum tables, decode latency, and a failure report that separates
   "gold word never reached the candidate pool" from "reached it but ranked low". */
'use strict';
const fs=require('fs'),zlib=require('zlib');
const A=process.argv.slice(2),opt=(k,d)=>{const i=A.indexOf('--'+k);return i>=0?A[i+1]:d};
const ENG=opt('engine'),PACK=opt('pack','/tmp/pack/compact').replace(/\/?$/,'/'),DATA=opt('data','dataset.json'),WORDS=+opt('words',120000),OPTS=JSON.parse(opt('opts','{}')),OUT=opt('out',''),LIMIT=+opt('limit',0);
const SPLIT=opt('split','all');
const ASSERT=opt('assert','');   /* e.g. --assert top1>=72,top3>=85,p95<=300 : exit 1 when a measured number is outside the bound (regression guard in CI) */
function h32(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0}return h}
const inSplit=w=>SPLIT==='all'||((h32('split|'+w)%5===0)===(SPLIT==='test'));   /* hold out 1/5 of the WORD TYPES: test words are never seen in fitting */
const SHARD=(opt('shard','0/1')).split('/').map(Number);
const full=PACK.includes('model');
const txt=f=>zlib.gunzipSync(fs.readFileSync(PACK+f+'.gz')).toString('utf8');
const buf=f=>{const b=zlib.gunzipSync(fs.readFileSync(PACK+f+'.gz'));return b.buffer.slice(b.byteOffset,b.byteOffset+b.length)};
const M=require(require('path').resolve(ENG));const W=M.Sulekhak.create();
const P={cfg:txt('cfg'),lex:txt('lex'),rom:txt('rom'),clus:txt('clus'),syl_uni:txt('syl_uni'),syl_bi:txt('syl_bi'),syl_chan:txt('syl_chan'),idx:buf('idx')};
P.ng=full?[buf('ng_bi1'),buf('ng_bi2'),buf('ng_tri')]:[buf('ng')];
W.engine.swipeWords=WORDS;
const t0=Date.now();W.load(P);console.error('loaded',Date.now()-t0,'ms; words',W.size,'engine',ENG);
const D=JSON.parse(fs.readFileSync(DATA,'utf8'));
const ROWS=['qwertyuiop','asdfghjkl','zxcvbnm'],OFF=[0,0.5,1.5],ASP=D.meta.geoms;
const KC={};const keyset=g=>KC[g]||(KC[g]=(()=>{const K={};ROWS.forEach((r,y)=>[...r].forEach((c,i)=>K[c]=[i+0.5+OFF[y],(y+0.5)*ASP[g]]));return K})());
const strip=s=>s.replace(/‌/g,'');
function rankOf(list,w){for(let i=0;i<list.length;i++)if(list[i]===w)return i;const s=strip(w);for(let i=0;i<list.length;i++)if(strip(list[i])===s)return i;return -1}   /* ZWNJ-insensitive, as in the typing tests */
const NK=8;
const PERG=opt('perg','');const perg=[];
const buckets={};const lat=[];const fails=[];
function B(k){return buckets[k]||(buckets[k]={n:0,h1:0,h3:0,h5:0,h8:0,mrr:0,miss:0})}
function rec(k,r){const b=B(k);b.n++;if(r>=0){if(r<1)b.h1++;if(r<3)b.h3++;if(r<5)b.h5++;if(r<8)b.h8++;b.mrr+=1/(r+1)}else b.miss++}
let G=D.gestures;if(LIMIT)G=G.slice(0,LIMIT);
G=G.filter((g,i)=>i%SHARD[1]===SHARD[0]&&inSplit(g.word));
for(const g of G){
  const spec={k:keyset(g.geom),p:g.pts};
  W.engine.resetCache&&0;
  const prev=g.prev||'<s>';
  const s=process.hrtime.bigint();
  let out;
  try{out=W.engine.swipe(spec,prev,g.prev2||null,NK,OPTS)}catch(e){out=[];console.error('ERR',g.id,e.message)}
  lat.push(Number(process.hrtime.bigint()-s)/1e6);
  const list=out.map(x=>x[0]);const r=rankOf(list,g.word);
  if(PERG)perg.push([g.id,r]);
  const first=g.cats;
  rec('ALL',r);if(g.set==='text'&&g.profile==='normal'&&g.spell==='plain')rec('matched-geom='+g.geom,r);rec('set='+g.set,r);rec('profile='+g.profile,r);rec('geom='+g.geom,r);rec('spell='+g.spell,r);
  for(const c of first)rec('cat='+c,r);
  rec(g.set+'/'+g.profile+'/'+g.spell,r);
  if(r!==0)fails.push({id:g.id,word:g.word,roman:g.roman,rank:r,top:list.slice(0,3)});
}
lat.sort((a,b)=>a-b);const q=p=>lat[Math.min(lat.length-1,Math.floor(p*lat.length))];
const pc=(a,b)=>b?(100*a/b).toFixed(1):'-';
const rows=Object.keys(buckets).sort().map(k=>{const b=buckets[k];return {k,n:b.n,top1:+pc(b.h1,b.n),top3:+pc(b.h3,b.n),top5:+pc(b.h5,b.n),top8:+pc(b.h8,b.n),mrr:+(b.mrr/b.n).toFixed(3),wer1:+pc(b.n-b.h1,b.n),wer3:+pc(b.n-b.h3,b.n)}});
const res={engine:ENG,pack:full?'full':'compact',swipeWords:WORDS,opts:OPTS,n:G.length,latencyMs:{mean:+(lat.reduce((a,b)=>a+b,0)/lat.length).toFixed(1),p50:+q(0.5).toFixed(1),p95:+q(0.95).toFixed(1),max:+lat[lat.length-1].toFixed(1)},rows};
console.log(JSON.stringify(res.latencyMs));
for(const r of rows)if(/^(ALL|set=|profile=|geom=|spell=|cat=|matched-geom)/.test(r.k))console.log(r.k.padEnd(22),String(r.n).padStart(5),'top1',String(r.top1).padStart(5),'top3',String(r.top3).padStart(5),'top5',String(r.top5).padStart(5),'top8',String(r.top8).padStart(5),'MRR',r.mrr,'WER1',r.wer1);
if(PERG)fs.writeFileSync(PERG,JSON.stringify(perg));
if(OUT)fs.writeFileSync(OUT,JSON.stringify({...res,failures:fails.slice(0,400)}));
if(ASSERT){
  const all=rows.find(r=>r.k==='ALL'),m={top1:all.top1,top3:all.top3,top5:all.top5,top8:all.top8,mrr:all.mrr,wer1:all.wer1,p50:res.latencyMs.p50,p95:res.latencyMs.p95,mean:res.latencyMs.mean};
  let bad=0;
  for(const c of ASSERT.split(',')){const mm=/^(\w+)(>=|<=)([\d.]+)$/.exec(c.trim());if(!mm){console.error('bad --assert term',c);bad++;continue}
    const v=m[mm[1]],lim=+mm[3],ok=mm[2]==='>='?v>=lim:v<=lim;console.log((ok?'PASS ':'FAIL ')+mm[1]+' '+v+' '+mm[2]+' '+lim);if(!ok)bad++}
  if(bad)process.exit(1);
}
