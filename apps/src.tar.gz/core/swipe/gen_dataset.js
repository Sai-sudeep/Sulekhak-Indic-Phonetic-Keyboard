#!/usr/bin/env node
/* Sulekhak swipe evaluation set generator (deterministic).
   node gen_dataset.js --pack /path/to/compact --prompts prompts.json --out dataset.json [--lex-per-cat 120]
   Every gesture is a function of (generator version, id): re-running gives the same bytes.
   Gestures are SYNTHETIC (no recorded human swipes exist yet); see README.md for the model and its limits. */
'use strict';
const fs=require('fs'),zlib=require('zlib');
const A=process.argv.slice(2),opt=(k,d)=>{const i=A.indexOf('--'+k);return i>=0?A[i+1]:d};
const PACK=opt('pack','/tmp/pack/compact/'),PROMPTS=opt('prompts',''),OUT=opt('out','dataset.json'),PER=+opt('lex-per-cat',120);
const GEN_VERSION='sk-swipe-gen-3';
const gz=f=>zlib.gunzipSync(fs.readFileSync(PACK.replace(/\/?$/,'/')+f+'.gz')).toString('utf8');

/* ---------- seeded randomness: one independent stream per gesture ---------- */
function hash32(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0}return h}
function rng(seed){let a=seed>>>0;return()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
const gaussOf=r=>()=>{let u=r()||1e-9,v=r();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};

/* ---------- keyboard geometry (units: one key width; y scaled by the key aspect = key height / key width) ---------- */
const ROWS=['qwertyuiop','asdfghjkl','zxcvbnm'],OFF=[0,0.5,1.5];
const GEOMS={                                   /* name -> aspect (key height / width) */
  desktop:1.0,        /* on-screen keyboard of a laptop or the web typist on a computer */
  phonePortrait:1.35, /* 360-412 dp wide, keys about 36x48 dp */
  phoneLandscape:0.62,/* keys wide and short */
  tablet:1.0
};
function layout(geom){const asp=GEOMS[geom],K={};ROWS.forEach((r,y)=>[...r].forEach((c,i)=>K[c]=[i+0.5+OFF[y],(y+0.5)*asp]));return K}
const KCACHE={};const keys=g=>KCACHE[g]||(KCACHE[g]=layout(g));
function neighbours(K,c,rad){return Object.keys(K).filter(b=>b!==c&&Math.hypot(K[c][0]-K[b][0],K[c][1]-K[b][1])<rad)}

/* ---------- user profiles ----------
   drift:   AR(1) wander of the whole finger, in key widths (std of the innovation)
   jit:     independent per-sample jitter
   endOff:  how far the first and last touch land from the key centre
   cut:     0..1 corner cutting (1 = a smooth spline that skips the sharp turns at letters)
   stray:   chance, per letter and side, of brushing a neighbouring key on the way
   sub:     chance a letter is replaced by a neighbouring key
   speed:   keys per second
*/
const PROFILES={
  precise:{drift:0.03,jit:0.015,endOff:0.05,cut:0.0,stray:0,sub:0,speed:6},
  normal :{drift:0.05,jit:0.02,endOff:0.12,cut:0.35,stray:0,sub:0,speed:7},
  sloppy :{drift:0.09,jit:0.04,endOff:0.28,cut:0.6,stray:0,sub:0.04,speed:9},
  strayL :{drift:0.05,jit:0.02,endOff:0.15,cut:0.35,stray:0.22,sub:0.03,speed:7},
  strayM :{drift:0.06,jit:0.03,endOff:0.2,cut:0.4,stray:0.4,sub:0.08,speed:8},
  fast   :{drift:0.07,jit:0.03,endOff:0.22,cut:0.75,stray:0.1,sub:0.04,speed:13}
};

if(process.env.PROF_OVERRIDE){const o=JSON.parse(process.env.PROF_OVERRIDE);for(const k in o)Object.assign(PROFILES[k]||(PROFILES[k]={}),o[k])}
function spellOut(roman){return [...roman.toLowerCase()].filter(c=>/[a-z]/.test(c))}
function synthesize(roman,geom,prof,seedKey){
  const K=keys(geom),P=PROFILES[prof],r=rng(hash32(GEN_VERSION+'|'+seedKey)),g=gaussOf(r);
  let l0=spellOut(roman);if(l0.length<2)return null;
  const way=[];
  l0.forEach((c,i)=>{
    const edge=i===0||i===l0.length-1;let x=c;
    if(!edge&&r()<P.sub){const nb=neighbours(K,c,1.4);if(nb.length)x=nb[Math.floor(r()*nb.length)]}
    if(i>0&&r()<P.stray){const nb=neighbours(K,c,1.4);if(nb.length)way.push(nb[Math.floor(r()*nb.length)])}
    way.push(x);
    if(i<l0.length-1&&r()<P.stray){const nb=neighbours(K,c,1.4);if(nb.length)way.push(nb[Math.floor(r()*nb.length)])}
  });
  const w=[];for(const c of way)if(!w.length||w[w.length-1]!==c)w.push(c);
  if(w.length<2)return null;
  let pts=w.map(c=>[K[c][0],K[c][1]]);
  pts[0][0]+=g()*P.endOff;pts[0][1]+=g()*P.endOff*0.6;
  const L=pts.length-1;pts[L][0]+=g()*P.endOff;pts[L][1]+=g()*P.endOff*0.6;
  /* corner cutting: pull each interior waypoint towards the midpoint of its neighbours */
  /* corner cutting: at a sharp turn the finger rounds the corner, but never by more than a fraction of a key (cap = 0.7 * cut key widths) */
  if(P.cut>0){const q=pts.map(p=>p.slice());for(let i=1;i<L;i++){const mx=(pts[i-1][0]+pts[i+1][0])/2-pts[i][0],my=(pts[i-1][1]+pts[i+1][1])/2-pts[i][1],len=Math.hypot(mx,my);if(len>1e-6){const mv=Math.min(len*0.5,P.cut*0.7);q[i][0]+=mx/len*mv;q[i][1]+=my/len*mv}}pts=q}
  /* walk along the polyline at the profile's speed, slowing near the waypoints; sample at 60 Hz */
  const out=[];let t=0,seg=0,f=0,ox=0,oy=0;const dt=1000/60;
  out.push([pts[0][0],pts[0][1],0]);
  let guard=0;
  while(seg<L&&guard++<20000){
    const a=pts[seg],b=pts[seg+1],d=Math.hypot(b[0]-a[0],b[1]-a[1])||1e-6;
    const near=Math.min(f,1-f)*d;                        /* distance to the closest waypoint, in key widths */
    const slow=0.45+0.55*Math.min(1,near/0.6);
    const v=P.speed*slow*(1+0.15*g());
    f+=Math.max(0.01,v)*dt/1000/d;
    if(f>=1){seg++;f=0;if(seg>=L)break;continue}
    t+=dt;
    ox=ox*0.93+g()*P.drift*0.4;oy=oy*0.93+g()*P.drift*0.4;
    out.push([a[0]+(b[0]-a[0])*f+ox+g()*P.jit,a[1]+(b[1]-a[1])*f+oy+g()*P.jit,Math.round(t)]);
  }
  t+=dt;out.push([pts[L][0]+ox*0.5,pts[L][1]+oy*0.5,Math.round(t)]);
  return out.map(p=>[+p[0].toFixed(3),+p[1].toFixed(3),p[2]]);
}

/* ---------- the word lists ---------- */
const lex=gz('lex').split('\n').filter(Boolean).map(l=>{const t=l.indexOf('\t');return{w:l.slice(0,t),c:+l.slice(t+1)}});
const rom=gz('rom').split('\n').slice(0,lex.length).map(l=>l?l.split(' '):[]);
const plainOf=i=>(rom[i].find(a=>/^[a-z]+$/.test(a.replace(/~/g,'')))||'').replace(/~/g,'');
const altOf=(i,r)=>{const al=[...new Set(rom[i].map(a=>a.replace(/~/g,'')).filter(a=>/^[a-z]{2,}$/.test(a)))];const o=al.filter(a=>a!==plainOf(i));return o.length?o[Math.floor(r()*o.length)]:null};
const dropA=a=>a.charAt(0)+a.slice(1,-1).replace(/a/g,'')+a.charAt(a.length-1);
const cat=w=>{const c=[];if(/ଁ/.test(w))c.push('chandrabindu');if(/‌/.test(w))c.push('zwnj');if(/(ଡ଼|ଢ଼|ଡ଼|ଢ଼)/.test(w))c.push('nukta');if(/ୟ/.test(w))c.push('ya-nukta');if(/ୱ/.test(w))c.push('wa');if(/୍/.test(w))c.push('conjunct');return c.length?c:['plain']};

const G=[];let n=0;
function add(set,w,roman,spell,prof,geom,prev,prev2,i,cats){
  const id=`${set}:${i}:${spell}:${prof}:${geom}`;
  const pts=synthesize(roman,geom,prof,id);if(!pts)return;
  G.push({id,set,word:w,roman,spell,profile:prof,geom,prev,prev2,cats,pts});
}
/* A. running text: real sentences, real context, the user's own spelling next to the canonical one */
if(PROMPTS){
  const pr=JSON.parse(fs.readFileSync(PROMPTS,'utf8'));let k=0;
  for(const s of pr){let p1='<s>',p2=null;
    for(let i=0;i<s.words.length;i++,k++){
      const w=s.words[i],cs=cat(w);
      const pl=s.plain[i].replace(/[^a-zA-Z]/g,''),ty=s.typed[i].replace(/[^a-zA-Z]/g,'');
      for(const prof of ['precise','normal','sloppy','strayL','strayM','fast']){
        add('text',w,pl,'plain',prof,'phonePortrait',p1,p2,k,cs);
        if(ty&&ty.toLowerCase()!==pl.toLowerCase())add('text',w,ty,'typed',prof,'phonePortrait',p1,p2,k,cs);
      }
      add('text',w,pl,'plain','normal','phoneLandscape',p1,p2,k,cs);
      add('text',w,pl,'plain','normal','desktop',p1,p2,k,cs);
      p2=p1===('<s>')?null:p1;p1=w;
    }}
}
/* B. orthographic strata drawn from the word list (frequency-weighted, no context) */
{
  const r=rng(hash32(GEN_VERSION+'|strata'));
  const top=Math.min(lex.length,120000);
  const cum=new Float64Array(top);let s=0;for(let i=0;i<top;i++){s+=lex[i].c;cum[i]=s}
  const strata={};
  const pickIdx=()=>{const x=r()*s;let lo=0,hi=top-1;while(lo<hi){const m=(lo+hi)>>1;if(cum[m]<x)lo=m+1;else hi=m}return lo};
  for(let tries=0;tries<4000000;tries++){
    const i=pickIdx(),w=lex[i].w;if(!plainOf(i))continue;
    for(const c of cat(w)){strata[c]=strata[c]||new Set();if(strata[c].size<PER)strata[c].add(i)}
    if(['plain','conjunct','chandrabindu','zwnj','nukta','ya-nukta','wa'].every(c=>strata[c]&&strata[c].size>=(c==='zwnj'||c==='wa'||c==='nukta'?Math.min(PER,60):PER)))break;
  }
  /* rare strata (zwnj, nukta, wa) are scanned exhaustively so they are not empty */
  for(let i=0;i<top;i++){const w=lex[i].w;for(const c of ['zwnj','nukta','wa','chandrabindu']){if(cat(w).includes(c)){strata[c]=strata[c]||new Set();if(strata[c].size<PER&&plainOf(i))strata[c].add(i)}}}
  for(const c in strata){
    for(const i of strata[c]){
      const w=lex[i].w,rr=rng(hash32('alt'+i));
      for(const prof of ['normal','strayL','sloppy']){
        add('strata',w,plainOf(i),'plain',prof,'phonePortrait','<s>',null,i,cat(w));
      }
      const alt=altOf(i,rr);if(alt)add('strata',w,alt,'alt','normal','phonePortrait','<s>',null,i,cat(w));
      const da=dropA(plainOf(i));if(da!==plainOf(i)&&da.length>=2)add('strata',w,da,'schwa','normal','phonePortrait','<s>',null,i,cat(w));
    }
  }
}
fs.writeFileSync(OUT,JSON.stringify({meta:{generator:GEN_VERSION,geoms:GEOMS,profiles:PROFILES,n:G.length},gestures:G}));
const by={};for(const g of G){const k=g.set+'/'+g.profile;by[k]=(by[k]||0)+1}
console.error('wrote',OUT,'gestures',G.length,JSON.stringify(by));
