// Odia apostrophe words: the apostrophe spelling sits next to the plain one, and short head words offer their phrases.
// run:  node core/odia/apos_test.js   (from the repository root)
const E = require('../../shared/engine.js'); E.loadBuiltin();
let bad = 0;
function want(roman, items, adj) {
  const c = E.candidates(roman);
  for (const it of items) if (c.indexOf(it) < 0) { console.log('FAIL', roman, 'is missing', it); bad++; }
  if (adj) { const i = c.indexOf(adj[0]), j = c.indexOf(adj[1]); if (i < 0 || j < 0 || Math.abs(i - j) !== 1) { console.log('FAIL', roman, 'not next to each other:', adj.join(' / ')); bad++; } }
}
want('tara', ["ତା'ର", 'ତାର']); want('taaku', ["ତା'କୁ", 'ତାକୁ'], ['ତାକୁ', "ତା'କୁ"]);
want('toku', ["ତୋ'କୁ", 'ତୋକୁ'], ['ତୋକୁ', "ତୋ'କୁ"]); want('tora', ["ତୋ'ର", 'ତୋର']);
want('kana', ["କ'ଣ", 'କଣ', "କ'ଣ ପାଇଁ", 'କଣ ପାଇଁ', "କ'ଣ କଲୁ", "କ'ଣ ହେଲା", "କ'ଣ କରିବି", "କ'ଣ ହୋଇଛି", "କ'ଣ କହିଲ", "କ'ଣ ଦରକାର", "କ'ଣ ଜାଣିଛ", "କ'ଣ ହେବ"]);
want('ta', ["ତା'", 'ତା', "ତା' ପାଇଁ", 'ତା ପାଇଁ', "ତା' ଠାରୁ", "ତା' ପାଖରେ", "ତା' ସହିତ", "ତା' ଦ୍ୱାରା", "ତା' ନିକଟରେ", "ତା' ଭଳି", "ତା' ପରି", "ତା' ବିନା", "ତା' ନାମରେ", "ତା' ଉପରେ", "ତା' ତଳେ", "ତା' ଆଗରେ", "ତା' ପଛରେ", "ତା' ଭିତରେ", "ତା' ପରେ", "ତା' ପୂର୍ବରୁ", "ତା' ସତ୍ତ୍ୱେ", "ତା' ବଦଳରେ", "ତା' ଅନୁସାରେ", "ତା' ଫଳରେ", "ତା' ସଙ୍ଗେ", "ତା' ଆଗରୁ", "ତା' ସହ"]);
want('to', ["ତୋ'", "ତୋ' ପାଇଁ", "ତୋ' ଠାରୁ", "ତୋ' ପାଖରେ", "ତୋ' ସହିତ", "ତୋ' ଭଳି", "ତୋ' ବିନା"]);
want('ma', ["ମା'", 'ମା', "ମା' ପାଖକୁ", "ମା' ପାଇଁ", "ମା' ବାପା", "ମା' ପୁଅ", "ମା' ଝିଅ", "ମା' ପାଖରେ"]);
want('maara', ["ମା'ର", 'ମାର'], ['ମାର', "ମା'ର"]); want('maaku', ["ମା'କୁ", 'ମାକୁ'], ['ମାକୁ', "ମା'କୁ"]);
want('maangkara', ["ମା'ଙ୍କର", 'ମାଙ୍କର'], ['ମାଙ୍କର', "ମା'ଙ୍କର"]); want('maangku', ["ମା'ଙ୍କୁ", 'ମାଙ୍କୁ']);
want('tahele', ["ତା'ହେଲେ", 'ତାହେଲେ'], ['ତାହେଲେ', "ତା'ହେଲେ"]); want('mor', ["ମୋ'ର"]);
// nothing else grows an apostrophe
for (const r of ['kala', 'rama', 'bhala', 'namaskar']) if (E.candidates(r).some(x => x.indexOf("'") >= 0)) { console.log('FAIL', r, 'got an apostrophe form'); bad++; }
console.log(bad ? 'FAILED ' + bad : 'apostrophe tests passed'); process.exit(bad ? 1 : 0);
