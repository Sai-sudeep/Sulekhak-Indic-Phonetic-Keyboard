/* A tiny model of a host, used to test sequences of keys against the reference machine. The 'engine' is a stub: a word is shown as {buf}. */
'use strict';
var KM = require('./keymachine.js');
var TOK = { sp: 'space', ent: 'enter', esc: 'esc', bs: 'bksp', tab: 'tab', stab: 'shtab', up: 'up', dn: 'down', lt: 'left', rt: 'right', pgup: 'pgup', pgdn: 'pgdn', nav: 'nav', snav: 'selnav', chord: 'chord', cdisc: 'chordDiscard' };
function tokens(s) {
  var out = [], i = 0, m;
  while (i < s.length) {
    if (s[i] === '[' && (m = /^\[([a-z]+)\]/.exec(s.slice(i)))) { out.push({ cls: TOK[m[1]], tok: m[1] }); i += m[0].length; }
    else { var c = s[i]; out.push({ cls: KM.charClass(c), ch: c, tok: c }); i++; }
  }
  return out;
}
function defaultCands(buf) { var st = KM.stateOf(buf); return st === 'word' ? 5 : st === 'digits' ? 2 : st === 'sym' ? (buf === '*' ? 9 : 3) : st === 'dots' ? 3 : 0; }
function run(keys, opts) {
  opts = opts || {};
  var h = { buf: '', sel: 0, out: [] };
  function nC() { return opts.cands != null ? opts.cands : defaultCands(h.buf); }
  function key(k, state0) {
    var ctx = { buf: state0 === 'idle' ? '' : h.buf, nCands: nC(), sel: h.sel };
    var d = KM.decide(ctx, k);
    d.effects.forEach(function (e) {
      switch (e) {
        case 'start': h.buf = k.ch; h.sel = 0; break;
        case 'append': h.buf += k.ch; h.sel = 0; break;
        case 'commit': h.out.push('{' + h.buf + '}'); h.buf = ''; break;
        case 'commitAuto': h.out.push('{' + h.buf + '}_'); h.buf = ''; break;
        case 'commitSpace': h.out.push('{' + h.buf + '}␣'); h.buf = ''; break;
        case 'commitTyped': h.out.push('{' + h.buf + '}' + k.ch); h.buf = ''; break;
        case 'pick': h.out.push('{' + h.buf + '#' + k.ch + '}_'); h.buf = ''; break;
        case 'bksp': h.buf = h.buf.slice(0, -1); break;
        case 'discard': h.buf = ''; break;
        case 'nukta': h.out.push('<nukta>'); break;
        case 'delCodepoint': h.out.push('<del1>'); break;
        case 'candNext': h.out.push('<next>'); break;
        case 'candPrev': h.out.push('<prev>'); break;
        case 'pageNext': h.out.push('<pageNext>'); break;
        case 'pagePrev': h.out.push('<pagePrev>'); break;
        case 'swallow': break;
        case 'again': key(k, 'idle'); break;
        case 'pass': h.out.push('<pass:' + k.tok + '>'); break;
        default: throw new Error('effect ' + e);
      }
    });
  }
  tokens(keys).forEach(function (k) { key(k); });
  return h.out.join('') + (h.buf ? '«' + h.buf + '»' : '');
}
module.exports = { run: run, tokens: tokens };
