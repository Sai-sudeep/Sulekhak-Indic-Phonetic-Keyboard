/* Stand-alone > : put the nukta on the ଡ / ଢ of the word just typed. A faithful port of OdiaController.m nuktaBack: (macOS, the reference).
   Input: the text before the caret (only the last 14 code units are looked at) and the script (0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese).
   Output: null when there is no ଡ/ଢ to mark (the host then types a lone nukta), else {drop, text}: remove the last `drop` code units
   before the caret and type `text` in their place. */
'use strict';
function nrm(c) {
  if (c >= 0x0900 && c <= 0x097F && c !== 0x0964 && c !== 0x0965) return c + 0x200;
  if (c === 0x09F0) return 0x0B30;
  if (c === 0x09F1) return 0x0B71;
  if (c >= 0x0980 && c <= 0x09FF) return c + 0x180;
  return c;
}
function mark(c) { c = nrm(c); return (c >= 0x0B3E && c <= 0x0B44) || c === 0x0B47 || c === 0x0B48 || c === 0x0B4B || c === 0x0B4C || c === 0x0B56 || c === 0x0B57 || c === 0x0B62 || c === 0x0B63 || c === 0x0B3C || (c >= 0x0B01 && c <= 0x0B03) || c === 0x0B4D || c === 0x200C || c === 0x200D; }
function lett(c) { c = nrm(c); return (c >= 0x0B05 && c <= 0x0B39) || c === 0x0B5C || c === 0x0B5D || c === 0x0B5F || c === 0x0B60 || c === 0x0B61 || c === 0x0B71; }
function nuktaOf(script) { return String.fromCharCode(script === 1 ? 0x093C : (script === 2 || script === 5) ? 0x09BC : 0x0B3C); }
function nuktaEdit(before, script) {
  var len = before.length; if (len === 0) return null;
  var n = Math.min(14, len), s = before.slice(len - n), end = n, space = false, i, j, cs;
  var C = function (k) { return s.charCodeAt(k); };
  if (end >= 2 && C(end - 1) === 32 && (mark(C(end - 2)) || lett(C(end - 2)))) { space = true; end--; }
  i = end - 1;
  while (i > 0 && mark(C(i))) i--;
  if (i < 0 || !lett(C(i))) return null;
  cs = i;
  while (cs > 0 && nrm(C(cs - 1)) === 0x0B4D) { cs--; if (cs > 0 && lett(C(cs - 1))) cs--; else break; }
  var at = -1, nuk = nuktaOf(script);
  for (j = end - 1; j >= cs; j--) {
    var u = C(j);
    if ((nrm(u) === 0x0B21 || nrm(u) === 0x0B22) && !(j + 1 < end && nrm(C(j + 1)) === 0x0B3C)) { at = j + 1; nuk = String.fromCharCode(0x0B3C + (u - nrm(u))); break; }
  }
  if (at < 0) return null;
  var seg = s.slice(cs, end);
  seg = seg.slice(0, at - cs) + nuk + seg.slice(at - cs);
  if (space) seg += ' ';
  return { drop: n - cs, text: seg };
}
module.exports = { nuktaEdit: nuktaEdit };
