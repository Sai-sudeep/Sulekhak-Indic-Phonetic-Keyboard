'use strict';
var fs = require('fs'), path = require('path'), N = require('./nukta.js');
var V = JSON.parse(fs.readFileSync(path.join(__dirname, 'nukta_vectors.json'), 'utf8')), bad = 0;
V.forEach(function (v) { var g = N.nuktaEdit(v.before, v.script); if (JSON.stringify(g) !== JSON.stringify(v.expect)) { bad++; console.log('FAIL ' + v.before + ' ' + JSON.stringify(g) + ' != ' + JSON.stringify(v.expect)); } });
console.log((V.length - bad) + '/' + V.length + ' nukta vectors passed'); process.exit(bad ? 1 : 0);
