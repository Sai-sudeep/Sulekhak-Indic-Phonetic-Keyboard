/* Reference key machine for the Sulekhak desktop keyboards. It reads sulekhak-keymap.json (the single source of truth) and answers one
   question: given what is being typed (state) and a key (class), which effects happen? It has no knowledge of any operating system.
   Adapters (macOS, Windows) turn real key events into a class with classify(), call decide(), and carry out the effects.        */
'use strict';
var KM = (function () {
  var spec = null;
  function load(s) { spec = s; resolve(); return KM; }
  function resolve() {
    var t = spec.table;
    Object.keys(t).forEach(function (st) {
      var row = t[st];
      if (row.inherit) {
        var base = t[row.inherit], out = {};
        Object.keys(base).forEach(function (k) { out[k] = base[k]; });
        Object.keys(row).forEach(function (k) { if (k !== 'inherit') out[k] = row[k]; });
        t[st] = out;
      }
    });
  }
  /* The state of a buffer. */
  function stateOf(buf) {
    if (!buf) return 'idle';
    if (/^[0-9]+$/.test(buf)) return 'digits';
    if (/^\.+$/.test(buf)) return 'dots';
    if (buf === '|' || buf === '*') return 'sym';
    return 'word';
  }
  /* Class of a printable character (what the layout produced for the key, shift included). */
  function charClass(c) {
    if (c.length !== 1) return null;
    if (/[A-Za-z]/.test(c)) return 'letter';
    if (c === '`' || c === '~' || c === "'") return 'mark';
    if (c === '>') return 'gt';
    if (c === '0') return 'digit0';
    if (c >= '1' && c <= '9') return 'digit19';
    if (c === '.') return 'dot';
    if (c === '|') return 'bar';
    if (c === '*') return 'star';
    if (c.charCodeAt(0) > 32 && c.charCodeAt(0) !== 127) return 'punct';
    return null;
  }
  /* ctx: {buf, nCands, sel}. key: {cls, ch?} where digit classes carry ch. Returns {effects:[...], swallow:bool}. */
  function decide(ctx, key) {
    var st = stateOf(ctx.buf), cell = spec.table[st][key.cls];
    if (cell === undefined) throw new Error('no rule for ' + st + '/' + key.cls);
    var page = spec.pageSize;
    function cond(name) {
      if (name === 'multiPage') return Math.ceil(ctx.nCands / page) > 1;
      if (name === 'hasChoice') { var i = Math.floor(ctx.sel / page) * page + (key.ch.charCodeAt(0) - 49); return i < ctx.nCands; }
      throw new Error('condition ' + name);
    }
    var eff = Array.isArray(cell) ? cell : (cond(cell['if']) ? cell.then : cell['else']);
    return { state: st, effects: eff.slice(), swallow: eff.indexOf('pass') < 0 };
  }
  return { load: load, decide: decide, stateOf: stateOf, charClass: charClass, get spec() { return spec; } };
})();
if (typeof module !== 'undefined') module.exports = KM;
