'use strict';
var fs = require('fs'), path = require('path');
var KM = require('./keymachine.js'), sim = require('./sim.js');
KM.load(JSON.parse(fs.readFileSync(path.join(__dirname, 'sulekhak-keymap.json'), 'utf8')));
var V = JSON.parse(fs.readFileSync(path.join(__dirname, 'vectors.json'), 'utf8')), bad = 0, n = 0;
V.forEach(function (v) {
  if (v.skip) return; n++;
  var got = sim.run(v.keys, { cands: v.cands });
  if (got !== v.expect) { bad++; console.log('FAIL ' + JSON.stringify(v.keys) + (v.cands ? ' cands=' + v.cands : '') + '\n  expected ' + v.expect + '\n  got      ' + got); }
});
/* physical keys on a US layout: the scheme's keys must land in the class the table expects */
var us = KM.spec.physicalUS, want = { Backquote: ['mark', 'mark'], Quote: ['mark', 'punct'], Period: ['dot', 'gt'], Backslash: ['punct', 'bar'], Digit8: ['digit19', 'star'], Digit0: ['digit0', 'punct'], Digit1: ['digit19', 'punct'], Comma: ['punct', 'punct'], Semicolon: ['punct', 'punct'] };
Object.keys(want).forEach(function (k) { [0, 1].forEach(function (s) { n++; var c = KM.charClass(us[k][s]); if (c !== want[k][s]) { bad++; console.log('FAIL physical ' + k + (s ? '+Shift' : '') + ': ' + us[k][s] + ' is ' + c + ', expected ' + want[k][s]); } }); });
/* completeness: every state has a rule for every class */
var classes = Object.keys(KM.spec.classes);
Object.keys(KM.spec.table).forEach(function (st) { classes.forEach(function (c) { n++; if (KM.spec.table[st][c] === undefined) { bad++; console.log('FAIL missing rule ' + st + '/' + c); } }); });
console.log((n - bad) + '/' + n + ' passed');
process.exit(bad ? 1 : 0);
