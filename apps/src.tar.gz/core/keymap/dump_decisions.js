/* Writes every decision of the reference machine for a set of list sizes: other implementations must give the same answers.  node dump_decisions.js > decisions.txt */
'use strict';
var fs = require('fs'), path = require('path'), KM = require('./keymachine.js');
KM.load(JSON.parse(fs.readFileSync(path.join(__dirname, 'sulekhak-keymap.json'), 'utf8')));
var bufs = { idle: '', word: 'ba', digits: '5', dots: '..', sym: '|' };
var ctxs = [[5, 0, '3'], [12, 0, '3'], [2, 0, '5'], [12, 9, '5']];
var out = [];
Object.keys(bufs).forEach(function (st) {
  Object.keys(KM.spec.classes).forEach(function (cl) {
    ctxs.forEach(function (c) {
      var d = KM.decide({ buf: bufs[st], nCands: c[0], sel: c[1] }, { cls: cl, ch: c[2] });
      out.push([st, cl, c[0], c[1], c[2], d.effects.join(',')].join(' '));
    });
  });
});
process.stdout.write(out.join('\n') + '\n');
