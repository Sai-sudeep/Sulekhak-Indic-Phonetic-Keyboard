#!/bin/bash
# Install / upgrade test on an Android emulator.  Usage: upgrade_test.sh <old.apk> <new.apk> <other-key.apk>
#   old.apk        the previous release (lower versionCode, same signing key as the new one)
#   new.apk        the APK that will be shipped
#   other-key.apk  same package, HIGHER versionCode, signed with a different key (must be refused: proves the test can fail)
# Checks: in-place upgrade works; the app's private data survives; the keyboard stays switched on; a forged update is refused; a downgrade is refused.
set -u
OLD=$1; NEW=$2; OTHER=$3
PKG=com.saisudeep.sulekhak
fail=0
ok()  { echo "PASS  $*"; }
bad() { echo "FAIL  $*"; fail=1; }
vc()  { adb shell dumpsys package $PKG | grep -m1 -o 'versionCode=[0-9]*' | cut -d= -f2; }

adb wait-for-device
adb shell 'while [ "$(getprop sys.boot_completed)" != 1 ]; do sleep 2; done'
adb uninstall $PKG >/dev/null 2>&1

out=$(adb install "$OLD" 2>&1); echo "$out" | grep -q Success && ok "fresh install of the old release" || { bad "fresh install: $out"; exit 1; }
V1=$(vc)
# Android needs a few seconds to register a freshly installed keyboard: ask again for up to 60 s
ime_on() { for i in $(seq 1 20); do adb shell ime enable $PKG/.SulekhakIME >/dev/null 2>&1; adb shell ime list -s | grep -q "$PKG/.SulekhakIME" && return 0; sleep 3; done; return 1; }
ime_on && ok "keyboard is registered and switched on" || bad "keyboard not enabled after install"

# private data: the emulator image allows adb root; a marker inside the app's data directory stands for the user's learned words and settings
adb root >/dev/null 2>&1; sleep 3; adb wait-for-device
adb shell "mkdir -p /data/data/$PKG/files && echo keep-me > /data/data/$PKG/files/upgrade_marker" 
adb shell "test -f /data/data/$PKG/files/upgrade_marker" && ok "marker written into the app's data" || bad "could not write the marker (adb root unavailable?)"

out=$(adb install -r "$NEW" 2>&1); echo "$out" | grep -q Success && ok "in-place upgrade over the old release" || bad "upgrade failed: $out"
V2=$(vc)
[ "${V2:-0}" -gt "${V1:-0}" ] && ok "versionCode went up ($V1 -> $V2)" || bad "versionCode did not go up ($V1 -> $V2)"
adb shell "test -f /data/data/$PKG/files/upgrade_marker" && ok "app data survived the upgrade" || bad "app data was lost in the upgrade"
sleep 3
adb shell ime list -s | grep -q "$PKG/.SulekhakIME" && ok "keyboard is still switched on after the upgrade" || bad "keyboard was switched off by the upgrade"

out=$(adb install -r "$OTHER" 2>&1); echo "$out" | grep -q "UPDATE_INCOMPATIBLE" && ok "an update signed with another key is refused (INSTALL_FAILED_UPDATE_INCOMPATIBLE)" || bad "forged update was not refused: $out"
adb shell "test -f /data/data/$PKG/files/upgrade_marker" && ok "data intact after the refused update" || bad "data lost after the refused update"

out=$(adb install -r "$OLD" 2>&1); echo "$out" | grep -q "VERSION_DOWNGRADE" && ok "a downgrade is refused by Android (expected; rollback = ship a newer versionCode)" || bad "downgrade result unexpected: $out"
[ "$(vc)" = "$V2" ] && ok "still on the upgraded version" || bad "version changed unexpectedly"

# clean uninstall leaves nothing registered
adb uninstall $PKG | grep -q Success && ok "uninstall" || bad "uninstall failed"
# Android drops the registration asynchronously after the package is removed (the input-method
# manager is notified by a broadcast), so poll for up to 60 s instead of reading it once.
gone=0
for i in $(seq 1 30); do
  adb wait-for-device >/dev/null 2>&1
  if ! adb shell ime list -s 2>/dev/null | grep -q "$PKG" && ! adb shell ime list -a 2>/dev/null | grep -q "$PKG/"; then gone=1; break; fi
  sleep 2
done
[ "$gone" = 1 ] && ok "keyboard registration removed by uninstall" || { adb shell ime list -a 2>&1 | grep -i sulekhak || true; bad "keyboard still registered after uninstall"; }
exit $fail
