#!/bin/bash
# Emulator checks for the personal build (no Google account needed). Usage: personal_smoke.sh <Sulekhak-Android.apk>
# Checks: the sign-in screen is shown; Google's answer (custom-scheme redirect) reaches the app and a wrong/forged answer is refused without a crash;
# the keyboard registers; the engine page loads with the sync glue and reports no script errors.
set -u
APK=$1; NEXT=${2:-}; PKG=com.saisudeep.sulekhak
fail=0
ok()  { echo "PASS  $*"; }
bad() { echo "FAIL  $*"; fail=1; }
ui()  {   # the setup page scrolls: dump at the top and after each scroll, so a control below the fold is still seen (uiautomator lists only what is on screen)
  local i; for i in 1 2 3 4; do
    for t in 1 2 3; do adb shell uiautomator dump /sdcard/ui.xml >/dev/null 2>&1 && break; sleep 2; done
    adb shell cat /sdcard/ui.xml; echo
    adb shell input swipe 540 1700 540 500 300 >/dev/null 2>&1; sleep 1
  done
  adb shell input swipe 540 500 540 1900 200 >/dev/null 2>&1; adb shell input swipe 540 500 540 1900 200 >/dev/null 2>&1; adb shell input swipe 540 500 540 1900 200 >/dev/null 2>&1
}

adb wait-for-device
adb shell 'while [ "$(getprop sys.boot_completed)" != 1 ]; do sleep 2; done'
adb uninstall $PKG >/dev/null 2>&1
adb logcat -c
out=$(adb install "$APK" 2>&1); echo "$out" | grep -q Success && ok "install" || { bad "install: $out"; exit 1; }

# 0. the English data and engine are inside the app
for f in assets/english.js assets/sulekhak/en/en_lex.txt assets/sulekhak/en/en_ng.txt assets/sulekhak/en/en_fix.txt; do
  unzip -l "$APK" | grep -q " $f\$" && ok "APK contains $f" || bad "APK is missing $f"
done

# 1. the redirect address of the Google client resolves to our activity
r=$(adb shell cmd package resolve-activity --brief -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d 'com.saisudeep.sulekhak:/oauth2redirect?code=x&state=y' 2>&1)
echo "$r" | grep -q "OAuthRedirectActivity" && ok "com.saisudeep.sulekhak:/oauth2redirect opens OAuthRedirectActivity" || bad "redirect not routed to the app: $r"
# nothing else (a browser, another app) may claim it
n=$(adb shell cmd package query-activities --brief -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d 'com.saisudeep.sulekhak:/oauth2redirect?code=x' 2>&1 | grep -c '/')
[ "$n" -le 1 ] && ok "only one app can receive the redirect" || bad "more than one app claims the redirect ($n)"

# 2. the app opens and offers sign-in
adb shell input keyevent KEYCODE_HOME >/dev/null 2>&1; sleep 1
echo "am start: $(adb shell am start -W -n $PKG/.SetupActivity 2>&1 | tr '\n' ' ')"; sleep 4
echo "resumed: $(adb shell dumpsys activity activities 2>/dev/null | grep -m2 -i 'mResumedActivity\|ResumedActivity' | tr '\n' ' ')"
x=$(ui)
echo "$x" | grep -q 'Sign in with Google' && ok "setup screen offers 'Sign in with Google'" || { bad "sign-in button not on screen"; echo "--- nodes seen:"; echo "$x" | grep -o 'class="[^"]*" package="[^"]*" content-desc="[^"]*"' | sort | uniq -c | head -20; echo "$x" | grep -o 'text="[^"]*"' | grep -v 'text=""' | sort -u | head -30; }
echo "$x" | grep -q 'Not signed in' && ok "status says not signed in" || bad "status text missing"

# 3. a forged answer (wrong state) and an error answer are refused, the app survives and still says 'not signed in'
adb shell am start -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d 'com.saisudeep.sulekhak:/oauth2redirect?code=forged&state=wrong' >/dev/null 2>&1; sleep 5
x=$(ui); echo "$x" | grep -q 'Not signed in' && ok "forged answer: still not signed in" || bad "forged answer changed the sign-in state"
adb shell am start -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d 'com.saisudeep.sulekhak:/oauth2redirect?error=access_denied' >/dev/null 2>&1; sleep 5
x=$(ui); echo "$x" | grep -q 'Not signed in' && ok "error answer: still not signed in" || bad "error answer changed the sign-in state"
adb shell run-as $PKG ls shared_prefs 2>/dev/null | grep -q sulekhak_google && adb shell run-as $PKG cat shared_prefs/sulekhak_google.xml | grep -q 'name="r"' && bad "a refresh token was stored after a forged answer" || ok "no token stored after forged / error answers"

# 4. keyboard + engine page
for i in $(seq 1 20); do adb shell ime enable $PKG/.SulekhakIME >/dev/null 2>&1; adb shell ime list -s | grep -q "$PKG/.SulekhakIME" && break; sleep 3; done
adb shell ime list -s | grep -q "$PKG/.SulekhakIME" && ok "keyboard registered" || bad "keyboard not registered"
adb shell settings put secure show_ime_with_hard_keyboard 1 >/dev/null 2>&1
adb shell ime set $PKG/.SulekhakIME >/dev/null 2>&1
adb shell am start -n $PKG/.SetupActivity >/dev/null 2>&1; sleep 3
# focus the test box (found on screen, not at a guessed position): the keyboard and its engine page start
adb shell input keyevent KEYCODE_HOME >/dev/null 2>&1; adb shell am start -n $PKG/.SetupActivity >/dev/null 2>&1; sleep 3
adb shell uiautomator dump /sdcard/ui.xml >/dev/null 2>&1
b=$(adb shell cat /sdcard/ui.xml | grep -o 'class="android.widget.EditText"[^>]*bounds="\[[0-9]*,[0-9]*\]\[[0-9]*,[0-9]*\]"' | grep -o '\[[0-9]*,[0-9]*\]\[[0-9]*,[0-9]*\]' | head -1)
if [ -n "$b" ]; then
  nums=$(echo "$b" | tr -c '0-9' ' '); set -- $nums; tx=$(( ($1 + $3) / 2 )); ty=$(( ($2 + $4) / 2 )); echo "test box at $tx,$ty"
  adb shell input tap $tx $ty; sleep 6
  adb shell dumpsys input_method 2>/dev/null | grep -q 'mInputShown=true' && ok "keyboard opened on the test box" || bad "keyboard did not open on the test box"
else bad "test box not found on screen"; fi
adb logcat -d > /tmp/log.txt
grep -q 'FATAL EXCEPTION' /tmp/log.txt && { grep -A12 'FATAL EXCEPTION' /tmp/log.txt | head -30; bad "the app crashed"; } || ok "no crash in the log"
if grep -E 'chromium.*(Uncaught|SyntaxError|ReferenceError|TypeError)' /tmp/log.txt | grep -qi -E 'ime|SKP|learning|drive|personal'; then grep -E 'chromium.*(Uncaught|SyntaxError|ReferenceError|TypeError)' /tmp/log.txt | head; bad "script error in the engine page"; else ok "no script error in the engine page"; fi

# 5. the update: the next build (same key, higher version) installs over this one with no uninstall, and keeps the app's data
if [ -n "$NEXT" ]; then
  # a release APK is not debuggable, so run-as cannot reach its folder: use adb root (the emulator image allows it), like upgrade_test.sh
  adb root >/dev/null 2>&1; sleep 3; adb wait-for-device
  adb shell "mkdir -p /data/data/$PKG/files && echo kept > /data/data/$PKG/files/upgrade_marker" >/dev/null 2>&1
  adb shell "cat /data/data/$PKG/files/upgrade_marker" 2>/dev/null | grep -q kept && ok "marker written into the app's data" || bad "could not write the data marker (adb root unavailable?)"
  v0=$(adb shell dumpsys package $PKG | grep -m1 versionCode | tr -s ' ')
  out=$(adb install -r "$NEXT" 2>&1); echo "$out" | grep -q Success && ok "the next build installs over the installed one (adb install -r, no uninstall)" || bad "update refused: $out"
  v1=$(adb shell dumpsys package $PKG | grep -m1 versionCode | tr -s ' ')
  [ "$v0" != "$v1" ] && ok "version changed: $v0 -> $v1" || bad "version did not change ($v1)"
  adb shell "cat /data/data/$PKG/files/upgrade_marker" 2>/dev/null | grep -q kept && ok "app data survived the update" || bad "app data lost in the update"
  adb shell ime list -s | grep -q "$PKG/.SulekhakIME" && ok "keyboard still registered after the update" || bad "keyboard lost after the update"
fi
exit $fail
