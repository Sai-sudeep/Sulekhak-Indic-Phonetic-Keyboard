package com.saisudeep.sulekhak;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Opens the system screens needed to switch the keyboard on, and offers a box to try it. */
public class SetupActivity extends Activity {
    private TextView syncStatus;
    private Button syncIn, syncOut;
    private final GoogleAuth.Listener authListener = new GoogleAuth.Listener() { public void onChanged() { refreshSync(); } };

    private void refreshSync() {
        if (syncStatus == null) return;
        if (!GoogleAuth.configured()) return;
        boolean in = GoogleAuth.signedIn(this);
        String st = getSharedPreferences("sulekhak", Context.MODE_PRIVATE).getString("sync_state", "");
        String detail = st.contains("|") ? st.substring(st.indexOf('|') + 1) : "";
        String state = st.contains("|") ? st.substring(0, st.indexOf('|')) : st;
        String err = GoogleAuth.lastError();
        syncStatus.setText(in ? "Signed in as " + GoogleAuth.email(this) + "\n" + (state.isEmpty() ? "" : "Sync: " + state + (detail.isEmpty() ? "" : " (" + detail + ")"))
                              : "Not signed in. Your typing preferences are learned on this phone only until you sign in." + (err.isEmpty() ? "" : "\n" + err));
        syncIn.setVisibility(in ? android.view.View.GONE : android.view.View.VISIBLE);
        syncOut.setVisibility(in ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        GoogleAuth.onNativeResult(this, requestCode, resultCode == RESULT_OK ? data : null);
    }

    @Override
    protected void onResume() { super.onResume(); GoogleAuth.listen(authListener); refreshSync(); }

    @Override
    protected void onPause() { GoogleAuth.unlisten(authListener); super.onPause(); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (18 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText(getString(R.string.ime_name));
        title.setTextSize(24);
        title.setTextColor(0xFF1F2A44);
        root.addView(title);

        // Sync comes first: the help text below is long, and the sign-in button must be reachable without scrolling past it
        TextView syncTitle = new TextView(this);
        syncTitle.setText("Sync with Google");
        syncTitle.setTextSize(18);
        syncTitle.setTextColor(0xFF1F2A44);
        syncTitle.setPadding(0, pad, 0, pad / 4);
        if (GoogleAuth.configured()) root.addView(syncTitle);           // the public app has no Google sign-in at all: nothing about it is shown
        syncStatus = new TextView(this);
        syncStatus.setTextSize(14);
        syncStatus.setTextColor(0xFF333333);
        if (GoogleAuth.configured()) root.addView(syncStatus);
        syncIn = new Button(this);
        syncIn.setText("Sign in with Google");
        syncIn.setOnClickListener(new android.view.View.OnClickListener() { public void onClick(android.view.View v) { GoogleAuth.startSignIn(SetupActivity.this); } });
        if (GoogleAuth.configured()) root.addView(syncIn);
        syncOut = new Button(this);
        syncOut.setText("Sign out");
        syncOut.setOnClickListener(new android.view.View.OnClickListener() { public void onClick(android.view.View v) { GoogleAuth.signOut(SetupActivity.this); } });
        if (GoogleAuth.configured()) root.addView(syncOut);
        refreshSync();

        EditText test = new EditText(this);
        test.setHint("Try typing here");
        test.setMinLines(4);
        test.setTextSize(20);
        root.addView(test, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));


        TextView help = new TextView(this);
        help.setText("Type " + (BuildConfig.EDITION < 0 ? "Odia, Devanagari, Assamese and Bangla" : BuildConfig.EDITION_NAME) + " with Roman letters in any app.\n\n"
                + "1. Tap \"1. Enable keyboard\" and switch " + getString(R.string.ime_name) + " on.\n"
                + "2. Tap \"2. Choose keyboard\" and pick " + getString(R.string.ime_name) + ".\n"
                + "3. Try it in the box below. Type e.g. sarkar, birodh, shikhsa. The word list works offline; the first words may be plain until the smart suggestions finish loading (a few seconds).\n\n"
                + "Keys: Shift gives capitals (T, D, N for the retroflex sounds); Tab walks through the candidates. "
                + "Hold the full stop (.) or the grave key (`) for the halant, halant + ZWNJ, halant + ZWJ, ZWNJ and ZWJ (the full stop also has all the punctuation, including the apostrophe); slide to pick. "
                + "?123 opens symbols (long press: symbols, number pad, emoji); on that page the key named with the script's own first letter (\u0B05 / \u0905 / \u0985) opens a scrolling page of every vowel, sign and consonant of the script. "
                + "Slide on the space bar to move the cursor; the globe key or a long press on space switches keyboard. "
                + "At the top, the gear on the left opens the settings; the switch on the right " + (BuildConfig.EDITION < 0 ? "chooses the script (tap the script letter again to go on to the next script), English (A) or IPA." : "chooses " + BuildConfig.EDITION_NAME + ", English (A) or IPA.") + "\n\n"
                + "IPA typing: tap a key and the symbols that look like it (and, for vowels, the ones that share its place) appear above the keys; tap one to use it, or just keep typing to keep the letter. Hold any key to see them all. "
                + "Settings: 20 colours, bordered / unbordered / soft feathered keys, light or dark, and gesture typing (swipe across the letters; only dictionary words and parts of words are accepted).");
        help.setTextSize(15);
        help.setTextColor(0xFF333333);
        help.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(help);

        Button b1 = new Button(this);
        b1.setText("1. Enable keyboard");
        b1.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) { startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)); }
        });
        root.addView(b1);

        Button b2 = new Button(this);
        b2.setText("2. Choose keyboard");
        b2.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (m != null) m.showInputMethodPicker();
            }
        });
        root.addView(b2);



        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }
}
