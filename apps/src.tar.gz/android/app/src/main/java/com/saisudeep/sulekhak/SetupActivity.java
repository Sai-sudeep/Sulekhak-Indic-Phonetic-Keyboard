package com.saisudeep.sulekhak;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Opens the system screens needed to switch the keyboard on, and offers a box to try it. */
public class SetupActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (18 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText(getString(R.string.ime_name));
        title.setTextSize(24);
        title.setTextColor(0xFF1F2A44);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("Type " + (BuildConfig.EDITION < 0 ? "Odia, Devanagari, Assamese and Bangla" : BuildConfig.EDITION_NAME) + " with Roman letters in any app.\n\n"
                + "1. Tap \"1. Enable keyboard\" and switch " + getString(R.string.ime_name) + " on.\n"
                + "2. Tap \"2. Choose keyboard\" and pick " + getString(R.string.ime_name) + ".\n"
                + "3. Try it in the box below. Type e.g. sarkar, birodh, shikhsa. The word list works offline; the first words may be plain until the smart suggestions finish loading (a few seconds).\n\n"
                + "Keys: Shift gives capitals (T, D, N for the retroflex sounds); Tab walks through the candidates. "
                + "Hold the full stop (.) or the grave key (`) for the halant, halant + ZWNJ, halant + ZWJ, ZWNJ and ZWJ (the full stop also has all the punctuation, including the apostrophe); slide to pick. "
                + "?123 opens symbols (long press: symbols, number pad, emoji); on that page the key named with the script's own first letter (\u0B05 / \u0905 / \u0985) opens a scrolling page of every vowel, sign and consonant of the script. "
                + "Slide on the space bar to move the cursor; the globe key or a long press on space switches keyboard. "
                + "At the top, the gear on the left opens the settings; the switch on the right " + (BuildConfig.EDITION < 0 ? "chooses the script (tap the script letter again to go on to the next script), English (A) or IPA." : "chooses " + BuildConfig.EDITION_NAME + ", English (A) or IPA.") + "\n\n"
                + "IPA typing: tap a key and the symbols that look like it (and, for vowels, the ones that share its place) appear above the keys; tap one to use it, or just keep typing to keep the letter. Hold any key to see them all. "
                + "Settings: 20 colours, bordered / unbordered / soft feathered keys, light or dark, and gesture typing (swipe across the letters; only dictionary words and parts of words are accepted).");
        help.setTextSize(15);
        help.setTextColor(0xFF333333);
        help.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(help);

        Button b1 = new Button(this);
        b1.setText("1. Enable keyboard");
        b1.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) { startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)); }
        });
        root.addView(b1);

        Button b2 = new Button(this);
        b2.setText("2. Choose keyboard");
        b2.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (m != null) m.showInputMethodPicker();
            }
        });
        root.addView(b2);

        EditText test = new EditText(this);
        test.setHint("Try typing here");
        test.setMinLines(4);
        test.setTextSize(20);
        root.addView(test, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }
}
