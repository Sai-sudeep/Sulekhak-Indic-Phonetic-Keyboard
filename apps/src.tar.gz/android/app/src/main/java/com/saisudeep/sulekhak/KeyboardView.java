package com.saisudeep.sulekhak;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.SparseArray;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * The keyboard itself: one view that draws every key and handles every touch (several fingers at once), so typing never
 * waits for the layout system. Layers: letters, two symbol pages, number pad, emoji.
 * Long press on the full stop opens a hover-to-pick punctuation panel; long press on the ?123 key opens a hover-to-pick
 * panel switcher; the space bar slides the text cursor and a long press on it (or on the globe) opens the keyboard picker.
 */
public class KeyboardView extends View {
    public interface Host {
        void onKey(int code, String text);
        /** A swipe across the letters: the guesses at the Roman spelling, best first. */
        void onGesture(String[] variants);
    }

    // codes sent to the host
    public static final int K_LETTER = 1, K_ROMAN_SYM = 2, K_TEXT = 3, K_SPACE = 4, K_BACKSPACE = 5, K_ENTER = 6, K_TAB = 7,
            K_LEFT = 8, K_RIGHT = 9, K_GLOBE = 10, K_PICKER = 11, K_DIGITS = 12;
    // codes used inside the view
    private static final int V_SHIFT = 20, V_LAYER = 21, V_EMOJI_CAT = 22, V_SYM_PAGE = 23, V_DIGITSTYLE = 24;

    public static final int L_ABC = 0, L_SYM1 = 1, L_SYM2 = 2, L_NUM = 3, L_EMOJI = 4, L_ODIA = 5;

    private static final int S_LETTER = 0, S_FN = 1, S_ACCENT = 2, S_EMOJI = 3;

    private static final String[] EMOJI_TABS = {"😀", "👍", "❤️", "🐶", "🍔", "✈️"};
    private static final String[][] EMOJI = {
            ("😀 😃 😄 😁 😆 😅 😂 🤣 "
                    + "😊 😇 🙂 😉 😍 🥰 😘 😋 "
                    + "😎 🤔 😐 😴 😢 😭 😡 😱").split(" "),
            ("👍 👎 👌 ✌️ 🤞 🙏 👏 🙌 "
                    + "💪 👋 🤝 ☝️ 👆 👇 👈 👉 "
                    + "✋ 🤟 🤘 👊 ✊ 🤙 🖖 🙋").split(" "),
            ("❤️ 🧡 💛 💚 💙 💜 🖤 💔 "
                    + "💕 💖 💯 ✨ 🔥 ⭐ 🌟 🎉 "
                    + "🎊 ✅ ❌ ❗ ❓ ⚡ 💥 💫").split(" "),
            ("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 "
                    + "🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 "
                    + "🐦 🐢 🐍 🦋 🌸 🌹 🌻 🌳").split(" "),
            ("🍎 🍌 🍇 🍉 🍓 🍒 🥭 🍍 "
                    + "🍅 🥕 🌽 🍞 🧀 🍕 🍔 🍟 "
                    + "🍗 🍚 🍜 🍰 🍩 ☕ 🍵 🥤").split(" "),
            ("🚗 🚌 🚂 ✈️ 🚀 🏠 🏫 📱 "
                    + "💻 📚 ✏️ 📷 🎵 🎬 ⚽ 🏆 "
                    + "🎁 💡 🔑 ⏰ 📅 💰 🌍 🕉️").split(" ")
    };

    /** Punctuation panel (long press on the full stop). Last row is the one nearest the finger. */
    private static final String[] PUNCT = {
            "@", "#", "$", "%", "&", "*",
            "+", "=", "_", "(", ")", "/",
            ":", ";", "-", "।", "…", "~",
            "\"", "'", "!", "?", ",", "."
    };
    private static final int PUNCT_COLS = 6;

    /** Long press on a Roman letter: the Odia letters, signs and common conjuncts that belong to that key (generated from the same table as the web and desktop keyboards). */
    private static final java.util.HashMap<String, String[]> ALTS = new java.util.HashMap<>();
    static {
        put("'", "ଽ", "୰", "ୖ", "ୗ");
        put("a", "ଅ", "ଆ", "ା", "ଁ", "ଽ");
        put("b", "ବ", "ଭ", "ବ୍ୟ", "ବ୍ର", "ବ୍ଲ", "ଭ୍ର", "ଭ୍ୟ", "ବ୍ଦ", "ବ୍ଧ");
        put("c", "ଚ", "ଛ", "ଚ୍ଛ", "ଚ୍ଚ", "ଚ୍ୟ", "ଚ୍ର", "ଚ୍କ", "ଚ୍ଥ", "ଚ୍ପ");
        put("d", "ଦ", "ଧ", "ଡ", "ଢ", "ଦ୍ୱ", "ଦ୍ଧ", "ଦ୍ର", "ଦ୍ୟ", "ଧ୍ୟ", "ଡ୍ର", "ଦ୍ଦ");
        put("e", "ଏ", "ଐ", "େ", "ୈ");
        put("f", "ଫ", "ଫ୍ର", "ଫ୍ଲ", "ଫ୍ଟ", "ଫ୍ୟ", "ଫ୍ସ", "ଫ୍କ", "ଫ୍ତ");
        put("g", "ଗ", "ଘ", "ଙ", "ଙ୍କ", "ଙ୍ଗ", "ଗ୍ର", "ଗ୍ନ", "ଗ୍ୟ", "ଙ୍ଖ", "ଗ୍ଲ");
        put("h", "ହ", "ଃ", "ହ୍ମ", "ହ୍ନ", "ହ୍ୟ", "ହ୍ଲ", "ହ୍ୱ", "ହ୍ର");
        put("i", "ଇ", "ଈ", "ି", "ୀ");
        put("j", "ଜ", "ଝ", "ଞ", "ଯ", "ଞ୍ଚ", "ଞ୍ଜ", "ଜ୍ଞ", "ଜ୍ୟ", "ଜ୍ଜ", "ଜ୍ର", "ଯ୍ୟ");
        put("k", "କ", "ଖ", "କ୍ଷ", "କ୍ତ", "କ୍ର", "କ୍ସ", "କ୍ୟ", "କ୍ଟ", "ଖ୍ୟ");
        put("l", "ଲ", "ଳ", "ଌ", "ୢ", "ୡ", "ୣ", "ଲ୍ଲ", "ଲ୍ୟ", "ଳ୍ପ", "ଲ୍ର", "ଲ୍ଟ", "ଲ୍ସ");
        put("m", "ମ", "ଂ", "ଁ", "ଃ", "ମ୍ବ", "ମ୍ପ", "ମ୍ଭ", "ମ୍ୟ", "ମ୍ମ", "ମ୍ର");
        put("n", "ନ", "ଣ", "ଙ", "ଞ", "ଙ୍କ", "ନ୍ତ", "ଙ୍ଗ", "ଣ୍ଡ", "ନ୍ଦ", "ଣ୍ଟ", "ଞ୍ଚ");
        put("o", "ଓ", "ଔ", "ୋ", "ୌ");
        put("p", "ପ", "ଫ", "ପ୍ର", "ପ୍ତ", "ପ୍ଲ", "ଫ୍ର", "ପ୍ୟ", "ଫ୍ଲ", "ପ୍ଟ");
        put("q", "କ", "କ୍ଷ", "କ୍ତ", "କ୍ର", "କ୍ସ", "କ୍ୟ", "କ୍ଟ", "କ୍ଲ");
        put("r", "ର", "ଋ", "ୃ", "ୠ", "ୄ", "ର୍ମ", "ର୍ବ", "ର୍ଥ", "ର୍ଗ", "ର୍କ", "ର୍ଟ", "ର୍ଷ");
        put("s", "ସ", "ଶ", "ଷ", "ଷ୍ଟ", "ସ୍ତ", "ସ୍ଥ", "ସ୍ୱ", "ଶ୍ର", "ଶ୍ୱ", "ସ୍କ");
        put("t", "ତ", "ଥ", "ଟ", "ଠ", "ତ୍ର", "ତ୍ତ", "ତ୍ୟ", "ଟ୍ର", "ତ୍ୱ", "ତ୍ସ", "ତ୍ମ");
        put("u", "ଉ", "ଊ", "ୁ", "ୂ");
        put("v", "ଵ", "ବ", "ଭ", "ବ୍ୟ", "ବ୍ର", "ବ୍ଲ", "ଭ୍ର", "ଭ୍ୟ", "ବ୍ଦ", "ବ୍ଧ");
        put("w", "ୱ", "ଵ");
        put("x", "କ୍ଷ", "କ୍ଷ୍ମ", "କ୍ଷ୍ଣ", "କ୍ଷ୍ୟ");
        put("y", "ୟ", "ଯ", "ଯ୍ୟ");
        put("z", "\u200C", "\u200D", "୍", "୍\u200C", "୍\u200D");
    }
    private static void put(String key, String... items) { ALTS.put(key, items); }

    private static boolean isDependentSign(char c) {
        return (c >= 0x0B3E && c <= 0x0B4D) || c == 0x0B3C || (c >= 0x0B01 && c <= 0x0B03) || c == 0x0B44 || c == 0x0B56 || c == 0x0B57 || c == 0x0B62 || c == 0x0B63;
    }

    private static final class Key {
        String label = "", hint = "", text = "";
        int code, arg, style, longpress;     // longpress: 0 none, 1 punctuation panel, 2 layer panel, 3 keyboard picker, 4 letter list
        float w = 1f;
        boolean repeat, deferred, big, spacer, glow;
        String hintL = "";
        boolean down;
        final RectF cell = new RectF(), face = new RectF();
    }

    private static final class Touch {
        Key key;
        float sx, sy;
        int sent;
        boolean consumed, swiped, gesture;
        Runnable lp;
    }

    private static final class Popup {
        String[] items, vals;      // vals: what is typed when it differs from what is drawn (a dotted circle in front of a sign)
        int cols, rows, hover, def;
        float cell;
        final RectF rect = new RectF();
        int mode;                  // 1 punctuation, 2 layers, 3 letters of a key
        RectF anchor;
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private Host host;
    private final List<Key[]> rows = new ArrayList<>();
    private final SparseArray<Touch> touches = new SparseArray<>();
    private Popup pop;
    private int popId = -1;

    private int layer = L_ABC, shift = 0, emojiCat = 0;
    private boolean odiaMode = true, odiaDigits = false, night = false;
    private int script = 0;                    // 0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese: the letters on the keys are written in this script

    public void setScript(int sc) {
        script = (sc == 1 || sc == 2 || sc == 5) ? sc : 0;
        rebuild();
    }

    /** An Odia letter, sign or digit written in the chosen script (the three blocks line up; the few that do not are mapped by hand). Something the script does not have gives "". */
    private String sc(String o) {
        if (script == 0 || o == null) return o;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < o.length(); i++) {
            char c = o.charAt(i);
            int d = c;
            if (c >= 0x0B00 && c <= 0x0B7F) {
                if (script == 1) d = c - 0x200;
                else if (c == 0x0B30) d = script == 5 ? 0x09F0 : 0x09B0;
                else if (c == 0x0B35 || c == 0x0B71) d = script == 5 ? 0x09F1 : 0x09AC;
                else if (c == 0x0B33) d = 0x09B2;
                else d = c - 0x180;
                if (Character.getType(d) == Character.UNASSIGNED) return "";
            }
            b.append((char) d);
        }
        return b.toString();
    }
    private int digitBase() { return script == 1 ? 0x0966 : (script == 2 || script == 5) ? 0x09E6 : 0x0B66; }
    private static boolean isDependentAny(char c) {
        return isDependentSign(c) || (c >= 0x093E && c <= 0x094D) || (c >= 0x09BE && c <= 0x09CD) || c == 0x0901 || c == 0x0902 || c == 0x0903 || c == 0x093C || c == 0x09BC || c == 0x0981 || c == 0x0982 || c == 0x0983;
    }
    private String spaceLabel = "";
    private long lastShiftTap = 0;
    private float rowH, density;
    private int repId = -1;

    // theme
    private int cBg, cKey, cFn, cShadow, cText, cHint, cAccent, cAccentText, cPopup, cBar, cBorder, cZ, cZText;
    private int themeIdx = 0, keyStyle = 0;          // keyStyle: 0 bordered, 1 unbordered, 2 unbordered with soft feathered edges
    private boolean gestureOn = false;

    public static final String[] THEME_NAMES = {"Classic indigo", "Ocean", "Sky", "Cyan", "Teal", "Emerald", "Forest", "Lime", "Gold", "Orange",
            "Coral", "Crimson", "Rose", "Magenta", "Violet", "Lavender", "Plum", "Chocolate", "Slate", "Graphite"};
    public static final int[] THEME_ACCENT = {0xFF4F7BE8, 0xFF1E88E5, 0xFF29B6F6, 0xFF00ACC1, 0xFF00897B, 0xFF1FA463, 0xFF388E3C, 0xFF9CCC27, 0xFFF2B01E, 0xFFFB8C00,
            0xFFFF6F59, 0xFFD32F2F, 0xFFEC407A, 0xFFD81B8F, 0xFF7E57C2, 0xFFAB8CF0, 0xFF8E24AA, 0xFF8D6E63, 0xFF607D8B, 0xFF9E9E9E};

    // swipe typing
    private final ArrayList<float[]> trail = new ArrayList<>();      // x, y, time of the finger now swiping
    private final ArrayList<float[]> fading = new ArrayList<>();
    private long fadeStart = 0;
    private int gestId = -1;
    private long gestT0 = 0;
    private float gt() { return SystemClock.uptimeMillis() - gestT0; }

    private final Paint pFace = new Paint(Paint.ANTI_ALIAS_FLAG), pText = new Paint(Paint.ANTI_ALIAS_FLAG),
            pHint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Runnable repeater = new Runnable() {
        public void run() {
            Touch t = touches.get(repId);
            if (t == null || t.key == null || !t.key.repeat) return;
            if (host != null) host.onKey(t.key.code, t.key.text);
            h.postDelayed(this, 45);
        }
    };

    public KeyboardView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        pText.setTextAlign(Paint.Align.CENTER);
        pHint.setTextAlign(Paint.Align.RIGHT);
        setNight((c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        setHapticFeedbackEnabled(true);
        rebuild();
    }

    public void setHost(Host x) { host = x; }

    private float dp(float v) { return v * density; }

    // ------------------------------------------------------------------ state set by the host
    public void setNight(boolean n) { setLook(themeIdx, keyStyle, n); }

    /** theme: 0..19 (colour), style: 0 bordered, 1 unbordered, 2 unbordered with soft feathered edges. */
    public void setLook(int theme, int style, boolean n) {
        night = n;
        themeIdx = (theme < 0 || theme >= THEME_ACCENT.length) ? 0 : theme;
        keyStyle = (style < 0 || style > 2) ? 0 : style;
        float[] hsv = new float[3];
        int acc = THEME_ACCENT[themeIdx];
        Color.colorToHSV(acc, hsv);
        float h = hsv[0], sat = Math.min(1f, hsv[1] / 0.75f);
        if (themeIdx == 0) {                         // the original look, kept exactly
            if (n) {
                cBg = 0xFF1C2130; cKey = 0xFF343B54; cFn = 0xFF262D44; cShadow = 0xFF121624; cText = 0xFFEAEEFA; cHint = 0xFF9AA4C4;
                cAccent = 0xFF4F7BE8; cPopup = 0xFF3B4466; cBar = 0xFF262D44; cBorder = 0xFF5A6590;
            } else {
                cBg = 0xFFDFE3EC; cKey = 0xFFF6F7FB; cFn = 0xFFCDD3E1; cShadow = 0xFFB9BFD0; cText = 0xFF283044; cHint = 0xFF6B7490;
                cAccent = 0xFF3A63D0; cPopup = 0xFFFFFFFF; cBar = 0xFFD3D8E6; cBorder = 0xFF9AA3BE;
            }
        } else if (n) {
            cBg = hsv(h, 0.42f * sat, 0.15f); cKey = hsv(h, 0.30f * sat, 0.29f); cFn = hsv(h, 0.36f * sat, 0.21f); cShadow = hsv(h, 0.45f * sat, 0.08f);
            cText = hsv(h, 0.05f * sat, 0.96f); cHint = hsv(h, 0.22f * sat, 0.78f); cPopup = hsv(h, 0.30f * sat, 0.33f); cBar = hsv(h, 0.40f * sat, 0.20f);
            cBorder = hsv(h, 0.35f * sat, 0.52f);
            float v = Math.max(hsv[2], 0.62f);
            cAccent = hsv(h, hsv[1], v);
        } else {
            cBg = hsv(h, 0.13f * sat, 0.90f); cKey = hsv(h, 0.04f * sat, 0.99f); cFn = hsv(h, 0.16f * sat, 0.80f); cShadow = hsv(h, 0.22f * sat, 0.68f);
            cText = hsv(h, 0.45f * sat, 0.20f); cHint = hsv(h, 0.30f * sat, 0.42f); cPopup = 0xFFFFFFFF; cBar = hsv(h, 0.16f * sat, 0.84f);
            cBorder = hsv(h, 0.30f * sat, 0.62f);
            cAccent = hsv(h, hsv[1], Math.min(hsv[2], 0.86f));
        }
        cAccentText = luminance(cAccent) > 0.62 ? 0xFF1B1F2E : 0xFFFFFFFF;
        // the Z key: the colour opposite the theme, so it stands out as the special key
        cZ = hsv((h + 180f) % 360f, 0.82f, n ? 0.98f : 0.92f);
        cZText = luminance(cZ) > 0.5 ? 0xFF1B1F2E : 0xFFFFFFFF;
        invalidate();
    }

    private static int hsv(float h, float s, float v) {
        return Color.HSVToColor(new float[]{h, Math.max(0f, Math.min(1f, s)), Math.max(0f, Math.min(1f, v))});
    }

    private static double luminance(int c) {
        return (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
    }

    public int barColor() { return cBar; }
    public int textColor() { return cText; }
    public int hintColor() { return cHint; }
    public int accentColor() { return cAccent; }
    public int accentTextColor() { return cAccentText; }
    public int keyColor() { return cKey; }
    public int popupColor() { return cPopup; }
    public int zColor() { return cZ; }
    public boolean isNight() { return night; }
    public int themeIndex() { return themeIdx; }
    public int keyStyleIndex() { return keyStyle; }

    public void setGesture(boolean on) { gestureOn = on; }

    /** The height the keys take, so a panel shown in their place can be the same size. */
    public int preferredHeight() {
        boolean land = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        return (int) (dp(land ? 44 : 57) * 5 + dp(6));
    }

    public int bgColor() { return cBg; }

    public void setOdiaMode(boolean o) {
        odiaMode = o;
        rebuild();
    }

    public void setOdiaDigits(boolean o) {
        odiaDigits = o;
        rebuild();
    }

    public void setSpaceLabel(String s) {
        spaceLabel = s == null ? "" : s;
        rebuild();
    }

    public void setLayer(int l) {
        layer = l;
        shift = 0;
        dismissPopup();
        rebuild();
    }

    public void resetShift() {
        if (shift == 1) { shift = 0; rebuild(); }
    }

    // ------------------------------------------------------------------ layouts
    private Key key(String label, int code, String text, float w, int style) {
        Key k = new Key();
        k.label = label;
        k.code = code;
        k.text = text;
        k.w = w;
        k.style = style;
        return k;
    }

    private String digit(char d) {
        if (!odiaDigits) return String.valueOf(d);
        return String.valueOf((char) (digitBase() + (d - '0')));
    }

    private String otherDigit(char d) {
        if (odiaDigits) return String.valueOf(d);
        return String.valueOf((char) (digitBase() + (d - '0')));
    }

    private Key digitKey(char d) {
        Key k = key(digit(d), K_TEXT, digit(d), 1f, S_LETTER);
        if (odiaMode) k.hint = otherDigit(d);
        return k;
    }

    private Key[] digitRow() {
        Key[] r = new Key[10];
        for (int i = 0; i < 9; i++) r[i] = digitKey((char) ('1' + i));
        r[9] = digitKey('0');
        return r;
    }

    private String hintFor(String t) {
        if (!odiaMode) return "";
        if (t.equals("x")) return sc("କ୍ଷ");
        if (t.equals("R")) return sc("ଡ଼");
        if (t.equals("V")) return script == 0 ? "୵" : "";
        if (t.equals("M")) return "◌" + sc("ଂ");
        if (t.equals("H")) return "◌" + sc("ଃ");
        return "";
    }

    private Key letter(String c) {
        String s = shift > 0 ? c.toUpperCase() : c;
        Key k = key(s, K_LETTER, s, 1f, S_LETTER);
        k.hint = hintFor(s);
        if (odiaMode && c.equalsIgnoreCase("z")) k.glow = true;
        if (odiaMode && ALTS.containsKey(c.toLowerCase())) {     // a tap types the letter on release; holding opens the list of matras, rare letters and conjuncts
            k.deferred = true;
            k.longpress = 4;
        }
        return k;
    }

    private Key[] letters(String s) {
        Key[] r = new Key[s.length()];
        for (int i = 0; i < r.length; i++) r[i] = letter(s.substring(i, i + 1));
        return r;
    }

    private Key[] join(Key[]... parts) {
        int n = 0;
        for (Key[] p : parts) n += p.length;
        Key[] r = new Key[n];
        int i = 0;
        for (Key[] p : parts) for (Key k : p) r[i++] = k;
        return r;
    }

    private Key[] one(Key k) { return new Key[]{k}; }

    private Key spacerKey(float w) {
        Key k = key("", 0, "", w, S_LETTER);
        k.spacer = true;
        return k;
    }

    private Key tabKey(float w) {
        Key k = key("\u21E5", K_TAB, "", w, S_FN);
        k.big = true;
        return k;
    }

    private Key[] textRow(String[] items) {
        Key[] r = new Key[items.length];
        for (int i = 0; i < r.length; i++) r[i] = key(items[i], K_TEXT, items[i], 1f, S_LETTER);
        return r;
    }

    /** Odia letters and signs typed directly; dependent signs are shown on a dotted circle. */
    private Key[] odiaRow(String[] items, boolean dependent) {
        Key[] r = new Key[items.length];
        for (int i = 0; i < r.length; i++) {
            String it = sc(items[i]);
            r[i] = key(dependent ? "\u25CC" + it : it, K_TEXT, it, 1f, S_LETTER);
            r[i].big = true;
        }
        return r;
    }

    private Key backspace(float w) {
        Key k = key("⌫", K_BACKSPACE, "", w, S_FN);
        k.repeat = true;
        k.big = true;
        return k;
    }

    private Key enter() {
        Key k = key("↵", K_ENTER, "", 1.3f, S_ACCENT);
        k.big = true;
        return k;
    }

    private Key space(float w) {
        Key k = key(spaceLabel, K_SPACE, " ", w, S_LETTER);
        k.deferred = true;
        k.longpress = 3;
        return k;
    }

    private Key globe() {
        Key k = key("🌐", K_GLOBE, "", 1f, S_FN);
        k.deferred = true;
        k.longpress = 3;
        return k;
    }

    private Key layerKey(String label, int target, float w) {
        Key k = key(label, V_LAYER, "", w, S_FN);
        k.arg = target;
        k.deferred = true;
        return k;
    }

    private Key period() {
        Key k = key(".", K_ROMAN_SYM, ".", 1f, S_LETTER);
        k.deferred = true;
        k.longpress = 1;
        k.big = true;
        if (odiaMode) { k.hint = "।"; k.hintL = "'"; }
        return k;
    }

    private Key romanSym(String s, String hint) {
        Key k = key(s, K_ROMAN_SYM, s, 1f, S_LETTER);
        if (odiaMode) k.hint = hint;
        return k;
    }

    private Key[] bottomPanel() {
        Key sy = layerKey("#+=", L_SYM1, 1f);
        Key em = layerKey("😊", L_EMOJI, 1f);
        Key nm = layerKey("123", L_NUM, 1f);
        Key od = layerKey("\u0B05", L_ODIA, 1f);
        return join(one(layerKey("ABC", L_ABC, 1.3f)), one(globe()), one(sy), one(nm), one(em), one(od), one(space(2.2f)), one(period()), one(enter()));
    }

    private void rebuild() {
        rows.clear();
        if (layer == L_ABC) {
            rows.add(digitRow());
            rows.add(letters("qwertyuiop"));
            rows.add(join(one(spacerKey(0.5f)), letters("asdfghjkl"), one(spacerKey(0.5f))));
            Key sh = key(shift == 2 ? "\u21EA" : "\u21E7", V_SHIFT, "", 1.5f, shift > 0 ? S_ACCENT : S_FN);
            sh.big = true;
            rows.add(join(one(sh), letters("zxcvbnm"), one(backspace(1.5f))));
            Key q = layerKey("?123", L_SYM1, 1.2f);
            q.longpress = 2;
            Key en = enter();
            en.w = 1.3f;
            Key gl = globe();
            gl.w = 0.9f;
            Key[] sy4 = {romanSym("`", "\u25CC\u0B4D"), romanSym(">", "\u25CC\u0B3C"), romanSym("~", "\u25CC\u0B01")};
            for (Key k4 : sy4) k4.w = 0.85f;
            Key pd = period();
            pd.w = 0.85f;
            Key sp = space(2.75f);          // the apostrophe now lives under a long press on the full stop, so the space bar takes its width
            rows.add(join(one(q), one(gl), sy4, one(sp), one(pd), one(tabKey(1f)), one(en)));
        } else if (layer == L_SYM1 || layer == L_SYM2) {
            rows.add(digitRow());
            Key pg = key(layer == L_SYM1 ? "=\\<" : "?123", V_SYM_PAGE, "", 1.4f, S_FN);
            if (layer == L_SYM1) {
                rows.add(textRow(new String[]{"@", "#", "₹", "$", "%", "&", "-", "+", "(", ")"}));
                rows.add(join(one(pg), textRow(new String[]{"!", "?", "\"", "'", ":", ";", "/"}), one(backspace(1.4f))));
                rows.add(textRow(new String[]{"।", ",", ".", "…", "_", "*", "=", "^", "~", "|"}));
            } else {
                rows.add(textRow(new String[]{"~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆"}));
                rows.add(join(one(pg), textRow(new String[]{"£", "¢", "€", "¥", "°", "©", "®"}), one(backspace(1.4f))));
                rows.add(textRow(new String[]{"[", "]", "{", "}", "<", ">", "«", "»", "±", "§"}));
            }
            rows.add(bottomPanel());
        } else if (layer == L_ODIA) {
            rows.add(odiaRow(new String[]{"\u0B05", "\u0B06", "\u0B07", "\u0B08", "\u0B09", "\u0B0A", "\u0B0B", "\u0B0F", "\u0B10", "\u0B13"}, false));
            rows.add(odiaRow(new String[]{"\u0B3E", "\u0B3F", "\u0B40", "\u0B41", "\u0B42", "\u0B43", "\u0B47", "\u0B48", "\u0B4B", "\u0B4C"}, true));
            rows.add(odiaRow(new String[]{"\u0B14", "\u0B0C", "\u0B60", "\u0B61", "\u0B3D", "\u0B70", "\u0B56", "\u0B57"}, false));
            Key[] signs = odiaRow(new String[]{"\u0B44", "\u0B62", "\u0B63", "\u0B01", "\u0B02", "\u0B03", "\u0B3C", "\u0B4D"}, true);
            Key zwnj = key("ZWNJ", K_TEXT, "\u200C", 1.3f, S_FN);
            Key zwj = key("ZWJ", K_TEXT, "\u200D", 1.3f, S_FN);
            rows.add(join(signs, one(zwnj), one(zwj)));
            rows.add(bottomPanel());
        } else if (layer == L_NUM) {
            Key[] r0 = join(textRow(new String[]{"1", "2", "3"}), one(backspace(1f)));
            Key[] r1 = textRow(new String[]{"4", "5", "6", "."});
            Key[] r2 = textRow(new String[]{"7", "8", "9", ","});
            for (int i = 0; i < 3; i++) { r0[i].text = digit((char) ('1' + i)); r0[i].label = r0[i].text; }
            for (int i = 0; i < 3; i++) { r1[i].text = digit((char) ('4' + i)); r1[i].label = r1[i].text; }
            for (int i = 0; i < 3; i++) { r2[i].text = digit((char) ('7' + i)); r2[i].label = r2[i].text; }
            Key zero = key(digit('0'), K_TEXT, digit('0'), 1f, S_LETTER);
            Key style = key(odiaDigits ? sc("୧୨୩") : "123", V_DIGITSTYLE, "", 1f, S_FN);
            style.deferred = true;
            Key[] r3 = join(one(key("+", K_TEXT, "+", 1f, S_LETTER)), one(zero), one(key("-", K_TEXT, "-", 1f, S_LETTER)), one(style));
            for (Key[] r : new Key[][]{r0, r1, r2, r3}) for (Key k : r) k.big = true;
            rows.add(r0);
            rows.add(r1);
            rows.add(r2);
            rows.add(r3);
            Key sy = layerKey("#+=", L_SYM1, 1f);
            Key em = layerKey("😊", L_EMOJI, 1f);
            rows.add(join(one(layerKey("ABC", L_ABC, 1.3f)), one(globe()), one(sy), one(em), one(space(2.2f)), one(period()), one(enter())));
        } else {
            Key[] tabs = new Key[EMOJI_TABS.length];
            for (int i = 0; i < tabs.length; i++) {
                Key k = key(EMOJI_TABS[i], V_EMOJI_CAT, "", 1f, i == emojiCat ? S_ACCENT : S_FN);
                k.arg = i;
                k.deferred = true;
                tabs[i] = k;
            }
            rows.add(tabs);
            String[] set = EMOJI[emojiCat];
            for (int r = 0; r < 3; r++) {
                Key[] row = new Key[8];
                for (int c = 0; c < 8; c++) {
                    String e = set[r * 8 + c];
                    row[c] = key(e, K_TEXT, e, 1f, S_EMOJI);
                    row[c].big = true;
                }
                rows.add(row);
            }
            rows.add(join(one(layerKey("ABC", L_ABC, 1.3f)), one(globe()), one(layerKey("123", L_NUM, 1f)), one(space(2.2f)), one(period()), one(backspace(1.3f)), one(enter())));
        }
        layoutKeys(getWidth(), getHeight());
        invalidate();
    }

    private void layoutKeys(int w, int hh) {
        if (w <= 0 || hh <= 0 || rows.isEmpty()) return;
        float pad = dp(2), gx = dp(3), gy = dp(5);
        rowH = hh / (float) rows.size();
        for (int r = 0; r < rows.size(); r++) {
            Key[] row = rows.get(r);
            float tot = 0;
            for (Key k : row) tot += k.w;
            float x = pad, avail = w - 2 * pad, top = r * rowH;
            for (Key k : row) {
                float cw = avail * k.w / tot;
                k.cell.set(x, top, x + cw, top + rowH);
                k.face.set(x + gx / 2, top + gy / 2, x + cw - gx / 2, top + rowH - gy / 2);
                x += cw;
            }
        }
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(w, preferredHeight());
    }

    @Override
    protected void onSizeChanged(int w, int hh, int ow, int oh) {
        super.onSizeChanged(w, hh, ow, oh);
        layoutKeys(w, hh);
    }

    // ------------------------------------------------------------------ drawing
    private final Paint pFx = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path trailPath = new Path();
    private RectF glowRect = null;

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(cBg);
        glowRect = null;
        for (Key[] row : rows) for (Key k : row) drawKey(c, k);
        if (pop != null) drawPopup(c);
        drawTrail(c);
        if (!trail.isEmpty() || !fading.isEmpty()) postInvalidateDelayed(33);              // the swipe trail follows the finger and fades
        else if (glowRect != null) postInvalidateDelayed(33, (int) (glowRect.left - dp(10)), (int) (glowRect.top - dp(10)), (int) (glowRect.right + dp(10)), (int) (glowRect.bottom + dp(10)));   // the Z key shimmers
    }

    private void drawText(Canvas c, String s, float cx, float cy, float size) {
        pText.setTextSize(size);
        Paint.FontMetrics fm = pText.getFontMetrics();
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, pText);
    }

    private void drawKey(Canvas c, Key k) {
        if (k.spacer) return;
        float rad = dp(8);
        boolean emoji = k.style == S_EMOJI;
        int face = k.style == S_FN ? cFn : (k.style == S_ACCENT ? cAccent : cKey);
        int txt = k.style == S_ACCENT ? cAccentText : cText;
        if (k.glow) { face = cZ; txt = cZText; }
        if (k.down) { face = cAccent; txt = cAccentText; }
        if (!emoji || k.down) {
            if (keyStyle == 0) {                                   // bordered: a little shadow, the face and a thin outline
                if (!k.down) {
                    pFace.setColor(cShadow);
                    c.drawRoundRect(k.face.left, k.face.top + dp(1.5f), k.face.right, k.face.bottom + dp(1.5f), rad, rad, pFace);
                }
                pFace.setColor(face);
                c.drawRoundRect(k.face, rad, rad, pFace);
                if (!k.down) {
                    pFx.setStyle(Paint.Style.STROKE);
                    pFx.setStrokeWidth(dp(1.1f));
                    pFx.setColor(k.glow ? cZ : cBorder);
                    c.drawRoundRect(k.face.left + dp(0.5f), k.face.top + dp(0.5f), k.face.right - dp(0.5f), k.face.bottom - dp(0.5f), rad, rad, pFx);
                    pFx.setStyle(Paint.Style.FILL);
                }
            } else if (keyStyle == 1) {                            // unbordered: flat faces
                pFace.setColor(face);
                c.drawRoundRect(k.face, rad, rad, pFace);
            } else {                                               // soft: no edge at all, the face fades out towards its rim
                int steps = 5;
                float la = k.down ? 0.9f : (k.glow ? 0.5f : 0.30f);     // each layer is a little smaller than the one before, so the middle is solid and the rim fades out
                for (int i = 0; i < steps; i++) {
                    float g = dp(0.9f) * i;
                    pFace.setColor((face & 0x00FFFFFF) | (((int) (255 * la)) << 24));
                    c.drawRoundRect(k.face.left + g, k.face.top + g, k.face.right - g, k.face.bottom - g, Math.max(dp(3), rad - g * 0.5f), Math.max(dp(3), rad - g * 0.5f), pFace);
                }
            }
            if (k.glow && !k.down) drawGlow(c, k, rad);
        }
        pText.setColor(txt);
        float cx = k.face.centerX(), cy = k.face.centerY();
        float size;
        if (k.style == S_EMOJI) size = rowH * 0.52f;
        else if (k.big) size = rowH * (layer == L_NUM ? 0.46f : 0.40f);
        else if (k.label.length() > 1 && k.style != S_LETTER) size = rowH * 0.27f;
        else if (k.code == K_SPACE) size = rowH * 0.26f;
        else size = rowH * 0.40f;
        if (k.style == S_FN && k.label.length() >= 4) size = rowH * 0.25f;
        if (k.code == V_EMOJI_CAT) size = rowH * 0.42f;
        if (k.code == K_GLOBE || (k.code == V_LAYER && k.label.length() == 2)) size = rowH * 0.36f;
        if (k.code == K_SPACE) pText.setColor(k.down ? txt : cHint);
        drawText(c, k.label, cx, cy, size);
        if (!k.down) {
            if (k.hint.length() > 0) drawHint(c, k, k.hint, true);
            if (k.hintL.length() > 0) drawHint(c, k, k.hintL, false);
        }
    }

    /** A small label in the top corner of a key. It is shrunk to fit the key and left out when even that does not fit, so it never spills over the edge. */
    private void drawHint(Canvas c, Key k, String text, boolean right) {
        float size = rowH * 0.20f, room = k.face.width() - dp(8);
        pHint.setTextSize(size);
        float w = pHint.measureText(text);
        if (w > room) {
            size = size * room / w;
            if (size < rowH * 0.12f) return;
            pHint.setTextSize(size);
        }
        pHint.setColor(cHint);
        pHint.setTextAlign(right ? Paint.Align.RIGHT : Paint.Align.LEFT);
        c.drawText(text, right ? k.face.right - dp(4) : k.face.left + dp(4), k.face.top + rowH * 0.24f, pHint);
        pHint.setTextAlign(Paint.Align.RIGHT);
    }

    /** The Z key: a halo that breathes and a band of light that sweeps across it from left to right, then rests a moment. */
    private void drawGlow(Canvas c, Key k, float rad) {
        glowRect = k.face;
        long now = SystemClock.uptimeMillis();
        float breathe = 0.5f + 0.5f * (float) Math.sin(now / 420.0);
        pFx.setStyle(Paint.Style.STROKE);
        for (int i = 1; i <= 3; i++) {
            pFx.setStrokeWidth(dp(1.4f));
            int a = (int) ((70 - i * 18) * (0.55f + 0.45f * breathe));
            pFx.setColor((cZ & 0x00FFFFFF) | (Math.max(0, a) << 24));
            float g = dp(1.8f) * i;
            c.drawRoundRect(k.face.left - g, k.face.top - g, k.face.right + g, k.face.bottom + g, rad + g, rad + g, pFx);
        }
        pFx.setStyle(Paint.Style.FILL);
        long period = 2600, sweep = 1500;
        long t = now % period;
        if (t < sweep) {
            float p = t / (float) sweep;
            float bw = k.face.width() * 0.55f;
            float x0 = k.face.left - bw + p * (k.face.width() + bw * 2);
            c.save();
            Path clip = new Path();
            clip.addRoundRect(k.face, rad, rad, Path.Direction.CW);
            c.clipPath(clip);
            pFx.setShader(new LinearGradient(x0, k.face.top, x0 + bw, k.face.bottom, new int[]{0x00FFFFFF, 0xB3FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(k.face, pFx);
            pFx.setShader(null);
            c.restore();
        }
    }

    private void drawTrail(Canvas c) {
        ArrayList<float[]> pts = !trail.isEmpty() ? trail : fading;
        if (pts.size() < 2) return;
        int alpha = 0xC0;
        if (trail.isEmpty()) {
            long dt = SystemClock.uptimeMillis() - fadeStart;
            if (dt > 260) { fading.clear(); return; }
            alpha = (int) (0xC0 * (1f - dt / 260f));
        }
        trailPath.reset();
        trailPath.moveTo(pts.get(0)[0], pts.get(0)[1]);
        for (int i = 1; i < pts.size(); i++) trailPath.lineTo(pts.get(i)[0], pts.get(i)[1]);
        pFx.setStyle(Paint.Style.STROKE);
        pFx.setStrokeCap(Paint.Cap.ROUND);
        pFx.setStrokeJoin(Paint.Join.ROUND);
        pFx.setStrokeWidth(dp(9));
        pFx.setColor((cAccent & 0x00FFFFFF) | ((alpha / 3) << 24));
        c.drawPath(trailPath, pFx);
        pFx.setStrokeWidth(dp(4));
        pFx.setColor((cAccent & 0x00FFFFFF) | (alpha << 24));
        c.drawPath(trailPath, pFx);
        pFx.setStyle(Paint.Style.FILL);
    }

    private void drawPopup(Canvas c) {
        Popup p = pop;
        float rad = dp(10);
        pFace.setColor(0x33000000);
        c.drawRoundRect(p.rect.left, p.rect.top + dp(2), p.rect.right, p.rect.bottom + dp(2), rad, rad, pFace);
        pFace.setColor(cPopup);
        c.drawRoundRect(p.rect, rad, rad, pFace);
        for (int i = 0; i < p.items.length; i++) {
            int col = i % p.cols, row = i / p.cols;
            float l = p.rect.left + col * p.cell, t = p.rect.top + row * p.cell;
            if (i == p.hover) {
                pFace.setColor(cAccent);
                c.drawRoundRect(l + dp(2), t + dp(2), l + p.cell - dp(2), t + p.cell - dp(2), dp(8), dp(8), pFace);
                pText.setColor(cAccentText);
            } else {
                pText.setColor(cText);
            }
            drawText(c, p.items[i], l + p.cell / 2, t + p.cell / 2, p.cell * (p.items[i].length() > 2 ? 0.34f : 0.5f));
        }
    }

    // ------------------------------------------------------------------ touch
    private Key hit(float x, float y) {
        if (rows.isEmpty() || rowH <= 0) return null;
        int r = (int) (y / rowH);
        if (r < 0) r = 0;
        if (r >= rows.size()) r = rows.size() - 1;
        Key[] row = rows.get(r);
        for (int i = 0; i < row.length; i++) {
            Key k = row[i];
            if (x >= k.cell.left && x < k.cell.right) {
                if (!k.spacer) return k;
                if (i + 1 < row.length && !row[i + 1].spacer) return row[i + 1];
                if (i > 0 && !row[i - 1].spacer) return row[i - 1];
                return null;
            }
        }
        Key f = row[0].spacer && row.length > 1 ? row[1] : row[0];
        Key l = row[row.length - 1].spacer && row.length > 1 ? row[row.length - 2] : row[row.length - 1];
        return x < row[0].cell.left ? f : l;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked(), ai = e.getActionIndex();
        switch (a) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                down(e.getPointerId(ai), e.getX(ai), e.getY(ai));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) move(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                up(e.getPointerId(ai), e.getX(ai), e.getY(ai), false);
                break;
            case MotionEvent.ACTION_CANCEL:
                for (int i = touches.size() - 1; i >= 0; i--) up(touches.keyAt(i), 0, 0, true);
                break;
            default:
                break;
        }
        return true;
    }

    private void down(final int id, float x, float y) {
        if (pop != null) return;
        final Key k = hit(x, y);
        if (k == null) return;
        final Touch t = new Touch();
        t.key = k;
        t.sx = x;
        t.sy = y;
        touches.put(id, t);
        k.down = true;
        invalidate();
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (!k.deferred) {
            fire(k);
            if (k.repeat) {
                repId = id;
                h.removeCallbacks(repeater);
                h.postDelayed(repeater, 380);
            }
        } else if (k.longpress != 0) {
            t.lp = new Runnable() {
                public void run() { longPress(id, t); }
            };
            h.postDelayed(t.lp, k.code == K_SPACE ? 550 : 380);
        }
    }

    private void move(int id, float x, float y) {
        Touch t = touches.get(id);
        if (t == null) return;
        if (pop != null && popId == id) { updateHover(x, y); return; }
        if (t.gesture) {
            trail.add(new float[]{x, y, gt()});
            invalidate();
            return;
        }
        if (gestureOn && odiaMode && layer == L_ABC && pop == null && gestId < 0 && t.key.code == K_LETTER && !t.consumed
                && Math.hypot(x - t.sx, y - t.sy) > dp(26)) {          // a finger that slides across the letters is swipe typing, not a tap
            t.gesture = true;
            gestId = id;
            if (t.lp != null) { h.removeCallbacks(t.lp); t.lp = null; }
            t.key.down = false;
            trail.clear();
            fading.clear();
            gestT0 = SystemClock.uptimeMillis() - 30;
            trail.add(new float[]{t.sx, t.sy, 0});
            trail.add(new float[]{x, y, gt()});
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            invalidate();
            return;
        }
        if (t.key.code == K_SPACE && !t.consumed) {
            int steps = (int) ((x - t.sx) / dp(13));
            if (steps != t.sent) {
                if (!t.swiped) {
                    t.swiped = true;
                    if (t.lp != null) { h.removeCallbacks(t.lp); t.lp = null; }
                }
                int d = steps - t.sent;
                int n = Math.abs(d);
                for (int i = 0; i < n; i++) if (host != null) host.onKey(d > 0 ? K_RIGHT : K_LEFT, "");
                t.sent = steps;
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            }
        } else if (t.lp != null && Math.abs(x - t.sx) + Math.abs(y - t.sy) > dp(40)) {
            h.removeCallbacks(t.lp);
            t.lp = null;
            t.swiped = true;       // the finger slid away: it is not a tap on this key
        }
    }

    private void up(int id, float x, float y, boolean cancel) {
        Touch t = touches.get(id);
        if (t == null) return;
        touches.remove(id);
        if (t.lp != null) { h.removeCallbacks(t.lp); t.lp = null; }
        if (id == repId) { h.removeCallbacks(repeater); repId = -1; }
        t.key.down = false;
        if (t.gesture) {
            trail.add(new float[]{x, y, gt()});
            String[] v = cancel ? null : decodeGesture();
            fading.clear();
            fading.addAll(trail);
            fadeStart = SystemClock.uptimeMillis();
            trail.clear();
            gestId = -1;
            invalidate();
            if (v != null && v.length > 0 && host != null) host.onGesture(v);
            return;
        }
        if (pop != null && popId == id) {
            Popup p = pop;
            dismissPopup();
            if (!cancel && p.hover >= 0) perform(p, p.items[p.hover]);
            invalidate();
            return;
        }
        if (!cancel && t.key.deferred && !t.consumed && !t.swiped) {
            RectF r = new RectF(t.key.cell);
            r.inset(-dp(14), -dp(14));
            if (r.contains(x, y)) fire(t.key);
        }
        invalidate();
    }

    private void dismissPopup() {
        pop = null;
        popId = -1;
        invalidate();
    }

    private void longPress(int id, Touch t) {
        t.lp = null;
        t.consumed = true;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        Key k = t.key;
        if (k.longpress == 3) {
            if (host != null) host.onKey(K_PICKER, "");
            k.down = false;
            invalidate();
            return;
        }
        Popup p = new Popup();
        p.anchor = new RectF(k.face);
        if (k.longpress == 4) {
            String[] list0 = ALTS.get(k.text.toLowerCase());
            if (list0 == null) return;
            java.util.ArrayList<String> conv = new java.util.ArrayList<>();
            for (String x : list0) { String y = sc(x); if (y.length() > 0 || x.length() == 0) conv.add(y); }
            String[] list = conv.toArray(new String[0]);
            if (list.length == 0) return;
            p.mode = 3;
            p.vals = list;
            p.items = new String[list.length];
            for (int i = 0; i < list.length; i++) {
                String li = list[i];
                p.items[i] = li.equals("\u200C") ? "ZWNJ" : li.equals("\u200D") ? "ZWJ" : li.equals(sc("୍\u200C")) ? "\u25CC" + sc("୍") + " + \u250A" : li.equals(sc("୍\u200D")) ? "\u25CC" + sc("୍") + " + [" : (li.length() > 0 && isDependentAny(li.charAt(0)) ? "\u25CC" + li : li);
            }
            p.cols = list.length > 6 ? (list.length + 1) / 2 : list.length;
            p.cell = dp(46);
            p.def = 0;
        } else if (k.longpress == 1) {
            p.mode = 1;
            p.items = PUNCT;
            p.cols = PUNCT_COLS;
            p.cell = dp(44);
            p.def = PUNCT.length - 1;
        } else {
            p.mode = 2;
            p.items = new String[]{"?123", "123", "😊"};
            p.cols = 3;
            p.cell = dp(54);
            p.def = 0;
        }
        p.rows = (p.items.length + p.cols - 1) / p.cols;
        float w = p.cols * p.cell, hh = p.rows * p.cell;
        float left = k.longpress == 1 ? k.face.right - w : k.longpress == 4 ? k.face.centerX() - w / 2 : k.face.left;
        if (left + w > getWidth() - dp(2)) left = getWidth() - dp(2) - w;
        if (left < dp(2)) left = dp(2);
        float bottom = k.face.top - dp(4);
        float top = bottom - hh;
        if (top < 0) { top = dp(2); bottom = top + hh; }
        p.rect.set(left, top, left + w, top + hh);
        p.hover = p.def;
        pop = p;
        popId = id;
        invalidate();
    }

    private void updateHover(float x, float y) {
        Popup p = pop;
        int nh;
        if (p.rect.contains(x, y)) {
            int col = (int) ((x - p.rect.left) / p.cell), row = (int) ((y - p.rect.top) / p.cell);
            nh = row * p.cols + col;
            if (nh >= p.items.length) nh = -1;
        } else if (p.anchor.contains(x, y)) {
            nh = p.def;
        } else {
            nh = -1;
        }
        if (nh != p.hover) {
            p.hover = nh;
            if (nh >= 0) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            invalidate();
        }
    }

    private void perform(Popup p, String item) {
        if (p.mode == 3) {
            if (host != null) host.onKey(K_TEXT, p.vals[p.hover]);
            if (shift == 1) { shift = 0; rebuild(); }
        } else if (p.mode == 1) {
            if (host != null) host.onKey(item.equals(".") || item.equals("'") ? K_ROMAN_SYM : K_TEXT, item);
        } else {
            if (item.equals("?123")) setLayer(L_SYM1);
            else if (item.equals("123")) setLayer(L_NUM);
            else if (item.equals("\u0B05")) setLayer(L_ODIA);
            else setLayer(L_EMOJI);
        }
    }

    // ------------------------------------------------------------------ swipe typing
    private Key letterAt(float x, float y) {
        if (layer != L_ABC || rows.size() < 4) return null;
        for (int r = 1; r <= 3; r++) {
            Key[] row = rows.get(r);
            float top = r * rowH;
            if (y < top - rowH * 0.15f || y >= top + rowH * 1.15f) continue;
            if (y < top || y >= top + rowH) { if (Math.abs(y - (top + rowH / 2)) > rowH * 0.62f) continue; }
            for (Key k : row) {
                if (k.spacer || k.code != K_LETTER || k.text.length() != 1) continue;
                if (x >= k.cell.left && x < k.cell.right) return k;
            }
        }
        return null;
    }

    private static final class Visit {
        char ch;
        float t0, t1;
        boolean corner;
    }

    /**
     * Turns the finger's path into guesses at the Roman spelling. The letters under the path are collected in order; the ones the
     * finger started or ended on, turned at, or lingered on count as certain, the rest (the vowels it merely passed over, the
     * neighbours it brushed) as maybe. The guesses go from the certain letters alone up to everything passed over; the engine
     * (dictionary and word statistics) then picks the words that fit them.
     */
    private String[] decodeGesture() {
        int n = trail.size();
        if (n < 3) return null;
        // dense, evenly spaced points along the path
        ArrayList<float[]> P = new ArrayList<>();
        P.add(trail.get(0));
        for (int i = 1; i < n; i++) {
            float[] a = trail.get(i - 1), b = trail.get(i);
            float d = (float) Math.hypot(b[0] - a[0], b[1] - a[1]);
            int steps = Math.max(1, (int) (d / dp(5)));
            for (int s2 = 1; s2 <= steps; s2++) {
                float f = s2 / (float) steps;
                P.add(new float[]{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f});
            }
        }
        int m = P.size();
        // corners: where the direction changes sharply
        boolean[] corner = new boolean[m];
        int w = 4;                                  // 4 steps of about 5 dp each
        double best = 0;
        int bestI = -1;
        for (int i = w; i < m - w; i++) {
            double a1 = Math.atan2(P.get(i)[1] - P.get(i - w)[1], P.get(i)[0] - P.get(i - w)[0]);
            double a2 = Math.atan2(P.get(i + w)[1] - P.get(i)[1], P.get(i + w)[0] - P.get(i)[0]);
            double d = Math.abs(a2 - a1);
            if (d > Math.PI) d = 2 * Math.PI - d;
            if (d > 1.05) {                         // more than about 60 degrees
                if (d > best) { best = d; bestI = i; }
            } else if (bestI >= 0) {
                corner[bestI] = true;
                best = 0;
                bestI = -1;
            }
        }
        if (bestI >= 0) corner[bestI] = true;
        // the letters visited
        ArrayList<Visit> vs = new ArrayList<>();
        Visit cur = null;
        for (int i = 0; i < m; i++) {
            Key k = letterAt(P.get(i)[0], P.get(i)[1]);
            if (k == null) { if (corner[i] && cur != null) cur.corner = true; continue; }
            char ch = Character.toLowerCase(k.text.charAt(0));
            if (cur == null || cur.ch != ch) {
                cur = new Visit();
                cur.ch = ch;
                cur.t0 = P.get(i)[2];
                vs.add(cur);
            }
            cur.t1 = P.get(i)[2];
            if (corner[i]) cur.corner = true;
        }
        if (vs.isEmpty()) return null;
        vs.get(0).corner = true;
        vs.get(vs.size() - 1).corner = true;
        for (int i = 1; i < vs.size() - 1; i++) if (vs.get(i).t1 - vs.get(i).t0 > 150) vs.get(i).corner = true;      // lingered
        StringBuilder certain = new StringBuilder(), withVowels = new StringBuilder(), all = new StringBuilder(), nearly = new StringBuilder();
        for (int i = 0; i < vs.size(); i++) {
            Visit v = vs.get(i);
            boolean vowel = "aeiou".indexOf(v.ch) >= 0;
            all.append(v.ch);
            if (v.corner) certain.append(v.ch);
            if (v.corner || vowel) withVowels.append(v.ch);
            if (v.corner || vowel || (i > 0 && i < vs.size() - 1 && v.t1 - v.t0 > 70)) nearly.append(v.ch);
        }
        ArrayList<String> out = new ArrayList<>();
        String[] order = {withVowels.toString(), certain.toString(), nearly.toString(), all.toString()};
        for (String o : order) if (o.length() > 0 && !out.contains(o)) out.add(o);
        return out.toArray(new String[0]);
    }

    private void fire(Key k) {
        switch (k.code) {
            case V_SHIFT: {
                long now = SystemClock.uptimeMillis();
                if (shift == 1 && now - lastShiftTap < 380) shift = 2;
                else shift = (shift == 0) ? 1 : 0;
                lastShiftTap = now;
                rebuild();
                break;
            }
            case V_LAYER:
                setLayer(k.arg);
                break;
            case V_EMOJI_CAT:
                emojiCat = k.arg;
                rebuild();
                break;
            case V_SYM_PAGE:
                layer = (layer == L_SYM1) ? L_SYM2 : L_SYM1;
                rebuild();
                break;
            case V_DIGITSTYLE:
                odiaDigits = !odiaDigits;
                if (host != null) host.onKey(K_DIGITS, odiaDigits ? "odia" : "roman");
                rebuild();
                break;
            case K_LETTER:
                if (host != null) host.onKey(K_LETTER, k.text);
                if (shift == 1) { shift = 0; rebuild(); }
                break;
            default:
                if (host != null) host.onKey(k.code, k.text);
                break;
        }
    }
}
