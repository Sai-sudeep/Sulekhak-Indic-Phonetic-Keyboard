package com.saisudeep.sulekhak;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Sulekhak Odia phonetic keyboard. The language engine (the same JavaScript that runs in the web tool) lives in a hidden
 * WebView; this class is the input method: it keeps the Roman letters being typed, shows the Odia word being formed in the
 * text field, and offers the candidates in the strip above the keys.
 *
 * Nothing is drawn or sent to the text field until the engine has answered for the letters typed so far, so the word
 * never flashes between Roman and Odia; keys pressed meanwhile wait in a short queue and run in order.
 */
public class SulekhakIME extends InputMethodService implements KeyboardView.Host {
    static final String HOST = "appassets.androidplatform.net";
    static final int HIST_MAX = 800;
    static final int NCHIP = 16;

    private static final class Act {
        final boolean fresh;
        final Runnable run;
        Act(boolean f, Runnable r) { fresh = f; run = r; }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView web;
    private boolean ready = false;                  // smart engine loaded

    // what is being typed
    private final StringBuilder buf = new StringBuilder();
    private List<String> cands = new ArrayList<>();
    private String shownBuf = "";                   // the letters the shown candidates belong to
    private String prevCtx = "<s>";
    private List<String> nextList = new ArrayList<>();   // next-word suggestions shown while nothing is being typed
    private int nseq = 0;
    private int sel = 0, seq = 0, shownSeq = 0, composingLen = 0;
    private boolean autoSpace = false;               // the last thing typed was a word followed by our own space
    private long lastEdit = 0;
    private final List<Act> queue = new ArrayList<>();

    // mode
    private boolean odiaMode = true, forcedEn = false, numeric = false;
    private int script = 0;      // the script typed now: 0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese (an edition is fixed to its own, the all-in-one cycles through them)
    private static final int[] CYCLE = {0, 1, 5, 2};
    private static String scriptName(int sc) { return sc == 1 ? "Devanagari" : sc == 2 ? "Bangla" : sc == 5 ? "Assamese" : "Odia"; }
    private static String scriptNative(int sc) { return sc == 1 ? "हिन्दी" : sc == 2 ? "বাংলা" : sc == 5 ? "অসমীয়া" : "ଓଡ଼ିଆ"; }
    private static String scriptLetter(int sc) { return sc == 1 ? "अ" : sc == 2 ? "অ" : sc == 5 ? "অ" : "ଓ"; }

    private SharedPreferences prefs;
    private final List<String[]> hist = new ArrayList<>();

    // views
    private LinearLayout root, bar, candRow, modeBox;
    private HorizontalScrollView candScroll;
    private TextView segScript, segEn, hintView, romanLbl;
    private GearView gear;
    private ScrollView panel;
    private boolean settingsOpen = false, gestureOn = false, gestureBuf = false;
    private boolean autoSurround = true;           // select text, type ( [ { " ' ` or < and the selection is wrapped
    private static final String SURR_OPEN = "([{\"'`<";
    private static final String SURR_CLOSE = ")]}\"'`>";
    private int themeIdx = 0, keyStyle = 0, appearance = 0;     // appearance: 0 follow the phone, 1 light, 2 dark
    private final TextView[] chips = new TextView[NCHIP];
    private KeyboardView kb;
    private boolean night = false;
    private int cBar, cChipText, cChipDim, cSel, cSelText, cHint, cModeBg;

    // ------------------------------------------------------------------ engine (hidden WebView)
    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("sulekhak", Context.MODE_PRIVATE);
        odiaMode = prefs.getBoolean("odia_mode", true);
        script = BuildConfig.EDITION >= 0 ? BuildConfig.EDITION : prefs.getInt("script", 0);
        if (script != 0 && script != 1 && script != 2 && script != 5) script = 0;
        themeIdx = prefs.getInt("theme", 0);
        keyStyle = prefs.getInt("kstyle", 0);
        appearance = prefs.getInt("appearance", 0);
        gestureOn = prefs.getBoolean("gesture", false);
        autoSurround = prefs.getBoolean("autosurround", true);
        loadHistory();
        initWeb();
    }

    private void initWeb() {
        try {
            web = new WebView(this);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            web.addJavascriptInterface(new Bridge(), "Android");
            web.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                    return serve(r.getUrl() == null ? null : r.getUrl().getHost(), r.getUrl() == null ? null : r.getUrl().getPath());
                }

                @Override
                public void onPageFinished(WebView v, String url) {
                    sendReplay();
                }

                @Override
                public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                    ready = false;
                    try { web.destroy(); } catch (Exception ignored) { }
                    web = null;
                    handler.postDelayed(new Runnable() { public void run() { initWeb(); } }, 1000);
                    return true;
                }
            });
            web.loadUrl("https://" + HOST + "/ime.html");
        } catch (Throwable t) {
            web = null;     // no WebView on this device: the keyboard still types, only without suggestions
        }
    }

    private WebResourceResponse serve(String host, String path) {
        if (!HOST.equals(host) || path == null || path.length() < 2) return null;
        String p = path.substring(1);
        try {
            InputStream in = getAssets().open(p);
            String mime = p.endsWith(".html") ? "text/html" : (p.endsWith(".js") ? "text/javascript" : "text/plain");
            return new WebResourceResponse(mime, "utf-8", in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
        }
    }

    private void sendReplay() {
        if (web == null) return;
        try {
            JSONArray a = new JSONArray();
            for (String[] h : hist) { JSONArray p = new JSONArray(); p.put(h[0]); p.put(h[1]); a.put(p); }
            web.evaluateJavascript("imeSetScript(" + script + ",0)", null);
            web.evaluateJavascript("imeReplay(" + a.toString() + ")", null);
        } catch (Exception ignored) { }
    }

    public class Bridge {
        @JavascriptInterface
        public void post(final String s) {
            handler.post(new Runnable() { public void run() { onMsg(s); } });
        }
    }

    private void onMsg(String s) {
        try {
            JSONObject o = new JSONObject(s);
            String t = o.optString("t");
            if ("ready".equals(t)) {
                ready = true;
                renderBar();
            } else if ("n".equals(t)) {
                if (o.optInt("id", -1) != nseq || buf.length() != 0) return;
                JSONArray l = o.getJSONArray("list");
                List<String> n = new ArrayList<>();
                for (int i = 0; i < l.length() && i < NCHIP; i++) n.add(l.getString(i));
                nextList = n;
                renderBar();
            } else if ("c".equals(t)) {
                if (o.optInt("id", -1) != seq || buf.length() == 0) return;
                JSONArray l = o.getJSONArray("list");
                List<String> n = new ArrayList<>();
                for (int i = 0; i < l.length(); i++) n.add(l.getString(i));
                if (n.isEmpty()) n.add(buf.toString());
                cands = n;
                sel = 0;
                shownSeq = seq;
                shownBuf = buf.toString();
                updateComposing();
                renderBar();
                if (candScroll != null) candScroll.scrollTo(0, 0);
                drain();
            }
        } catch (Exception ignored) { }
    }

    private void query() {
        if (buf.length() == 0) { clearBuffer(); return; }
        seq++;
        if (web == null) {
            cands = new ArrayList<>();
            cands.add(buf.toString());
            sel = 0;
            shownSeq = seq;
            shownBuf = buf.toString();
            updateComposing();
            renderBar();
            return;
        }
        web.evaluateJavascript("imeQuery(" + seq + "," + JSONObject.quote(buf.toString()) + "," + JSONObject.quote(prevCtx) + ")", null);
    }

    /** Asks the engine which words usually follow `word`; the answer arrives as a "n" message and is shown as chips. */
    private void requestNext(String word) {
        nseq++;
        nextList = new ArrayList<>();
        if (web == null || !ready || !hasNonAscii(word) || word.length() < 2) return;
        web.evaluateJavascript("imeNext(" + nseq + "," + JSONObject.quote(word) + ")", null);
    }

    /** A next-word chip was tapped: put the word in with a space and look for the word after it. */
    private void pickNext(int idx) {
        if (idx < 0 || idx >= nextList.size()) return;
        String w = nextList.get(idx);
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(w + " ", 1);
        autoSpace = true;
        stamp();
        if (web != null) web.evaluateJavascript("imeCommit(\"\"," + JSONObject.quote(w) + ")", null);
        requestNext(w);
        renderBar();
    }

    /** The Odia word before the one being typed (for next-word statistics); "<s>" at the start of a sentence. */
    private String prevWord() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "<s>";
        CharSequence t = ic.getTextBeforeCursor(80, 0);
        if (t == null) return "<s>";
        String s = t.toString();
        int i = s.length() - 1;
        while (i >= 0 && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) i--;
        int e = i;
        while (i >= 0) {
            char c = s.charAt(i);
            boolean odia = (c >= 0x0B00 && c <= 0x0B7F && c != 0x0B64 && c != 0x0B65) || (c >= 0x0900 && c <= 0x097F && c != 0x0964 && c != 0x0965) || (c >= 0x0980 && c <= 0x09FF);
            if (odia || c == 0x200C || c == 0x200D) i--; else break;
        }
        if (e < 0 || i == e) return "<s>";
        return s.substring(i + 1, e + 1);
    }

    // ------------------------------------------------------------------ history (the memory cache)
    private void loadHistory() {
        hist.clear();
        String h = prefs.getString("hist", "");
        for (String line : h.split("\n")) {
            int p = line.indexOf('\t');
            if (p > 0 && p < line.length() - 1) hist.add(new String[]{line.substring(0, p), line.substring(p + 1)});
        }
    }

    private void remember(String roman, String word) {
        hist.add(new String[]{roman, word});
        while (hist.size() > HIST_MAX) hist.remove(0);
        StringBuilder sb = new StringBuilder();
        for (String[] h : hist) sb.append(h[0]).append('\t').append(h[1]).append('\n');
        prefs.edit().putString("hist", sb.toString()).apply();
        if (web != null) web.evaluateJavascript("imeCommit(" + JSONObject.quote(roman) + "," + JSONObject.quote(word) + ")", null);
    }

    // ------------------------------------------------------------------ small helpers
    private static boolean hasNonAscii(String s) {
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) > 127) return true;
        return false;
    }

    private static boolean wordContinues(String w) {
        if (w.isEmpty()) return true;
        char last = w.charAt(w.length() - 1);
        return last == 0x0B4D || last == 0x200C;
    }

    private static boolean isDots(CharSequence s) {
        if (s.length() == 0) return false;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) != '.') return false;
        return true;
    }

    private static boolean isDigits(String s) {
        if (s.length() == 0) return false;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) < '0' || s.charAt(i) > '9') return false;
        return true;
    }

    private static boolean isPunct(String t) {
        return t.length() == 1 && ",.;:!?।".indexOf(t.charAt(0)) >= 0;
    }

    private boolean effectiveOdia() { return odiaMode && !forcedEn && !numeric; }

    private void stamp() { lastEdit = SystemClock.uptimeMillis(); }

    // ------------------------------------------------------------------ the key queue
    private void act(boolean fresh, Runnable r) {
        if (!queue.isEmpty()) { queue.add(new Act(fresh, r)); return; }
        if (fresh && buf.length() > 0 && shownSeq != seq && web != null) {
            queue.add(new Act(fresh, r));
            handler.removeCallbacks(watchdog);
            handler.postDelayed(watchdog, 700);
            return;
        }
        r.run();
    }

    private void drain() {
        while (!queue.isEmpty()) {
            Act a = queue.get(0);
            if (a.fresh && buf.length() > 0 && shownSeq != seq && web != null) {
                handler.removeCallbacks(watchdog);
                handler.postDelayed(watchdog, 700);
                break;
            }
            queue.remove(0);
            a.run.run();
        }
    }

    private final Runnable watchdog = new Runnable() {
        public void run() {          // the engine did not answer in time: carry on with what is shown
            if (buf.length() > 0 && shownSeq != seq) {
                if (cands.isEmpty()) { cands = new ArrayList<>(); cands.add(buf.toString()); }
                shownSeq = seq;
                if (shownBuf.length() == 0) shownBuf = buf.toString();
                updateComposing();
                renderBar();
            }
            drain();
        }
    };

    // ------------------------------------------------------------------ typing logic
    private void updateComposing() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || cands.isEmpty()) return;
        String shown = cands.get(sel < cands.size() ? sel : 0);
        ic.setComposingText(shown, 1);
        composingLen = shown.length();
        stamp();
    }

    private void clearBuffer() {
        gestureBuf = false;
        buf.setLength(0);
        cands = new ArrayList<>();
        shownBuf = "";
        sel = 0;
        composingLen = 0;
        shownSeq = seq;
        renderBar();
    }

    private void finishComposing() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.finishComposingText();
        stamp();
    }

    private void commitCandidate(int idx, boolean space) {
        if (buf.length() == 0) return;
        String roman = shownBuf.length() > 0 ? shownBuf : buf.toString();
        String word = (idx >= 0 && idx < cands.size()) ? cands.get(idx) : roman;
        boolean sp = space && !wordContinues(word);
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(word + (sp ? " " : ""), 1);
        stamp();
        autoSpace = sp;
        if (!gestureBuf && idx != 1 && hasNonAscii(word) && !isDots(roman) && !isDigits(roman)) remember(roman, word);
        clearBuffer();
        if (sp) requestNext(word); else nextList = new ArrayList<>();
    }

    private void commitDirect(String t) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (autoSpace && isPunct(t)) {            // "word ." becomes "word." when the space was ours
            CharSequence b = ic.getTextBeforeCursor(1, 0);
            if (b != null && b.length() == 1 && b.charAt(0) == ' ') ic.deleteSurroundingText(1, 0);
        }
        ic.commitText(t, 1);
        autoSpace = false;
        nextList = new ArrayList<>();
        stamp();
        renderBar();
    }

    private void flushPending() {
        if (buf.length() > 0) commitCandidate(sel, false);
    }

    private void typeLetter(String ch) {
        if (!effectiveOdia()) { commitDirect(ch); return; }
        if (gestureBuf && buf.length() > 0) commitCandidate(sel, false);          // a swiped word is settled before letters are typed after it
        if (buf.length() > 0 && isDots(buf)) commitCandidate(sel, false);
        if (buf.length() == 0) { prevCtx = prevWord(); nextList = new ArrayList<>(); }
        buf.append(ch);
        autoSpace = false;
        query();
    }

    private void typeRomanSym(String s) {
        if (!effectiveOdia()) { commitDirect(s); return; }
        if (gestureBuf && buf.length() > 0) commitCandidate(sel, false);
        if (s.equals(".")) {
            if (buf.length() > 0 && isDots(buf)) { buf.append('.'); query(); return; }
            flushPending();
            InputConnection ic = getCurrentInputConnection();
            if (autoSpace && ic != null) {
                CharSequence b = ic.getTextBeforeCursor(1, 0);
                if (b != null && b.length() == 1 && b.charAt(0) == ' ') ic.deleteSurroundingText(1, 0);
            }
            autoSpace = false;
            prevCtx = prevWord();
            nextList = new ArrayList<>();
            buf.append('.');
            query();
            return;
        }
        if (s.equals(">") && buf.length() == 0) { commitDirect("଼"); return; }   // nukta after the letter before it
        if (buf.length() == 0) { prevCtx = prevWord(); nextList = new ArrayList<>(); }
        buf.append(s);
        autoSpace = false;
        query();
    }

    private void typeOther(String t) {
        flushPending();
        commitDirect(t);
    }

    private void doSpace() {
        if (buf.length() > 0) { commitCandidate(sel, true); return; }
        commitDirect(" ");
    }

    private void doBackspace() {
        InputConnection ic = getCurrentInputConnection();
        autoSpace = false;
        if (gestureBuf && buf.length() > 0) {            // a swiped word goes in one piece
            if (ic != null) { ic.setComposingText("", 1); ic.finishComposingText(); }
            stamp();
            clearBuffer();
            return;
        }
        if (buf.length() > 0) {
            buf.setLength(buf.length() - 1);
            if (buf.length() == 0) {
                if (ic != null) { ic.setComposingText("", 1); ic.finishComposingText(); }
                stamp();
                clearBuffer();
            } else {
                query();
            }
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
            stamp();
        }
    }

    private void doEnter() {
        flushPending();
        autoSpace = false;
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        int action = ei == null ? EditorInfo.IME_ACTION_NONE : (ei.imeOptions & EditorInfo.IME_MASK_ACTION);
        boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        if (ic != null && !multi && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
        stamp();
    }

    private void doTab() {
        if (buf.length() > 0 && cands.size() > 1) {      // Tab walks through the candidates, like on the web page
            sel = (sel + 1) % cands.size();
            updateComposing();
            renderBar();
            return;
        }
        flushPending();
        EditorInfo ei = getCurrentInputEditorInfo();
        boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        if (multi) commitDirect("\t");
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_TAB);
        stamp();
    }

    private void moveCursor(int dir) {
        flushPending();
        autoSpace = false;
        sendDownUpKeyEvents(dir < 0 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT);
        stamp();
    }

    /** The little toggle at the top: the script segment (a second tap there goes on to the next script in the all-in-one) or English. */
    private void setTyping(final boolean wantScript) {
        act(true, new Runnable() {
            public void run() {
                flushPending();
                if (wantScript) {
                    if (odiaMode && BuildConfig.EDITION < 0) {
                        int i = 0;
                        for (int q = 0; q < CYCLE.length; q++) if (CYCLE[q] == script) i = q;
                        script = CYCLE[(i + 1) % CYCLE.length];
                    }
                    odiaMode = true;
                } else {
                    odiaMode = false;
                }
                prefs.edit().putBoolean("odia_mode", odiaMode).putInt("script", script).apply();
                if (web != null) web.evaluateJavascript("imeSetScript(" + script + ",0)", null);
                applyMode();
            }
        });
    }

    private void applyMode() {
        if (kb == null) return;
        kb.setScript(script);
        kb.setOdiaMode(effectiveOdia());
        kb.setSpaceLabel(effectiveOdia() ? scriptNative(script) : "English");
        renderBar();
    }

    private void switchKeyboard(boolean picker) {
        flushPending();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) return;
        if (picker) { imm.showInputMethodPicker(); return; }
        boolean ok = false;
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ok = switchToNextInputMethod(false);
            } else {
                IBinder tok = getWindow().getWindow().getAttributes().token;
                ok = imm.switchToNextInputMethod(tok, false);
            }
        } catch (Throwable ignored) { }
        if (!ok) imm.showInputMethodPicker();
    }

    // ------------------------------------------------------------------ KeyboardView.Host
    @Override
    public void onKey(int code, final String text) {
        if (autoSurround && buf.length() == 0 && text != null && text.length() == 1
                && (code == KeyboardView.K_LETTER || code == KeyboardView.K_ROMAN_SYM || code == KeyboardView.K_TEXT)
                && SURR_OPEN.indexOf(text.charAt(0)) >= 0 && hasSelection()) {
            final char oc = text.charAt(0);
            act(true, new Runnable() {
                public void run() {
                    if (!surroundSelection(oc)) dispatchKey(KeyboardView.K_TEXT, String.valueOf(oc));     // the selection vanished meanwhile: type it as usual
                }
            });
            return;
        }
        dispatchKey(code, text);
    }

    private boolean hasSelection() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return false;
        CharSequence sel = ic.getSelectedText(0);
        return sel != null && sel.length() > 0;
    }

    /** Wraps the selected text in the matching pair and keeps the original text selected (so (( )) can be stacked).
     *  Nothing but the two marks is inserted: the text between them, its line breaks and its indentation are untouched. */
    private boolean surroundSelection(char open) {
        InputConnection ic = getCurrentInputConnection();
        int k = SURR_OPEN.indexOf(open);
        if (ic == null || k < 0) return false;
        CharSequence sel = ic.getSelectedText(0);
        if (sel == null || sel.length() == 0) return false;
        int start = -1;
        ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
        if (et != null && et.selectionStart >= 0 && et.selectionEnd >= 0) start = et.startOffset + Math.min(et.selectionStart, et.selectionEnd);
        String inner = sel.toString();
        ic.beginBatchEdit();
        ic.commitText(open + inner + SURR_CLOSE.charAt(k), 1);
        if (start >= 0) ic.setSelection(start + 1, start + 1 + inner.length());
        ic.endBatchEdit();
        autoSpace = false;
        nextList = new ArrayList<>();
        stamp();
        renderBar();
        return true;
    }

    private void dispatchKey(int code, final String text) {
        if (!nextList.isEmpty() && code != KeyboardView.K_LETTER && code != KeyboardView.K_ROMAN_SYM && code != KeyboardView.K_TEXT && code != KeyboardView.K_SPACE) {
            nextList = new ArrayList<>();      // anything but typing a word drops the next-word chips
            renderBar();
        }
        switch (code) {
            case KeyboardView.K_LETTER:
                act(false, new Runnable() { public void run() { typeLetter(text); } });
                break;
            case KeyboardView.K_ROMAN_SYM:
                act(false, new Runnable() { public void run() { typeRomanSym(text); } });
                break;
            case KeyboardView.K_TEXT:
                act(true, new Runnable() { public void run() { typeOther(text); } });
                break;
            case KeyboardView.K_SPACE:
                act(true, new Runnable() { public void run() { doSpace(); } });
                break;
            case KeyboardView.K_BACKSPACE:
                act(false, new Runnable() { public void run() { doBackspace(); } });
                break;
            case KeyboardView.K_ENTER:
                act(true, new Runnable() { public void run() { doEnter(); } });
                break;
            case KeyboardView.K_TAB:
                act(true, new Runnable() { public void run() { doTab(); } });
                break;
            case KeyboardView.K_LEFT:
                act(true, new Runnable() { public void run() { moveCursor(-1); } });
                break;
            case KeyboardView.K_RIGHT:
                act(true, new Runnable() { public void run() { moveCursor(1); } });
                break;
            case KeyboardView.K_GLOBE:
                act(true, new Runnable() { public void run() { switchKeyboard(false); } });
                break;
            case KeyboardView.K_PICKER:
                act(true, new Runnable() { public void run() { switchKeyboard(true); } });
                break;
            case KeyboardView.K_DIGITS:
                prefs.edit().putBoolean("digits_odia", "odia".equals(text)).apply();
                break;
            default:
                break;
        }
    }

    @Override
    public void onGesture(final String[] v) {
        act(true, new Runnable() { public void run() { gestureWord(v); } });
    }

    /** A swipe over the letters: the guesses go to the engine, which answers with the words that fit; they appear like typed candidates. */
    private void gestureWord(String[] v) {
        if (!effectiveOdia() || v == null || v.length == 0) return;
        if (buf.length() > 0) commitCandidate(sel, true);       // the word before is settled, with its space
        prevCtx = prevWord();
        nextList = new ArrayList<>();
        autoSpace = false;
        buf.setLength(0);
        buf.append(v[0]);
        gestureBuf = true;
        seq++;
        if (web == null) {
            cands = new ArrayList<>();
            cands.add(v[0]);
            sel = 0;
            shownSeq = seq;
            shownBuf = v[0];
            updateComposing();
            renderBar();
            return;
        }
        JSONArray arr = new JSONArray();
        for (String x : v) arr.put(x);
        web.evaluateJavascript("imeGesture(" + seq + "," + arr.toString() + "," + JSONObject.quote(prevCtx) + ")", null);
    }

    // ------------------------------------------------------------------ input session
    @Override
    public boolean onEvaluateFullscreenMode() { return false; }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        handler.removeCallbacks(watchdog);
        queue.clear();
        gestureBuf = false;
        if (settingsOpen) showSettings(false);
        buf.setLength(0);
        cands = new ArrayList<>();
        shownBuf = "";
        composingLen = 0;
        shownSeq = seq;
        autoSpace = false;
        nextList = new ArrayList<>();
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE || cls == InputType.TYPE_CLASS_DATETIME;
        forcedEn = cls == InputType.TYPE_CLASS_TEXT && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_URI);
        if (kb == null) return;
        night = isNight();
        applyTheme();
        kb.setOdiaDigits(prefs.getBoolean("digits_odia", false));
        kb.setLayer(numeric ? KeyboardView.L_NUM : KeyboardView.L_ABC);
        applyMode();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        finishComposing();
        buf.setLength(0);
        cands = new ArrayList<>();
        composingLen = 0;
        queue.clear();
        super.onFinishInputView(finishingInput);
    }

    @Override
    public void onFinishInput() {
        finishComposing();
        buf.setLength(0);
        cands = new ArrayList<>();
        composingLen = 0;
        super.onFinishInput();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candStart, int candEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candStart, candEnd);
        if (buf.length() == 0 && !nextList.isEmpty() && SystemClock.uptimeMillis() - lastEdit > 250) {     // the cursor was moved by hand: the next-word chips no longer fit
            nextList = new ArrayList<>();
            renderBar();
            return;
        }
        if (buf.length() == 0 || composingLen == 0) return;
        if (SystemClock.uptimeMillis() - lastEdit < 150) return;     // an echo of something this keyboard just did
        boolean inside = candStart >= 0 && candEnd >= candStart && newSelStart >= candStart && newSelEnd <= candEnd;
        if (!inside) {                                              // the cursor was moved elsewhere: settle the word as shown
            finishComposing();
            queue.clear();
            clearBuffer();
        }
    }

    @Override
    public void onDestroy() {
        try { if (web != null) web.destroy(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ views
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private boolean isNight() {
        if (appearance == 1) return false;
        if (appearance == 2) return true;
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    @Override
    public View onCreateInputView() {
        settingsOpen = false;
        night = isNight();
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        // a very small toggle: the script of the keyboard | English
        modeBox = new LinearLayout(this);
        modeBox.setOrientation(LinearLayout.HORIZONTAL);
        modeBox.setGravity(Gravity.CENTER);
        segScript = new TextView(this);
        segScript.setGravity(Gravity.CENTER);
        segScript.setTextSize(12);
        segScript.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setTyping(true); }
        });
        segEn = new TextView(this);
        segEn.setGravity(Gravity.CENTER);
        segEn.setTextSize(11);
        segEn.setText("A");
        segEn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setTyping(false); }
        });
        modeBox.addView(segScript, new LinearLayout.LayoutParams(dp(26), dp(22)));
        modeBox.addView(segEn, new LinearLayout.LayoutParams(dp(26), dp(22)));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.setMargins(dp(8), 0, dp(4), 0);
        bar.addView(modeBox, mlp);

        candScroll = new HorizontalScrollView(this);
        candScroll.setHorizontalScrollBarEnabled(false);
        candScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        candRow = new LinearLayout(this);
        candRow.setOrientation(LinearLayout.HORIZONTAL);
        candRow.setGravity(Gravity.CENTER_VERTICAL);
        candScroll.addView(candRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        hintView = new TextView(this);
        hintView.setTextSize(14);
        hintView.setPadding(dp(8), 0, dp(10), 0);
        hintView.setGravity(Gravity.CENTER_VERTICAL);
        candRow.addView(hintView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        romanLbl = new TextView(this);
        romanLbl.setTextSize(13);
        romanLbl.setPadding(dp(6), 0, dp(6), 0);
        romanLbl.setGravity(Gravity.CENTER_VERTICAL);
        romanLbl.setVisibility(View.GONE);
        candRow.addView(romanLbl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        for (int i = 0; i < NCHIP; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setTextSize(20);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(13), 0, dp(13), 0);
            t.setVisibility(View.GONE);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { if (buf.length() == 0 && !nextList.isEmpty()) pickNext(idx); else commitCandidate(idx, true); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.setMargins(dp(2), dp(6), dp(2), dp(6));
            candRow.addView(t, lp);
            chips[i] = t;
        }
        bar.addView(candScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        gear = new GearView(this);
        gear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showSettings(!settingsOpen); }
        });
        bar.addView(gear, new LinearLayout.LayoutParams(dp(42), ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        kb = new KeyboardView(this);
        kb.setHost(this);
        root.addView(kb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        panel = new ScrollView(this);
        panel.setVisibility(View.GONE);
        panel.setVerticalScrollBarEnabled(false);
        root.addView(panel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, kb.preferredHeight()));

        kb.setOdiaDigits(prefs.getBoolean("digits_odia", false));
        applyTheme();
        applyMode();
        return root;
    }

    private void applyTheme() {
        if (kb == null) return;
        kb.setLook(themeIdx, keyStyle, night);
        kb.setGesture(gestureOn);
        cBar = kb.barColor(); cChipText = kb.textColor(); cChipDim = kb.hintColor(); cSel = kb.accentColor(); cSelText = kb.accentTextColor();
        cHint = kb.hintColor(); cModeBg = kb.keyColor();
        root.setBackgroundColor(kb.bgColor());
        bar.setBackgroundColor(cBar);
        hintView.setTextColor(cHint);
        romanLbl.setTextColor(cChipDim);
        gear.setColor(cChipText);
        GradientDrawable g = new GradientDrawable();
        g.setColor(cModeBg);
        g.setCornerRadius(dp(7));
        modeBox.setBackground(g);
        if (panel != null) {
            panel.setBackgroundColor(kb.bgColor());
            if (settingsOpen) rebuildPanel();
        }
        renderBar();
    }

    // ------------------------------------------------------------------ settings panel
    private void showSettings(boolean on) {
        if (kb == null || panel == null) return;
        if (on) flushPending();
        settingsOpen = on;
        if (on) rebuildPanel();
        panel.setVisibility(on ? View.VISIBLE : View.GONE);
        kb.setVisibility(on ? View.GONE : View.VISIBLE);
        gear.setOpen(on);
    }

    private TextView label(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(12);
        v.setTextColor(kb.hintColor());
        v.setPadding(0, dp(8), 0, dp(3));
        return v;
    }

    private interface Pick { void on(int i); }

    private LinearLayout segments(String[] names, int sel, final Pick pk) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextSize(13);
            t.setGravity(Gravity.CENTER);
            boolean on = i == sel;
            t.setTextColor(on ? kb.accentTextColor() : kb.textColor());
            GradientDrawable g = new GradientDrawable();
            g.setColor(on ? kb.accentColor() : kb.keyColor());
            g.setCornerRadius(dp(9));
            t.setBackground(g);
            t.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pk.on(idx); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            lp.setMargins(i == 0 ? 0 : dp(3), 0, i == names.length - 1 ? 0 : dp(3), 0);
            row.addView(t, lp);
        }
        return row;
    }

    private void rebuildPanel() {
        panel.removeAllViews();
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(4), dp(12), dp(8));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Keyboard settings");
        title.setTextSize(15);
        title.setTextColor(kb.textColor());
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView done = new TextView(this);
        done.setText("Done");
        done.setTextSize(13);
        done.setGravity(Gravity.CENTER);
        done.setTextColor(kb.accentTextColor());
        GradientDrawable dg = new GradientDrawable();
        dg.setColor(kb.accentColor());
        dg.setCornerRadius(dp(9));
        done.setBackground(dg);
        done.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showSettings(false); } });
        head.addView(done, new LinearLayout.LayoutParams(dp(64), dp(30)));
        col.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));

        col.addView(label("Colour  ·  " + KeyboardView.THEME_NAMES[themeIdx]));
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 10; c++) {
                final int idx = r * 10 + c;
                SwatchView sv = new SwatchView(this, KeyboardView.THEME_ACCENT[idx], idx == themeIdx, kb.textColor());
                sv.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        themeIdx = idx;
                        prefs.edit().putInt("theme", idx).apply();
                        applyTheme();
                    }
                });
                row.addView(sv, new LinearLayout.LayoutParams(0, dp(34), 1f));
            }
            col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
        }

        col.addView(label("Keys"));
        col.addView(segments(new String[]{"Bordered", "Unbordered", "Soft feathered"}, keyStyle, new Pick() {
            public void on(int i) { keyStyle = i; prefs.edit().putInt("kstyle", i).apply(); applyTheme(); }
        }));

        col.addView(label("Appearance"));
        col.addView(segments(new String[]{"Follow phone", "Light", "Dark"}, appearance, new Pick() {
            public void on(int i) { appearance = i; prefs.edit().putInt("appearance", i).apply(); night = isNight(); applyTheme(); }
        }));

        LinearLayout gl = new LinearLayout(this);
        gl.setGravity(Gravity.CENTER_VERTICAL);
        gl.setPadding(0, dp(10), 0, 0);
        LinearLayout gt = new LinearLayout(this);
        gt.setOrientation(LinearLayout.VERTICAL);
        TextView g1 = new TextView(this);
        g1.setText("Gesture typing");
        g1.setTextSize(14);
        g1.setTextColor(kb.textColor());
        TextView g2 = new TextView(this);
        g2.setText("Swipe across the letters to type a word (in the script modes)");
        g2.setTextSize(11);
        g2.setTextColor(kb.hintColor());
        gt.addView(g1);
        gt.addView(g2);
        gl.addView(gt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final ToggleView tv = new ToggleView(this, gestureOn, kb.accentColor(), kb.keyColor(), kb.hintColor());
        tv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                gestureOn = !gestureOn;
                prefs.edit().putBoolean("gesture", gestureOn).apply();
                kb.setGesture(gestureOn);
                tv.set(gestureOn);
            }
        });
        gl.addView(tv, new LinearLayout.LayoutParams(dp(50), dp(28)));
        col.addView(gl);

        LinearLayout sl = new LinearLayout(this);
        sl.setGravity(Gravity.CENTER_VERTICAL);
        sl.setPadding(0, dp(10), 0, 0);
        LinearLayout st2 = new LinearLayout(this);
        st2.setOrientation(LinearLayout.VERTICAL);
        TextView s1 = new TextView(this);
        s1.setText("Auto-surround");
        s1.setTextSize(14);
        s1.setTextColor(kb.textColor());
        TextView s2 = new TextView(this);
        s2.setText("Select text, then type ( [ { \" ' ` or < to wrap it: (hello)");
        s2.setTextSize(11);
        s2.setTextColor(kb.hintColor());
        st2.addView(s1);
        st2.addView(s2);
        sl.addView(st2, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final ToggleView sv2 = new ToggleView(this, autoSurround, kb.accentColor(), kb.keyColor(), kb.hintColor());
        sv2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                autoSurround = !autoSurround;
                prefs.edit().putBoolean("autosurround", autoSurround).apply();
                sv2.set(autoSurround);
            }
        });
        sl.addView(sv2, new LinearLayout.LayoutParams(dp(50), dp(28)));
        col.addView(sl);

        panel.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    /** The gear that opens the settings (drawn, so it looks the same on every phone). */
    private static final class GearView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int color = 0xFFFFFFFF;
        private boolean open = false;
        GearView(Context c) { super(c); }
        void setColor(int c) { color = c; invalidate(); }
        void setOpen(boolean o) { open = o; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, d = getResources().getDisplayMetrics().density;
            float ro = 9f * d, ri = 6.6f * d, rh = 2.8f * d;
            Path path = new Path();
            int teeth = 8;
            for (int i = 0; i < teeth * 2; i++) {          // alternating tooth tips and roots
                double a1 = Math.PI * 2 * (i - 0.5) / (teeth * 2), a2 = Math.PI * 2 * (i + 0.5) / (teeth * 2);
                float r = (i % 2 == 0) ? ro : ri;
                float x1 = cx + (float) Math.cos(a1) * r, y1 = cy + (float) Math.sin(a1) * r;
                float x2 = cx + (float) Math.cos(a2) * r, y2 = cy + (float) Math.sin(a2) * r;
                if (i == 0) path.moveTo(x1, y1); else path.lineTo(x1, y1);
                path.lineTo(x2, y2);
            }
            path.close();
            path.addCircle(cx, cy, rh, Path.Direction.CW);
            path.setFillType(Path.FillType.EVEN_ODD);          // the hole in the middle
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setAlpha(open ? 255 : 215);
            c.drawPath(path, p);
        }
    }

    private static final class SwatchView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int color, ring;
        private final boolean on;
        SwatchView(Context c, int color, boolean on, int ring) { super(c); this.color = color; this.on = on; this.ring = ring; }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, d = getResources().getDisplayMetrics().density;
            float r = Math.min(getWidth() / 2f - 2 * d, 13 * d);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawCircle(cx, cy, r, p);
            if (on) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.2f * d);
                p.setColor(ring);
                c.drawCircle(cx, cy, r + 1.6f * d, p);
                p.setStrokeWidth(2f * d);
                p.setColor(0xFFFFFFFF);
                Path t = new Path();
                t.moveTo(cx - 4.5f * d, cy);
                t.lineTo(cx - 1.2f * d, cy + 3.6f * d);
                t.lineTo(cx + 4.8f * d, cy - 3.6f * d);
                c.drawPath(t, p);
            }
        }
    }

    private static final class ToggleView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean on;
        private final int onC, offC, knob;
        ToggleView(Context c, boolean on, int onC, int offC, int knob) { super(c); this.on = on; this.onC = onC; this.offC = offC; this.knob = knob; }
        void set(boolean v) { on = v; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
            float th = 22 * d, tw = 42 * d, l = (w - tw) / 2f, t = (h - th) / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? onC : offC);
            c.drawRoundRect(new RectF(l, t, l + tw, t + th), th / 2, th / 2, p);
            p.setColor(on ? 0xFFFFFFFF : knob);
            float r = th / 2 - 3 * d;
            c.drawCircle(on ? l + tw - th / 2 : l + th / 2, t + th / 2, r, p);
        }
    }

    /** Updates the strip in place (no views are created or removed), so nothing flickers while typing. */
    private void renderBar() {
        if (candRow == null) return;
        boolean odia = effectiveOdia();
        segScript.setText(scriptLetter(script));
        segScript.setTextColor(odia ? cSelText : cChipDim);
        segEn.setTextColor(odia ? cChipDim : cSelText);
        GradientDrawable gs = new GradientDrawable();
        gs.setColor(odia ? cSel : Color.TRANSPARENT);
        gs.setCornerRadius(dp(7));
        segScript.setBackground(gs);
        GradientDrawable ge = new GradientDrawable();
        ge.setColor(odia ? Color.TRANSPARENT : cSel);
        ge.setCornerRadius(dp(7));
        segEn.setBackground(ge);
        boolean has = buf.length() > 0 && !cands.isEmpty();
        boolean nxt = !has && buf.length() == 0 && odia && !nextList.isEmpty();
        if (!has && !nxt) {
            hintView.setText(!odia ? "English typing" : (ready ? "Sulekhak " + scriptName(script) + "  ·  type in Roman letters" : "Sulekhak " + scriptName(script) + "  ·  type in Roman letters (smart suggestions loading)"));
            hintView.setVisibility(View.VISIBLE);
        } else {
            hintView.setVisibility(View.GONE);
        }
        if (has) {
            romanLbl.setText(shownBuf.length() > 0 ? shownBuf : buf.toString());
            romanLbl.setVisibility(View.VISIBLE);
        } else {
            romanLbl.setVisibility(View.GONE);
        }
        for (int i = 0; i < NCHIP; i++) {
            TextView t = chips[i];
            if (nxt && i < nextList.size()) {
                String w = nextList.get(i);
                if (!w.contentEquals(t.getText())) t.setText(w);
                t.setTextColor(cChipText);
                t.setBackground(null);
                t.setVisibility(View.VISIBLE);
            } else if (has && i < cands.size()) {
                String w = shownCand(cands.get(i));
                if (!w.contentEquals(t.getText())) t.setText(w);
                boolean on = i == sel;
                t.setTextColor(on ? cSelText : (i == 1 ? cChipDim : cChipText));
                if (on) {
                    GradientDrawable g = new GradientDrawable();
                    g.setColor(cSel);
                    g.setCornerRadius(dp(9));
                    t.setBackground(g);
                } else {
                    t.setBackground(null);
                }
                t.setVisibility(View.VISIBLE);
            } else if (t.getVisibility() != View.GONE) {
                t.setVisibility(View.GONE);
            }
        }
    }

    /** How a candidate is written in the strip. A halant with a joiner is spelled out so the difference can be seen:
     *  halant + ZWNJ as  ୍ + ┊ , halant + ZWJ as  ୍ + [ ; a plain halant stays just the halant; a lone ZWNJ / ZWJ by name. */
    static String shownCand(String w) {
        if (w.equals("\u200C")) return "ZWNJ";
        if (w.equals("\u200D")) return "ZWJ";
        int n = w.length();
        if (n >= 2 && w.charAt(n - 2) == '\u0B4D' && (w.charAt(n - 1) == '\u200C' || w.charAt(n - 1) == '\u200D')) {
            String b = w.substring(0, n - 1);
            if (b.length() == 1) b = "\u25CC" + b;
            return b + " + " + (w.charAt(n - 1) == '\u200C' ? "\u250A" : "[");
        }
        return w;
    }
}
