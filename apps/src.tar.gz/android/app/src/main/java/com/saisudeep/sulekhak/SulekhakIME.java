package com.saisudeep.sulekhak;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Sulekhak Odia phonetic keyboard. The language engine (the same JavaScript that runs in the web tool) lives in a hidden
 * WebView; this class is the input method: it keeps the Roman letters being typed, shows the Odia word being formed in the
 * text field, and offers the candidates in the strip above the keys.
 *
 * Nothing is drawn or sent to the text field until the engine has answered for the letters typed so far, so the word
 * never flashes between Roman and Odia; keys pressed meanwhile wait in a short queue and run in order.
 */
public class SulekhakIME extends InputMethodService implements KeyboardView.Host {
    static final String HOST = "appassets.androidplatform.net";
    static final int HIST_MAX = 800;
    static final int NCHIP = 24;
    static final int NPHON = 240;                    // Phonetic mode: every symbol of a key's list gets a chip (the bar scrolls)

    private static final class Act {
        final boolean fresh;
        final Runnable run;
        Act(boolean f, Runnable r) { fresh = f; run = r; }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView web;
    private boolean ready = false;                  // smart engine loaded

    // what is being typed
    private final StringBuilder buf = new StringBuilder();
    private List<String> cands = new ArrayList<>();
    private String shownBuf = "";                   // the letters the shown candidates belong to
    private String prevCtx = "<s>";
    private List<String> nextList = new ArrayList<>();   // next-word suggestions shown while nothing is being typed
    private int nseq = 0;
    private int sel = 0, seq = 0, shownSeq = 0, composingLen = 0;
    private boolean autoSpace = false;               // the last thing typed was a word followed by our own space
    // English suggestions (personal build)
    private boolean lowerFirst = false;               // English: the next word starts in lower case although it follows a full stop (the shift key was tapped to cancel the automatic capital)
    private boolean capAuto = false;                 // the word in the buffer began with an automatic capital (backspace takes that capital back)
    private int enAuto = 0;                          // 1: cands.get(0) is a correction and cands.get(1) is the text as typed
    private String lastTyped = null, lastCorrected = null;   // an autocorrection just applied, so backspace can take it back
    private int lastCommitLen = 0;
    private long lastCommitAt = 0;
    private boolean incognito = false;               // the app asked for no personalised learning: nothing is recorded
    private long lastEdit = 0;
    private final List<Act> queue = new ArrayList<>();

    // mode
    private boolean odiaMode = true, forcedEn = false, numeric = false, uriEn = false;     // uriEn: an address bar starts in English, but the language buttons still work there
    private boolean phon = false;                   // Phonetic (IPA) typing: a letter is typed, and the symbols that look like it are offered above the keys
    private String phonKey = null;                  // the letter now shown (underlined) in the text, waiting for a pick from phonCands
    private String[] phonCands = new String[0];
    private String flash = "";                      // a short note in the strip, gone with the next key
    private int script = 0;      // the script typed now: 0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese (an edition is fixed to its own, the all-in-one cycles through them)
    private static final int[] CYCLE = {0, 1, 5, 2};
    private static String scriptName(int sc) { return sc == 1 ? "Devanagari" : sc == 2 ? "Bangla" : sc == 5 ? "Assamese" : "Odia"; }
    private static String scriptNative(int sc) { return sc == 1 ? "हिन्दी" : sc == 2 ? "বাংলা" : sc == 5 ? "অসমীয়া" : "ଓଡ଼ିଆ"; }
    private static String scriptLetter(int sc) { return sc == 1 ? "अ" : sc == 2 ? "অ" : sc == 5 ? "অ" : "ଓ"; }

    private SharedPreferences prefs;
    private final List<String[]> hist = new ArrayList<>();

    // views
    private LinearLayout root, bar, candRow, modeBox;
    private HorizontalScrollView candScroll;
    private TextView segScript, segEn, segIpa, hintView, romanLbl;
    private GearView gear;
    private ScrollView panel;
    private boolean settingsOpen = false, gestureOn = true, gestureBuf = false;
    private boolean autoSurround = true;           // select text, type ( [ { " ' ` or < and the selection is wrapped
    private static final String SURR_OPEN = "([{\"'`<";
    private static final String SURR_CLOSE = ")]}\"'`>";
    private int themeIdx = 0, keyStyle = 0, appearance = 0;     // appearance: 0 follow the phone, 1 light, 2 dark
    private final TextView[] chips = new TextView[NPHON];
    private KeyboardView kb;
    private boolean night = false;
    private int cBar, cChipText, cChipDim, cSel, cSelText, cHint, cModeBg;

    // ------------------------------------------------------------------ engine (hidden WebView)
    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("sulekhak", Context.MODE_PRIVATE);
        odiaMode = prefs.getBoolean("odia_mode", true);
        phon = prefs.getBoolean("phon", false);
        script = BuildConfig.EDITION >= 0 ? BuildConfig.EDITION : prefs.getInt("script", 0);
        if (script != 0 && script != 1 && script != 2 && script != 5) script = 0;
        if (!prefs.getBoolean("look_v6", false)) {                // one time: the new standard look is Light + Bordered + Slate (change it in the keyboard's settings any time)
            prefs.edit().putInt("theme", 18).putInt("kstyle", 0).putInt("appearance", 1).putBoolean("look_v6", true).apply();
        }
        themeIdx = prefs.getInt("theme", 18);
        keyStyle = prefs.getInt("kstyle", 0);
        appearance = prefs.getInt("appearance", 1);
        gestureOn = prefs.getBoolean("gesture", true);
        autoSurround = prefs.getBoolean("autosurround", true);
        loadHistory();
        initWeb();
    }

    private void initWeb() {
        try {
            web = new WebView(this);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            web.addJavascriptInterface(new Bridge(), "Android");
            web.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                    return serve(r.getUrl() == null ? null : r.getUrl().getHost(), r.getUrl() == null ? null : r.getUrl().getPath());
                }

                @Override
                public void onPageFinished(WebView v, String url) {
                    sendReplay();
                    startPersonal();
                }

                @Override
                public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                    ready = false;
                    try { web.destroy(); } catch (Exception ignored) { }
                    web = null;
                    handler.postDelayed(new Runnable() { public void run() { initWeb(); } }, 1000);
                    return true;
                }
            });
            web.loadUrl("https://" + HOST + "/ime.html");
        } catch (Throwable t) {
            web = null;     // no WebView on this device: the keyboard still types, only without suggestions
        }
    }

    private WebResourceResponse serve(String host, String path) {
        if (!HOST.equals(host) || path == null || path.length() < 2) return null;
        String p = path.substring(1);
        try {
            InputStream in = getAssets().open(p);
            boolean bin = p.endsWith(".bin");
            String mime = p.endsWith(".html") ? "text/html" : (p.endsWith(".js") ? "text/javascript" : (bin ? "application/octet-stream" : "text/plain"));
            return new WebResourceResponse(mime, bin ? null : "utf-8", in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
        }
    }

    // ------------------------------------------------------------------ personal learning + Google sync (the engine page does the learning; this side signs in and keeps the files)
    private final GoogleAuth.Listener authListener = new GoogleAuth.Listener() { public void onChanged() { pushToken(); } };
    private boolean personalOn = false;

    private void startPersonal() {
        if (web == null) return;
        try {
            String init = "SKP.initHost({did:" + JSONObject.quote(GoogleAuth.deviceId(this)) + ",name:" + JSONObject.quote(android.os.Build.MODEL == null ? "android" : android.os.Build.MODEL)
                    + ",platform:'android',allowed:" + GoogleAuth.allowedJson()
                    + ",post:function(m){window.Android.post(JSON.stringify(m));}});SKP.setMode(" + script + ",0," + enWanted() + ");" + (enWanted() ? "if(window.imeSetEnglish)imeSetEnglish(true);" : "");
            web.evaluateJavascript("if(window.SKP){" + init + "}", null);
            personalOn = true;
            GoogleAuth.listen(authListener);
            pushToken();
        } catch (Exception ignored) { }
    }

    /** gives the page a fresh access token (or tells it it is signed out); runs the network on a worker thread */
    private void pushToken() {
        if (web == null || !personalOn) return;
        final Context c = getApplicationContext();
        new Thread(new Runnable() {
            public void run() {
                final String[] a = GoogleAuth.signedIn(c) ? GoogleAuth.access(c) : null;
                handler.post(new Runnable() {
                    public void run() {
                        if (web == null) return;
                        if (a == null) web.evaluateJavascript("if(window.SKP)SKP.signedOut()", null);
                        else web.evaluateJavascript("if(window.SKP)SKP.setToken(" + JSONObject.quote(a[0]) + "," + a[1] + "," + JSONObject.quote(a[2]) + ")", null);
                    }
                });
            }
        }, "sk-token").start();
    }

    private void onPersonalMsg(String t, JSONObject o) {
        if ("sk-need".equals(t)) {
            String lang = o.optString("lang");
            if (web != null) web.evaluateJavascript("if(window.SKP)SKP.hostLoad(" + JSONObject.quote(lang) + "," + JSONObject.quote(GoogleAuth.readLang(this, lang)) + ")", null);
        } else if ("sk-save".equals(t)) {
            final String lang = o.optString("lang"), text = o.optString("text");
            final Context c = getApplicationContext();
            new Thread(new Runnable() { public void run() { GoogleAuth.writeLang(c, lang, text); } }, "sk-save").start();
        } else if ("sk-token".equals(t)) {
            pushToken();
        } else if ("sk-signout".equals(t)) {
            GoogleAuth.signOut(this);
        } else if ("sk-state".equals(t)) {
            prefs.edit().putString("sync_state", o.optString("state") + "|" + o.optString("detail")).apply();
        }
    }

    private void noteSwipe(String word, boolean accepted) {
        if (web != null && personalOn && word != null && hasNonAscii(word))
            web.evaluateJavascript("if(window.imeNoteSwipe)imeNoteSwipe(" + JSONObject.quote(word) + "," + accepted + ")", null);
    }

    private void noteSkip(String roman, String word) {
        if (web != null && personalOn && roman != null && word != null && hasNonAscii(word))
            web.evaluateJavascript("if(window.imeNoteSkip)imeNoteSkip(" + JSONObject.quote(roman) + "," + JSONObject.quote(word) + ")", null);
    }

    private void sendReplay() {
        if (web == null) return;
        try {
            JSONArray a = new JSONArray();
            for (String[] h : hist) { JSONArray p = new JSONArray(); p.put(h[0]); p.put(h[1]); a.put(p); }
            web.evaluateJavascript("imeSetScript(" + script + ",0)", null);
            if (enWanted()) web.evaluateJavascript("if(window.imeSetEnglish)imeSetEnglish(true)", null);
            web.evaluateJavascript("imeReplay(" + a.toString() + ")", null);
        } catch (Exception ignored) { }
    }

    public class Bridge {
        @JavascriptInterface
        public void post(final String s) {
            handler.post(new Runnable() { public void run() { onMsg(s); } });
        }
    }

    private void onMsg(String s) {
        try {
            JSONObject o = new JSONObject(s);
            String t = o.optString("t");
            if ("ready".equals(t)) {
                ready = true;
                renderBar();
            } else if (t.startsWith("sk-")) {
                onPersonalMsg(t, o);
            } else if ("n".equals(t)) {
                if (o.optInt("id", -1) != nseq || buf.length() != 0) return;
                JSONArray l = o.getJSONArray("list");
                List<String> n = new ArrayList<>();
                for (int i = 0; i < l.length() && i < NCHIP; i++) n.add(l.getString(i));
                nextList = n;
                renderBar();
            } else if ("c".equals(t)) {
                if (o.optInt("id", -1) != seq || buf.length() == 0) return;
                JSONArray l = o.getJSONArray("list");
                List<String> n = new ArrayList<>();
                for (int i = 0; i < l.length(); i++) n.add(l.getString(i));
                if (n.isEmpty() && gestureBuf) {              // the swipe matched no word of the dictionary: nothing is typed
                    buf.setLength(0);
                    clearBuffer();
                    flash = ready ? "No word matched that swipe. Tap the letters, or swipe again." : "Suggestions are still loading. Swipe again in a moment.";
                    renderBar();
                    drain();
                    return;
                }
                if (n.isEmpty()) n.add(buf.toString());
                enAuto = (effectiveEn() && !gestureBuf && n.size() > 1) ? o.optInt("auto", 0) : 0;
                cands = n;
                sel = 0;
                shownSeq = seq;
                shownBuf = buf.toString();
                updateComposing();
                renderBar();
                if (candScroll != null) candScroll.scrollTo(0, 0);
                drain();
            }
        } catch (Exception ignored) { }
    }

    private void query() {
        if (buf.length() == 0) { clearBuffer(); return; }
        seq++;
        if (web == null) {
            cands = new ArrayList<>();
            cands.add(buf.toString());
            sel = 0;
            shownSeq = seq;
            shownBuf = buf.toString();
            updateComposing();
            renderBar();
            return;
        }
        if (effectiveEn()) { web.evaluateJavascript("imeEnQuery(" + seq + "," + JSONObject.quote(buf.toString()) + "," + JSONObject.quote(prevCtx) + ")", null); return; }
        web.evaluateJavascript("imeQuery(" + seq + "," + JSONObject.quote(buf.toString()) + "," + JSONObject.quote(prevCtx) + ")", null);
    }

    /** Asks the engine which words usually follow `word`; the answer arrives as a "n" message and is shown as chips. */
    private void requestNext(String word) {
        nseq++;
        nextList = new ArrayList<>();
        if (effectiveEn()) { if (word.length() >= 1) web.evaluateJavascript("imeEnNext(" + nseq + "," + JSONObject.quote(word.toLowerCase()) + ")", null); return; }
        if (web == null || !ready || !hasNonAscii(word) || word.length() < 2) return;
        web.evaluateJavascript("imeNext(" + nseq + "," + JSONObject.quote(word) + ")", null);
    }

    /** A next-word chip was tapped: put the word in with a space and look for the word after it. */
    private void pickNext(int idx) {
        if (idx < 0 || idx >= nextList.size()) return;
        String w = nextList.get(idx);
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(w + " ", 1);
        autoSpace = true;
        stamp();
        if (effectiveEn()) enLearnNote(w, w, "next", null);
        else if (web != null) web.evaluateJavascript("imeCommit(\"\"," + JSONObject.quote(w) + ")", null);
        requestNext(w);
        renderBar();
    }

    /** The Odia word before the one being typed (for next-word statistics); "<s>" at the start of a sentence. */
    /** English: the word before the cursor (lower case), or "<s>" at the start of a sentence. */
    private String prevWordEn() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "<s>";
        CharSequence t = ic.getTextBeforeCursor(80, 0);
        if (t == null) return "<s>";
        String s = t.toString();
        int i = s.length() - 1;
        while (i >= 0 && (s.charAt(i) == ' ' || s.charAt(i) == '\t' || s.charAt(i) == ',' || s.charAt(i) == ';')) i--;
        if (i < 0) return "<s>";
        int e = i;
        while (i >= 0) {
            char c = s.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '\'' || c == 0x2019) i--; else break;
        }
        if (i == e) return "<s>";
        String w = s.substring(i + 1, e + 1).toLowerCase().replace('\u2019', '\'');
        while (w.startsWith("'")) w = w.substring(1);
        return w.length() == 0 ? "<s>" : w;
    }

    private String prevWord() {
        if (effectiveEn()) return prevWordEn();
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "<s>";
        CharSequence t = ic.getTextBeforeCursor(80, 0);
        if (t == null) return "<s>";
        String s = t.toString();
        int i = s.length() - 1;
        while (i >= 0 && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) i--;
        int e = i;
        while (i >= 0) {
            char c = s.charAt(i);
            boolean odia = (c >= 0x0B00 && c <= 0x0B7F && c != 0x0B64 && c != 0x0B65) || (c >= 0x0900 && c <= 0x097F && c != 0x0964 && c != 0x0965) || (c >= 0x0980 && c <= 0x09FF);
            if (odia || c == 0x200C || c == 0x200D) i--; else break;
        }
        if (e < 0 || i == e) return "<s>";
        return s.substring(i + 1, e + 1);
    }

    // ------------------------------------------------------------------ history (the memory cache)
    private void loadHistory() {
        hist.clear();
        String h = prefs.getString("hist", "");
        for (String line : h.split("\n")) {
            int p = line.indexOf('\t');
            if (p > 0 && p < line.length() - 1) hist.add(new String[]{line.substring(0, p), line.substring(p + 1)});
        }
    }

    private void remember(String roman, String word) {
        hist.add(new String[]{roman, word});
        while (hist.size() > HIST_MAX) hist.remove(0);
        StringBuilder sb = new StringBuilder();
        for (String[] h : hist) sb.append(h[0]).append('\t').append(h[1]).append('\n');
        prefs.edit().putString("hist", sb.toString()).apply();
        if (web != null) web.evaluateJavascript("imeCommit(" + JSONObject.quote(roman) + "," + JSONObject.quote(word) + ")", null);
    }

    // ------------------------------------------------------------------ small helpers
    private static boolean hasNonAscii(String s) {
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) > 127) return true;
        return false;
    }

    private static boolean wordContinues(String w) {
        if (w.isEmpty()) return true;
        char last = w.charAt(w.length() - 1);
        return last == 0x0B4D || last == 0x200C;
    }

    private static boolean isDots(CharSequence s) {
        if (s.length() == 0) return false;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) != '.') return false;
        return true;
    }

    private static boolean isDigits(String s) {
        if (s.length() == 0) return false;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) < '0' || s.charAt(i) > '9') return false;
        return true;
    }

    private static boolean isPunct(String t) {
        return t.length() == 1 && ",.;:!?।".indexOf(t.charAt(0)) >= 0;
    }

    private boolean effectiveOdia() { return odiaMode && !phon && !forcedEn && !numeric && !uriEn; }
    private boolean effectivePhon() { return phon && !forcedEn && !numeric && !uriEn; }
    /** English with suggestions, spelling help, next-word chips and swipe typing (the personal build only; the page needs the English data). */
    private boolean effectiveEn() { return BuildConfig.ENGLISH && web != null && !odiaMode && !phon && !forcedEn && !numeric && !uriEn; }
    private boolean enWanted() { return BuildConfig.ENGLISH && !odiaMode && !phon; }
    private void enLearnNote(String typed, String word, String how, String passed) {
        if (web == null || incognito || !personalOn) return;
        web.evaluateJavascript("if(window.imeEnCommit)imeEnCommit(" + JSONObject.quote(typed) + "," + JSONObject.quote(word) + "," + JSONObject.quote(prevCtx) + ","
                + JSONObject.quote(how) + "," + (passed == null ? "null" : JSONObject.quote(passed)) + ")", null);
    }

    private void stamp() { lastEdit = SystemClock.uptimeMillis(); }

    // ------------------------------------------------------------------ the key queue
    private void act(boolean fresh, Runnable r) {
        if (!queue.isEmpty()) { queue.add(new Act(fresh, r)); return; }
        if (fresh && buf.length() > 0 && shownSeq != seq && web != null) {
            queue.add(new Act(fresh, r));
            handler.removeCallbacks(watchdog);
            handler.postDelayed(watchdog, 700);
            return;
        }
        r.run();
    }

    private void drain() {
        while (!queue.isEmpty()) {
            Act a = queue.get(0);
            if (a.fresh && buf.length() > 0 && shownSeq != seq && web != null) {
                handler.removeCallbacks(watchdog);
                handler.postDelayed(watchdog, 700);
                break;
            }
            queue.remove(0);
            a.run.run();
        }
    }

    private final Runnable watchdog = new Runnable() {
        public void run() {          // the engine did not answer in time: carry on with what is shown
            if (buf.length() > 0 && shownSeq != seq) {
                if (cands.isEmpty()) { cands = new ArrayList<>(); cands.add(buf.toString()); }
                shownSeq = seq;
                if (shownBuf.length() == 0) shownBuf = buf.toString();
                updateComposing();
                renderBar();
            }
            drain();
        }
    };

    // ------------------------------------------------------------------ typing logic
    private void updateComposing() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || cands.isEmpty()) return;
        String shown = cands.get(sel < cands.size() ? sel : 0);
        if (effectiveEn() && !gestureBuf && enAuto == 1 && sel == 0 && cands.size() > 1) shown = cands.get(1);      // English: the letters stay as typed until the space key applies the correction
        ic.setComposingText(shown, 1);
        composingLen = shown.length();
        stamp();
    }

    private void clearBuffer() {
        gestureBuf = false;
        buf.setLength(0);
        cands = new ArrayList<>();
        shownBuf = "";
        sel = 0;
        composingLen = 0;
        shownSeq = seq;
        renderBar();
    }

    private void finishComposing() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.finishComposingText();
        stamp();
    }

    /** English: a word is settled (space key, a suggestion tapped, punctuation, the next swipe). */
    private void commitEn(int idx, boolean space) {
        String typed = buf.toString();
        InputConnection ic = getCurrentInputConnection();
        String word, how, passed = null;
        if (gestureBuf) {
            word = (idx >= 0 && idx < cands.size()) ? cands.get(idx) : typed;
            how = "swipe";
            if (idx > 0 && cands.size() > 0) passed = cands.get(0);
        } else if (typed.endsWith("'") || cands.isEmpty()) {
            word = typed;
            how = "typed";
        } else {
            word = (idx >= 0 && idx < cands.size()) ? cands.get(idx) : typed;
            if (enAuto == 1) { how = idx == 0 ? "auto" : (idx == 1 ? "keeptyped" : "pick"); if (idx != 0) passed = cands.get(0); }
            else { how = idx == 0 ? "typed" : "pick"; if (idx != 0 && !cands.get(0).equals(typed)) passed = cands.get(0); }
        }
        String shownWord = polishWordEn(word);
        if (ic != null) ic.commitText(shownWord + (space ? " " : ""), 1);
        stamp();
        autoSpace = space;
        enLearnNote(typed, word, how, passed);
        if (how.equals("auto")) { lastTyped = typed; lastCorrected = shownWord; lastCommitLen = shownWord.length() + (space ? 1 : 0); lastCommitAt = SystemClock.uptimeMillis(); }
        else lastTyped = null;
        clearBuffer();
        if (space) requestNext(word); else nextList = new ArrayList<>();
    }

    /** English: backspace right after an automatic correction puts the letters back as they were typed, and the word is not corrected again. */
    private boolean undoAutoCorrection() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || lastTyped == null || buf.length() != 0 || SystemClock.uptimeMillis() - lastCommitAt > 10000) { lastTyped = null; return false; }
        CharSequence b = ic.getTextBeforeCursor(lastCommitLen, 0);
        String expect = lastCorrected + (lastCommitLen > lastCorrected.length() ? " " : "");
        if (b == null || !b.toString().equals(expect)) { lastTyped = null; return false; }
        String t0 = lastTyped, c0 = lastCorrected;
        lastTyped = null;
        ic.beginBatchEdit();
        ic.deleteSurroundingText(lastCommitLen, 0);
        ic.setComposingText(t0, 1);
        ic.endBatchEdit();
        buf.setLength(0);
        buf.append(t0);
        enAuto = 0;
        gestureBuf = false;
        cands = new ArrayList<>();
        cands.add(t0);
        sel = 0;
        shownBuf = t0;
        composingLen = t0.length();
        nextList = new ArrayList<>();
        autoSpace = false;
        stamp();
        enLearnNote(t0, t0, "revert", c0);
        query();
        return true;
    }

    private void commitCandidate(int idx, boolean space) {
        if (buf.length() == 0) return;
        if (effectiveEn()) { commitEn(idx, space); return; }
        String roman = shownBuf.length() > 0 ? shownBuf : buf.toString();
        String word = (idx >= 0 && idx < cands.size()) ? cands.get(idx) : roman;
        boolean sp = space && !wordContinues(word);
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(word + (sp ? " " : ""), 1);
        stamp();
        autoSpace = sp;
        if (!gestureBuf && idx != 1 && hasNonAscii(word) && !isDots(roman) && !isDigits(roman)) remember(roman, word);
        if (gestureBuf) {                                             // swipe preferences: the word taken is liked, the first guess passed over is not
            if (idx >= 0 && idx < cands.size() && hasNonAscii(word)) {
                noteSwipe(word, true);
                if (idx > 0 && cands.size() > 0 && hasNonAscii(cands.get(0))) noteSwipe(cands.get(0), false);
            }
        } else if (idx > 0 && idx != 1 && cands.size() > 0 && !cands.get(0).equals(word) && hasNonAscii(word)) noteSkip(roman, cands.get(0));
        clearBuffer();
        if (sp) requestNext(word); else nextList = new ArrayList<>();
    }

    // ------------------------------------------------------------------ English: capital letters and curly punctuation (the same rules as the web, Mac, Windows and iPhone typing)
    private boolean enPolish(String key) { try { return getSharedPreferences("sulekhak", 0).getBoolean(key, true); } catch (Exception e) { return true; } }
    private static final java.util.HashSet<String> EN_ABBR = new java.util.HashSet<>(java.util.Arrays.asList("mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "vs", "etc", "e.g", "i.e", "no", "fig", "eq", "approx", "dept", "est", "inc", "ltd", "co", "mt", "ft", "vol", "pp", "p", "a.m", "p.m", "u.s", "u.k"));
    /** the next letter begins a sentence: the start of the text, a new line, or . ! ? … (closing quotes and brackets allowed) and a space */
    private boolean sentenceStartEn() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return false;
        CharSequence cs = ic.getTextBeforeCursor(60, 0);
        if (cs == null) return false;
        String p = cs.toString();
        while (p.length() > 0) {            // an opening quote or bracket right before the letter does not hide the start behind it
            char l = p.charAt(p.length() - 1);
            boolean openStraight = l == '"' && (p.length() == 1 || Character.isWhitespace(p.charAt(p.length() - 2)));
            if (l == '\u201C' || l == '\u2018' || l == '(' || l == '[' || openStraight) p = p.substring(0, p.length() - 1); else break;
        }
        int n = p.length(), spaces = 0;
        if (n == 0) return true;
        while (n > 0 && Character.isWhitespace(p.charAt(n - 1))) { if (p.charAt(n - 1) == '\n') return true; n--; spaces++; }
        if (n == 0) return true;
        if (spaces == 0) return false;
        while (n > 0 && "\"'\u201D\u2019)]".indexOf(p.charAt(n - 1)) >= 0) n--;
        if (n == 0) return false;
        char e = p.charAt(n - 1);
        if (e != '.' && e != '!' && e != '?' && e != '\u2026') return false;
        if (e == '.' && !(n >= 2 && p.charAt(n - 2) == '.')) {
            int b = n - 1;
            while (b > 0 && (Character.isLetter(p.charAt(b - 1)) || p.charAt(b - 1) == '.')) b--;
            if (EN_ABBR.contains(p.substring(b, n - 1).toLowerCase())) return false;
        }
        return true;
    }
    private boolean openContextEn() {
        InputConnection ic = getCurrentInputConnection();
        CharSequence b = ic == null ? null : ic.getTextBeforeCursor(1, 0);
        if (b == null || b.length() == 0) return true;
        char c = b.charAt(0);
        return Character.isWhitespace(c) || "([{\u2014\u2013\u201C\u2018/-".indexOf(c) >= 0;
    }
    /** how a finished English word stands in the text: a lone i is I, apostrophes are curly */
    private String polishWordEn(String w) {
        if (enPolish("enCap")) {
            String l = w.replace('\u2019', '\'').toLowerCase();
            if (l.equals("i") || l.equals("i'm") || l.equals("i'll") || l.equals("i've") || l.equals("i'd")) w = "I" + w.substring(1);
        }
        if (enPolish("enSmart")) w = w.replace('\'', '\u2019');
        return w;
    }
    /** a mark typed in English: quotes become curly, -- an em dash, ... an ellipsis */
    private void commitDirectEn(String t) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && t.length() == 1 && enPolish("enSmart")) {
            char c = t.charAt(0);
            if (c == '"' || c == '\'') { boolean open = openContextEn(); commitDirect(c == '"' ? (open ? "\u201C" : "\u201D") : (open ? "\u2018" : "\u2019")); return; }
            if (c == '-') { CharSequence b = ic.getTextBeforeCursor(1, 0); if (b != null && b.toString().equals("-")) { ic.deleteSurroundingText(1, 0); commitDirect("\u2014"); return; } }
            if (c == '.') { CharSequence b = ic.getTextBeforeCursor(2, 0); if (b != null && b.toString().equals("..")) { ic.deleteSurroundingText(2, 0); commitDirect("\u2026"); return; } }
        }
        commitDirect(t);
    }

    private void commitDirect(String t) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (t.length() == 1 && t.charAt(0) >= '0' && t.charAt(0) <= '9') {      // a plain digit goes in as a key press, like on every other keyboard: many apps (dialer, browsers, number fields) listen for the key, not for text
            flash = "";
            autoSpace = false;
            nextList = new ArrayList<>();
            sendDownUpKeyEvents(KeyEvent.KEYCODE_0 + (t.charAt(0) - '0'));
            stamp();
            renderBar();
            return;
        }
        if (autoSpace && isPunct(t)) {            // "word ." becomes "word." when the space was ours
            CharSequence b = ic.getTextBeforeCursor(1, 0);
            if (b != null && b.length() == 1 && b.charAt(0) == ' ') ic.deleteSurroundingText(1, 0);
        }
        ic.commitText(t, 1);
        autoSpace = false;
        nextList = new ArrayList<>();
        stamp();
        renderBar();
    }

    /** Where a nukta typed after a finished letter belongs: on the last ଡ or ଢ of that letter (the root consonant), never on a matra or vowel sign.
     *  `before` is the text before the cursor; a single space we added after a picked word is skipped. Returns the index of that ଡ / ଢ, or -1 when the
     *  letter has none (then a plain nukta is written, as before). */
    static int nuktaTarget(CharSequence before) {
        int end = before.length();
        if (end > 0 && before.charAt(end - 1) == ' ') end--;
        int i = end;
        while (i > 0 && isSignOrMatra(before.charAt(i - 1))) i--;                       // matras, chandrabindu, anusvara ... after the base
        if (i == 0 || !isOdiaCons(before.charAt(i - 1))) return -1;
        int j = i - 1;                                                                  // the base consonant; walk back over halant + consonant pairs (the conjunct)
        while (j >= 2 && (before.charAt(j - 1) == 0x0B4D || before.charAt(j - 1) == 0x200C || before.charAt(j - 1) == 0x200D)) {
            int h = j - 1;
            while (h > 0 && (before.charAt(h) != 0x0B4D)) h--;
            if (before.charAt(h) != 0x0B4D || h < 1 || !isOdiaCons(before.charAt(h - 1))) break;
            j = h - 1;
        }
        for (int k = end - 1; k >= j; k--) {
            char c = before.charAt(k);
            if (c == 0x0B21 || c == 0x0B22) return (k + 1 < before.length() && before.charAt(k + 1) == 0x0B3C) ? -2 : k;   // -2: it already has its nukta
        }
        int base = i - 1;                                                               // no ଡ / ଢ in the letter: the nukta goes on the base consonant, before its matra
        return (base + 1 < before.length() && before.charAt(base + 1) == 0x0B3C) ? -2 : base;
    }
    private static boolean isSignOrMatra(char c) {
        return (c >= 0x0B3E && c <= 0x0B4C) || (c >= 0x0B01 && c <= 0x0B03) || c == 0x0B56 || c == 0x0B57 || c == 0x0B62 || c == 0x0B63 || c == 0x0B3C;
    }
    private static boolean isOdiaCons(char c) { return (c >= 0x0B15 && c <= 0x0B39) || c == 0x0B5C || c == 0x0B5D || c == 0x0B5F || c == 0x0B71; }

    private void commitNukta() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence b = ic.getTextBeforeCursor(24, 0);
        int k = b == null ? -1 : nuktaTarget(b);
        if (k == -2) return;                                    // the letter already has its nukta: nothing is added after a matra
        if (k < 0) { commitDirect("଼"); return; }
        ic.beginBatchEdit();
        String tail = b.subSequence(k + 1, b.length()).toString();
        ic.deleteSurroundingText(b.length() - (k + 1), 0);
        ic.commitText("଼" + tail, 1);
        ic.endBatchEdit();
        flash = "";
        autoSpace = false;
        nextList = new ArrayList<>();
        stamp();
        renderBar();
    }

    private void flushPending() {
        if (phonKey != null) commitPhon();
        if (buf.length() > 0) commitCandidate(sel, false);
    }

    // ------------------------------------------------------------------ Phonetic (IPA) typing
    /** A letter in Phonetic mode: it is shown at once (underlined), and the symbols that look like it appear above the keys; a tap on one replaces it, the next key keeps it. */
    private void typePhon(String ch) {
        if (phonKey != null) commitPhon();
        String[] l = PhonData.get(ch);
        InputConnection ic = getCurrentInputConnection();
        if (l == null || l.length < 2 || ic == null) { commitDirect(ch); return; }
        ic.setComposingText(ch, 1);
        stamp();
        autoSpace = false;
        phonKey = ch;
        phonCands = l;
        renderBar();
    }

    private void commitPhon() {
        if (phonKey == null) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.finishComposingText();
        stamp();
        phonKey = null;
        phonCands = new String[0];
        renderBar();
    }

    private void pickPhon(int idx) {
        if (phonKey == null || idx < 0 || idx >= phonCands.length) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(phonCands[idx], 1);
        stamp();
        phonKey = null;
        phonCands = new String[0];
        renderBar();
    }

    private static boolean combiningMark(String s) {
        if (s == null || s.length() == 0) return false;
        int t = Character.getType(s.charAt(0));
        return t == Character.NON_SPACING_MARK || t == Character.COMBINING_SPACING_MARK || t == Character.ENCLOSING_MARK;
    }

    private void typeLetter(String ch) {
        flash = "";
        if (effectivePhon()) { typePhon(ch); return; }
        if (effectiveEn()) { typeLetterEn(ch); return; }
        if (!effectiveOdia()) { commitDirect(ch); return; }
        if (gestureBuf && buf.length() > 0) commitCandidate(sel, false);          // a swiped word is settled before letters are typed after it
        if (buf.length() > 0 && isDots(buf)) commitCandidate(sel, false);
        if (buf.length() == 0) { prevCtx = prevWord(); nextList = new ArrayList<>(); }
        buf.append(ch);
        autoSpace = false;
        query();
    }

    private void typeLetterEn(String ch) {
        boolean letter = ch.length() == 1 && ((ch.charAt(0) >= 'a' && ch.charAt(0) <= 'z') || (ch.charAt(0) >= 'A' && ch.charAt(0) <= 'Z'));
        if (!letter) { flushPending(); commitDirect(ch); return; }          // accented letters and the like go in as they are
        if (gestureBuf && buf.length() > 0) commitCandidate(sel, true);       // a swiped word is settled, with its space
        if (buf.length() == 0) {
            prevCtx = prevWord(); nextList = new ArrayList<>();
            boolean lf = lowerFirst;
            lowerFirst = false;
            capAuto = false;
            char c0 = ch.charAt(0);
            if (!lf && enPolish("enCap") && sentenceStartEn()) {
                if (c0 >= 'a' && c0 <= 'z') { ch = ch.toUpperCase(); capAuto = true; }
                else if (c0 >= 'A' && c0 <= 'Z' && capShown) capAuto = true;      // the keys were showing the automatic capital
            }
        }
        buf.append(ch);
        autoSpace = false;
        lastTyped = null;
        query();
    }

    private void typeRomanSym(String s) {
        flash = "";
        if (effectiveEn()) {
            if (s.equals("'") && buf.length() > 0 && !gestureBuf) { buf.append('\''); autoSpace = false; query(); return; }     // don't, it's
            flushPending();                                                    // the word is settled (corrected if needed) before the mark
            commitDirectEn(s);
            return;
        }
        if (!effectiveOdia()) { if (phonKey != null) commitPhon(); commitDirect(s); return; }
        if (gestureBuf && buf.length() > 0) commitCandidate(sel, false);
        if (s.equals(".")) {
            if (buf.length() > 0 && isDots(buf)) { buf.append('.'); query(); return; }
            flushPending();
            InputConnection ic = getCurrentInputConnection();
            if (autoSpace && ic != null) {
                CharSequence b = ic.getTextBeforeCursor(1, 0);
                if (b != null && b.length() == 1 && b.charAt(0) == ' ') ic.deleteSurroundingText(1, 0);
            }
            autoSpace = false;
            prevCtx = prevWord();
            nextList = new ArrayList<>();
            buf.append('.');
            query();
            return;
        }
        if (s.equals(">") && buf.length() == 0) { commitNukta(); return; }   // nukta: on the ଡ / ଢ of the letter before the cursor
        if (buf.length() == 0) { prevCtx = prevWord(); nextList = new ArrayList<>(); }
        buf.append(s);
        autoSpace = false;
        query();
    }

    private void typeOther(String t) {
        if (effectiveEn() && t.equals("'") && buf.length() > 0 && !gestureBuf) { buf.append('\''); autoSpace = false; query(); return; }
        flushPending();
        if (effectiveEn()) commitDirectEn(t); else commitDirect(t);
    }

    private boolean capShown = false;
    /** English: at the start of a sentence the keys show capitals (and the shift key is lit) until a letter is typed or shift is tapped to cancel */
    private void refreshAutoCap() {
        if (kb == null) return;
        boolean want = false;
        try { want = effectiveEn() && !lowerFirst && buf.length() == 0 && enPolish("enCap") && sentenceStartEn(); } catch (Exception ignored) { }
        capShown = want;
        kb.setAutoCap(want);
    }

    private void doSpace() {
        lowerFirst = false;
        flash = "";
        if (phonKey != null) commitPhon();
        if (buf.length() > 0) { commitCandidate(sel, true); return; }
        commitDirect(" ");
    }

    private void doBackspace() {
        InputConnection ic = getCurrentInputConnection();
        autoSpace = false;
        flash = "";
        if (effectiveEn() && undoAutoCorrection()) return;
        if (phonKey != null) {                           // the letter still showing is taken back
            if (ic != null) { ic.setComposingText("", 1); ic.finishComposingText(); }
            stamp();
            phonKey = null;
            phonCands = new String[0];
            renderBar();
            return;
        }
        if (gestureBuf && buf.length() > 0) {            // a swiped word goes in one piece
            if (ic != null) { ic.setComposingText("", 1); ic.finishComposingText(); }
            stamp();
            clearBuffer();
            return;
        }
        if (buf.length() == 1 && capAuto && effectiveEn()) {         // the automatic capital is taken back: the same letter, in lower case, and no more capital for this word
            capAuto = false;
            lowerFirst = true;
            buf.setCharAt(0, Character.toLowerCase(buf.charAt(0)));
            query();
            return;
        }
        if (buf.length() > 0) {
            buf.setLength(buf.length() - 1);
            if (buf.length() == 0) {
                if (ic != null) { ic.setComposingText("", 1); ic.finishComposingText(); }
                stamp();
                clearBuffer();
            } else {
                query();
            }
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
            stamp();
        }
    }

    private void doEnter() {
        lowerFirst = false;
        flushPending();
        autoSpace = false;
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        int action = ei == null ? EditorInfo.IME_ACTION_NONE : (ei.imeOptions & EditorInfo.IME_MASK_ACTION);
        boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        if (ic != null && !multi && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
        stamp();
    }

    private void doTab() {
        if (buf.length() > 0 && cands.size() > 1) {      // Tab walks through the candidates, like on the web page
            sel = (sel + 1) % cands.size();
            updateComposing();
            renderBar();
            return;
        }
        flushPending();
        EditorInfo ei = getCurrentInputEditorInfo();
        boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        if (multi) commitDirect("\t");
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_TAB);
        stamp();
    }

    private void moveCursor(int dir) {
        flushPending();
        autoSpace = false;
        sendDownUpKeyEvents(dir < 0 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT);
        stamp();
    }

    /** The switch at the top right: the script (a second tap on it, in the all-in-one, goes on to the next script), English, or Phonetic IPA. */
    private void setTyping(final int which) {         // 0 script, 1 English, 2 Phonetic
        act(true, new Runnable() {
            public void run() {
                flushPending();
                uriEn = false;                               // a language button was pressed: it is honoured in an address bar too
                if (which == 0) {
                    if (odiaMode && !phon && BuildConfig.EDITION < 0) {
                        int i = 0;
                        for (int q = 0; q < CYCLE.length; q++) if (CYCLE[q] == script) i = q;
                        script = CYCLE[(i + 1) % CYCLE.length];
                    }
                    odiaMode = true;
                    phon = false;
                } else if (which == 1) {
                    odiaMode = false;
                    phon = false;
                } else {
                    phon = true;
                }
                flash = "";
                prefs.edit().putBoolean("odia_mode", odiaMode).putBoolean("phon", phon).putInt("script", script).apply();
                if (web != null) {
                    web.evaluateJavascript("imeSetScript(" + script + ",0)", null);
                    if (BuildConfig.ENGLISH) web.evaluateJavascript("if(window.imeSetEnglish)imeSetEnglish(" + enWanted() + ")", null);
                }
                lastTyped = null;
                applyMode();
            }
        });
    }

    private void applyMode() {
        if (kb == null) return;
        kb.setScript(script);
        kb.setPhonMode(effectivePhon());
        kb.setOdiaMode(effectiveOdia());
        kb.setEnSwipe(effectiveEn());
        kb.setSpaceLabel(effectivePhon() ? "IPA" : effectiveOdia() ? scriptNative(script) : "English");
        renderBar();
        refreshAutoCap();
    }

    private void switchKeyboard(boolean picker) {
        flushPending();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) return;
        if (picker) { imm.showInputMethodPicker(); return; }
        boolean ok = false;
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ok = switchToNextInputMethod(false);
            } else {
                IBinder tok = getWindow().getWindow().getAttributes().token;
                ok = imm.switchToNextInputMethod(tok, false);
            }
        } catch (Throwable ignored) { }
        if (!ok) imm.showInputMethodPicker();
    }

    // ------------------------------------------------------------------ KeyboardView.Host
    @Override
    public void onKey(int code, final String text) {
        if (autoSurround && buf.length() == 0 && text != null && text.length() == 1
                && (code == KeyboardView.K_LETTER || code == KeyboardView.K_ROMAN_SYM || code == KeyboardView.K_TEXT)
                && SURR_OPEN.indexOf(text.charAt(0)) >= 0 && hasSelection()) {
            final char oc = text.charAt(0);
            act(true, new Runnable() {
                public void run() {
                    if (!surroundSelection(oc)) dispatchKey(KeyboardView.K_TEXT, String.valueOf(oc));     // the selection vanished meanwhile: type it as usual
                }
            });
            return;
        }
        dispatchKey(code, text);
    }

    private boolean hasSelection() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return false;
        CharSequence sel = ic.getSelectedText(0);
        return sel != null && sel.length() > 0;
    }

    /** Wraps the selected text in the matching pair and keeps the original text selected (so (( )) can be stacked).
     *  Nothing but the two marks is inserted: the text between them, its line breaks and its indentation are untouched. */
    private boolean surroundSelection(char open) {
        InputConnection ic = getCurrentInputConnection();
        int k = SURR_OPEN.indexOf(open);
        if (ic == null || k < 0) return false;
        CharSequence sel = ic.getSelectedText(0);
        if (sel == null || sel.length() == 0) return false;
        int start = -1;
        ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
        if (et != null && et.selectionStart >= 0 && et.selectionEnd >= 0) start = et.startOffset + Math.min(et.selectionStart, et.selectionEnd);
        String inner = sel.toString();
        ic.beginBatchEdit();
        ic.commitText(open + inner + SURR_CLOSE.charAt(k), 1);
        if (start >= 0) ic.setSelection(start + 1, start + 1 + inner.length());
        ic.endBatchEdit();
        autoSpace = false;
        nextList = new ArrayList<>();
        stamp();
        renderBar();
        return true;
    }

    private void dispatchKey(int code, final String text) {
        if (!nextList.isEmpty() && code != KeyboardView.K_LETTER && code != KeyboardView.K_ROMAN_SYM && code != KeyboardView.K_TEXT && code != KeyboardView.K_SPACE) {
            nextList = new ArrayList<>();      // anything but typing a word drops the next-word chips
            renderBar();
        }
        switch (code) {
            case KeyboardView.K_LETTER:
                act(false, new Runnable() { public void run() { typeLetter(text); } });
                break;
            case KeyboardView.K_ROMAN_SYM:
                act(false, new Runnable() { public void run() { typeRomanSym(text); } });
                break;
            case KeyboardView.K_TEXT:
                act(true, new Runnable() { public void run() { typeOther(text); } });
                break;
            case KeyboardView.K_SPACE:
                act(true, new Runnable() { public void run() { doSpace(); } });
                break;
            case KeyboardView.K_BACKSPACE:
                act(false, new Runnable() { public void run() { doBackspace(); } });
                break;
            case KeyboardView.K_ENTER:
                act(true, new Runnable() { public void run() { doEnter(); } });
                break;
            case KeyboardView.K_TAB:
                act(true, new Runnable() { public void run() { doTab(); } });
                break;
            case KeyboardView.K_LEFT:
                act(true, new Runnable() { public void run() { moveCursor(-1); } });
                break;
            case KeyboardView.K_RIGHT:
                act(true, new Runnable() { public void run() { moveCursor(1); } });
                break;
            case KeyboardView.K_GLOBE:
                act(true, new Runnable() { public void run() { switchKeyboard(false); } });
                break;
            case KeyboardView.K_PICKER:
                act(true, new Runnable() { public void run() { switchKeyboard(true); } });
                break;
            case KeyboardView.K_AUTOCAP_OFF:
                lowerFirst = true;
                capShown = false;
                break;
            case KeyboardView.K_DIGITS:
                prefs.edit().putBoolean("digits_odia", "odia".equals(text)).apply();
                break;
            default:
                break;
        }
    }

    @Override
    public void onGestureStart(final String letter) {
        act(false, new Runnable() { public void run() { retractFirstLetter(letter); } });
    }

    /** A swipe starts on a key that was already typed on touch-down: that one letter is taken out again, so "bed" is not committed as "b " + "bed". */
    private void retractFirstLetter(String letter) {
        if (!(effectiveOdia() || effectiveEn()) || gestureBuf || buf.length() == 0 || letter == null || letter.length() == 0) return;
        String b = buf.toString();
        if (!b.toLowerCase(Locale.ROOT).endsWith(letter.toLowerCase(Locale.ROOT))) return;
        buf.setLength(b.length() - letter.length());
        if (buf.length() == 0) {
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) { ic.setComposingText("", 1); ic.finishComposingText(); }
            stamp();
            clearBuffer();
        } else {
            query();
        }
    }

    @Override
    public void onGesture(final String[] v, final String trace) {
        act(true, new Runnable() { public void run() { gestureWord(v, trace); } });
    }

    /** A swipe over the letters: the guesses go to the engine, which answers with the words that fit; they appear like typed candidates. */
    private void gestureWord(String[] v, String trace) {
        if (!(effectiveOdia() || effectiveEn()) || v == null || v.length == 0) return;
        if (buf.length() > 0) commitCandidate(sel, true);       // the word before is settled, with its space
        prevCtx = prevWord();
        nextList = new ArrayList<>();
        autoSpace = false;
        buf.setLength(0);
        buf.append(v[0]);
        gestureBuf = true;
        seq++;
        if (web == null) {
            cands = new ArrayList<>();
            cands.add(v[0]);
            sel = 0;
            shownSeq = seq;
            shownBuf = v[0];
            updateComposing();
            renderBar();
            return;
        }
        JSONArray arr = new JSONArray();
        for (String x : v) arr.put(x);
        if (effectiveEn()) { web.evaluateJavascript("imeEnSwipe(" + seq + "," + (trace == null ? "null" : trace) + "," + arr.toString() + "," + JSONObject.quote(prevCtx) + ")", null); return; }
        if (trace != null) web.evaluateJavascript("imeSwipe(" + seq + "," + trace + "," + arr.toString() + "," + JSONObject.quote(prevCtx) + ")", null);
        else web.evaluateJavascript("imeGesture(" + seq + "," + arr.toString() + "," + JSONObject.quote(prevCtx) + ")", null);
    }

    // ------------------------------------------------------------------ input session
    @Override
    public boolean onEvaluateFullscreenMode() { return false; }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        handler.removeCallbacks(watchdog);
        queue.clear();
        gestureBuf = false;
        enAuto = 0;
        lowerFirst = false;
        capAuto = false;
        lastTyped = null;
        incognito = info != null && (info.imeOptions & 0x1000000) != 0;       // IME_FLAG_NO_PERSONALIZED_LEARNING
        phonKey = null;
        phonCands = new String[0];
        flash = "";
        if (settingsOpen) showSettings(false);
        buf.setLength(0);
        cands = new ArrayList<>();
        shownBuf = "";
        composingLen = 0;
        shownSeq = seq;
        autoSpace = false;
        nextList = new ArrayList<>();
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE || cls == InputType.TYPE_CLASS_DATETIME;
        forcedEn = cls == InputType.TYPE_CLASS_TEXT && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS);
        uriEn = cls == InputType.TYPE_CLASS_TEXT && var == InputType.TYPE_TEXT_VARIATION_URI;     // the address bar of a browser: English first, any language one tap away
        if (kb == null) return;
        night = isNight();
        applyTheme();
        kb.setOdiaDigits(prefs.getBoolean("digits_odia", false));
        kb.setLayer(numeric ? KeyboardView.L_NUM : KeyboardView.L_ABC);
        applyMode();
        refreshAutoCap();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        finishComposing();
        phonKey = null;
        buf.setLength(0);
        cands = new ArrayList<>();
        composingLen = 0;
        queue.clear();
        super.onFinishInputView(finishingInput);
    }

    @Override
    public void onFinishInput() {
        finishComposing();
        phonKey = null;
        buf.setLength(0);
        cands = new ArrayList<>();
        composingLen = 0;
        super.onFinishInput();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candStart, int candEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candStart, candEnd);
        if (buf.length() == 0 && SystemClock.uptimeMillis() - lastEdit > 250) lowerFirst = false;      // the cursor was moved by hand: a new place, a new decision
        refreshAutoCap();
        if (buf.length() == 0 && !nextList.isEmpty() && SystemClock.uptimeMillis() - lastEdit > 250) {     // the cursor was moved by hand: the next-word chips no longer fit
            nextList = new ArrayList<>();
            renderBar();
            return;
        }
        if (phonKey != null && SystemClock.uptimeMillis() - lastEdit > 250) {      // the cursor was moved by hand: the letter stays as it is
            phonKey = null;
            phonCands = new String[0];
            renderBar();
        }
        if (buf.length() == 0 || composingLen == 0) return;
        if (SystemClock.uptimeMillis() - lastEdit < 150) return;     // an echo of something this keyboard just did
        boolean inside = candStart >= 0 && candEnd >= candStart && newSelStart >= candStart && newSelEnd <= candEnd;
        if (!inside) {                                              // the cursor was moved elsewhere: settle the word as shown
            finishComposing();
            queue.clear();
            clearBuffer();
        }
    }

    @Override
    public void onDestroy() {
        GoogleAuth.unlisten(authListener);
        try { if (web != null) web.destroy(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ views
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private boolean isNight() {
        if (appearance == 1) return false;
        if (appearance == 2) return true;
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    @Override
    public View onCreateInputView() {
        settingsOpen = false;
        night = isNight();
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        // settings on the left: a wide, tall button, so it is easy to hit
        gear = new GearView(this);
        gear.setOnTouchListener(new TapListener(new Runnable() {
            public void run() { showSettings(!settingsOpen); }
        }));
        bar.addView(gear, new LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT));

        candScroll = new HorizontalScrollView(this);
        candScroll.setHorizontalScrollBarEnabled(false);
        candScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        candRow = new LinearLayout(this);
        candRow.setOrientation(LinearLayout.HORIZONTAL);
        candRow.setGravity(Gravity.CENTER_VERTICAL);
        candScroll.addView(candRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        hintView = new TextView(this);
        hintView.setTextSize(14);
        hintView.setPadding(dp(8), 0, dp(10), 0);
        hintView.setGravity(Gravity.CENTER_VERTICAL);
        candRow.addView(hintView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        romanLbl = new TextView(this);
        romanLbl.setTextSize(13);
        romanLbl.setPadding(dp(6), 0, dp(6), 0);
        romanLbl.setGravity(Gravity.CENTER_VERTICAL);
        romanLbl.setVisibility(View.GONE);
        candRow.addView(romanLbl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        for (int i = 0; i < NPHON; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setTextSize(20);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(13), 0, dp(13), 0);
            t.setVisibility(View.GONE);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (phonKey != null) pickPhon(idx);
                    else if (buf.length() == 0 && !nextList.isEmpty()) pickNext(idx);
                    else commitCandidate(idx, true);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.setMargins(dp(2), dp(6), dp(2), dp(6));
            candRow.addView(t, lp);
            chips[i] = t;
        }
        bar.addView(candScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        // the language switch on the right: script | English | IPA. Each part is at least 46 x 40 dp, and a tap counts when the finger lifts
        // anywhere near it, so a switch is never lost to a slightly slipping finger.
        modeBox = new LinearLayout(this);
        modeBox.setOrientation(LinearLayout.HORIZONTAL);
        modeBox.setGravity(Gravity.CENTER);
        segScript = new SegView(this, 14);
        segScript.setOnTouchListener(new TapListener(new Runnable() { public void run() { setTyping(0); } }));
        segEn = new SegView(this, 13);
        segEn.setText("A");
        segEn.setOnTouchListener(new TapListener(new Runnable() { public void run() { setTyping(1); } }));
        segIpa = new SegView(this, 12);
        segIpa.setText("IPA");
        segIpa.setOnTouchListener(new TapListener(new Runnable() { public void run() { setTyping(2); } }));
        modeBox.addView(segScript, new LinearLayout.LayoutParams(dp(46), dp(40)));
        modeBox.addView(segEn, new LinearLayout.LayoutParams(dp(46), dp(40)));
        modeBox.addView(segIpa, new LinearLayout.LayoutParams(dp(46), dp(40)));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.setMargins(dp(6), 0, dp(6), 0);
        bar.addView(modeBox, mlp);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        kb = new KeyboardView(this);
        kb.setHost(this);
        root.addView(kb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        panel = new ScrollView(this);
        panel.setVisibility(View.GONE);
        panel.setVerticalScrollBarEnabled(false);
        root.addView(panel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, kb.preferredHeight()));

        kb.setOdiaDigits(prefs.getBoolean("digits_odia", false));
        applyTheme();
        applyMode();
        return root;
    }

    private void applyTheme() {
        if (kb == null) return;
        kb.setLook(themeIdx, keyStyle, night);
        kb.setGesture(gestureOn);
        cBar = kb.barColor(); cChipText = kb.textColor(); cChipDim = kb.hintColor(); cSel = kb.accentColor(); cSelText = kb.accentTextColor();
        cHint = kb.hintColor(); cModeBg = kb.keyColor();
        root.setBackgroundColor(kb.bgColor());
        bar.setBackgroundColor(cBar);
        hintView.setTextColor(cHint);
        romanLbl.setTextColor(cChipDim);
        gear.setColor(cChipText);
        GradientDrawable g = new GradientDrawable();
        g.setColor(cModeBg);
        g.setCornerRadius(dp(7));
        modeBox.setBackground(g);
        if (panel != null) {
            panel.setBackgroundColor(kb.bgColor());
            if (settingsOpen) rebuildPanel();
        }
        renderBar();
    }

    // ------------------------------------------------------------------ settings panel
    private void showSettings(boolean on) {
        if (kb == null || panel == null) return;
        if (on) flushPending();
        settingsOpen = on;
        if (on) rebuildPanel();
        panel.setVisibility(on ? View.VISIBLE : View.GONE);
        kb.setVisibility(on ? View.GONE : View.VISIBLE);
        gear.setOpen(on);
    }

    private TextView label(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(12);
        v.setTextColor(kb.hintColor());
        v.setPadding(0, dp(8), 0, dp(3));
        return v;
    }

    private interface Pick { void on(int i); }

    private LinearLayout segments(String[] names, int sel, final Pick pk) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextSize(13);
            t.setGravity(Gravity.CENTER);
            boolean on = i == sel;
            t.setTextColor(on ? kb.accentTextColor() : kb.textColor());
            GradientDrawable g = new GradientDrawable();
            g.setColor(on ? kb.accentColor() : kb.keyColor());
            g.setCornerRadius(dp(9));
            t.setBackground(g);
            t.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pk.on(idx); } });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            lp.setMargins(i == 0 ? 0 : dp(3), 0, i == names.length - 1 ? 0 : dp(3), 0);
            row.addView(t, lp);
        }
        return row;
    }

    private void rebuildPanel() {
        panel.removeAllViews();
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(4), dp(12), dp(8));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Keyboard settings");
        title.setTextSize(15);
        title.setTextColor(kb.textColor());
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView done = new TextView(this);
        done.setText("Done");
        done.setTextSize(13);
        done.setGravity(Gravity.CENTER);
        done.setTextColor(kb.accentTextColor());
        GradientDrawable dg = new GradientDrawable();
        dg.setColor(kb.accentColor());
        dg.setCornerRadius(dp(9));
        done.setBackground(dg);
        done.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { showSettings(false); } });
        head.addView(done, new LinearLayout.LayoutParams(dp(64), dp(30)));
        col.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));

        col.addView(label("Colour  ·  " + KeyboardView.THEME_NAMES[themeIdx]));
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 10; c++) {
                final int idx = r * 10 + c;
                SwatchView sv = new SwatchView(this, KeyboardView.THEME_ACCENT[idx], idx == themeIdx, kb.textColor());
                sv.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        themeIdx = idx;
                        prefs.edit().putInt("theme", idx).apply();
                        applyTheme();
                    }
                });
                row.addView(sv, new LinearLayout.LayoutParams(0, dp(34), 1f));
            }
            col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
        }

        col.addView(label("Keys"));
        col.addView(segments(new String[]{"Bordered", "Unbordered", "Soft feathered"}, keyStyle, new Pick() {
            public void on(int i) { keyStyle = i; prefs.edit().putInt("kstyle", i).apply(); applyTheme(); }
        }));

        col.addView(label("Appearance"));
        col.addView(segments(new String[]{"Follow phone", "Light", "Dark"}, appearance, new Pick() {
            public void on(int i) { appearance = i; prefs.edit().putInt("appearance", i).apply(); night = isNight(); applyTheme(); }
        }));

        LinearLayout gl = new LinearLayout(this);
        gl.setGravity(Gravity.CENTER_VERTICAL);
        gl.setPadding(0, dp(10), 0, 0);
        LinearLayout gt = new LinearLayout(this);
        gt.setOrientation(LinearLayout.VERTICAL);
        TextView g1 = new TextView(this);
        g1.setText("Gesture typing");
        g1.setTextSize(14);
        g1.setTextColor(kb.textColor());
        TextView g2 = new TextView(this);
        g2.setText("Swipe across the letters to type a word (in the script modes)");
        g2.setTextSize(11);
        g2.setTextColor(kb.hintColor());
        gt.addView(g1);
        gt.addView(g2);
        gl.addView(gt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final ToggleView tv = new ToggleView(this, gestureOn, kb.accentColor(), kb.keyColor(), kb.hintColor());
        tv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                gestureOn = !gestureOn;
                prefs.edit().putBoolean("gesture", gestureOn).apply();
                kb.setGesture(gestureOn);
                tv.set(gestureOn);
            }
        });
        gl.addView(tv, new LinearLayout.LayoutParams(dp(50), dp(28)));
        col.addView(gl);

        LinearLayout sl = new LinearLayout(this);
        sl.setGravity(Gravity.CENTER_VERTICAL);
        sl.setPadding(0, dp(10), 0, 0);
        LinearLayout st2 = new LinearLayout(this);
        st2.setOrientation(LinearLayout.VERTICAL);
        TextView s1 = new TextView(this);
        s1.setText("Auto-surround");
        s1.setTextSize(14);
        s1.setTextColor(kb.textColor());
        TextView s2 = new TextView(this);
        s2.setText("Select text, then type ( [ { \" ' ` or < to wrap it: (hello)");
        s2.setTextSize(11);
        s2.setTextColor(kb.hintColor());
        st2.addView(s1);
        st2.addView(s2);
        sl.addView(st2, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final ToggleView sv2 = new ToggleView(this, autoSurround, kb.accentColor(), kb.keyColor(), kb.hintColor());
        sv2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                autoSurround = !autoSurround;
                prefs.edit().putBoolean("autosurround", autoSurround).apply();
                sv2.set(autoSurround);
            }
        });
        sl.addView(sv2, new LinearLayout.LayoutParams(dp(50), dp(28)));
        col.addView(sl);

        panel.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    /** A tap that is accepted when the finger goes down and lifts near the same place (a slip of up to 20 dp is still a tap). */
    private final class TapListener implements View.OnTouchListener {
        private final Runnable action;
        private float sx, sy;
        TapListener(Runnable a) { action = a; }

        @Override
        public boolean onTouch(View v, android.view.MotionEvent e) {
            switch (e.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    sx = e.getX();
                    sy = e.getY();
                    v.setPressed(true);
                    v.setAlpha(0.6f);
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                    v.setPressed(false);
                    v.setAlpha(1f);
                    if (Math.abs(e.getX() - sx) < dp(20) && Math.abs(e.getY() - sy) < dp(20)) {
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                        action.run();
                    }
                    return true;
                case android.view.MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    v.setAlpha(1f);
                    return true;
                default:
                    return true;
            }
        }
    }

    /** One part of the language switch. */
    private static final class SegView extends TextView {
        SegView(Context c, int sp) {
            super(c);
            setGravity(Gravity.CENTER);
            setTextSize(sp);
            setSingleLine(true);
            setIncludeFontPadding(false);
        }
    }

    /** The gear that opens the settings (drawn, so it looks the same on every phone). */
    private static final class GearView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int color = 0xFFFFFFFF;
        private boolean open = false;
        GearView(Context c) { super(c); }
        void setColor(int c) { color = c; invalidate(); }
        void setOpen(boolean o) { open = o; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, d = getResources().getDisplayMetrics().density;
            float ro = 9f * d, ri = 6.6f * d, rh = 2.8f * d;
            Path path = new Path();
            int teeth = 8;
            for (int i = 0; i < teeth * 2; i++) {          // alternating tooth tips and roots
                double a1 = Math.PI * 2 * (i - 0.5) / (teeth * 2), a2 = Math.PI * 2 * (i + 0.5) / (teeth * 2);
                float r = (i % 2 == 0) ? ro : ri;
                float x1 = cx + (float) Math.cos(a1) * r, y1 = cy + (float) Math.sin(a1) * r;
                float x2 = cx + (float) Math.cos(a2) * r, y2 = cy + (float) Math.sin(a2) * r;
                if (i == 0) path.moveTo(x1, y1); else path.lineTo(x1, y1);
                path.lineTo(x2, y2);
            }
            path.close();
            path.addCircle(cx, cy, rh, Path.Direction.CW);
            path.setFillType(Path.FillType.EVEN_ODD);          // the hole in the middle
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setAlpha(open ? 255 : 215);
            c.drawPath(path, p);
        }
    }

    private static final class SwatchView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int color, ring;
        private final boolean on;
        SwatchView(Context c, int color, boolean on, int ring) { super(c); this.color = color; this.on = on; this.ring = ring; }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, d = getResources().getDisplayMetrics().density;
            float r = Math.min(getWidth() / 2f - 2 * d, 13 * d);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawCircle(cx, cy, r, p);
            if (on) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.2f * d);
                p.setColor(ring);
                c.drawCircle(cx, cy, r + 1.6f * d, p);
                p.setStrokeWidth(2f * d);
                p.setColor(0xFFFFFFFF);
                Path t = new Path();
                t.moveTo(cx - 4.5f * d, cy);
                t.lineTo(cx - 1.2f * d, cy + 3.6f * d);
                t.lineTo(cx + 4.8f * d, cy - 3.6f * d);
                c.drawPath(t, p);
            }
        }
    }

    private static final class ToggleView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean on;
        private final int onC, offC, knob;
        ToggleView(Context c, boolean on, int onC, int offC, int knob) { super(c); this.on = on; this.onC = onC; this.offC = offC; this.knob = knob; }
        void set(boolean v) { on = v; invalidate(); }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
            float th = 22 * d, tw = 42 * d, l = (w - tw) / 2f, t = (h - th) / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? onC : offC);
            c.drawRoundRect(new RectF(l, t, l + tw, t + th), th / 2, th / 2, p);
            p.setColor(on ? 0xFFFFFFFF : knob);
            float r = th / 2 - 3 * d;
            c.drawCircle(on ? l + tw - th / 2 : l + th / 2, t + th / 2, r, p);
        }
    }

    private GradientDrawable segBg(boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? cSel : Color.TRANSPARENT);
        g.setCornerRadius(dp(9));
        return g;
    }

    /** Updates the strip in place (no views are created or removed), so nothing flickers while typing. */
    private void renderBar() {
        if (candRow == null) return;
        boolean odia = effectiveOdia();
        boolean ipa = effectivePhon();
        boolean english = !odia && !ipa;
        segScript.setText(scriptLetter(script));
        segScript.setTextColor(odia ? cSelText : cChipDim);
        segEn.setTextColor(english ? cSelText : cChipDim);
        segIpa.setTextColor(ipa ? cSelText : cChipDim);
        segScript.setBackground(segBg(odia));
        segEn.setBackground(segBg(english));
        segIpa.setBackground(segBg(ipa));
        boolean has = buf.length() > 0 && !cands.isEmpty();
        boolean nxt = !has && buf.length() == 0 && (odia || effectiveEn()) && !nextList.isEmpty();
        boolean pk = ipa && phonKey != null;
        if (pk) {
            hintView.setVisibility(View.GONE);
            romanLbl.setVisibility(View.GONE);
            for (int i = 0; i < NPHON; i++) {
                TextView t = chips[i];
                if (i < phonCands.length) {
                    String w = combiningMark(phonCands[i]) ? "\u25CC" + phonCands[i] : phonCands[i];
                    if (!w.contentEquals(t.getText())) t.setText(w);
                    boolean on = i == 0;
                    t.setTextColor(on ? cSelText : cChipText);
                    if (on) {
                        GradientDrawable g = new GradientDrawable();
                        g.setColor(cSel);
                        g.setCornerRadius(dp(9));
                        t.setBackground(g);
                    } else {
                        t.setBackground(null);
                    }
                    t.setVisibility(View.VISIBLE);
                } else if (t.getVisibility() != View.GONE) {
                    t.setVisibility(View.GONE);
                }
            }
            if (candScroll != null) candScroll.scrollTo(0, 0);
            return;
        }
        if (!has && !nxt) {
            String msg = flash.length() > 0 ? flash
                    : ipa ? "IPA  ·  tap a key, then pick a look-alike here (or hold the key)"
                    : !odia ? "English typing" : (ready ? "Sulekhak " + scriptName(script) + "  ·  type in Roman letters" : "Sulekhak " + scriptName(script) + "  ·  type in Roman letters (smart suggestions loading)");
            hintView.setText(msg);
            hintView.setVisibility(View.VISIBLE);
        } else {
            hintView.setVisibility(View.GONE);
        }
        if (has && !effectiveEn()) {
            romanLbl.setText(shownBuf.length() > 0 ? shownBuf : buf.toString());
            romanLbl.setVisibility(View.VISIBLE);
        } else {
            romanLbl.setVisibility(View.GONE);
        }
        for (int i = 0; i < NPHON; i++) {
            TextView t = chips[i];
            if (nxt && i < nextList.size()) {
                String w = nextList.get(i);
                if (!w.contentEquals(t.getText())) t.setText(w);
                t.setTextColor(cChipText);
                t.setBackground(null);
                t.setVisibility(View.VISIBLE);
            } else if (has && i < cands.size()) {
                String w = shownCand(cands.get(i));
                if (!w.contentEquals(t.getText())) t.setText(w);
                boolean on = i == sel;
                t.setTextColor(on ? cSelText : ((i == 1 && (!effectiveEn() || enAuto == 1)) ? cChipDim : cChipText));
                if (on) {
                    GradientDrawable g = new GradientDrawable();
                    g.setColor(cSel);
                    g.setCornerRadius(dp(9));
                    t.setBackground(g);
                } else {
                    t.setBackground(null);
                }
                t.setVisibility(View.VISIBLE);
            } else if (t.getVisibility() != View.GONE) {
                t.setVisibility(View.GONE);
            }
        }
    }

    /** How a candidate is written in the strip. A halant with a joiner is spelled out so the difference can be seen:
     *  halant + ZWNJ as  ୍ + ┊ , halant + ZWJ as  ୍ + [ ; a plain halant stays just the halant; a lone ZWNJ / ZWJ by name. */
    static String shownCand(String w) {
        if (w.equals("\u200C")) return "ZWNJ";
        if (w.equals("\u200D")) return "ZWJ";
        int n = w.length();
        if (n >= 2 && w.charAt(n - 2) == '\u0B4D' && (w.charAt(n - 1) == '\u200C' || w.charAt(n - 1) == '\u200D')) {
            String b = w.substring(0, n - 1);
            if (b.length() == 1) b = "\u25CC" + b;
            return b + " + " + (w.charAt(n - 1) == '\u200C' ? "\u250A" : "[");
        }
        return w;
    }
}
