package com.saisudeep.sulekhak;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Sulekhak Odia phonetic keyboard. The language engine (the same JavaScript that runs in the web tool) lives in a hidden
 * WebView; this class is the input method: it keeps the Roman letters being typed, shows the Odia word being formed in the
 * text field, and offers the candidates in the strip above the keys.
 *
 * Nothing is drawn or sent to the text field until the engine has answered for the letters typed so far, so the word
 * never flashes between Roman and Odia; keys pressed meanwhile wait in a short queue and run in order.
 */
public class SulekhakIME extends InputMethodService implements KeyboardView.Host {
    static final String HOST = "appassets.androidplatform.net";
    static final int HIST_MAX = 800;
    static final int NCHIP = 16;

    private static final class Act {
        final boolean fresh;
        final Runnable run;
        Act(boolean f, Runnable r) { fresh = f; run = r; }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView web;
    private boolean ready = false;                  // smart engine loaded

    // what is being typed
    private final StringBuilder buf = new StringBuilder();
    private List<String> cands = new ArrayList<>();
    private String shownBuf = "";                   // the letters the shown candidates belong to
    private String prevCtx = "<s>";
    private List<String> nextList = new ArrayList<>();   // next-word suggestions shown while nothing is being typed
    private int nseq = 0;
    private int sel = 0, seq = 0, shownSeq = 0, composingLen = 0;
    private boolean autoSpace = false;               // the last thing typed was a word followed by our own space
    private long lastEdit = 0;
    private final List<Act> queue = new ArrayList<>();

    // mode
    private boolean odiaMode = true, forcedEn = false, numeric = false;

    private SharedPreferences prefs;
    private final List<String[]> hist = new ArrayList<>();

    // views
    private LinearLayout root, bar, candRow;
    private HorizontalScrollView candScroll;
    private TextView modeChip, hintView, romanLbl;
    private final TextView[] chips = new TextView[NCHIP];
    private KeyboardView kb;
    private boolean night = false;
    private int cBar, cChipText, cChipDim, cSel, cSelText, cHint, cModeBg;

    // ------------------------------------------------------------------ engine (hidden WebView)
    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("sulekhak", Context.MODE_PRIVATE);
        odiaMode = prefs.getBoolean("odia_mode", true);
        loadHistory();
        initWeb();
    }

    private void initWeb() {
        try {
            web = new WebView(this);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            web.addJavascriptInterface(new Bridge(), "Android");
            web.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                    return serve(r.getUrl() == null ? null : r.getUrl().getHost(), r.getUrl() == null ? null : r.getUrl().getPath());
                }

                @Override
                public void onPageFinished(WebView v, String url) {
                    sendReplay();
                }

                @Override
                public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                    ready = false;
                    try { web.destroy(); } catch (Exception ignored) { }
                    web = null;
                    handler.postDelayed(new Runnable() { public void run() { initWeb(); } }, 1000);
                    return true;
                }
            });
            web.loadUrl("https://" + HOST + "/ime.html");
        } catch (Throwable t) {
            web = null;     // no WebView on this device: the keyboard still types, only without suggestions
        }
    }

    private WebResourceResponse serve(String host, String path) {
        if (!HOST.equals(host) || path == null || path.length() < 2) return null;
        String p = path.substring(1);
        try {
            InputStream in = getAssets().open(p);
            String mime = p.endsWith(".html") ? "text/html" : (p.endsWith(".js") ? "text/javascript" : "text/plain");
            return new WebResourceResponse(mime, "utf-8", in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
        }
    }

    private void sendReplay() {
        if (web == null) return;
        try {
            JSONArray a = new JSONArray();
            for (String[] h : hist) { JSONArray p = new JSONArray(); p.put(h[0]); p.put(h[1]); a.put(p); }
            web.evaluateJavascript("imeReplay(" + a.toString() + ")", null);
        } catch (Exception ignored) { }
    }

    public class Bridge {
        @JavascriptInterface
        public void post(final String s) {
            handler.post(new Runnable() { public void run() { onMsg(s); } });
        }
    }

    private void onMsg(String s) {
        try {
            JSONObject o = new JSONObject(s);
            String t = o.optString("t");
            if ("ready".equals(t)) {
                ready = true;
                renderBar();
            } else if ("n".equals(t)) {
                if (o.optInt("id", -1) != nseq || buf.length() != 0) return;
                JSONArray l = o.getJSONArray("list");
                List<String> n = new ArrayList<>();
                for (int i = 0; i < l.length() && i < NCHIP; i++) n.add(l.getString(i));
                nextList = n;
                renderBar();
            } else if ("c".equals(t)) {
                if (o.optInt("id", -1) != seq || buf.length() == 0) return;
                JSONArray l = o.getJSONArray("list");
                List<String> n = new ArrayList<>();
                for (int i = 0; i < l.length(); i++) n.add(l.getString(i));
                if (n.isEmpty()) n.add(buf.toString());
                cands = n;
                sel = 0;
                shownSeq = seq;
                shownBuf = buf.toString();
                updateComposing();
                renderBar();
                if (candScroll != null) candScroll.scrollTo(0, 0);
                drain();
            }
        } catch (Exception ignored) { }
    }

    private void query() {
        if (buf.length() == 0) { clearBuffer(); return; }
        seq++;
        if (web == null) {
            cands = new ArrayList<>();
            cands.add(buf.toString());
            sel = 0;
            shownSeq = seq;
            shownBuf = buf.toString();
            updateComposing();
            renderBar();
            return;
        }
        web.evaluateJavascript("imeQuery(" + seq + "," + JSONObject.quote(buf.toString()) + "," + JSONObject.quote(prevCtx) + ")", null);
    }

    /** Asks the engine which words usually follow `word`; the answer arrives as a "n" message and is shown as chips. */
    private void requestNext(String word) {
        nseq++;
        nextList = new ArrayList<>();
        if (web == null || !ready || !hasNonAscii(word) || word.length() < 2) return;
        web.evaluateJavascript("imeNext(" + nseq + "," + JSONObject.quote(word) + ")", null);
    }

    /** A next-word chip was tapped: put the word in with a space and look for the word after it. */
    private void pickNext(int idx) {
        if (idx < 0 || idx >= nextList.size()) return;
        String w = nextList.get(idx);
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(w + " ", 1);
        autoSpace = true;
        stamp();
        if (web != null) web.evaluateJavascript("imeCommit(\"\"," + JSONObject.quote(w) + ")", null);
        requestNext(w);
        renderBar();
    }

    /** The Odia word before the one being typed (for next-word statistics); "<s>" at the start of a sentence. */
    private String prevWord() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "<s>";
        CharSequence t = ic.getTextBeforeCursor(80, 0);
        if (t == null) return "<s>";
        String s = t.toString();
        int i = s.length() - 1;
        while (i >= 0 && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) i--;
        int e = i;
        while (i >= 0) {
            char c = s.charAt(i);
            boolean odia = (c >= 0x0B00 && c <= 0x0B7F && c != 0x0B64 && c != 0x0B65);
            if (odia || c == 0x200C || c == 0x200D) i--; else break;
        }
        if (e < 0 || i == e) return "<s>";
        return s.substring(i + 1, e + 1);
    }

    // ------------------------------------------------------------------ history (the memory cache)
    private void loadHistory() {
        hist.clear();
        String h = prefs.getString("hist", "");
        for (String line : h.split("\n")) {
            int p = line.indexOf('\t');
            if (p > 0 && p < line.length() - 1) hist.add(new String[]{line.substring(0, p), line.substring(p + 1)});
        }
    }

    private void remember(String roman, String word) {
        hist.add(new String[]{roman, word});
        while (hist.size() > HIST_MAX) hist.remove(0);
        StringBuilder sb = new StringBuilder();
        for (String[] h : hist) sb.append(h[0]).append('\t').append(h[1]).append('\n');
        prefs.edit().putString("hist", sb.toString()).apply();
        if (web != null) web.evaluateJavascript("imeCommit(" + JSONObject.quote(roman) + "," + JSONObject.quote(word) + ")", null);
    }

    // ------------------------------------------------------------------ small helpers
    private static boolean hasNonAscii(String s) {
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) > 127) return true;
        return false;
    }

    private static boolean wordContinues(String w) {
        if (w.isEmpty()) return true;
        char last = w.charAt(w.length() - 1);
        return last == 0x0B4D || last == 0x200C;
    }

    private static boolean isDots(CharSequence s) {
        if (s.length() == 0) return false;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) != '.') return false;
        return true;
    }

    private static boolean isDigits(String s) {
        if (s.length() == 0) return false;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) < '0' || s.charAt(i) > '9') return false;
        return true;
    }

    private static boolean isPunct(String t) {
        return t.length() == 1 && ",.;:!?।".indexOf(t.charAt(0)) >= 0;
    }

    private boolean effectiveOdia() { return odiaMode && !forcedEn && !numeric; }

    private void stamp() { lastEdit = SystemClock.uptimeMillis(); }

    // ------------------------------------------------------------------ the key queue
    private void act(boolean fresh, Runnable r) {
        if (!queue.isEmpty()) { queue.add(new Act(fresh, r)); return; }
        if (fresh && buf.length() > 0 && shownSeq != seq && web != null) {
            queue.add(new Act(fresh, r));
            handler.removeCallbacks(watchdog);
            handler.postDelayed(watchdog, 700);
            return;
        }
        r.run();
    }

    private void drain() {
        while (!queue.isEmpty()) {
            Act a = queue.get(0);
            if (a.fresh && buf.length() > 0 && shownSeq != seq && web != null) {
                handler.removeCallbacks(watchdog);
                handler.postDelayed(watchdog, 700);
                break;
            }
            queue.remove(0);
            a.run.run();
        }
    }

    private final Runnable watchdog = new Runnable() {
        public void run() {          // the engine did not answer in time: carry on with what is shown
            if (buf.length() > 0 && shownSeq != seq) {
                if (cands.isEmpty()) { cands = new ArrayList<>(); cands.add(buf.toString()); }
                shownSeq = seq;
                if (shownBuf.length() == 0) shownBuf = buf.toString();
                updateComposing();
                renderBar();
            }
            drain();
        }
    };

    // ------------------------------------------------------------------ typing logic
    private void updateComposing() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || cands.isEmpty()) return;
        String shown = cands.get(sel < cands.size() ? sel : 0);
        ic.setComposingText(shown, 1);
        composingLen = shown.length();
        stamp();
    }

    private void clearBuffer() {
        buf.setLength(0);
        cands = new ArrayList<>();
        shownBuf = "";
        sel = 0;
        composingLen = 0;
        shownSeq = seq;
        renderBar();
    }

    private void finishComposing() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.finishComposingText();
        stamp();
    }

    private void commitCandidate(int idx, boolean space) {
        if (buf.length() == 0) return;
        String roman = shownBuf.length() > 0 ? shownBuf : buf.toString();
        String word = (idx >= 0 && idx < cands.size()) ? cands.get(idx) : roman;
        boolean sp = space && !wordContinues(word);
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(word + (sp ? " " : ""), 1);
        stamp();
        autoSpace = sp;
        if (idx != 1 && hasNonAscii(word) && !isDots(roman) && !isDigits(roman)) remember(roman, word);
        clearBuffer();
        if (sp) requestNext(word); else nextList = new ArrayList<>();
    }

    private void commitDirect(String t) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (autoSpace && isPunct(t)) {            // "word ." becomes "word." when the space was ours
            CharSequence b = ic.getTextBeforeCursor(1, 0);
            if (b != null && b.length() == 1 && b.charAt(0) == ' ') ic.deleteSurroundingText(1, 0);
        }
        ic.commitText(t, 1);
        autoSpace = false;
        nextList = new ArrayList<>();
        stamp();
        renderBar();
    }

    private void flushPending() {
        if (buf.length() > 0) commitCandidate(sel, false);
    }

    private void typeLetter(String ch) {
        if (!effectiveOdia()) { commitDirect(ch); return; }
        if (buf.length() > 0 && isDots(buf)) commitCandidate(sel, false);
        if (buf.length() == 0) { prevCtx = prevWord(); nextList = new ArrayList<>(); }
        buf.append(ch);
        autoSpace = false;
        query();
    }

    private void typeRomanSym(String s) {
        if (!effectiveOdia()) { commitDirect(s); return; }
        if (s.equals(".")) {
            if (buf.length() > 0 && isDots(buf)) { buf.append('.'); query(); return; }
            flushPending();
            InputConnection ic = getCurrentInputConnection();
            if (autoSpace && ic != null) {
                CharSequence b = ic.getTextBeforeCursor(1, 0);
                if (b != null && b.length() == 1 && b.charAt(0) == ' ') ic.deleteSurroundingText(1, 0);
            }
            autoSpace = false;
            prevCtx = prevWord();
            nextList = new ArrayList<>();
            buf.append('.');
            query();
            return;
        }
        if (s.equals(">") && buf.length() == 0) { commitDirect("଼"); return; }   // nukta after the letter before it
        if (buf.length() == 0) { prevCtx = prevWord(); nextList = new ArrayList<>(); }
        buf.append(s);
        autoSpace = false;
        query();
    }

    private void typeOther(String t) {
        flushPending();
        commitDirect(t);
    }

    private void doSpace() {
        if (buf.length() > 0) { commitCandidate(sel, true); return; }
        commitDirect(" ");
    }

    private void doBackspace() {
        InputConnection ic = getCurrentInputConnection();
        autoSpace = false;
        if (buf.length() > 0) {
            buf.setLength(buf.length() - 1);
            if (buf.length() == 0) {
                if (ic != null) { ic.setComposingText("", 1); ic.finishComposingText(); }
                stamp();
                clearBuffer();
            } else {
                query();
            }
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
            stamp();
        }
    }

    private void doEnter() {
        flushPending();
        autoSpace = false;
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        int action = ei == null ? EditorInfo.IME_ACTION_NONE : (ei.imeOptions & EditorInfo.IME_MASK_ACTION);
        boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        if (ic != null && !multi && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
        stamp();
    }

    private void doTab() {
        if (buf.length() > 0 && cands.size() > 1) {      // Tab walks through the candidates, like on the web page
            sel = (sel + 1) % cands.size();
            updateComposing();
            renderBar();
            return;
        }
        flushPending();
        EditorInfo ei = getCurrentInputEditorInfo();
        boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        if (multi) commitDirect("\t");
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_TAB);
        stamp();
    }

    private void moveCursor(int dir) {
        flushPending();
        autoSpace = false;
        sendDownUpKeyEvents(dir < 0 ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT);
        stamp();
    }

    private void toggleMode() {
        act(true, new Runnable() {
            public void run() {
                flushPending();
                odiaMode = !odiaMode;
                prefs.edit().putBoolean("odia_mode", odiaMode).apply();
                applyMode();
            }
        });
    }

    private void applyMode() {
        if (kb == null) return;
        kb.setOdiaMode(effectiveOdia());
        kb.setSpaceLabel(effectiveOdia() ? "ଓଡ଼ିଆ" : "English");
        renderBar();
    }

    private void switchKeyboard(boolean picker) {
        flushPending();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) return;
        if (picker) { imm.showInputMethodPicker(); return; }
        boolean ok = false;
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ok = switchToNextInputMethod(false);
            } else {
                IBinder tok = getWindow().getWindow().getAttributes().token;
                ok = imm.switchToNextInputMethod(tok, false);
            }
        } catch (Throwable ignored) { }
        if (!ok) imm.showInputMethodPicker();
    }

    // ------------------------------------------------------------------ KeyboardView.Host
    @Override
    public void onKey(int code, final String text) {
        if (!nextList.isEmpty() && code != KeyboardView.K_LETTER && code != KeyboardView.K_ROMAN_SYM && code != KeyboardView.K_TEXT && code != KeyboardView.K_SPACE) {
            nextList = new ArrayList<>();      // anything but typing a word drops the next-word chips
            renderBar();
        }
        switch (code) {
            case KeyboardView.K_LETTER:
                act(false, new Runnable() { public void run() { typeLetter(text); } });
                break;
            case KeyboardView.K_ROMAN_SYM:
                act(false, new Runnable() { public void run() { typeRomanSym(text); } });
                break;
            case KeyboardView.K_TEXT:
                act(true, new Runnable() { public void run() { typeOther(text); } });
                break;
            case KeyboardView.K_SPACE:
                act(true, new Runnable() { public void run() { doSpace(); } });
                break;
            case KeyboardView.K_BACKSPACE:
                act(false, new Runnable() { public void run() { doBackspace(); } });
                break;
            case KeyboardView.K_ENTER:
                act(true, new Runnable() { public void run() { doEnter(); } });
                break;
            case KeyboardView.K_TAB:
                act(true, new Runnable() { public void run() { doTab(); } });
                break;
            case KeyboardView.K_LEFT:
                act(true, new Runnable() { public void run() { moveCursor(-1); } });
                break;
            case KeyboardView.K_RIGHT:
                act(true, new Runnable() { public void run() { moveCursor(1); } });
                break;
            case KeyboardView.K_GLOBE:
                act(true, new Runnable() { public void run() { switchKeyboard(false); } });
                break;
            case KeyboardView.K_PICKER:
                act(true, new Runnable() { public void run() { switchKeyboard(true); } });
                break;
            case KeyboardView.K_DIGITS:
                prefs.edit().putBoolean("digits_odia", "odia".equals(text)).apply();
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------ input session
    @Override
    public boolean onEvaluateFullscreenMode() { return false; }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        handler.removeCallbacks(watchdog);
        queue.clear();
        buf.setLength(0);
        cands = new ArrayList<>();
        shownBuf = "";
        composingLen = 0;
        shownSeq = seq;
        autoSpace = false;
        nextList = new ArrayList<>();
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE || cls == InputType.TYPE_CLASS_DATETIME;
        forcedEn = cls == InputType.TYPE_CLASS_TEXT && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_URI);
        if (kb == null) return;
        night = isNight();
        applyTheme();
        kb.setOdiaDigits(prefs.getBoolean("digits_odia", false));
        kb.setLayer(numeric ? KeyboardView.L_NUM : KeyboardView.L_ABC);
        applyMode();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        finishComposing();
        buf.setLength(0);
        cands = new ArrayList<>();
        composingLen = 0;
        queue.clear();
        super.onFinishInputView(finishingInput);
    }

    @Override
    public void onFinishInput() {
        finishComposing();
        buf.setLength(0);
        cands = new ArrayList<>();
        composingLen = 0;
        super.onFinishInput();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candStart, int candEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candStart, candEnd);
        if (buf.length() == 0 && !nextList.isEmpty() && SystemClock.uptimeMillis() - lastEdit > 250) {     // the cursor was moved by hand: the next-word chips no longer fit
            nextList = new ArrayList<>();
            renderBar();
            return;
        }
        if (buf.length() == 0 || composingLen == 0) return;
        if (SystemClock.uptimeMillis() - lastEdit < 150) return;     // an echo of something this keyboard just did
        boolean inside = candStart >= 0 && candEnd >= candStart && newSelStart >= candStart && newSelEnd <= candEnd;
        if (!inside) {                                              // the cursor was moved elsewhere: settle the word as shown
            finishComposing();
            queue.clear();
            clearBuffer();
        }
    }

    @Override
    public void onDestroy() {
        try { if (web != null) web.destroy(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ views
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    @Override
    public View onCreateInputView() {
        night = isNight();
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        modeChip = new TextView(this);
        modeChip.setGravity(Gravity.CENTER);
        modeChip.setTextSize(17);
        modeChip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { toggleMode(); }
        });
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(44), dp(34));
        mlp.setMargins(dp(6), 0, dp(4), 0);
        bar.addView(modeChip, mlp);

        candScroll = new HorizontalScrollView(this);
        candScroll.setHorizontalScrollBarEnabled(false);
        candScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        candRow = new LinearLayout(this);
        candRow.setOrientation(LinearLayout.HORIZONTAL);
        candRow.setGravity(Gravity.CENTER_VERTICAL);
        candScroll.addView(candRow, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        hintView = new TextView(this);
        hintView.setTextSize(14);
        hintView.setPadding(dp(8), 0, dp(10), 0);
        hintView.setGravity(Gravity.CENTER_VERTICAL);
        candRow.addView(hintView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        romanLbl = new TextView(this);
        romanLbl.setTextSize(13);
        romanLbl.setPadding(dp(6), 0, dp(6), 0);
        romanLbl.setGravity(Gravity.CENTER_VERTICAL);
        romanLbl.setVisibility(View.GONE);
        candRow.addView(romanLbl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        for (int i = 0; i < NCHIP; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setTextSize(20);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(13), 0, dp(13), 0);
            t.setVisibility(View.GONE);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { if (buf.length() == 0 && !nextList.isEmpty()) pickNext(idx); else commitCandidate(idx, true); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.setMargins(dp(2), dp(6), dp(2), dp(6));
            candRow.addView(t, lp);
            chips[i] = t;
        }
        bar.addView(candScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        kb = new KeyboardView(this);
        kb.setHost(this);
        root.addView(kb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        kb.setOdiaDigits(prefs.getBoolean("digits_odia", false));
        applyTheme();
        applyMode();
        return root;
    }

    private void applyTheme() {
        if (kb == null) return;
        kb.setNight(night);
        if (night) {
            cBar = 0xFF262D44; cChipText = 0xFFEAEEFA; cChipDim = 0xFF9AA4C4; cSel = 0xFF4F7BE8; cSelText = 0xFFFFFFFF; cHint = 0xFF9AA4C4; cModeBg = 0xFF3B4466;
        } else {
            cBar = 0xFFD3D8E6; cChipText = 0xFF283044; cChipDim = 0xFF6B7490; cSel = 0xFF3A63D0; cSelText = 0xFFFFFFFF; cHint = 0xFF6B7490; cModeBg = 0xFFF6F7FB;
        }
        root.setBackgroundColor(kb.bgColor());
        bar.setBackgroundColor(cBar);
        GradientDrawable g = new GradientDrawable();
        g.setColor(cModeBg);
        g.setCornerRadius(dp(9));
        modeChip.setBackground(g);
        modeChip.setTextColor(cChipText);
        hintView.setTextColor(cHint);
        romanLbl.setTextColor(cChipDim);
    }

    /** Updates the strip in place (no views are created or removed), so nothing flickers while typing. */
    private void renderBar() {
        if (candRow == null) return;
        boolean odia = effectiveOdia();
        modeChip.setText(odia ? "ଓ" : "A");
        boolean has = buf.length() > 0 && !cands.isEmpty();
        boolean nxt = !has && buf.length() == 0 && odia && !nextList.isEmpty();
        if (!has && !nxt) {
            hintView.setText(!odia ? "English typing" : (ready ? "Sulekhak  ·  type in Roman letters" : "Sulekhak  ·  type in Roman letters (smart suggestions loading)"));
            hintView.setVisibility(View.VISIBLE);
        } else {
            hintView.setVisibility(View.GONE);
        }
        if (has) {
            romanLbl.setText(shownBuf.length() > 0 ? shownBuf : buf.toString());
            romanLbl.setVisibility(View.VISIBLE);
        } else {
            romanLbl.setVisibility(View.GONE);
        }
        for (int i = 0; i < NCHIP; i++) {
            TextView t = chips[i];
            if (nxt && i < nextList.size()) {
                String w = nextList.get(i);
                if (!w.contentEquals(t.getText())) t.setText(w);
                t.setTextColor(cChipText);
                t.setBackground(null);
                t.setVisibility(View.VISIBLE);
            } else if (has && i < cands.size()) {
                String w = cands.get(i);
                if (!w.contentEquals(t.getText())) t.setText(w);
                boolean on = i == sel;
                t.setTextColor(on ? cSelText : (i == 1 ? cChipDim : cChipText));
                if (on) {
                    GradientDrawable g = new GradientDrawable();
                    g.setColor(cSel);
                    g.setCornerRadius(dp(9));
                    t.setBackground(g);
                } else {
                    t.setBackground(null);
                }
                t.setVisibility(View.VISIBLE);
            } else if (t.getVisibility() != View.GONE) {
                t.setVisibility(View.GONE);
            }
        }
    }
}
