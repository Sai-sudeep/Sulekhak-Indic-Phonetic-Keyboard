package com.saisudeep.sulekhak;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

/** Google answers here after the browser sign-in. It finishes the exchange off the main thread, then returns to the setup screen. */
public class OAuthRedirectActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final Uri data = getIntent() == null ? null : getIntent().getData();
        final android.content.Context app = getApplicationContext();
        new Thread(new Runnable() {
            public void run() {
                final String err = GoogleAuth.finish(app, data);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        Toast.makeText(app, err == null ? "Signed in. Your typing preferences now sync." : err, Toast.LENGTH_LONG).show();
                        Intent i = new Intent(app, SetupActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(i);
                        finish();
                    }
                });
            }
        }, "sk-oauth").start();
    }
}
