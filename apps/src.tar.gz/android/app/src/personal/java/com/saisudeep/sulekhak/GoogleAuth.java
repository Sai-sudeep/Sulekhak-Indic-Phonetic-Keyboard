package com.saisudeep.sulekhak;

import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Tasks;

import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Sign-in with Google for the personal build.
 *  Main route: Google's own Authorization API (Google Play services): the account picker and consent screen appear inside the phone, Google checks this app by
 *  its package name and signing key (the Android OAuth client), and gives a short-lived access token whenever one is asked for - nothing secret is stored here.
 *  Fallback when Play services are missing: the browser opens, Google answers to com.saisudeep.sulekhak:/oauth2redirect (PKCE) and only the refresh token is kept,
 *  encrypted with a key that lives in the Android Keystore. Only accounts on the allowed list (BuildConfig) are accepted on both routes. */
final class GoogleAuth {
    static final String REDIRECT = "com.saisudeep.sulekhak:/oauth2redirect";
    private static final String PREFS = "sulekhak_google";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    interface Listener { void onChanged(); }
    private static final List<Listener> LISTENERS = new ArrayList<>();
    static synchronized void listen(Listener l) { if (!LISTENERS.contains(l)) LISTENERS.add(l); }
    static synchronized void unlisten(Listener l) { LISTENERS.remove(l); }
    private static void changed() {
        final List<Listener> copy;
        synchronized (GoogleAuth.class) { copy = new ArrayList<>(LISTENERS); }
        MAIN.post(new Runnable() { public void run() { for (Listener l : copy) { try { l.onChanged(); } catch (Exception ignored) { } } } });
    }

    private static String access;
    private static long accessExp;
    private static String lastError = "";
    static String lastError() { return lastError; }

    static boolean configured() { return BuildConfig.GOOGLE_CLIENT_ID.length() > 0; }
    static boolean allowed(String email) {
        if (email == null) return false;
        for (String a : BuildConfig.GOOGLE_ALLOWED.split(",")) if (a.trim().equalsIgnoreCase(email.trim())) return true;
        return false;
    }
    static String allowedJson() {
        StringBuilder sb = new StringBuilder("[");
        String[] a = BuildConfig.GOOGLE_ALLOWED.split(",");
        for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(','); sb.append(JSONObject.quote(a[i].trim().toLowerCase(Locale.ROOT))); }
        return sb.append(']').toString();
    }

    // ---------------------------------------------------------------- the stored refresh token (Keystore-encrypted)
    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias("sulekhak_tok")) {
            KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder("sulekhak_tok", KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
            g.generateKey();
        }
        return (SecretKey) ks.getKey("sulekhak_tok", null);
    }
    private static void store(Context c, String refresh, String email) {
        try {
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.ENCRYPT_MODE, key());
            byte[] ct = ci.doFinal(refresh.getBytes(StandardCharsets.UTF_8));
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString("r", Base64.encodeToString(ct, Base64.NO_WRAP)).putString("iv", Base64.encodeToString(ci.getIV(), Base64.NO_WRAP))
                    .putString("e", email).apply();
        } catch (Exception e) { lastError = "could not store the sign-in: " + e.getMessage(); }
    }
    private static String refreshToken(Context c) {
        try {
            SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String r = p.getString("r", null), iv = p.getString("iv", null);
            if (r == null || iv == null) return null;
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
            return new String(ci.doFinal(Base64.decode(r, Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (Exception e) { return null; }
    }
    static String email(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("e", ""); }
    static boolean signedIn(Context c) { return isNative(c) || refreshToken(c) != null; }
    private static boolean isNative(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("native", false); }
    static void signOut(final Context c) {
        final String r = refreshToken(c);
        final String mail = email(c);
        final boolean nat = isNative(c);
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply();
        if (nat && mail.length() > 0) new Thread(new Runnable() { public void run() { revokeNative(c, mail); } }, "sk-revoke").start();
        access = null; accessExp = 0;
        if (r != null) new Thread(new Runnable() { public void run() { try { post("https://oauth2.googleapis.com/revoke", "token=" + enc(r)); } catch (Exception ignored) { } } }).start();
        changed();
    }
    /** a stable name for this phone's slot in the shared files */
    static String deviceId(Context c) {
        SharedPreferences p = c.getSharedPreferences("sulekhak", Context.MODE_PRIVATE);
        String id = p.getString("learn_device", null);
        if (id == null) { id = "a" + String.format(Locale.ROOT, "%08x", new SecureRandom().nextInt()); p.edit().putString("learn_device", id).apply(); }
        return id;
    }


    // ---------------------------------------------------------------- the Google Play services route
    static final int RC_AUTH = 4711;
    private static final String[] SCOPES = {"https://www.googleapis.com/auth/drive.appdata", "https://www.googleapis.com/auth/userinfo.email", "openid"};

    private static AuthorizationRequest nativeRequest(String mail) {
        List<Scope> sc = new ArrayList<>();
        for (String x : SCOPES) sc.add(new Scope(x));
        AuthorizationRequest.Builder b = AuthorizationRequest.builder().setRequestedScopes(sc);
        if (mail != null && mail.length() > 0) b.setAccount(new Account(mail, "com.google"));
        return b.build();
    }
    /** take back the grant: Google's revoke endpoint with a token for the account (this version of Play services has no revoke call of its own) */
    private static void revokeNative(Context c, String mail) {
        try {
            AuthorizationResult res = Tasks.await(Identity.getAuthorizationClient(c).authorize(nativeRequest(mail)), 15, TimeUnit.SECONDS);
            if (!res.hasResolution() && res.getAccessToken() != null) post("https://oauth2.googleapis.com/revoke", "token=" + enc(res.getAccessToken()));
        } catch (Exception ignored) { }
    }
    /** the email that owns a token, from Google's userinfo answer */
    private static String emailOf(String token) {
        try {
            HttpURLConnection h = (HttpURLConnection) new URL("https://www.googleapis.com/oauth2/v3/userinfo").openConnection();
            h.setConnectTimeout(15000); h.setReadTimeout(20000);
            h.setRequestProperty("Authorization", "Bearer " + token);
            if (h.getResponseCode() != 200) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(h.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(); String ln; while ((ln = br.readLine()) != null) sb.append(ln); br.close();
            JSONObject o = new JSONObject(sb.toString());
            if (o.has("email_verified") && !o.optBoolean("email_verified", true)) return null;
            return o.getString("email").toLowerCase(Locale.ROOT);
        } catch (Exception e) { return null; }
    }
    /** an answer of the Authorization API (on a background thread): check the account, remember it */
    private static String acceptNative(Context c, AuthorizationResult res) {
        String tok = res.getAccessToken();
        if (tok == null) return "Google gave no access.";
        String mail = emailOf(tok);
        if (!allowed(mail)) {
            try { post("https://oauth2.googleapis.com/revoke", "token=" + enc(tok)); } catch (Exception ignored) { }
            return (mail == null ? "That account" : mail) + " is not an authorised account for this app.";
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().putBoolean("native", true).putString("e", mail).apply();
        access = tok; accessExp = System.currentTimeMillis() + 3000 * 1000L;
        lastError = "";
        changed();
        return null;
    }
    /** SetupActivity forwards onActivityResult here */
    static void onNativeResult(final Activity a, int requestCode, final Intent data) {
        if (requestCode != RC_AUTH) return;
        new Thread(new Runnable() {
            public void run() {
                String err;
                try {
                    if (data == null) err = "Sign-in was cancelled.";
                    else err = acceptNative(a, Identity.getAuthorizationClient(a).getAuthorizationResultFromIntent(data));
                } catch (Exception e) { err = "Sign-in failed: " + e.getMessage(); }
                final String msg = err;
                if (msg != null) lastError = msg;
                MAIN.post(new Runnable() { public void run() {
                    android.widget.Toast.makeText(a, msg == null ? "Signed in. Your typing preferences now sync." : msg, android.widget.Toast.LENGTH_LONG).show();
                    changed();
                } });
            }
        }, "sk-auth").start();
    }
    private static void startNative(final Activity a) {
        Identity.getAuthorizationClient(a).authorize(nativeRequest(null)).addOnSuccessListener(new OnSuccessListener<AuthorizationResult>() {
            public void onSuccess(final AuthorizationResult res) {
                if (res.hasResolution()) {
                    try { a.startIntentSenderForResult(res.getPendingIntent().getIntentSender(), RC_AUTH, null, 0, 0, 0); }
                    catch (Exception e) { lastError = "could not open the Google screen: " + e.getMessage(); changed(); }
                } else {
                    new Thread(new Runnable() { public void run() { String err = acceptNative(a, res); if (err != null) lastError = err; changed(); } }, "sk-auth").start();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            public void onFailure(Exception e) { lastError = "Google sign-in: " + e.getMessage(); changed(); }
        });
    }
    /** a token, silently, through Play services; null when the grant is gone (then the user must sign in again) */
    private static String[] nativeAccess(Context c) {
        try {
            if (access != null && System.currentTimeMillis() < accessExp - 120000)
                return new String[]{access, String.valueOf(Math.max(60, (accessExp - System.currentTimeMillis()) / 1000)), email(c)};
            AuthorizationResult res = Tasks.await(Identity.getAuthorizationClient(c).authorize(nativeRequest(email(c))), 25, TimeUnit.SECONDS);
            if (res.hasResolution() || res.getAccessToken() == null) {
                lastError = "Google needs you to sign in again.";
                c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply();
                access = null; accessExp = 0; changed();
                return null;
            }
            access = res.getAccessToken(); accessExp = System.currentTimeMillis() + 3000 * 1000L;
            return new String[]{access, "3000", email(c)};
        } catch (Exception e) {
            lastError = String.valueOf(e.getMessage());      // no network, etc.: keep the sign-in, try again later
            return null;
        }
    }

    // ---------------------------------------------------------------- sign in
    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }
    private static String b64url(byte[] b) { return Base64.encodeToString(b, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING); }

    static void startSignIn(Activity a) {
        if (!configured()) { lastError = "Sign-in is not set up in this build."; changed(); return; }
        try {
            if (com.google.android.gms.common.GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(a) == com.google.android.gms.common.ConnectionResult.SUCCESS) startNative(a);
            else startBrowser(a, null);          // no Google Play services on this phone
        } catch (Throwable t) { lastError = "Google sign-in: " + t.getMessage(); changed(); }
    }

    /** the browser route (used only when Google Play services cannot do it) */
    private static void startBrowser(Activity a, Throwable why) {
        try {
            SecureRandom r = new SecureRandom();
            byte[] v = new byte[48]; r.nextBytes(v);
            byte[] s = new byte[16]; r.nextBytes(s);
            String verifier = b64url(v), state = b64url(s);
            String challenge = b64url(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
            a.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("pv", verifier).putString("ps", state).apply();
            String url = "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + enc(BuildConfig.GOOGLE_CLIENT_ID) + "&redirect_uri=" + enc(REDIRECT)
                    + "&response_type=code&scope=" + enc("openid email https://www.googleapis.com/auth/drive.appdata")
                    + "&code_challenge=" + challenge + "&code_challenge_method=S256&state=" + state + "&access_type=offline&prompt=select_account%20consent";
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) { lastError = "could not open the browser: " + e.getMessage(); changed(); }
    }

    /** called by OAuthRedirectActivity on a background thread */
    static String finish(Context c, Uri data) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String state = p.getString("ps", null), verifier = p.getString("pv", null);
        p.edit().remove("ps").remove("pv").apply();
        if (data == null) return "No answer from Google.";
        if (data.getQueryParameter("error") != null) return "Google: " + data.getQueryParameter("error");
        if (state == null || !state.equals(data.getQueryParameter("state"))) return "The answer did not match the request.";
        String code = data.getQueryParameter("code");
        if (code == null || verifier == null) return "No code came back.";
        try {
            JSONObject j = post("https://oauth2.googleapis.com/token", "code=" + enc(code) + "&client_id=" + enc(BuildConfig.GOOGLE_CLIENT_ID)
                    + "&redirect_uri=" + enc(REDIRECT) + "&grant_type=authorization_code&code_verifier=" + enc(verifier));
            String mail = emailFromIdToken(j.optString("id_token", ""));
            if (!allowed(mail)) {
                try { post("https://oauth2.googleapis.com/revoke", "token=" + enc(j.optString("access_token"))); } catch (Exception ignored) { }
                return (mail == null ? "That account" : mail) + " is not an authorised account for this app.";
            }
            String refresh = j.optString("refresh_token", "");
            if (refresh.isEmpty()) return "Google did not give a long-lived sign-in (try again).";
            store(c, refresh, mail);
            access = j.getString("access_token"); accessExp = System.currentTimeMillis() + j.optInt("expires_in", 3000) * 1000L;
            lastError = "";
            changed();
            return null;
        } catch (Exception e) { return "Sign-in failed: " + e.getMessage(); }
    }

    private static String emailFromIdToken(String jwt) {
        try {
            String[] parts = jwt.split("\\.");
            JSONObject o = new JSONObject(new String(Base64.decode(parts[1], Base64.URL_SAFE), StandardCharsets.UTF_8));
            if (o.has("email_verified") && !o.optBoolean("email_verified", true)) return null;
            return o.getString("email").toLowerCase(Locale.ROOT);
        } catch (Exception e) { return null; }
    }

    private static JSONObject post(String url, String body) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setRequestMethod("POST"); h.setDoOutput(true); h.setConnectTimeout(15000); h.setReadTimeout(20000);
        h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        OutputStream os = h.getOutputStream(); os.write(body.getBytes(StandardCharsets.UTF_8)); os.close();
        int code = h.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? h.getInputStream() : h.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) { BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); String ln; while ((ln = br.readLine()) != null) sb.append(ln); br.close(); }
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + " " + (sb.length() > 120 ? sb.substring(0, 120) : sb));
        return sb.length() == 0 ? new JSONObject() : new JSONObject(sb.toString());
    }

    /** a valid access token, refreshed when it is about to run out: {token, seconds, email}, or null when signed out. Blocking: call from a background thread. */
    static synchronized String[] access(Context c) {
        if (isNative(c)) return nativeAccess(c);
        String r = refreshToken(c);
        if (r == null) return null;
        try {
            if (access == null || System.currentTimeMillis() > accessExp - 120000) {
                JSONObject j = post("https://oauth2.googleapis.com/token", "client_id=" + enc(BuildConfig.GOOGLE_CLIENT_ID) + "&refresh_token=" + enc(r) + "&grant_type=refresh_token");
                access = j.getString("access_token"); accessExp = System.currentTimeMillis() + j.optInt("expires_in", 3000) * 1000L;
            }
            long secs = Math.max(60, (accessExp - System.currentTimeMillis()) / 1000);
            return new String[]{access, String.valueOf(secs), email(c)};
        } catch (Exception e) {
            lastError = String.valueOf(e.getMessage());
            if (lastError.contains("invalid_grant")) signOut(c);          // expired or revoked: sign in again
            return null;
        }
    }

    // ---------------------------------------------------------------- local copy of each language file
    private static boolean goodLang(String l) { return "or".equals(l) || "hi".equals(l) || "mr".equals(l) || "bn".equals(l) || "as".equals(l) || "en".equals(l); }
    static String readLang(Context c, String lang) {
        if (!goodLang(lang)) return "";
        try {
            File f = new File(new File(c.getFilesDir(), "learning"), lang + ".json");
            if (!f.exists()) return "";
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] b = new byte[(int) f.length()]; int n = 0; while (n < b.length) { int k = in.read(b, n, b.length - n); if (k < 0) break; n += k; }
            in.close();
            return new String(b, 0, n, StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }
    static void writeLang(Context c, String lang, String text) {
        if (!goodLang(lang) || text == null || text.isEmpty()) return;
        try {
            File dir = new File(c.getFilesDir(), "learning"); dir.mkdirs();
            File f = new File(dir, lang + ".json"), t = new File(dir, lang + ".json.tmp");
            FileOutputStream o = new FileOutputStream(t); o.write(text.getBytes(StandardCharsets.UTF_8)); o.getFD().sync(); o.close();
            if (f.exists()) { File bak = new File(dir, lang + ".json.bak"); bak.delete(); f.renameTo(bak); }
            t.renameTo(f);
        } catch (Exception ignored) { }
    }
}
