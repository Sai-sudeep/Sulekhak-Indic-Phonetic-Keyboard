package com.saisudeep.sulekhak;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.security.SecureRandom;
import java.util.Locale;

/** The public app has no Google sign-in, no network permission and no Google libraries: this is the stand-in for the personal build's GoogleAuth.
 *  It only keeps the local copy of what the keyboard learns (one file per language, on this phone). */
final class GoogleAuth {
    interface Listener { void onChanged(); }
    static void listen(Listener l) { }
    static void unlisten(Listener l) { }

    static String lastError() { return ""; }
    static boolean configured() { return false; }
    static String allowedJson() { return "[]"; }
    static String email(Context c) { return ""; }
    static boolean signedIn(Context c) { return false; }
    static String[] access(Context c) { return null; }
    static void signOut(Context c) { }
    static void startSignIn(Activity a) { }
    static void onNativeResult(Activity a, int requestCode, Intent data) { }

    /** a stable name for this phone's slot in the learning files */
    static String deviceId(Context c) {
        SharedPreferences p = c.getSharedPreferences("sulekhak", Context.MODE_PRIVATE);
        String id = p.getString("learn_device", null);
        if (id == null) { id = "a" + String.format(Locale.ROOT, "%08x", new SecureRandom().nextInt()); p.edit().putString("learn_device", id).apply(); }
        return id;
    }

    private static boolean goodLang(String l) { return "or".equals(l) || "hi".equals(l) || "mr".equals(l) || "bn".equals(l) || "as".equals(l) || "en".equals(l); }
    static String readLang(Context c, String lang) {
        if (!goodLang(lang)) return "";
        try {
            File f = new File(new File(c.getFilesDir(), "learning"), lang + ".json");
            if (!f.exists()) return "";
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] b = new byte[(int) f.length()]; int n = 0; while (n < b.length) { int k = in.read(b, n, b.length - n); if (k < 0) break; n += k; }
            in.close();
            return new String(b, 0, n, java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }
    static void writeLang(Context c, String lang, String text) {
        if (!goodLang(lang) || text == null || text.isEmpty()) return;
        try {
            File dir = new File(c.getFilesDir(), "learning"); dir.mkdirs();
            File f = new File(dir, lang + ".json"), t = new File(dir, lang + ".json.tmp");
            FileOutputStream o = new FileOutputStream(t); o.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8)); o.getFD().sync(); o.close();
            if (f.exists()) { File bak = new File(dir, lang + ".json.bak"); bak.delete(); f.renameTo(bak); }
            t.renameTo(f);
        } catch (Exception ignored) { }
    }
}
