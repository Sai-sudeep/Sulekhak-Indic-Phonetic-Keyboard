from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':900})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///tmp/w/lekhani/html/sulekhk.html'); pg.wait_for_timeout(800)
    pg.click('.segb[data-sc="3"]'); pg.wait_for_timeout(200)
    pg.click('#ed') if pg.query_selector('#ed') else None
    pg.keyboard.type('hello there. i think i\'m ready -- are you? e.g. this works... "quoted" text. mr. smith went.',delay=8)
    pg.wait_for_timeout(300)
    txt=pg.evaluate('window.__lekhani.st.text'); print(repr(txt))
    # odia still works
    pg.click('.segb[data-sc="0"]'); pg.click('#ed'); pg.keyboard.press('Control+End'); pg.keyboard.type(' namaskar ',delay=10)
    print(repr(pg.evaluate('window.__lekhani.st.text')))
    pg.click('.segb[data-sc="3"]'); pg.screenshot(path='/tmp/w/logo/en.png')
    print(pg.evaluate("document.getElementById('ed').getAttribute('lang')"), errs)
    b.close()
