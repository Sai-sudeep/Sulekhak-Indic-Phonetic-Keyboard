from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':800})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///tmp/w/lekhani/html/sulekhk.html'); pg.wait_for_timeout(700)
    pg.click('#ed')
    pg.keyboard.type('namaskar... ',delay=15)       # three dots then space
    pg.keyboard.type('ok.. ',delay=15)
    pg.keyboard.type('.',delay=15); pg.keyboard.press('Enter')   # single dot then Enter -> highlighted danda
    pg.keyboard.type('ka.',delay=15); pg.keyboard.type('1',delay=15)
    print(repr(pg.evaluate('window.__lekhani.st.text')), errs)
    b.close()
