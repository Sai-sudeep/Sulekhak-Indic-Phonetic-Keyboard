/* ================= Phonetic module: IPA, extIPA and IAST symbols found by what they LOOK like ================= */
/* Everything here is generated from window.SKPH (phon-data.js), the one database behind the key guide, the picker,
   the unmatched panel and the Help view. Nothing is typed in by hand. */
var PH_READY=false, PHS=null, phPend=null, phLastKey=null, phHelpBuilt=false, phHelpOpener=null;
var PH_REL={first:'the symbol starts with a part that looks like the key glyph (an affricate, ligature, release or prenasalized sequence)',identity:'the symbol is the ASCII character on this key',id:'direct shape match',turn:'the key glyph turned 180°',mirror:'the key glyph mirrored left-right',flip:'the key glyph flipped upside-down',scaled:'a reduced-size or small-capital form of the key glyph',mark:'the isolated mark has the shape of the key glyph'};
var PH_INV={ipa:'IPA',extipa:'extIPA',iast:'IAST',other:'other convention',historical:'historical','unicode-compatible':'Unicode only'};
var PH_INVLONG={ipa:'Official IPA',extipa:'extIPA (disordered speech)',iast:'IAST',other:'Other documented phonetic convention',historical:'Historical or obsolete','unicode-compatible':'Unicode-compatible, not validated as phonetic'};
var PH_TIERS=['exact','high','medium','low'], PH_TIERNAME={exact:'Exact',high:'Strong',medium:'Medium',low:'Weak'};
function phEsc(s){ return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]}) }
function phShow(s){ return /^\p{M}+$/u.test(s)?'◌'+s:s }
function phCodes(s){ return Array.from(s).map(function(c){ var h=c.codePointAt(0).toString(16).toUpperCase(); return 'U+'+('0000'+h).slice(-Math.max(4,h.length)) }).join(' ') }
function phPrep(){
  if(PHS) return PHS; var D=window.SKPH; if(!D) return null;
  var E_=D.entries.map(function(r,i){ return {i:i,s:r[0],inv:D.inv[r[1]],cat:D.cats[r[2]],label:r[3],status:r[4],vis:D.vis[r[5]],src:r[6],note:r[7],isMark:!!r[8],kase:r[9],fonts:r[10],variantOf:r[11]} });
  var KS={}, RK={}, RKE={};
  D.keys.forEach(function(k){
    var seen={}, out=[];
    (D.keyMap[k]||[]).forEach(function(r){
      var e=E_[r[0]], tier=(r[1]==='identity'||r[2]==='exact')?'exact':r[2], m=seen[e.s];
      if(!m){ m=seen[e.s]={s:e.s,ents:[],invs:[],rel:r[1],conf:r[2],score:r[3],fonts:r[4],why:r[5]||'',tier:tier,label:e.label}; out.push(m) }
      m.ents.push(e.i); if(m.invs.indexOf(e.inv)<0) m.invs.push(e.inv);
      if(r[3]>m.score){ m.score=r[3]; m.rel=r[1]; m.conf=r[2]; m.fonts=r[4]; m.why=r[5]||''; m.tier=tier }
      (RKE[e.i]=RKE[e.i]||[]).push(k);
    });
    out.sort(function(a,b){ return (PH_TIERS.indexOf(a.tier)-PH_TIERS.indexOf(b.tier))||(b.score-a.score) });
    KS[k]=out; out.forEach(function(m){ (RK[m.s]=RK[m.s]||[]).push(k) });
  });
  var unmatched=E_.filter(function(e){ return /^unmatched/.test(e.vis) });
  PHS={D:D,E:E_,KS:KS,RK:RK,RKE:RKE,unmatched:unmatched};
  return PHS;
}
function phWhy(m){ return m.why||((PH_REL[m.rel]||m.rel)+'; '+m.fonts+' font'+(m.fonts===1?'':'s')+' agree; visual score '+m.score.toFixed(2)) }
function phTitle(m){ return m.s+'  '+phCodes(m.s)+'\n'+m.label+' · '+m.invs.map(function(x){return PH_INV[x]}).join(', ')+'\n'+PH_TIERNAME[m.tier]+': '+phWhy(m) }
function phKeyKind(k){ return k===' '?'space':/^[a-z]$/.test(k)?'lowercase letter':/^[A-Z]$/.test(k)?'uppercase letter':/^[0-9]$/.test(k)?'digit':'punctuation key' }
function phChips(list,key,cur){
  return list.map(function(m){ return '<button type="button" class="pm-s'+(m.s===cur?' on':'')+'" data-s="'+phEsc(m.s)+'" data-k="'+phEsc(key)+'" title="'+phEsc(phTitle(m))+'" aria-label="'+phEsc(m.s+', '+m.label+', '+PH_TIERNAME[m.tier])+'">'+phEsc(phShow(m.s))+'</button>' }).join('<span class="pm-c" aria-hidden="true">, </span>');
}
function phGroups(key,cur){
  var P=phPrep(); if(!P) return ''; var L=P.KS[key]||[], h='', n=0;
  PH_TIERS.forEach(function(t){
    var g=L.filter(function(m){ return m.tier===t }); if(!g.length) return; n+=g.length;
    h+='<div class="pm-g"><span class="pm-gl">'+PH_TIERNAME[t]+'</span><span class="pm-gc">'+phChips(g,key,cur)+'</span></div>';
  });
  return h;
}
function phAlts(k,n){ if(!PH_READY) return ''; var P=phPrep(); if(!P) return ''; return (P.KS[k]||[]).filter(function(m){ return m.tier!=='exact' }).slice(0,n||3).map(function(m){ return phShow(m.s) }).join(' ') }
function phHasAlt(k){ var P=phPrep(); return !!(P&&(P.KS[k]||[]).some(function(m){ return m.tier!=='exact' })) }

/* ---- the picker under the editor: what to put at the caret for the key just pressed ---- */
var pmPick=$('pmpick');
function phRenderPick(key){
  if(key!==undefined) phLastKey=key;
  if(SC!==4){ pmPick.hidden=true; return }
  var P=phPrep(); if(!P){ pmPick.hidden=true; return }
  pmPick.hidden=false;
  if(phLastKey===null){ pmPick.innerHTML='<p class="pm-empty">Press a key, or click one on the key guide. Every symbol that looks like that key appears here, strongest first. <b>Tab</b> swaps the letter you just typed for the next one; <b>Esc</b> keeps it.</p>'; return }
  var k=phLastKey, cur=phValid()?phPend.text:null, L=P.KS[k]||[], nAlt=L.filter(function(m){return m.tier!=='exact'}).length;
  var h='<div class="pm-ph"><span class="pm-key" aria-label="Key '+phEsc(k)+'">'+phEsc(k===' '?'space':k)+'</span><span class="pm-kk">'+phKeyKind(k)+'</span><span class="pm-hint">Tab / Shift+Tab swap the typed letter for the next or previous symbol · Esc keeps it · click a symbol to insert it</span></div>';
  if(nAlt) h+=phGroups(k,cur);
  else h+='<p class="pm-empty">No symbol in the validated IPA, extIPA or IAST inventories looks like <b>'+phEsc(k===' '?'space':k)+'</b> in the fonts checked, so none is offered. Nothing is forced; see the right-hand list for symbols that match no key.</p>';
  pmPick.innerHTML=h;
}
function phValid(){ return !!(phPend&&st.anchor===null&&st.pos===phPend.start+phPend.len&&st.text.slice(phPend.start,phPend.start+phPend.len)===phPend.text) }
function phReplace(sym,key){
  /* swap the pending symbol for sym (one undo step), or insert at the caret */
  flush();
  if(phValid()&&phPend.key===key){
    var p=phPend; save(); splice(p.start,p.len,sym,fm[p.start]||0); st.pos=p.start+sym.length; st.anchor=null; draw();
    phPend={start:p.start,len:sym.length,text:sym,key:key};
  } else {
    if(selRange()) delSel(); var start=st.pos; ins(sym); draw();
    phPend=key?{start:start,len:sym.length,text:sym,key:key}:null;
  }
  if(key) phRenderPick(key);
}
function phCycle(dir){
  var P=phPrep(), L=P.KS[phPend.key]||[]; if(L.length<2){ return }
  var i=0; L.forEach(function(m,j){ if(m.s===phPend.text) i=j });
  phReplace(L[(i+dir+L.length)%L.length].s,phPend.key);
}
function pressPH(k,ext){
  if(k==='Tab'||k==='Escape'){
    if(!phValid()) return undefined;
    if(k==='Escape'){ phPend=null; phRenderPick(); return true }
    phCycle(ext?-1:1); return true;
  }
  if(Array.from(k).length!==1) return undefined;        /* Backspace, Enter, arrows ... keep their normal behaviour */
  flush(); if(selRange()) delSel();
  var start=st.pos; ins(k); draw();
  phPend={start:start,len:k.length,text:k,key:k}; phRenderPick(k);
  return true;
}
/* the key guide's own list (shown on hover, or after a long press on a touch screen) is tappable too */
var pmInfoEl=$('kginfo');
if(pmInfoEl) pmInfoEl.addEventListener('pointerdown',function(e){ var b=e.target.closest('.pm-s'); if(!b||SC!==4) return; e.preventDefault(); phReplace(b.getAttribute('data-s'),b.getAttribute('data-k')); ed.focus() });
pmPick.addEventListener('pointerdown',function(e){ var b=e.target.closest('.pm-s'); if(!b) return; e.preventDefault(); phReplace(b.getAttribute('data-s'),b.getAttribute('data-k')); ed.focus() });
pmPick.addEventListener('keydown',function(e){ if((e.key==='Enter'||e.key===' ')&&e.target.classList&&e.target.classList.contains('pm-s')){ e.preventDefault(); phReplace(e.target.getAttribute('data-s'),e.target.getAttribute('data-k')) } });

/* ---- key guide hooks ---- */
function phTip(k){
  var P=phPrep(); if(!P) return '';
  var L=P.KS[k]||[], nAlt=L.filter(function(m){return m.tier!=='exact'}).length;
  var h='<div><code>'+phEsc(k)+'</code> <span style="opacity:.7">'+phKeyKind(k)+'</span></div>';
  if(!nAlt) return h+'<div style="margin-top:6px">No genuine visual match: nothing is forced.</div>';
  var shown=0, rows='';
  PH_TIERS.forEach(function(t){ var g=L.filter(function(m){ return m.tier===t&&t!=='exact' }); if(!g.length) return; rows+='<div class="pm-tr"><i>'+PH_TIERNAME[t]+'</i> <span class="pm-ts">'+g.slice(0,10).map(function(m){ return phEsc(phShow(m.s)) }).join(', ')+(g.length>10?' …':'')+'</span></div>'; shown+=g.length });
  return h+rows+'<div style="margin-top:6px;opacity:.7;font-size:.85em">'+nAlt+' symbol'+(nAlt===1?'':'s')+' · click the key to type it, then Tab to swap</div>';
}
window.phTip=phTip; window.phInfo=function(k){ return phInfo(k) };
function phInfo(k){
  var P=phPrep(); if(!P) return '<div>Phonetic data is not loaded.</div>';
  var L=P.KS[k]||[], nAlt=L.filter(function(m){return m.tier!=='exact'}).length;
  var h='<div><code>'+phEsc(k)+'</code> <span style="opacity:.75">'+phKeyKind(k)+'</span></div>';
  if(!nAlt) return h+'<div style="margin-top:6px">No symbol looks like this key in the fonts checked. Nothing is forced.</div>';
  return h+'<div class="pm-info">'+phGroups(k,null)+'</div>';
}

/* ---- unmatched panel (right-hand side) ---- */
var pmSide=$('pmside');
function phCopy(s){
  function fb(){ var t=document.createElement('textarea'); t.value=s; t.style.cssText='position:fixed;left:-9999px;top:0'; document.body.appendChild(t); t.select(); try{ document.execCommand('copy') }catch(e){} document.body.removeChild(t) }
  if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(s).catch(fb); else fb();
  flash('Copied '+phShow(s)+'  '+phCodes(s));
}
function phInsertSym(s){ phPend=null; flush(); if(selRange()) delSel(); ins(s); draw(); flash('Inserted '+phShow(s)+'  '+phCodes(s)) }
function phRow(e,mode){
  var P=PHS, keys=P.RKE[e.i], vis=e.vis==='mapped'?('keys: '+(keys||[]).map(phEsc).join(' ')):e.vis==='composed-from-keys'?'typed with the keys themselves':e.vis==='composed-from-mapped-parts'?'composed of mapped parts':e.vis==='unmatched-font-coverage-insufficient'?'unmatched (fewer than 2 fonts draw it)':'no keyboard match';
  return '<li class="pm-r" data-eid="'+e.i+'"><span class="pm-sym" lang="und">'+phEsc(phShow(e.s))+'</span><span class="pm-m"><b>'+phEsc(e.label)+'</b><i>'+phCodes(e.s)+' · '+phEsc(e.cat)+' · '+phEsc(PH_INV[e.inv])+' · '+phEsc(e.status)+(mode==='inv'?' · '+vis:'')+'</i></span><span class="pm-b"><button type="button" class="btn ghost" data-a="copy" aria-label="Copy '+phEsc(e.s)+'">Copy</button><button type="button" class="btn ghost" data-a="ins" aria-label="Insert '+phEsc(e.s)+' at the caret">Insert</button></span></li>';
}
function phFilterEntries(list,q,inv,cat,st_){
  q=(q||'').trim().toLowerCase(); var hexq=q.replace(/^u\+/,'');
  return list.filter(function(e){
    if(inv&&e.inv!==inv) return false; if(cat&&e.cat!==cat) return false; if(st_&&e.status!==st_) return false;
    if(!q) return true;
    return e.s.toLowerCase().indexOf(q)>=0||e.label.toLowerCase().indexOf(q)>=0||e.cat.toLowerCase().indexOf(q)>=0||phCodes(e.s).toLowerCase().indexOf(q)>=0||(hexq.length>=2&&phCodes(e.s).toLowerCase().replace(/u\+/g,'').indexOf(hexq)>=0);
  });
}
function phOptions(vals,all){ return '<option value="">'+all+'</option>'+vals.map(function(v){ return '<option value="'+phEsc(v)+'">'+phEsc(v)+'</option>' }).join('') }
function phBuildSide(){
  var P=phPrep(); if(!P||pmSide.getAttribute('data-built')) return; pmSide.setAttribute('data-built','1');
  var cats=Array.from(new Set(P.unmatched.map(function(e){return e.cat}))).sort(), invs=Array.from(new Set(P.unmatched.map(function(e){return e.inv})));
  var sts=Array.from(new Set(P.unmatched.map(function(e){return e.status}))).sort();
  pmSide.innerHTML='<div class="pm-sh"><h2>No keyboard match</h2><button type="button" class="btn ghost pm-helpb" id="pmhelp2">? Help</button></div>'+
   '<p class="pm-note" id="pmsn"></p>'+
   '<div class="pm-f"><input type="search" id="pmsq" placeholder="Search" title="Search by symbol, U+ code or name" aria-label="Search the unmatched symbols by symbol, code or name"><select id="pminv" aria-label="Inventory"><option value="">All inventories</option>'+invs.map(function(v){return '<option value="'+v+'">'+PH_INVLONG[v]+'</option>'}).join('')+'</select><select id="pmcat" aria-label="Category">'+phOptions(cats,'All categories')+'</select><select id="pmst" aria-label="Validation status">'+phOptions(sts,'Any status')+'</select></div>'+
   '<ul class="pm-list" id="pmul" aria-label="Symbols with no visual match to any key"></ul>';
  function go(){ phRenderUnmatched() }
  ['pmsq','pminv','pmcat','pmst'].forEach(function(id){ $(id).addEventListener(id==='pmsq'?'input':'change',go) });
  pmSide.addEventListener('click',function(e){ var b=e.target.closest('[data-a]'); if(!b) return; var li=b.closest('[data-eid]'); var en=PHS.E[+li.getAttribute('data-eid')]; if(b.getAttribute('data-a')==='copy') phCopy(en.s); else { phInsertSym(en.s); ed.focus() } });
  $('pmhelp2').addEventListener('click',function(){ phOpenHelp(this) });
  phRenderUnmatched();
}
function phRenderUnmatched(){
  var P=PHS; if(!P||!$('pmul')) return;
  var list=phFilterEntries(P.unmatched,$('pmsq').value,$('pminv').value,$('pmcat').value,$('pmst').value);
  $('pmul').innerHTML=list.map(function(e){ return phRow(e,'un') }).join('')||'<li class="pm-empty">'+(P.unmatched.length?'Nothing matches the filter.':'Every symbol in the database is reachable from at least one key. Nothing is left here.')+'</li>';
  $('pmsn').textContent=P.unmatched.length?P.unmatched.length+' symbols have no keyboard match yet. Showing '+list.length+'.':'All '+P.E.length+' symbols are reachable from at least one key, so nothing is left here.';
}

/* ---- Help: the whole mapping and inventory, interactive, built from the same database ---- */
var pmDlg=$('pmhelpdlg'), pmIn=$('pmhelpin');
function phHelpKeys(){
  var P=PHS, D=P.D, groups=[['Lowercase letters',/^[a-z]$/],['Uppercase letters',/^[A-Z]$/],['Digits',/^[0-9]$/],['Punctuation and other keys',/^[^a-zA-Z0-9]$/]], h='';
  groups.forEach(function(g){
    var ks=D.keys.filter(function(k){ return g[1].test(k) }); h+='<h3>'+g[0]+' <small>('+ks.length+')</small></h3><div class="pm-kt">';
    ks.forEach(function(k){
      var L=P.KS[k]||[], alts=L.filter(function(m){return m.tier!=='exact'}).length;
      h+='<div class="pm-kr" data-key="'+phEsc(k)+'"><span class="pm-key">'+phEsc(k)+'</span><div class="pm-kc">'+(L.length?phGroups(k,null):'')+(alts?'':'<span class="pm-none">'+(L.length?'no other symbol looks like it; nothing is forced':'no genuine visual match; nothing is forced')+'</span>')+'</div></div>';
    });
    h+='</div>';
  });
  return h;
}
function phHelpInv(){
  var P=PHS, invs=['ipa','extipa','iast','other','historical','unicode-compatible'], cats=Array.from(new Set(P.E.map(function(e){return e.cat}))).sort();
  var h='<div class="pm-f"><input type="search" id="pmiq" placeholder="Search symbol, U+ code or name" aria-label="Search the inventory"><select id="pmii" aria-label="Inventory"><option value="">All inventories</option>'+invs.map(function(v){return '<option value="'+v+'">'+PH_INVLONG[v]+'</option>'}).join('')+'</select><select id="pmic" aria-label="Category">'+phOptions(cats,'All categories')+'</select><select id="pmiv" aria-label="Mapping"><option value="">Mapped and unmatched</option><option value="mapped">Mapped to keys</option><option value="un">Unmatched</option><option value="comp">Composed</option></select></div><p class="pm-note" id="pmin"></p><ul class="pm-list" id="pmiul"></ul>';
  return h;
}
function phRenderInv(){
  var P=PHS, q=$('pmiq').value, inv=$('pmii').value, cat=$('pmic').value, v=$('pmiv').value;
  var list=phFilterEntries(P.E,q,inv,cat,'').filter(function(e){ return !v||(v==='mapped'&&e.vis==='mapped')||(v==='un'&&/^unmatched/.test(e.vis))||(v==='comp'&&/^composed/.test(e.vis)) });
  $('pmiul').innerHTML=list.map(function(e){ return phRow(e,'inv') }).join('');
  $('pmin').textContent=P.E.length+' entries in the database. Showing '+list.length+'.';
}
function phHelpUn(){ return '<p class="pm-note">The same list as the right-hand panel. Every entry here is a validated symbol with no defensible visual match to any key; it is generated from the mapping database, so a symbol that maps to even one key can never appear here.</p><ul class="pm-list" id="pmhul"></ul>' }
function phHelpCand(){
  var D=PHS.D, h='<p class="pm-note">Your initial candidate table was treated as a starting point only. Each pair was checked against the rendered glyphs in several fonts. Where a key has a lowercase and an uppercase form, the result is listed per key.</p><table class="pm-tab"><thead><tr><th>Symbol</th><th>Table</th><th>Result</th><th>Kept on</th><th>Removed on</th><th>Why</th></tr></thead><tbody>';
  D.candidates.forEach(function(c){ h+='<tr data-cand="1"><td class="pm-sym">'+phEsc(phShow(c[0]))+'</td><td>'+(c[1]==='iast'?'IAST':'IPA / extIPA')+'</td><td>'+phEsc(c[2])+'</td><td>'+phEsc(c[3].split('').join(' '))+'</td><td>'+phEsc(c[4].split('').join(' '))+'</td><td>'+phEsc(c[5])+'</td></tr>' });
  return h+'</tbody></table>';
}
function phHelpAbout(){
  var D=PHS.D, P=PHS, src=D.sources.map(function(s){ return '<li><b>'+phEsc(s.title)+'</b> <span class="pm-badge pm-'+phEsc(s.accessStatus)+'">'+phEsc(s.accessStatus)+'</span><br><span class="pm-note">'+phEsc(s.usedFor)+'</span></li>' }).join('');
  var byInv={}; P.E.forEach(function(e){ byInv[e.inv]=(byInv[e.inv]||0)+1 });
  return '<div id="pmverify" class="pm-verify" role="status"></div>'+
   '<h3>What this is</h3><p>'+P.E.length+' validated entries in separate inventories ('+Object.keys(byInv).map(function(k){return PH_INVLONG[k]+': '+byInv[k]}).join(' · ')+'), matched to the '+D.keys.length+' ASCII keys by the shapes the fonts actually draw, not by sound, transliteration or Unicode name. Mapping set '+phEsc(D.hash)+', generated '+phEsc(D.generated)+'.</p>'+
   '<h3>How a match is decided</h3><p>Each symbol and each key is drawn in '+D.fonts.length+' fonts and compared shape to shape. A match needs a similarity of at least '+D.thresholds.id+' (direct), '+D.thresholds.turn+' (turned, mirrored or flipped key), or '+D.thresholds.scaled+' (small capitals and raised forms), in at least two fonts and 40% of the fonts that draw it. Symbols with a letter and a mark inherit the match of the letter. Affricates (the ligature letters ʦ ʣ ʧ ʤ ʨ ʥ and the tie-bar forms t͡s d͡z t͡ʃ d͡ʒ t͡ɕ d͡ʑ ʈ͡ʂ ɖ͡ʐ p͡f t̪͡θ ...), release and prenasalized sequences (tˢ, ᵐb ...) and ligature letters (æ œ ʪ ...) are listed under the key their first part looks like, as Medium or Weak. Hand-checked additions and rejections are marked in the symbol tooltip. Strength: Exact is the key itself, Strong and Medium and Weak follow the score.</p>'+
   '<h3>What is not claimed</h3><p>The inventory is reconciled to the sources that could be read by machine. The printed official IPA chart, the extIPA 2025 chart and the VoQS chart are images or PDFs, so they could not be checked symbol by symbol here; entries resting on a single secondary source are marked <b>unresolved</b>. Treat this as complete only after that check has been done.</p>'+
   '<h3>Sources</h3><ul class="pm-src">'+src+'</ul>';
}
function phVerify(){
  var P=PHS, D=P.D, r=[];
  var rowsInv=document.querySelectorAll('#pmiul [data-eid]').length, rowsKeys=document.querySelectorAll('#pmhtab-keys [data-key]').length;
  var pairs={}; D.keys.forEach(function(k){ (D.keyMap[k]||[]).forEach(function(x){ pairs[k+'\u0000'+D.entries[x[0]][0]]=1 }) });
  var chipsKeys=document.querySelectorAll('#pmhtab-keys .pm-s').length;
  var unExp=P.E.filter(function(e){ return /^unmatched/.test(e.vis) }).length;
  var unHelp=document.querySelectorAll('#pmhul [data-eid]').length, unSide=P.unmatched.length;
  var composed=P.E.filter(function(e){ return /^composed/.test(e.vis) }).length;
  var mapped=P.E.filter(function(e){ return e.vis==='mapped' }).length, mappedKeys=Object.keys(P.RKE).length;
  var checks=[['entries shown (Help) vs database',rowsInv,P.E.length],['keys shown (Help) vs database',rowsKeys,D.keys.length],['key→symbol pairs shown vs database',chipsKeys,Object.keys(pairs).length],['unmatched shown (Help) vs generated',unHelp,unExp],['unmatched in side panel vs generated',unSide,unExp],['mapped entries vs reverse index',mapped,mappedKeys]];
  var ok=checks.every(function(c){ return c[1]===c[2] }), el=$('pmverify');
  var res={ok:ok,checks:checks.map(function(c){ return {name:c[0],shown:c[1],db:c[2]} }),composed:composed};
  if(el) el.innerHTML='<b class="'+(ok?'pm-ok':'pm-bad')+'">'+(ok?'The Help view agrees with the live database.':'The Help view does NOT agree with the database.')+'</b> '+checks.map(function(c){ return phEsc(c[0])+': '+c[1]+' / '+c[2] }).join(' · ');
  window.__phVerify=res; return res;
}
function phBuildHelp(){
  if(phHelpBuilt) return; var P=phPrep(); if(!P){ pmIn.innerHTML='<p>The phonetic data did not load.</p>'; return } phHelpBuilt=true;
  var tabs=[['keys','Keys → symbols',phHelpKeys],['inv','Symbol inventory',phHelpInv],['un','Unmatched',phHelpUn],['cand','Candidate table review',phHelpCand],['about','About and validation',phHelpAbout]];
  var h='<div class="pm-hh"><h2 id="pmhelph" tabindex="-1">Phonetic symbols: help and complete mapping</h2><button type="button" class="btn" id="pmhclose">Close</button></div>'+
   '<p class="pm-note">Pick a key to see every IPA, extIPA and IAST symbol that looks like it, strongest first. Click a symbol to select it, then copy it or put it into your text. Your text and selection are untouched while this window is open.</p>'+
   '<div class="pm-tabs" role="tablist" aria-label="Help sections">'+tabs.map(function(t,i){ return '<button type="button" role="tab" class="pm-tab-b" id="pmtb-'+t[0]+'" aria-controls="pmhtab-'+t[0]+'" aria-selected="'+(i===0)+'" tabindex="'+(i===0?0:-1)+'">'+t[1]+'</button>' }).join('')+'</div>'+
   '<div class="pm-sel" id="pmsel" aria-live="polite"><span class="pm-note">Select a symbol to see its details.</span></div>';
  tabs.forEach(function(t,i){ h+='<div role="tabpanel" class="pm-pane" id="pmhtab-'+t[0]+'" aria-labelledby="pmtb-'+t[0]+'"'+(i?' hidden':'')+'>'+t[2]()+'</div>' });
  pmIn.innerHTML=h;
  var list=PHS.unmatched; $('pmhul').innerHTML=list.map(function(e){ return phRow(e,'un') }).join('');
  phRenderInv(); ['pmiq','pmii','pmic','pmiv'].forEach(function(id){ $(id).addEventListener(id==='pmiq'?'input':'change',phRenderInv) });
  var tl=pmIn.querySelector('.pm-tabs');
  function show(id){ [].forEach.call(tl.querySelectorAll('[role=tab]'),function(b){ var on=b.id==='pmtb-'+id; b.setAttribute('aria-selected',on); b.tabIndex=on?0:-1; $('pmhtab-'+b.id.slice(5)).hidden=!on }) }
  tl.addEventListener('click',function(e){ var b=e.target.closest('[role=tab]'); if(b) show(b.id.slice(5)) });
  tl.addEventListener('keydown',function(e){ var bs=[].slice.call(tl.querySelectorAll('[role=tab]')), i=bs.indexOf(document.activeElement); if(i<0) return; var n=e.key==='ArrowRight'?i+1:e.key==='ArrowLeft'?i-1:e.key==='Home'?0:e.key==='End'?bs.length-1:-1; if(n<0) return; e.preventDefault(); n=(n+bs.length)%bs.length; bs[n].focus(); show(bs[n].id.slice(5)) });
  function select(s,key){
    var m=null; if(key&&PHS.KS[key]) PHS.KS[key].forEach(function(x){ if(x.s===s) m=x });
    var ents=PHS.E.filter(function(e){ return e.s===s }), keys=PHS.RK[s]||[];
    var d='<span class="pm-sym pm-big">'+phEsc(phShow(s))+'</span><div class="pm-sd"><b>'+phEsc(ents.length?ents[0].label:'')+'</b><br>'+phCodes(s)+' · '+ents.map(function(e){ return PH_INV[e.inv]+' / '+phEsc(e.cat)+' ('+phEsc(e.status)+')' }).join(' · ')+
      '<br>Keys that look like it: '+(keys.length?keys.map(function(k){return '<kbd>'+phEsc(k)+'</kbd>'}).join(' '):'none')+(m?'<br>On <kbd>'+phEsc(key)+'</kbd>: '+PH_TIERNAME[m.tier]+'. '+phEsc(phWhy(m)):'')+(ents.length&&ents[0].note?'<br><span class="pm-note">'+phEsc(ents[0].note)+'</span>':'')+
      '</div><div class="pm-b"><button type="button" class="btn" data-a="copy" data-s="'+phEsc(s)+'">Copy</button><button type="button" class="btn" data-a="ins" data-s="'+phEsc(s)+'">Insert</button></div>';
    $('pmsel').innerHTML=d;
  }
  pmIn.addEventListener('click',function(e){
    var a=e.target.closest('[data-a]'); if(a){ var s=a.getAttribute('data-s'); if(!s){ var li=a.closest('[data-eid]'); s=PHS.E[+li.getAttribute('data-eid')].s } if(a.getAttribute('data-a')==='copy') phCopy(s); else phInsertSym(s); return }
    var c=e.target.closest('.pm-s'); if(c){ select(c.getAttribute('data-s'),c.getAttribute('data-k')); return }
    var sym=e.target.closest('.pm-r'); if(sym){ select(PHS.E[+sym.getAttribute('data-eid')].s,null) }
  });
  $('pmhclose').addEventListener('click',phCloseHelp);
  phVerify();
}
function phOpenHelp(opener){
  phBuildHelp(); phHelpOpener=opener||document.activeElement; pmDlg.hidden=false; document.body.classList.add('pm-modal'); var h=$('pmhelph'); if(h) h.focus(); if(phHelpBuilt) phVerify();
}
function phCloseHelp(){ pmDlg.hidden=true; document.body.classList.remove('pm-modal'); if(phHelpOpener&&phHelpOpener.focus&&document.contains(phHelpOpener)&&phHelpOpener.id!=='pmhelp2'&&false) phHelpOpener.focus(); else ed.focus() }
pmDlg.addEventListener('keydown',function(e){
  if(e.key==='Escape'){ e.preventDefault(); e.stopPropagation(); phCloseHelp(); return }
  if(e.key==='Tab'){ var f=[].slice.call(pmDlg.querySelectorAll('button,input,select,[tabindex="0"]')).filter(function(x){ return !x.disabled&&x.offsetParent!==null }); if(!f.length) return; var a=f[0], z=f[f.length-1]; if(e.shiftKey&&document.activeElement===a){ e.preventDefault(); z.focus() } else if(!e.shiftKey&&document.activeElement===z){ e.preventDefault(); a.focus() } }
});
pmDlg.addEventListener('pointerdown',function(e){ if(e.target===pmDlg) phCloseHelp() });
$('pmhelp').addEventListener('click',function(){ phOpenHelp(this) });
function phApply(){
  var on=SC===4; document.body.classList.toggle('pm',on); pmSide.hidden=!on; $('pmopt').hidden=!on;
  if(on&&phPrep()){ phBuildSide(); phRenderPick() } else pmPick.hidden=true;
  if(!on) phPend=null;
}
window.__ph={prep:phPrep,verify:function(){ phBuildHelp(); return phVerify() },open:function(){ phOpenHelp($('pmhelp')) },close:phCloseHelp,pending:function(){ return phPend }};
PH_READY=true;
