# fills typist.tpl.html with the engine and the consonant-skeleton dictionary -> the two identical app files
eng=open('../src/engine.js',encoding='utf-8').read()
skel=open('../src/skel.dat.gz.b64').read().strip()
tpl=open('typist.tpl.html',encoding='utf-8').read()
out=tpl.replace('__SULEKHAK__',open('sulekhak.js',encoding='utf-8').read()).replace('__SKBRIDGE__',open('sk_bridge.js',encoding='utf-8').read()).replace('__SKEL__',skel).replace('__ENGINE__',eng).replace('__KB3D__',open('kb3d.js',encoding='utf-8').read()).replace('__PHONDATA__',open('phon-data.js',encoding='utf-8').read()).replace('__PHONFONTS__',open('phon-fonts.css',encoding='utf-8').read()).replace('/*__PHONUI__*/',open('phonetic.part.js',encoding='utf-8').read())
open('sulekhak.html','w',encoding='utf-8').write(out)
stub='''<!doctype html><meta charset="utf-8"><title>Sulekhak</title><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=sulekhak.html"><link rel="canonical" href="sulekhak.html"><p style="font:16px system-ui;padding:24px">Sulekhak (formerly Lekhani, ସୁलेখk) has moved to <a href="sulekhak.html">sulekhak.html</a>.</p><script>location.replace('sulekhak.html'+location.search+location.hash)</script>'''
for f in ('sulekhk.html','odia-lekhani-typist-keyboard.html','lekhani-odia-typist.html'):
    open(f,'w',encoding='utf-8').write(stub)
print(len(out))
