# fills typist.tpl.html with the engine and the consonant-skeleton dictionary -> the two identical app files
eng=open('../src/engine.js',encoding='utf-8').read()
skel=open('../src/skel.dat.gz.b64').read().strip()
tpl=open('typist.tpl.html',encoding='utf-8').read()
out=tpl.replace('__SULEKHAK__',open('sulekhak.js',encoding='utf-8').read()).replace('__SKBRIDGE__',open('sk_bridge.js',encoding='utf-8').read()).replace('__SKEL__',skel).replace('__ENGINE__',eng).replace('__KB3D__',open('kb3d.js',encoding='utf-8').read()).replace('__PHONDATA__',open('phon-data.js',encoding='utf-8').read()).replace('__PHONFONTS__',open('phon-fonts.css',encoding='utf-8').read()).replace('/*__PHONUI__*/',open('phonetic.part.js',encoding='utf-8').read())
open('sulekhak.html','w',encoding='utf-8').write(out)

# ---- one file per language: the same page with the script fixed (0 Odia, 1 Devanagari, 2 Bangla, 3 English, 4 Phonetic IPA, 5 Assamese).
# Each edition keeps its own saved options (localStorage key lekhaniScript.<n>), so it never disturbs the all-in-one page.
EDS=[('odia',0,'Odia','ଓଡ଼ିଆ','or'),('devanagari',1,'Devanagari','देवनागरी','hi'),('assamese',5,'Assamese','অসমীয়া','as'),('bangla',2,'Bangla','বাংলা','bn'),('phonetic',4,'Phonetic (IPA)','Phonetic','und-fonipa'),('english',3,'English','English','en')]
def edition(slug,n,label,native,lang):
    t=out
    def sub(a,b,count=1):
        nonlocal t
        assert t.count(a)>=1,(slug,a)
        t=t.replace(a,b) if count==0 else t.replace(a,b,count)
    sub('<title>Sulekhak · Phonetic Keyboard</title>','<title>Sulekhak %s · Phonetic Keyboard</title>'%label)
    sub('var SC=0, SMAR=false','var SK_ED=%d, SC=0, SMAR=false'%n)
    sub("function sopts(){","SC=SK_ED; function sopts(){")
    sub("'lekhaniScript'","'lekhaniScript.%d'"%n,0)
    links=' &middot; '.join('<a href="sulekhak-%s.html" lang="%s">%s</a>'%(e[0],e[4],e[3]) for e in EDS if e[0]!=slug)
    tag=('<span class="edtag"><b>Sulekhak %s</b> edition</span> <span class="edlinks"><a href="sulekhak.html">All scripts in one</a> &middot; %s</span>'%(label,links))
    sub('<span class="sclab">Write in</span>',tag)
    sub('</style>','.scbar .seg{display:none!important}.edtag{font-weight:600;margin-right:12px}.edlinks{font-size:.82em;opacity:.8}.edlinks a{color:inherit}\n</style>')
    return t
for slug,n,label,native,lang in EDS:
    open('sulekhak-%s.html'%slug,'w',encoding='utf-8').write(edition(slug,n,label,native,lang))
stub='''<!doctype html><meta charset="utf-8"><title>Sulekhak</title><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=sulekhak.html"><link rel="canonical" href="sulekhak.html"><p style="font:16px system-ui;padding:24px">Sulekhak (formerly Lekhani, ସୁलेখk) has moved to <a href="sulekhak.html">sulekhak.html</a>.</p><script>location.replace('sulekhak.html'+location.search+location.hash)</script>'''
for f in ('sulekhk.html','odia-lekhani-typist-keyboard.html','lekhani-odia-typist.html'):
    open(f,'w',encoding='utf-8').write(stub)
print(len(out),'+ editions:',', '.join(e[0] for e in EDS))
