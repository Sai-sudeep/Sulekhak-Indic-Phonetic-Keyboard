/* Sulekhak candidate engine - JavaScript twin of sulekhak_engine.py (works in browsers, node and JavaScriptCore).
   var S = Sulekhak.create(); S.load({cfg, lex, rom, big, clus, syl_uni, syl_bi, syl_chan});   // each a string (cfg a string too)
   S.suggest('prajak', prevWord, nLex, nConv) -> [[word,'lex'|'conv'], ...]       S.commit(word)        S.dumpCache() / S.loadCache(obj) */
var Sulekhak=(function(){
'use strict';
var HAL='\u0B4D';
var CLRE=new RegExp('[\u0B15-\u0B39\u0B5C\u0B5D\u0B5F\u0B71](?:'+HAL+'[\u0B15-\u0B39\u0B5C\u0B5D\u0B5F\u0B71])+','g');
function clusters(w){return w.match(CLRE)||[]}
/* ---- fuzzy Roman keys (same rules as the Python reference) ---- */
var TR={c:'k',q:'k',f:'p',v:'b',w:'b',z:'j'};
var CONS_H={b:1,c:1,d:1,f:1,g:1,j:1,k:1,l:1,m:1,n:1,p:1,r:1,s:1,t:1,v:1,w:1,x:1,y:1,z:1,'\u010d':1};
var NASAL_BEFORE={b:1,p:1,k:1,g:1,j:1,t:1,d:1,'\u010d':1};
function k1(s){
  s=s.toLowerCase();
  var n=s.length,i,c,o=[],j;
  /* ch / chh -> c-caron ; ee -> i ; oo -> u */
  for(i=0;i<n;i++){
    c=s.charAt(i);
    if(c==='c'&&s.charAt(i+1)==='h'){o.push('\u010d');i+=(s.charAt(i+2)==='h')?2:1}
    else o.push(c);
  }
  var p=[];
  for(i=0;i<o.length;i++){
    c=o[i];
    if((c==='e'||c==='o')&&o[i+1]===c){p.push(c==='e'?'i':'u');i++}
    else p.push(c);
  }
  /* collapse runs of the same letter */
  var q=[];
  for(i=0;i<p.length;i++){c=p[i];if(i>0&&c===p[i-1]&&((c>='a'&&c<='z')||c==='\u010d'))continue;q.push(c)}
  /* drop h after a consonant (tested on the string before dropping) */
  var r=[];
  for(i=0;i<q.length;i++){c=q[i];if(c==='h'&&i>0&&CONS_H[q[i-1]]===1)continue;r.push(c)}
  /* m before a stop -> n ; c q f v w z mapped ; x -> ks */
  var out='';
  for(i=0;i<r.length;i++){
    c=r[i];
    if(c==='m'&&NASAL_BEFORE[r[i+1]]===1)out+='n';
    else if(c==='c'||c==='q')out+='k';
    else if(c==='f')out+='p';
    else if(c==='v'||c==='w')out+='b';
    else if(c==='z')out+='j';
    else if(c==='x')out+='ks';
    else out+=c;
  }
  return out;
}
function k1_regex(s){
  s=s.toLowerCase().replace(/chh/g,'\u010d').replace(/ch/g,'\u010d');
  s=s.replace(/ee/g,'i').replace(/oo/g,'u');
  s=s.replace(/([a-z\u010d])\1+/g,'$1');
  s=s.replace(/([bcdfgjklmnprstvwxyz\u010d])h/g,'$1');
  s=s.replace(/m(?=[bpkgjtd\u010d])/g,'n');
  s=s.replace(/[cqfvwz]/g,function(c){return TR[c]}).replace(/x/g,'ks');
  return s;
}
function k2from(k){return k.charAt(0)+k.slice(1).replace(/a/g,'')}
function k2(s){return k2from(k1(s))}
function tkeys(t,f){
  var out=[f(t)],e;
  if(/c$/.test(t)){e=f(t.slice(0,-1)+'ch');if(out.indexOf(e)<0)out.push(e)}
  if(/e$/.test(t)){e=f(t.slice(0,-1)+'ee');if(out.indexOf(e)<0)out.push(e)}
  if(/o$/.test(t)){e=f(t.slice(0,-1)+'oo');if(out.indexOf(e)<0)out.push(e)}
  return out;
}
function alpha(r){return r.toLowerCase().replace(/[^a-z]/g,'')}
function startsWith(s,p){return s.length>=p.length&&s.lastIndexOf(p,0)===0}
function lines(s,keep){var a=s.length?s.split('\n'):[];if(!keep&&a.length&&a[a.length-1]==='')a.pop();return a}
var ALPHA='abcdefghijklmnopqrstuvwxyz';
function edit1(t){
  var v={},i,c,L=t.length;
  for(i=0;i<L;i++){
    v[t.slice(0,i)+t.slice(i+1)]=1;
    if(i+1<L&&t.charAt(i)!==t.charAt(i+1))v[t.slice(0,i)+t.charAt(i+1)+t.charAt(i)+t.slice(i+2)]=1;
    for(c=0;c<26;c++)if(ALPHA.charAt(c)!==t.charAt(i))v[t.slice(0,i)+ALPHA.charAt(c)+t.slice(i+1)]=1;
  }
  for(i=0;i<=L;i++)for(c=0;c<26;c++)v[t.slice(0,i)+ALPHA.charAt(c)+t.slice(i)]=1;
  delete v[t];delete v[''];
  return Object.keys(v);
}
function ed1(a,b){                      /* Damerau-Levenshtein distance <= 1 (insert, delete, substitute, adjacent swap) */
  var la=a.length,lb=b.length;
  if(Math.abs(la-lb)>1)return false;
  var i=0;while(i<la&&i<lb&&a.charAt(i)===b.charAt(i))i++;
  if(i===la||i===lb)return true;
  if(la===lb){
    if(a.slice(i+1)===b.slice(i+1))return true;
    if(i+1<la&&a.charAt(i)===b.charAt(i+1)&&a.charAt(i+1)===b.charAt(i)&&a.slice(i+2)===b.slice(i+2))return true;
    return false;
  }
  if(la<lb)return a.slice(i)===b.slice(i+1);
  return a.slice(i+1)===b.slice(i);
}
/* ---- the user's memory: recency-decayed counts of committed words ---- */
function Cache(tau){this.tau=tau||100;this.t=0;this.M=0;this.v={};this.last={}}
Cache.prototype.p=function(w){var x=this.v[w];return !x?0:x*Math.exp(-(this.t-this.last[w])/this.tau)/Math.max(this.M,1e-9)};
Cache.prototype.commit=function(w){
  this.t++;this.M=this.M*Math.exp(-1/this.tau)+1;
  var x=this.v.hasOwnProperty(w)?this.v[w]*Math.exp(-(this.t-1-this.last[w])/this.tau):0;
  this.v[w]=x+1;this.last[w]=this.t;
};
Cache.prototype.dump=function(){return {tau:this.tau,t:this.t,M:this.M,v:this.v,last:this.last}};
Cache.load=function(o){var c=new Cache(o.tau);c.t=o.t;c.M=o.M;c.v=o.v;c.last=o.last;return c};

function create(){
  var S={ready:false}, cfg, words, u, N, wid, romLines, romC, T, clv, bigText, bigIdx, bigC, foll, cache;
  var clp={}, k1c={}, k2c={}, suni, sU, sbi, stot, EX, FZ, maxL, cl;
  /* ଯ is written with j as often as with y (jatra / yatra, jog / yog): every spelling of a word with ଯ that has a y at the ଯ also stands for the same spelling with j in that place (ୟ keeps y). */
  function jvars(i,r){var w=words[i];if(!w||w.indexOf('\u0B2F')<0)return r;var kinds=[],c,k;
    for(k=0;k<w.length;k++){c=w.charCodeAt(k);if(c===0x0B2F)kinds.push('j');else if(c===0x0B5F)kinds.push('y')}
    if(!kinds.length)return r;var seen={},o=[],j,x;for(j=0;j<r.length;j++){seen[r[j]]=1;o.push(r[j])}
    for(j=0;j<r.length;j++){var s=r[j],ys=s.match(/y/g);if(!ys||ys.length!==kinds.length)continue;var n=0;x=s.replace(/y/g,function(){return kinds[n++]});if(!seen[x]){seen[x]=1;o.push(x)}}
    return o}
  function roms(i){var r=romC[i];if(r===undefined){var l=romLines[i];r=l?l.split(' '):[];r=romC[i]=jvars(i,r)}return r}
  function keys(i,f,store){var r=store[i];if(r===undefined){var seen={},o=[],rs=roms(i);for(var j=0;j<rs.length;j++){var x=f(rs[j]);if(!seen[x]){seen[x]=1;o.push(x)}}r=store[i]=o}return r}
  function buildTables(){
    var cap=cfg.cap;T={g0:[null,new Map(),new Map(),new Map(),new Map()],g1:[null,new Map(),new Map(),new Map(),new Map()],g2:[null,new Map(),new Map(),new Map(),new Map()]};
    function add(tab,keys){
      for(var j=0;j<keys.length;j++){
        var r=keys[j],lim=Math.min(4,r.length);
        for(var k=1;k<=lim;k++){
          var q=r.substr(0,k),M=tab[k],L=M.get(q);
          if(L===undefined){M.set(q,[cur])}
          else if(L[L.length-1]!==cur&&L.length<cap)L.push(cur);
        }
      }
    }
    var cur=0;
    for(var i=0;i<words.length;i++){
      var rs=roms(i);if(!rs.length)continue;cur=i;
      add(T.g0,rs);
      var a1=[],a2=[],s1={},s2={};
      for(var j=0;j<rs.length;j++){
        var x=k1(rs[j]);if(!s1[x]){s1[x]=1;a1.push(x)}
        var y=k2from(x);if(!s2[y]){s2[y]=1;a2.push(y)}
      }
      add(T.g1,a1);add(T.g2,a2);
    }
  }
  function indexBig(){
    bigText=lines(S._big);bigIdx={};
    for(var j=0;j<bigText.length;j++){var l=bigText[j],p=l.indexOf('\t');bigIdx[l.substr(0,p)]=j}
    bigC={};foll={};
  }
  function bigOf(prev){                     /* prev word (string) or '<s>' -> {tot, m: id->count, order: ids by count} or null */
    var pid=prev==='<s>'?-1:wid[prev];if(pid===undefined)return null;
    var r=bigC[pid];if(r!==undefined)return r;
    var j=bigIdx[pid];if(j===undefined)return bigC[pid]=null;
    var f=bigText[j].split('\t'),m={},order=[];
    if(f[2]){var ps=f[2].split(',');for(var q=0;q<ps.length;q++){var c=ps[q].indexOf(':'),id=+ps[q].substr(0,c);m[id]=+ps[q].substr(c+1);order.push(id)}}
    return bigC[pid]={tot:+f[1],m:m,order:order};
  }
  function clusterCounts(i){
    var r=clp[i];
    if(r===undefined){
      var n1=0,n2=0,cs=clusters(words[i]);
      for(var j=0;j<cs.length;j++){var k=cl.hasOwnProperty(cs[j])?cl[cs[j]]:2;if(k===1)n1++;else if(k===2)n2++}
      r=clp[i]=[n1,n2];
    }
    return r;
  }
  S.load=function(P){
    cfg=typeof P.cfg==='string'?JSON.parse(P.cfg):P.cfg;
    var L=lines(P.lex);words=new Array(L.length);u=new Float64Array(L.length);wid={};
    for(var i=0;i<L.length;i++){var t=L[i].indexOf('\t');words[i]=L[i].substr(0,t);var c=+L[i].substr(t+1);u[i]=c>0?c:0.3;wid[words[i]]=i}
    N=cfg.N;romLines=lines(P.rom,true);romC={};
    cl={};var C=lines(P.clus);for(i=0;i<C.length;i++){var f=C[i].split('\t');cl[f[0]]=+f[1]}
    S._big=P.big;indexBig();
    buildTables();
    /* converter */
    suni={};sU=0;var U=lines(P.syl_uni);for(i=0;i<U.length;i++){f=U[i].split('\t');suni[f[0]]=+f[1];sU+=+f[1]}
    sbi={};stot={};var B=lines(P.syl_bi);for(i=0;i<B.length;i++){f=B[i].split('\t');var cnt=+f[2];sbi[f[0]+'\t'+f[1]]=cnt;stot[f[0]]=(stot[f[0]]||0)+cnt}
    EX={};var fz={};maxL=0;var H=lines(P.syl_chan);
    for(i=0;i<H.length;i++){
      f=H[i].split('\t');var pen=+f[2];(EX[f[0]]||(EX[f[0]]=[])).push([f[1],pen]);
      if(f[0].length>maxL)maxL=f[0].length;
      var kk=k1(f[0]);if(kk){var m=fz[kk]||(fz[kk]={});if(!(f[1] in m)||m[f[1]]>pen)m[f[1]]=pen}
    }
    FZ={};for(var key in fz){var a=[];for(var o in fz[key])a.push([o,fz[key][o]]);FZ[key]=a}
    if(!cache)cache=new Cache(cfg.tau);
    S.ready=true;return S;
  };
  /* ---------------- lexicon side ---------------- */
  function nearEdit(t,i){
    var rs=roms(i),L=t.length;
    for(var j=0;j<rs.length;j++){var r=rs[j];for(var m=L-1;m<=L+1;m++){if(m>0&&r.substr(0,m)!==t.substr(0,m)&&ed1(t,r.substr(0,m)))return true}}
    return false;
  }
  S.lexicon=function(typed,prev,n,opt){
    var c=cfg,t=alpha(typed);if(!t)return [];
    var useEd=!(opt&&opt.noEdit)&&c.ed;
    var k=Math.min(t.length,4),pool={},p0=(T.g0[k].get(t.substr(0,k))||[]),i,j,key,kk,L;
    for(j=0;j<p0.length;j++)pool[p0[j]]=1;
    var tk1=tkeys(t,k1),tk2=tkeys(t,k2);
    for(j=0;j<tk1.length;j++){key=tk1[j];kk=Math.min(key.length,4);if(kk){L=(T.g1[kk].get(key.substr(0,kk))||[]);for(i=0;i<L.length;i++)pool[L[i]]=1}}
    for(j=0;j<tk2.length;j++){key=tk2[j];kk=Math.min(key.length,4);if(kk){L=(T.g2[kk].get(key.substr(0,kk))||[]);for(i=0;i<L.length;i++)pool[L[i]]=1}}
    var bg=bigOf(prev);
    if(bg){var fc=Math.min(bg.order.length,c.follower_cap);for(j=0;j<fc;j++)pool[bg.order[j]]=1}
    var edset=null;
    if(useEd&&t.length>=c.ed.minlen){
      var nex=0;
      for(j=0;j<p0.length&&nex<c.ed.gate;j++){var rs0=roms(p0[j]);for(var q=0;q<rs0.length;q++)if(startsWith(rs0[q],t)){nex++;break}}
      if(nex<c.ed.gate){
        var cand={};for(j=0;j<p0.length;j++)cand[p0[j]]=1;
        var base=t.length>4?t.substr(0,5):t,vs=edit1(base);
        for(j=0;j<vs.length;j++){
          var vv=t.length>4?vs[j]+t.substr(5):vs[j];kk=Math.min(vv.length,4);
          L=(T.g0[kk].get(vv.substr(0,kk))||[]);var m=Math.min(L.length,c.ed.cap);
          for(i=0;i<m;i++)cand[L[i]]=1;
        }
        edset={};for(var id in cand)if(nearEdit(t,+id)){edset[id]=1;pool[id]=1}
      }
    }
    var scored=[],bn=bg?Math.max(bg.tot,1e-9):1e-9;
    for(var sid in pool){
      i=+sid;var rs=roms(i),chan=null,x,y;
      for(j=0;j<rs.length;j++)if(startsWith(rs[j],t)){chan=0;break}
      if(chan===null){var K1=keys(i,k1,k1c);outer1:for(x=0;x<K1.length;x++)for(y=0;y<tk1.length;y++)if(startsWith(K1[x],tk1[y])){chan=-c.w1;break outer1}}
      if(chan===null){var K2=keys(i,k2,k2c);outer2:for(x=0;x<K2.length;x++)for(y=0;y<tk2.length;y++)if(startsWith(K2[x],tk2[y])){chan=-c.w2;break outer2}}
      if(chan===null&&edset&&edset[i])chan=-c.ed.w3;
      if(chan===null)continue;
      var w=words[i],pb=bg&&bg.m[i]?bg.m[i]/bn:0;
      var lm=c.a*pb+(1-c.a)*u[i]/N;
      lm=(1-c.lc)*lm+c.lc*cache.p(w);
      var cc=clusterCounts(i);
      scored.push([Math.log(lm+1e-12)+chan-c.p1*cc[0]-c.p2*cc[1],i]);
    }
    scored.sort(function(A,B){return B[0]!==A[0]?B[0]-A[0]:B[1]-A[1]});
    scored=scored.slice(0,n);
    return scored.map(function(s){return {w:words[s[1]],i:s[1],s:s[0]}});
  };
  /* ---------------- converter ---------------- */
  function slm(prev,o,c){
    var b=stot[prev]?(sbi[prev+'\t'+o]||0)/stot[prev]:0;
    var uu=o!=='$'?(suni[o]||0)/sU:1e-4;
    return Math.log(c.mix*b+(1-c.mix)*uu+1e-9);
  }
  function cmpBeam(a,b){return a[0]!==b[0]?b[0]-a[0]:(a[1]<b[1]?1:a[1]>b[1]?-1:(a[2]<b[2]?1:a[2]>b[2]?-1:0))}
  S.converter=function(typed,n){
    var c=cfg.converter,t=alpha(typed),L=t.length;if(!L)return [];
    var beams=new Array(L+1),i,ln,j,o;for(i=0;i<=L;i++)beams[i]=[];beams[0]=[[0,'','^']];
    for(i=0;i<L;i++){
      var hs=beams[i];if(!hs.length)continue;
      if(hs.length>c.beam){hs=hs.slice().sort(cmpBeam).slice(0,c.beam)}
      for(ln=1;ln<=Math.min(maxL,L-i);ln++){
        var seg=t.substr(i,ln),opts={},any=false,e=EX[seg],f;
        if(e)for(j=0;j<e.length;j++){opts[e[j][0]]=e[j][1];any=true}
        f=FZ[k1(seg)];
        if(f)for(j=0;j<f.length;j++){var v=f[j][1]+c.fz;if(!(f[j][0] in opts)||opts[f[j][0]]>v){opts[f[j][0]]=v;any=true}}
        if(!any)continue;
        for(var h=0;h<hs.length;h++){var H=hs[h];for(o in opts)beams[i+ln].push([H[0]+c.lam*slm(H[2],o,c)-opts[o],H[1]+o,o])}
      }
    }
    var seen={};
    for(j=0;j<beams[L].length;j++){
      var B=beams[L][j],sc2=B[0]+c.lam*slm(B[2],'$',c),cs=clusters(B[1]);
      for(var q=0;q<cs.length;q++){var kk=cl.hasOwnProperty(cs[q])?cl[cs[q]]:2;if(kk===1)sc2-=c.p1;else if(kk===2)sc2-=c.p2}
      if(!(B[1] in seen)||seen[B[1]]<sc2)seen[B[1]]=sc2;
    }
    var items=[];for(var w in seen)items.push([w,seen[w]]);
    items.sort(function(a,b){return b[1]-a[1]});items=items.slice(0,c.nbest);
    items=items.map(function(it){var id=wid[it[0]];return [it[0],it[1]+(id!==undefined?c.beta+c.gamma*Math.log(1+u[id]):0)]});
    items.sort(function(a,b){return b[1]-a[1]});
    return items.slice(0,n).map(function(a){return a[0]});
  };
  /* ---------------- public ---------------- */
  S.suggest=function(typed,prev,nLex,nConv,opt){
    prev=prev||'<s>';var d=cfg.display;if(nLex==null)nLex=d.lexicon;if(nConv==null)nConv=d.converter;
    var t=alpha(typed);if(!t)return [];
    var lex=S.lexicon(t,prev,nLex,opt),conv=nConv?S.converter(t,nConv):[];
    var near=!lex.length;
    if(!near){var rs=roms(lex[0].i),m=99;for(var j=0;j<rs.length;j++)if(startsWith(rs[j],t)&&rs[j].length<m)m=rs[j].length;near=m<=t.length+1}
    if(near&&lex.length&&cache.p(lex[0].w)>0.02)near=false;      /* a word the user has chosen before keeps the first place */
    var out=[],seen={},a=conv.map(function(w){return [w,'conv']}),b=lex.map(function(x){return [x.w,'lex']});
    var all=near?a.concat(b):b.concat(a);
    for(var q=0;q<all.length;q++)if(!seen[all[q][0]]){seen[all[q][0]]=1;out.push(all[q])}
    return out;
  };
  S.commit=function(w){if(w)cache.commit(w)};
  S.dumpCache=function(){return cache.dump()};
  S.loadCache=function(o){cache=Cache.load(o)};
  S.has=function(w){return wid.hasOwnProperty(w)};
  /* the words that most often follow `prev` in the news and dictionary text (empty when the word is not known) */
  S.next=function(prev,n){
    if(!S.ready||!prev||prev==='<s>') return [];
    var forms=[prev,prev.replace(/\u0B21\u0B3C/g,'\u0B5C').replace(/\u0B22\u0B3C/g,'\u0B5D').replace(/\u0B2F\u0B3C/g,'\u0B5F'),prev.replace(/\u0B5C/g,'\u0B21\u0B3C').replace(/\u0B5D/g,'\u0B22\u0B3C').replace(/\u0B5F/g,'\u0B2F\u0B3C')];
    for(var f=0;f<forms.length;f++){
      var r=bigOf(forms[f]); if(!r||!r.order.length) continue;
      var out=[];
      for(var i=0;i<r.order.length&&out.length<(n||6);i++){ var w=words[r.order[i]]; if(w&&/[\u0B05-\u0B39\u0B5C-\u0B61]/.test(w)) out.push(w) }
      if(out.length) return out;
    }
    return [];
  };
  S.k1=k1;S.k2=k2;S.ed1=ed1;
  return S;
}
return {create:create,k1:k1,k1_regex:k1_regex,k2:k2,ed1:ed1,alpha:alpha};
})();
if(typeof module!=='undefined')module.exports=Sulekhak;
