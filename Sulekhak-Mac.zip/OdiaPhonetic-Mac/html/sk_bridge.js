/* Sulekhak smart candidates (web): the engine runs in a Web Worker so typing never waits for it.
   Data files (sulekhak/*.gz) sit next to this page; if they cannot be fetched the original engine carries on alone. */
var SKB=(function(){
  var w=null,ready=false,failed=false,seq=0,res={},resKeys=[],SKKEY='sulekhakCommits1',on=true;
  try{ if(/[?&]sk=0\b/.test(location.search)||localStorage.getItem('sulekhakOff')==='1') on=false }catch(e){}
  var H="var S=Sulekhak.create();\n"+
   "function gz(u){return fetch(u).then(function(r){if(!r.ok)throw new Error(u+' '+r.status);return new Response(r.body.pipeThrough(new DecompressionStream('gzip'))).text()})}\n"+
   "onmessage=function(e){var m=e.data;\n"+
   " if(m.t==='init'){var N=['cfg','lex','rom','big','clus','syl_uni','syl_bi','syl_chan'];\n"+
   "  Promise.all(N.map(function(n){return gz(m.base+n+'.gz')})).then(function(a){var P={};N.forEach(function(n,i){P[n]=a[i]});S.load(P);(m.replay||[]).forEach(function(x){S.commit(x)});postMessage({t:'ready'})}).catch(function(err){postMessage({t:'fail',e:String(err)})})}\n"+
   " else if(m.t==='q'){postMessage({t:'r',buf:m.buf,prev:m.prev,r:S.suggest(m.buf,m.prev,m.nl,m.nc)})}\n"+
   " else if(m.t==='n'){postMessage({t:'nr',w:m.w,r:S.next(m.w,8)})}\n"+
   " else if(m.t==='c'){S.commit(m.w)}};";
  function start(){
    if(!on||w||failed)return;
    try{
      var src=document.getElementById('sk-src').textContent;
      w=new Worker(URL.createObjectURL(new Blob([src+"\n"+H],{type:'text/javascript'})));
      w.onmessage=function(e){var m=e.data;
        if(m.t==='ready'){ready=true;window.__skReady=1;if(SKB.onchange)SKB.onchange()}
        else if(m.t==='fail'){failed=true;window.__skFail=m.e;try{console.warn('Sulekhak engine not loaded:',m.e)}catch(x){}}
        else if(m.t==='nr'){if(SKB.onnext)SKB.onnext(m.w,m.r||[])}
        else if(m.t==='r'){var k=m.buf+'\t'+m.prev;if(!(k in res))resKeys.push(k);res[k]=m.r;if(resKeys.length>200)delete res[resKeys.shift()];if(SKB.onchange)SKB.onchange(m.buf)}};
      w.onerror=function(){failed=true};
      var replay=[];try{replay=JSON.parse(localStorage.getItem(SKKEY)||'[]')}catch(x){}
      w.postMessage({t:'init',base:new URL('sulekhak/',location.href).href,replay:replay});
    }catch(e){failed=true}
  }
  return {
    start:start,
    get ready(){return ready},
    get:function(buf,prev){return ready?res[buf+'\t'+prev]:undefined},
    ask:function(buf,prev){if(ready&&!((buf+'\t'+prev) in res))w.postMessage({t:'q',buf:buf,prev:prev,nl:4,nc:2})},
    commit:function(word){
      if(!word)return;
      if(ready)w.postMessage({t:'c',w:word});
      try{var a=JSON.parse(localStorage.getItem(SKKEY)||'[]');a.push(word);localStorage.setItem(SKKEY,JSON.stringify(a.slice(-400)))}catch(e){}
    },
    nextAsk:function(word){if(ready&&word)w.postMessage({t:'n',w:word})},      /* the words that usually follow `word` -> SKB.onnext(word, list) */
    onnext:null,
    onchange:null
  };
})();
