import re
s=open('typist.tpl.html',encoding='utf-8').read()
# 1. engine source + bridge
s=s.replace('<script type="text/plain" id="skeldata">__SKEL__</script>','<script type="text/plain" id="skeldata">__SKEL__</script>\n<script type="text/plain" id="sk-src">__SULEKHAK__</script>',1)
a=s.index("function remember(r,o)")
s=s[:a]+"__SKBRIDGE__\n"+s[a:]
# 2. refresh with merge
old="function refresh(){ st.navd=false; if(!st.buf){reset();return} var cr=E.candidatesIn(st.buf,SC,sopts()); st.cands=cr.disp; st.candsO=cr.odia;"
assert old in s
new='''function skPrev(){
  var t=(st.text||'').slice(Math.max(0,st.pos-80),st.pos), cls=SC===1?'[\\\\u0900-\\\\u0963\\\\u0966-\\\\u097F]':(SC===2||SC===5)?'[\\\\u0980-\\\\u09E3\\\\u09E6-\\\\u09FF]':'[\\\\u0B00-\\\\u0B63\\\\u0B66-\\\\u0B7F]';
  var m=t.match(new RegExp('('+cls+'[\\\\u200c\\\\u200d]?)+[ \\\\t]*$')); if(!m) return '<s>';
  var w=m[0].replace(/[ \\\\t]+$/,''); if(SC!==0){ try{ w=E.toOdia(w) }catch(e){} } return w || '<s>';
}
function skMerge(cr){
  if(!SKB.ready||!/^[A-Za-z]+$/.test(st.buf)) return cr;
  var pv=skPrev(), r=SKB.get(st.buf,pv);
  if(r===undefined){ SKB.ask(st.buf,pv); return cr }
  if(!r.length) return cr;
  var od=cr.odia, ds=cr.disp, O=[], D=[], seen={}, i;
  function push(o,d){ if(seen[o]) return; seen[o]=1; O.push(o); D.push(d) }
  push(r[0][0],E.toScript(r[0][0],SC,sopts()));
  if(od.length>1){ O.push(od[1]); D.push(ds[1]); seen[od[1]]=1 }
  for(i=1;i<r.length;i++) push(r[i][0],E.toScript(r[i][0],SC,sopts()));
  for(i=0;i<od.length;i++) if(i!==1) push(od[i],ds[i]);
  return {disp:D,odia:O};
}
SKB.onchange=function(b){ if(!b||b===st.buf){ if(st.buf) refresh() } };
setTimeout(function(){ SKB.start() },400);
function refresh(){ st.navd=false; if(!st.buf){reset();return} var cr=skMerge(E.candidatesIn(st.buf,SC,sopts())); st.cands=cr.disp; st.candsO=cr.odia;'''
s=s.replace(old,new,1)
# 3. commit hooks
old="E.lexAdd(roman,oword,3);remember(roman,oword)}\n  reset(); st.pending=false;"
assert old in s
s=s.replace(old,"E.lexAdd(roman,oword,3);remember(roman,oword);SKB.commit(oword)}\n  reset(); st.pending=false;",1)
old="E.lexAdd(roman,w,3); remember(roman,w); reset(); return true;"
assert old in s
s=s.replace(old,"E.lexAdd(roman,w,3); remember(roman,w); SKB.commit(w); reset(); return true;",1)
open('typist.tpl.html','w',encoding='utf-8').write(s)
m=open('make_html.py',encoding='utf-8').read()
m=m.replace("out=tpl.replace('__SKEL__',skel)","out=tpl.replace('__SULEKHAK__',open('sulekhak.js',encoding='utf-8').read()).replace('__SKBRIDGE__',open('sk_bridge.js',encoding='utf-8').read()).replace('__SKEL__',skel)",1)
open('make_html.py','w',encoding='utf-8').write(m)
