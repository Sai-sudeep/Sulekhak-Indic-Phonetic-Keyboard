/* Sulekhak candidate engine for the Mac keyboard (v3.2): the typing-test engine v6 (Roman aliases, spelling rules, weighted lexicon, trigram language model) behind the
   same small interface the Mac app has always used:  var SK=Sulekhak.create(); SK.load({cfg,lex,rom,clus,syl_uni,syl_bi,syl_chan, ng:[ArrayBuffer...], limit});
   SK.suggest(roman, prevWord, nLex, nConv) -> [[word,"lex"|"conv"],...]   SK.next(word, n) -> [word,...]   SK.commit(word)
   Original header: browser twin of sulekhak_engine.py / engine_ng.py.
   One engine instance holds one word list.  Language model:
     old pack : lm = a*P(w|prev) + (1-a)*P(w)                     (the shipped rule, bigram text file)
     new pack : order 1/2/3, count-dependent weights, bigram + trigram tables (compact binary)
   var S = SK.create(); S.load({cfg, lex, rom, big, clus, syl_uni, syl_bi, syl_chan, ng, limit});
   S.suggest(typed, prev, prev2, nLex, nConv) -> [[word,'lex'|'conv'], ...]     S.commit(word) */
var SKE=(function(){
'use strict';
var HAL='୍';
var CLRE=new RegExp('[କ-ହଡ଼ଢ଼ୟୱ](?:'+HAL+'[କ-ହଡ଼ଢ଼ୟୱ])+','g');
function clusters(w){return w.match(CLRE)||[]}
var CONS_H={b:1,c:1,d:1,f:1,g:1,j:1,k:1,l:1,m:1,n:1,p:1,r:1,s:1,t:1,v:1,w:1,x:1,y:1,z:1,'č':1};
var NASAL_BEFORE={b:1,p:1,k:1,g:1,j:1,t:1,d:1,'č':1};
function k1(s){
  s=s.toLowerCase().replace(/~/g,'');          /* chandrabindu marker in the lexicon keys: typed text never has it */
  var n=s.length,i,c,o=[];
  for(i=0;i<n;i++){
    c=s.charAt(i);
    if(c==='c'&&s.charAt(i+1)==='h'){o.push('č');i+=(s.charAt(i+2)==='h')?2:1}
    else o.push(c);
  }
  var p=[];
  for(i=0;i<o.length;i++){
    c=o[i];
    if((c==='e'||c==='o')&&o[i+1]===c){p.push(c==='e'?'i':'u');i++}
    else p.push(c);
  }
  var q=[];
  for(i=0;i<p.length;i++){c=p[i];if(i>0&&c===p[i-1]&&((c>='a'&&c<='z')||c==='č'))continue;q.push(c)}
  var r=[];
  for(i=0;i<q.length;i++){c=q[i];if(c==='h'&&i>0&&CONS_H[q[i-1]]===1)continue;r.push(c)}
  var out='';
  for(i=0;i<r.length;i++){
    c=r[i];
    if(c==='m'&&NASAL_BEFORE[r[i+1]]===1)out+='n';
    else if(c==='c'||c==='q')out+='k';
    else if(c==='f')out+='p';
    else if(c==='v'||c==='w')out+='b';
    else if(c==='z')out+='j';
    else if(c==='x')out+='ks';
    else out+=c;
  }
  return out;
}
function k2from(k){return k.charAt(0)+k.slice(1).replace(/a/g,'')}
function k2(s){return k2from(k1(s))}
function tkeys(t,f){
  var out=[f(t)],e;
  if(/c$/.test(t)){e=f(t.slice(0,-1)+'ch');if(out.indexOf(e)<0)out.push(e)}
  if(/e$/.test(t)){e=f(t.slice(0,-1)+'ee');if(out.indexOf(e)<0)out.push(e)}
  if(/o$/.test(t)){e=f(t.slice(0,-1)+'oo');if(out.indexOf(e)<0)out.push(e)}
  return out;
}
function alpha(r){return r.toLowerCase().replace(/[^a-z]/g,'')}
function startsWith(s,p){return s.length>=p.length&&s.lastIndexOf(p,0)===0}
function lines(s,keep){var a=s.length?s.split('\n'):[];if(!keep&&a.length&&a[a.length-1]==='')a.pop();return a}
var ALPHA='abcdefghijklmnopqrstuvwxyz';
function edit1(t){
  var v={},i,c,L=t.length;
  for(i=0;i<L;i++){
    v[t.slice(0,i)+t.slice(i+1)]=1;
    if(i+1<L&&t.charAt(i)!==t.charAt(i+1))v[t.slice(0,i)+t.charAt(i+1)+t.charAt(i)+t.slice(i+2)]=1;
    for(c=0;c<26;c++)if(ALPHA.charAt(c)!==t.charAt(i))v[t.slice(0,i)+ALPHA.charAt(c)+t.slice(i+1)]=1;
  }
  for(i=0;i<=L;i++)for(c=0;c<26;c++)v[t.slice(0,i)+ALPHA.charAt(c)+t.slice(i)]=1;
  delete v[t];delete v[''];
  return Object.keys(v);
}
function ed1(a,b){
  var la=a.length,lb=b.length;
  if(Math.abs(la-lb)>1)return false;
  var i=0;while(i<la&&i<lb&&a.charAt(i)===b.charAt(i))i++;
  if(i===la||i===lb)return true;
  if(la===lb){
    if(a.slice(i+1)===b.slice(i+1))return true;
    if(i+1<la&&a.charAt(i)===b.charAt(i+1)&&a.charAt(i+1)===b.charAt(i)&&a.slice(i+2)===b.slice(i+2))return true;
    return false;
  }
  if(la<lb)return a.slice(i)===b.slice(i+1);
  return a.slice(i+1)===b.slice(i);
}
function Cache(tau){this.tau=tau||100;this.t=0;this.M=0;this.v={};this.last={}}
Cache.prototype.p=function(w){var x=this.v[w];return !x?0:x*Math.exp(-(this.t-this.last[w])/this.tau)/Math.max(this.M,1e-9)};
Cache.prototype.commit=function(w){
  this.t++;this.M=this.M*Math.exp(-1/this.tau)+1;
  var x=this.v.hasOwnProperty(w)?this.v[w]*Math.exp(-(this.t-1-this.last[w])/this.tau):0;
  this.v[w]=x+1;this.last[w]=this.t;
};


/* ---- Roman spelling aliases: what people really type for the same Odia sound (typed side only; every lexicon key stays canonical) ----
   khy kkh ksy -> ksh (କ୍ଷ) ; jny gny dny jn gn -> gy (ଜ୍ଞ) ; s -> sh (ସ ଶ ଷ share one key) ; ng / n before s h -> m (ଂ) ; y -> j (ଯ) ; ru -> ri (ୃ) ; medial kh -> ksh */
function aliasVariants(t){
  var v=[],seen={};seen[t]=1;
  function add(x){if(x&&!seen[x]){seen[x]=1;v.push(x)}}
  var a=t.replace(/khy|kkh|ksy|kxy/g,'ksh'),
      a2=a.replace(/([a-z])kh/g,'$1ksh'),
      b=t.replace(/jny|gny|dny|jn|gn/g,'gy'),
      e=t.replace(/([bcdfghjklmnpqstvwxz])ru/g,'$1ri'),
      c=t.replace(/ng(?=[a-z])/g,'m').replace(/n(?=[sh])/g,'m'),
      d=t.replace(/([a-z])y/g,'$1j');
  add(t.replace(/s(?!h)/g,'sh'));add(a);add(a2);add(b);add(e);add(c);add(d);add(t.replace(/c(?!h)/g,'ch'));add(t.replace(/sr/g,'shr'));
  var all=d.replace(/jny|gny|dny|jn|gn/g,'gy').replace(/khy|kkh|ksy|kxy/g,'ksh').replace(/([a-z])kh/g,'$1ksh').replace(/ng(?=[a-z])/g,'m');
  add(all);
  return v.slice(0,7);
}
/* ---- spelling filter on every generated word (the web app's validWord + the ZWNJ rule B.2) ---- */
function vStop(cp){if(cp>=0xB15&&cp<=0xB18)return 1;if(cp>=0xB1A&&cp<=0xB1D)return 2;if((cp>=0xB1F&&cp<=0xB22)||cp===0xB5C||cp===0xB5D)return 3;if(cp>=0xB24&&cp<=0xB27)return 4;if(cp>=0xB2A&&cp<=0xB2D)return 5;return 0}
function vNasal(cp){switch(cp){case 0xB19:return 1;case 0xB1E:return 2;case 0xB23:return 3;case 0xB28:return 4;case 0xB2E:return 5}return 0}
function vCons(cp){return (cp>=0xB15&&cp<=0xB39)||cp===0xB5C||cp===0xB5D||cp===0xB5F||cp===0xB71}
function vSign(cp){return (cp>=0xB3E&&cp<=0xB44)||cp===0xB47||cp===0xB48||cp===0xB4B||cp===0xB4C||cp===0xB56||cp===0xB57||cp===0xB62||cp===0xB63}
function validWord(w){
  var n=w.length,i,cp=[];for(i=0;i<n;i++)cp.push(w.charCodeAt(i));
  for(i=0;i<n;i++){
    var c=cp[i],p=i?cp[i-1]:0,x=i+1<n?cp[i+1]:0;
    if(vSign(c)){if(!(vCons(p)||p===0xB3C))return false}
    else if(c===0xB4D){if(!(vCons(p)||p===0xB3C||p===0x200D))return false;if(x===0xB4D||vSign(x))return false}
    else if(c===0xB3C){if(!(p===0xB21||p===0xB22))return false}
    else if(c===0xB01||c===0xB02||c===0xB03){if(i===0||vSign(x))return false}
    else if(c===0x200C){if(p!==0xB4D)return false}
    else if(c===0x200D){if(!(p===0xB30&&x===0xB4D&&i+2<n&&(cp[i+2]===0xB5F||cp[i+2]===0xB2F)))return false}
    if(vCons(c)&&x===0xB4D&&i+2<n){
      var nx=cp[i+2],fc=vStop(nx),nl=vNasal(c);
      if(nl&&fc){if(nl!==fc&&!(nl===4&&fc===5))return false}
      if(c===0xB37&&(fc===4||fc===2))return false;
      if(c===0xB38&&fc===2)return false;
      if(c===0xB36&&(fc===3||fc===4))return false;
    }
  }
  return true;
}
/* rule B.2: a halant before ବ or ଵ keeps the letters apart with a ZWNJ, except in the true conjuncts (ର୍ବ ମ୍ବ ବ୍ବ ; ର୍ଵ) ; ଗ୍‌ଦ always */
function zwRule(w){
  if(w.indexOf(HAL)<0)return w;
  var o='',n=w.length;
  for(var i=0;i<n;i++){
    var c=w.charAt(i);o+=c;
    if(c===HAL&&i+1<n&&w.charAt(i+1)!=='‌'){
      var p=i?w.charAt(i-1):'',x=w.charAt(i+1);
      if(x==='ବ'&&p!=='ର'&&p!=='ମ'&&p!=='ବ')o+='‌';
      else if(x==='ଵ'&&p!=='ର')o+='‌';
      else if(x==='ଦ'&&p==='ଗ')o+='‌';
    }
  }
  return o;
}
function fixWord(w){return validWord(w)?zwRule(w):null}
/* compound members that end in a bare କ୍ : the joined spelling can read as another word (ବାକ୍ସଂଯମ reads as ବାକ୍ସ + ଂଯମ).  Proposed rule, see report. */
var ZWFIRST=['ବାକ୍','ଦିକ୍','ଦୃକ୍','ପ୍ରାକ୍','ପୃଥକ୍'];
var AKRE=/[କ-ହଡ଼ଢ଼ୟୱ](?!୍)/g;

/* compact n-gram files (see export_ng.py / split_ng.py): bigram parts and a trigram part, each a valid NG01 file */
function parseOne(buf){
  var dv=new DataView(buf),off=20;
  if(dv.getUint32(0,true)!==0x3130474E)throw new Error('bad n-gram file');
  var nA=dv.getUint32(4,true),nAF=dv.getUint32(8,true),nT=dv.getUint32(12,true),nTF=dv.getUint32(16,true);
  function u32(n){var a=new Uint32Array(buf.slice(off,off+n*4));off+=n*4;return a}
  function u16(n){var a=new Uint16Array(buf.slice(off,off+n*2));off+=n*2;return a}
  var g={nA:nA,nT:nT};
  g.A=u32(nA);g.TOT=u32(nA);g.OFF=u32(nA+1);g.FID=u32(nAF);g.FCN=u16(nAF);
  g.TA=u32(nT);g.TB=u32(nT);g.TN=u32(nT);g.TOFF=u32(nT+1);g.TID=u32(nTF);g.TCN=u16(nTF);
  return g;
}
function parseNG(bufs){
  if(!Array.isArray(bufs))bufs=[bufs];
  var g={A:[],TOT:[],OFF:[],FID:[],FCN:[]},i,j;
  var parts=bufs.map(parseOne),nA=0,nAF=0;
  parts.forEach(function(p){nA+=p.nA;nAF+=p.FID.length});
  g.A=new Uint32Array(nA);g.TOT=new Uint32Array(nA);g.OFF=new Uint32Array(nA+1);g.FID=new Uint32Array(nAF);g.FCN=new Uint16Array(nAF);
  var ca=0,cf=0;
  parts.forEach(function(p){
    if(p.nA){
      g.A.set(p.A,ca);g.TOT.set(p.TOT,ca);g.FID.set(p.FID,cf);g.FCN.set(p.FCN,cf);
      for(j=0;j<p.nA;j++)g.OFF[ca+j]=p.OFF[j]+cf;
      ca+=p.nA;cf+=p.FID.length;
    }
    if(p.nT){g.TA=p.TA;g.TB=p.TB;g.TN=p.TN;g.TOFF=p.TOFF;g.TID=p.TID;g.TCN=p.TCN;g.nT=p.nT}
  });
  g.OFF[nA]=nAF;
  g.nA=nA;
  /* the context arrays are sorted (np.unique), so a lookup is a binary search: no hash tables, a fraction of the memory */
  g.findA=function(a){var lo=0,hi=g.nA-1;while(lo<=hi){var m=(lo+hi)>>>1,v=g.A[m];if(v===a)return m;if(v<a)lo=m+1;else hi=m-1}return -1};
  g.findT=function(a,b){
    if(!g.nT)return -1;var lo=0,hi=g.nT-1;
    while(lo<=hi){var m=(lo+hi)>>>1,x=g.TA[m],y=g.TB[m];if(x===a&&y===b)return m;if(x<a||(x===a&&y<b))lo=m+1;else hi=m-1}
    return -1;
  };
  return g;
}

function create(){
  var S={ready:false,order:3,a2:0.9,k2:5,a3:0.8,k3:5,BOS:464570,wAlias:1.5,convAliasPen:1.0,shPen:0.3,shW:0.6,rules:true,aliases:true}, cfg, words, u, N, wid, romLines, romC, T, bigText, bigIdx, bigC, cache, ng, ngBi={}, ngTri={}, nw;
  var clp={}, k1c={}, k2c={}, suni, sU, sbi, stot, EX, FZ, maxL, cl;
  function roms(i){var r=romC[i];if(r===undefined){var l=romLines[i];r=romC[i]=l?l.split(' '):[]}return r}
  function keys(i,f,store){var r=store[i];if(r===undefined){var seen={},o=[],rs=roms(i);for(var j=0;j<rs.length;j++){var x=f(rs[j]);if(!seen[x]){seen[x]=1;o.push(x)}}r=store[i]=o}return r}
  function buildTables(){
    var cap=cfg.cap;T={g0:[null,new Map(),new Map(),new Map(),new Map()],g1:[null,new Map(),new Map(),new Map(),new Map()],g2:[null,new Map(),new Map(),new Map(),new Map()]};
    var cur=0;
    function add(tab,ks){
      for(var j=0;j<ks.length;j++){
        var r=ks[j],lim=Math.min(4,r.length);
        for(var k=1;k<=lim;k++){
          var q=r.substr(0,k),M=tab[k],L=M.get(q);
          if(L===undefined){M.set(q,[cur])}
          else if(L[L.length-1]!==cur&&L.length<cap)L.push(cur);
        }
      }
    }
    for(var i=0;i<words.length;i++){
      var rs=roms(i);if(!rs.length)continue;cur=i;
      add(T.g0,rs);
      var a1=[],a2=[],s1={},s2={};
      for(var j=0;j<rs.length;j++){
        var x=k1(rs[j]);if(!s1[x]){s1[x]=1;a1.push(x)}
        var y=k2from(x);if(!s2[y]){s2[y]=1;a2.push(y)}
      }
      add(T.g1,a1);add(T.g2,a2);
    }
  }
  /* old-style bigram text */
  function indexBig(text){
    bigText=lines(text);bigIdx={};
    for(var j=0;j<bigText.length;j++){var l=bigText[j],p=l.indexOf('\t');bigIdx[l.substr(0,p)]=j}
    bigC={};
  }
  function bigOf(prev){
    var pid=prev==='<s>'?-1:wid[prev];if(pid===undefined)return null;
    var r=bigC[pid];if(r!==undefined)return r;
    var j=bigIdx[pid];if(j===undefined)return bigC[pid]=null;
    var f=bigText[j].split('\t'),m={},order=[];
    if(f[2]){var ps=f[2].split(',');for(var q=0;q<ps.length;q++){var c=ps[q].indexOf(':'),id=+ps[q].substr(0,c);m[id]=+ps[q].substr(c+1);order.push(id)}}
    return bigC[pid]={tot:+f[1],m:m,order:order};
  }
  /* new-style tables */
  function ngBigram(a){
    var r=ngBi[a];if(r!==undefined)return r;
    var i=ng.findA(a);if(i<0)return ngBi[a]=null;
    var s=ng.OFF[i],e=ng.OFF[i+1],m=new Map(),order=[];
    for(var q=s;q<e;q++){var id=ng.FID[q];if(id<nw){m.set(id,ng.FCN[q]);order.push(id)}}
    return ngBi[a]={tot:ng.TOT[i],m:m,order:order};
  }
  function ngTrigram(a,b){
    var key=a*1048576+b,r=ngTri[key];if(r!==undefined)return r;
    var i=ng.findT(a,b);if(i<0)return ngTri[key]=null;
    var s=ng.TOFF[i],e=ng.TOFF[i+1],m=new Map(),order=[];
    for(var q=s;q<e;q++){var id=ng.TID[q];if(id<nw){m.set(id,ng.TCN[q]);order.push(id)}}
    return ngTri[key]={tot:ng.TN[i],m:m,order:order};
  }
  function clusterCounts(i){
    var r=clp[i];
    if(r===undefined){
      var n1=0,n2=0,cs=clusters(words[i]);
      for(var j=0;j<cs.length;j++){var k=cl.hasOwnProperty(cs[j])?cl[cs[j]]:2;if(k===1)n1++;else if(k===2)n2++}
      r=clp[i]=[n1,n2];
    }
    return r;
  }
  S.load=function(P){
    cfg=typeof P.cfg==='string'?JSON.parse(P.cfg):P.cfg;
    var L=lines(P.lex);if(P.limit&&L.length>P.limit)L=L.slice(0,P.limit);
    nw=L.length;words=new Array(nw);u=new Float64Array(nw);wid={};
    for(var i=0;i<nw;i++){var t=L[i].indexOf('\t');words[i]=L[i].substr(0,t);var c=+L[i].substr(t+1);u[i]=c>0?c:0.3;wid[words[i]]=i}
    N=cfg.N;romLines=lines(P.rom,true).slice(0,nw);romC={};
    cl={};var C=lines(P.clus);for(i=0;i<C.length;i++){var f=C[i].split('\t');cl[f[0]]=+f[1]}
    if(P.ng){ng=P.ng;ngBi={};ngTri={};bigText=[];bigIdx={}}else{ng=null;indexBig(P.big||'')}
    buildTables();
    if(P.conv){S.useConverter(P.conv)}
    cache=new Cache(cfg.tau);
    S.ready=true;S.size=nw;return S;
  };
  S.useConverter=function(P){                    /* converter tables can be shared by several engines */
    suni=P.suni;sU=P.sU;sbi=P.sbi;stot=P.stot;EX=P.EX;FZ=P.FZ;maxL=P.maxL;
  };
  S.convTables=function(){return {suni:suni,sU:sU,sbi:sbi,stot:stot,EX:EX,FZ:FZ,maxL:maxL}};
  S.buildConverter=function(P){
    var f,i,suni_={},sU_=0,U=lines(P.syl_uni);for(i=0;i<U.length;i++){f=U[i].split('\t');suni_[f[0]]=+f[1];sU_+=+f[1]}
    var sbi_={},stot_={},B=lines(P.syl_bi);for(i=0;i<B.length;i++){f=B[i].split('\t');var cnt=+f[2];sbi_[f[0]+'\t'+f[1]]=cnt;stot_[f[0]]=(stot_[f[0]]||0)+cnt}
    var EX_={},fz={},mL=0,H=lines(P.syl_chan);
    for(i=0;i<H.length;i++){
      f=H[i].split('\t');var pen=+f[2];(EX_[f[0]]||(EX_[f[0]]=[])).push([f[1],pen]);
      if(f[0].length>mL)mL=f[0].length;
      var kk=k1(f[0]);if(kk){var m=fz[kk]||(fz[kk]={});if(!(f[1] in m)||m[f[1]]>pen)m[f[1]]=pen}
    }
    var FZ_={};for(var key in fz){var a=[];for(var o in fz[key])a.push([o,fz[key][o]]);FZ_[key]=a}
    return {suni:suni_,sU:sU_,sbi:sbi_,stot:stot_,EX:EX_,FZ:FZ_,maxL:mL};
  };
  function nearEdit(t,i){
    var rs=roms(i),L=t.length;
    for(var j=0;j<rs.length;j++){var r=rs[j];for(var m=L-1;m<=L+1;m++){if(m>0&&r.substr(0,m)!==t.substr(0,m)&&ed1(t,r.substr(0,m)))return true}}
    return false;
  }
  function idOf(w){if(w==null)return -1;if(w==='<s>')return S.BOS;var i=wid[w];return i===undefined?-1:i}
  S.lexicon=function(typed,prev,prev2,n,opt){
    var c=cfg,t=alpha(typed);if(!t)return [];
    var useEd=!(opt&&opt.noEdit)&&c.ed;
    var k=Math.min(t.length,4),pool={},p0=(T.g0[k].get(t.substr(0,k))||[]),i,j,key,kk,L;
    for(j=0;j<p0.length;j++)pool[p0[j]]=1;
    var tk1=tkeys(t,k1),tk2=tkeys(t,k2),av=S.aliases?aliasVariants(t):[],shv=t.replace(/s(?!h)/g,'sh');
    for(j=0;j<av.length;j++){
      tkeys(av[j],k1).forEach(function(x){if(tk1.indexOf(x)<0)tk1.push(x)});
      tkeys(av[j],k2).forEach(function(x){if(tk2.indexOf(x)<0)tk2.push(x)});
      var ak=Math.min(av[j].length,4);L=T.g0[ak].get(av[j].substr(0,ak))||[];
      for(i=0;i<L.length;i++)pool[L[i]]=1;
    }
    for(j=0;j<tk1.length;j++){key=tk1[j];kk=Math.min(key.length,4);if(kk){L=(T.g1[kk].get(key.substr(0,kk))||[]);for(i=0;i<L.length;i++)pool[L[i]]=1}}
    for(j=0;j<tk2.length;j++){key=tk2[j];kk=Math.min(key.length,4);if(kk){L=(T.g2[kk].get(key.substr(0,kk))||[]);for(i=0;i<L.length;i++)pool[L[i]]=1}}
    var bg=null,tg=null,fc;
    if(ng){
      if(S.order>=2){var pi=idOf(prev);if(pi>=0){bg=ngBigram(pi);
        if(S.order>=3){var pj=idOf(prev2);if(pj>=0&&!(pj===S.BOS&&pi===S.BOS))tg=ngTrigram(pj,pi)}}}
      if(bg){fc=Math.min(bg.order.length,c.follower_cap);for(j=0;j<fc;j++)pool[bg.order[j]]=1}
      if(tg){fc=Math.min(tg.order.length,c.follower_cap);for(j=0;j<fc;j++)pool[tg.order[j]]=1}
    }else{
      bg=bigOf(prev||'<s>');
      if(bg){fc=Math.min(bg.order.length,c.follower_cap);for(j=0;j<fc;j++)pool[bg.order[j]]=1}
    }
    var edset=null;
    if(useEd&&t.length>=c.ed.minlen){
      var nex=0;
      for(j=0;j<p0.length&&nex<c.ed.gate;j++){var rs0=roms(p0[j]);for(var q=0;q<rs0.length;q++)if(startsWith(rs0[q],t)){nex++;break}}
      if(nex<c.ed.gate){
        var cand={};for(j=0;j<p0.length;j++)cand[p0[j]]=1;
        var base=t.length>4?t.substr(0,5):t,vs=edit1(base);
        for(j=0;j<vs.length;j++){
          var vv=t.length>4?vs[j]+t.substr(5):vs[j];kk=Math.min(vv.length,4);
          L=(T.g0[kk].get(vv.substr(0,kk))||[]);var m=Math.min(L.length,c.ed.cap);
          for(i=0;i<m;i++)cand[L[i]]=1;
        }
        edset={};for(var id in cand)if(nearEdit(t,+id)){edset[id]=1;pool[id]=1}
      }
    }
    var scored=[],bt=bg?bg.tot:0,tt=tg?tg.tot:0;
    var l2=bt>0?S.a2*bt/(bt+S.k2):0,l3=tt>0?S.a3*tt/(tt+S.k3):0;
    var bn=bg?Math.max(bg.tot,1e-9):1e-9;
    for(var sid in pool){
      i=+sid;var rs=roms(i),chan=null,x,y;
      for(j=0;j<rs.length;j++)if(startsWith(rs[j],t)){chan=0;break}
      if(chan===null&&av.length){outerA:for(j=0;j<rs.length;j++)for(x=0;x<av.length;x++)if(startsWith(rs[j],av[x])){chan=-(av[x]===shv?S.shW:S.wAlias);break outerA}}
      if(chan===null){var K1=keys(i,k1,k1c);outer1:for(x=0;x<K1.length;x++)for(y=0;y<tk1.length;y++)if(startsWith(K1[x],tk1[y])){chan=-c.w1;break outer1}}
      if(chan===null){var K2=keys(i,k2,k2c);outer2:for(x=0;x<K2.length;x++)for(y=0;y<tk2.length;y++)if(startsWith(K2[x],tk2[y])){chan=-c.w2;break outer2}}
      if(chan===null&&edset&&edset[i])chan=-c.ed.w3;
      if(chan===null)continue;
      var w=words[i],pu=u[i]/N,lm;
      if(ng){
        lm=pu;
        if(bt>0){var bc=bg.m.get(i);lm=l2*(bc?bc:0)/bt+(1-l2)*pu}
        if(tt>0){var tc=tg.m.get(i);lm=l3*(tc?tc:0)/tt+(1-l3)*lm}
      }else{
        var pb=bg&&bg.m[i]?bg.m[i]/bn:0;
        lm=c.a*pb+(1-c.a)*pu;
      }
      lm=(1-c.lc)*lm+c.lc*cache.p(w);
      var cc=clusterCounts(i);
      scored.push([Math.log(lm+1e-12)+chan-c.p1*cc[0]-c.p2*cc[1],i]);
    }
    scored.sort(function(A,B){return B[0]!==A[0]?B[0]-A[0]:B[1]-A[1]});
    scored=scored.slice(0,n);
    return scored.map(function(s){return {w:words[s[1]],i:s[1],s:s[0]}});
  };
  function slm(prev,o,c){
    var b=stot[prev]?(sbi[prev+'\t'+o]||0)/stot[prev]:0;
    var uu=o!=='$'?(suni[o]||0)/sU:1e-4;
    return Math.log(c.mix*b+(1-c.mix)*uu+1e-9);
  }
  function cmpBeam(a,b){return a[0]!==b[0]?b[0]-a[0]:(a[1]<b[1]?1:a[1]>b[1]?-1:(a[2]<b[2]?1:a[2]>b[2]?-1:0))}
  function convItems(t){
    var c=cfg.converter,L=t.length;if(!L)return [];
    var beams=new Array(L+1),i,ln,j,o;for(i=0;i<=L;i++)beams[i]=[];beams[0]=[[0,'','^']];
    for(i=0;i<L;i++){
      var hs=beams[i];if(!hs.length)continue;
      if(hs.length>c.beam){hs=hs.slice().sort(cmpBeam).slice(0,c.beam)}
      for(ln=1;ln<=Math.min(maxL,L-i);ln++){
        var seg=t.substr(i,ln),opts={},any=false,e=EX[seg],f;
        if(e)for(j=0;j<e.length;j++){opts[e[j][0]]=e[j][1];any=true}
        f=FZ[k1(seg)];
        if(f)for(j=0;j<f.length;j++){var v=f[j][1]+c.fz;if(!(f[j][0] in opts)||opts[f[j][0]]>v){opts[f[j][0]]=v;any=true}}
        if(!any)continue;
        for(var h=0;h<hs.length;h++){var H=hs[h];for(o in opts)beams[i+ln].push([H[0]+c.lam*slm(H[2],o,c)-opts[o],H[1]+o,o])}
      }
    }
    var seen={};
    for(j=0;j<beams[L].length;j++){
      var B=beams[L][j],sc2=B[0]+c.lam*slm(B[2],'$',c),cs=clusters(B[1]);
      for(var q=0;q<cs.length;q++){var kk=cl.hasOwnProperty(cs[q])?cl[cs[q]]:2;if(kk===1)sc2-=c.p1;else if(kk===2)sc2-=c.p2}
      if(!(B[1] in seen)||seen[B[1]]<sc2)seen[B[1]]=sc2;
    }
    var items=[];for(var w in seen)items.push([w,seen[w]]);
    items.sort(function(a,b){return b[1]-a[1]});items=items.slice(0,c.nbest);
    items=items.map(function(it){var id=wid[it[0]];return [it[0],it[1]+(id!==undefined?c.beta+c.gamma*Math.log(1+u[id]):0)]});
    items.sort(function(a,b){return b[1]-a[1]});
    return items;
  }
  S.converter=function(typed,n){
    var t=alpha(typed);if(!t)return [];
    var items=convItems(t),av=S.aliases?aliasVariants(t):[],m={},i,j,shv=t.replace(/s(?!h)/g,'sh');
    if(av.length){
      items.forEach(function(it){m[it[0]]=it[1]});
      for(i=0;i<Math.min(av.length,4);i++){var r=convItems(av[i]);for(j=0;j<r.length;j++){var sc=r[j][1]-(av[i]===shv?S.shPen:S.convAliasPen);if(!(r[j][0] in m)||m[r[j][0]]<sc)m[r[j][0]]=sc}}
      items=[];for(var w in m)items.push([w,m[w]]);items.sort(function(a,b){return b[1]-a[1]});
    }
    if(S.rules){var out=[];for(i=0;i<items.length;i++){var f=fixWord(items[i][0]);if(f!==null)out.push([f,items[i][1]])}items=out}
    return items.slice(0,n).map(function(a){return a[0]});
  };
  function zwCompound(w){
    for(var i=0;i<ZWFIRST.length;i++){var p=ZWFIRST[i];
      if(w.length>p.length+2&&w.lastIndexOf(p,0)===0&&w.charAt(p.length)!=='\u200C'){
        var R=w.slice(p.length),id=wid[R];
        if(id!==undefined&&u[id]>=100&&(R.match(AKRE)||[]).length>=3)return p+'\u200C'+R;
      }
    }
    return null;
  }
  S.zwCompound=zwCompound;
  S.suggest=function(typed,prev,prev2,nLex,nConv,opt){
    prev=prev||'<s>';var d=cfg.display;if(nLex==null)nLex=d.lexicon;if(nConv==null)nConv=d.converter;
    var t=alpha(typed);if(!t)return [];
    var lex=S.lexicon(t,prev,prev2,nLex,opt),conv=nConv?S.converter(t,nConv):[];
    var near=!lex.length;
    if(!near){var rs=roms(lex[0].i),m=99;for(var j=0;j<rs.length;j++)if(startsWith(rs[j],t)&&rs[j].length<m)m=rs[j].length;near=m<=t.length+1}
    var out=[],seen={},a=conv.map(function(w){return [w,'conv']}),b=[];
    lex.forEach(function(x){var w0=S.rules?zwRule(x.w):x.w,z=S.rules?zwCompound(w0):null;if(z)b.push([z,'lex']);b.push([w0,'lex'])});
    var all=near?a.concat(b):b.concat(a);
    for(var q=0;q<all.length;q++)if(!seen[all[q][0]]){seen[all[q][0]]=1;out.push(all[q])}
    return out;
  };
  S.next=function(w,n,w2){
    var out=[],seen={},a=idOf(w),i,id,bg,tg;
    if(!ng||a<0||a===S.BOS&&false)return out;
    function put(o){if(o)for(var q=0;q<o.order.length&&out.length<n;q++){id=o.order[q];if(id<nw&&!seen[id]){var x=words[id];if(x&&/[\u0B00-\u0B7F]/.test(x)){seen[id]=1;out.push(x)}}}}
    var b=w2!=null?idOf(w2):-1;
    if(b>=0&&S.order>=3){tg=ngTrigram(b,a);put(tg)}
    bg=ngBigram(a);put(bg);
    return out;
  };
  S.commit=function(w){if(w)cache.commit(w)};
  S.resetCache=function(){cache=new Cache(cfg.tau)};
  S.has=function(w){return wid.hasOwnProperty(w)};
  S.shortest=function(w){var i=wid[w];if(i===undefined)return 0;var rs=roms(i),m=99;for(var j=0;j<rs.length;j++)if(rs[j].length<m)m=rs[j].length;return m===99?0:m};
  return S;
}
/* automatic typist: one prompt sentence {words,plain,typed} -> per word {hit2,hit3,hit4 (gold in first 3 chips after k letters), found (letters until gold is among the 5 chips, 0 = never), maxk, base} */
function benchSentence(S,p){
  var out=[],prev='<s>',prev2='<s>';
  for(var i=0;i<p.words.length;i++){
    var gold=p.words[i],ty=p.typed[i].toLowerCase().replace(/[^a-z]/g,''),mk=ty.length,found=0,H=[],k,lst,w;
    for(k=1;k<=mk;k++){
      if(k>4&&found)break;
      lst=S.suggest(ty.slice(0,k),prev,prev2,3,2);w=lst.map(function(x){return x[0]});
      H[k]=w.slice(0,3).indexOf(gold)>=0;
      if(!found&&w.indexOf(gold)>=0)found=k;
    }
    function hk(k){var kk=Math.min(k,mk);return !!H[kk]}
    out.push({hit2:hk(2),hit3:hk(3),hit4:hk(4),found:found,maxk:mk,base:p.plain[i].length+1});
    prev2=prev;prev=gold;
  }
  return out;
}
return {create:create,parseNG:parseNG,alpha:alpha,benchSentence:benchSentence,aliasVariants:aliasVariants,validWord:validWord,zwRule:zwRule};
})();

/* ---- the interface the Mac app uses ---- */
var Sulekhak=(function(){
  var B64=null;
  function b64(str){                                   /* a base64 string -> ArrayBuffer (only used when the host cannot pass a binary buffer) */
    if(!B64){B64={};var al='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';for(var i=0;i<64;i++)B64[al.charAt(i)]=i}
    var n=str.length,pad=str.charAt(n-1)==='='?(str.charAt(n-2)==='='?2:1):0,len=(n/4*3)-pad,out=new Uint8Array(len),p=0,i2;
    for(i2=0;i2<n;i2+=4){
      var a=B64[str.charAt(i2)],b=B64[str.charAt(i2+1)],c=B64[str.charAt(i2+2)],d=B64[str.charAt(i2+3)];
      if(p<len)out[p++]=(a<<2)|(b>>4);if(p<len)out[p++]=((b&15)<<4)|(c>>2);if(p<len)out[p++]=((c&3)<<6)|d;
    }
    return out.buffer;
  }
  function create(){
    var S=SKE.create(),hist=[];                        /* hist = the words committed so far (for the word before the previous one) */
    var W={};
    W.engine=S;
    W.load=function(P){
      var q={cfg:P.cfg,lex:P.lex,rom:P.rom,big:'',clus:P.clus,syl_uni:P.syl_uni,syl_bi:P.syl_bi,syl_chan:P.syl_chan,limit:P.limit|0};
      var bufs=(P.ng||[]).map(function(x){return typeof x==='string'?b64(x):x});
      if(bufs.length)q.ng=SKE.parseNG(bufs);else q.big=P.big||'';
      S.load(q);S.useConverter(S.buildConverter(q));
      W.size=S.size;
      return W;
    };
    W.suggest=function(roman,prev,nLex,nConv){
      prev=prev||'<s>';
      var prev2=null;
      if(prev==='<s>')prev2=null;
      else if(hist.length&&hist[hist.length-1]===prev)prev2=hist.length>1?hist[hist.length-2]:'<s>';
      return S.suggest(roman,prev,prev2,nLex,nConv);
    };
    W.next=function(w,n){
      var p2=(hist.length&&hist[hist.length-1]===w)?(hist.length>1?hist[hist.length-2]:'<s>'):null;
      return S.next(w,n||8,p2);
    };
    W.commit=function(w){if(!w)return;S.commit(w);hist.push(w);if(hist.length>50)hist.shift()};
    return W;
  }
  return {create:create};
})();
if(typeof module!=='undefined')module.exports={SK:SKE,Sulekhak:Sulekhak};
