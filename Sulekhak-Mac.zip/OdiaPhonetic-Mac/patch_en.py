import re
p='/tmp/w/lekhani/html/typist.tpl.html'
t=open(p,encoding='utf-8').read()
def rep(a,b,cnt=1):
    global t
    assert t.count(a)>=1, a[:60]
    t=t.replace(a,b,cnt)
# 1 state
rep("var SC=0, SMAR=false, SCON=true;","var SC=0, SMAR=false, SCON=true, ENCAP=true, ENSMART=true;")
rep("SC=(sv0.sc===1||sv0.sc===2)?sv0.sc:0; SMAR=!!sv0.mar; SCON=sv0.con!==false }catch(e){}",
    "SC=(sv0.sc===1||sv0.sc===2||sv0.sc===3)?sv0.sc:0; SMAR=!!sv0.mar; SCON=sv0.con!==false; ENCAP=sv0.encap!==false; ENSMART=sv0.ensm!==false }catch(e){}")
rep("var SCNAME=['Odia','Devanagari','Bangla'], SCLANG=['or','hi','bn'];","var SCNAME=['Odia','Devanagari','Bangla','English'], SCLANG=['or','hi','bn','en'];")
rep("function scBase(){ return SC===1?0x0900:SC===2?0x0980:0x0B00 }","function scBase(){ return SC===1?0x0900:SC===2?0x0980:0x0B00 }\nfunction isEN(){ return SC===3 }")
rep("""lang="'+['or','hi','bn'][SC]+'\"""","""lang="'+SCLANG[SC]+'\"""")
# placeholder
rep("ph.textContent='Tap or click here, then type, for example namaskar';","ph.textContent=SC===3?'Tap or click here, then type English text':'Tap or click here, then type, for example namaskar';")
# html
rep("""      <button type="button" class="segb" role="radio" aria-checked="false" data-sc="2" lang="bn">বাংলা</button>
""","""      <button type="button" class="segb" role="radio" aria-checked="false" data-sc="2" lang="bn">বাংলা</button>
      <button type="button" class="segb" role="radio" aria-checked="false" data-sc="3" lang="en">English</button>
""")
rep("""    <button class="btn ghost" id="scconv\"""","""    <span class="dvopt" id="enopt" hidden>
      <label class="opt"><input type="checkbox" id="oCap" checked> Capital after . ! ? and for I</label>
      <label class="opt"><input type="checkbox" id="oSmart" checked> Curly quotes, &mdash; and &hellip;</label>
    </span>
    <button class="btn ghost" id="scconv\"""")
rep(".dvopt[hidden]{display:none}",".dvopt[hidden]{display:none}\n.scbar .btn[hidden]{display:none}")
# apply / save
rep("localStorage.setItem('lekhaniScript',JSON.stringify({sc:SC,mar:SMAR,con:SCON}))","localStorage.setItem('lekhaniScript',JSON.stringify({sc:SC,mar:SMAR,con:SCON,encap:ENCAP,ensm:ENSMART}))")
rep("var scbar=$('scbar'), dvopt=$('dvopt'), oMar=$('oMar'), oCon=$('oCon'), scnote=$('scnote');","var scbar=$('scbar'), dvopt=$('dvopt'), oMar=$('oMar'), oCon=$('oCon'), scnote=$('scnote'), enopt=$('enopt'), oCap=$('oCap'), oSmart=$('oSmart');")
rep("dvopt.hidden=SC!==1; oMar.checked=SMAR; oCon.checked=SCON;","dvopt.hidden=SC!==1; enopt.hidden=SC!==3; $('scconv').hidden=SC===3; oMar.checked=SMAR; oCon.checked=SCON; oCap.checked=ENCAP; oSmart.checked=ENSMART;")
rep("ed.setAttribute('aria-label','Writing area. Type English letters and pick the '+SCNAME[SC]+' word.');",
    "ed.setAttribute('aria-label',SC===3?'Writing area. Type English text; letters go in as typed.':'Writing area. Type English letters and pick the '+SCNAME[SC]+' word.');\n  ed.setAttribute('spellcheck',SC===3?'true':'false');")
rep("SC===2?'Bangla: ଳ is written ল':'';","SC===2?'Bangla: ଳ is written ল':SC===3?'English only: no transliteration, keys type what they say':'';")
rep("oCon.addEventListener('change',function(){ flush(); SCON=oCon.checked; saveScript(); applyScript() });",
    "oCon.addEventListener('change',function(){ flush(); SCON=oCon.checked; saveScript(); applyScript() });\noCap.addEventListener('change',function(){ ENCAP=oCap.checked; saveScript() });\noSmart.addEventListener('change',function(){ ENSMART=oSmart.checked; saveScript() });")
# key guide
rep("function glyphFor(k){      /* what typing k alone gives, as it should look on a key */",
    "function glyphFor(k){      /* what typing k alone gives, as it should look on a key */\n  if(SC===3) return {g:k,cap:'',sp:false};")
rep("var k=kk[0], sh=kk[1]||(/^[a-z]$/.test(k)?k.toUpperCase():null), a=glyphFor(k), b=sh?glyphFor(sh):null;",
    "var k=kk[0], sh=kk[1]||(/^[a-z]$/.test(k)?k.toUpperCase():null); if(SC===3) sh=EN_SHIFT[k]||sh; var a=glyphFor(k), b=sh?glyphFor(sh):null;")
rep("var KNOTES={","var EN_SHIFT={'`':'~','1':'!','2':'@','3':'#','4':'$','5':'%','6':'^','7':'&','8':'*','9':'(','0':')','.':'>',\"'\":'\"'};\nvar KNOTES={")
rep("function kgInfoFor(k){\n","function kgInfoFor(k){\n  if(SC===3){ var sh=EN_SHIFT[k]||(/^[a-z]$/.test(k)?k.toUpperCase():''); return '<div><code>'+esc(k)+'</code>'+(sh?' &nbsp; <code>Shift+'+esc(k)+'</code> <span class=\"big\">'+esc(sh)+'</span>':'')+'</div><div style=\"margin-top:6px\">English mode: this key types exactly what is printed on it.</div>' }\n")
# kgShowInfo idle text for English
rep("function kgShowInfo(k){ kgInfo.innerHTML=k?kgInfoFor(k):","function kgShowInfo(k){ if(!k&&SC===3){ kgInfo.innerHTML='<div>English mode: move over a key to see it. Typing is direct, with no word list.</div>'; return } kgInfo.innerHTML=k?kgInfoFor(k):")
# press: english branch before 'var c=k;'
rep("  var c=k;\n  if(composing&&st.buf==='.'){","  if(SC===3) return pressEN(k);\n  var c=k;\n  if(composing&&st.buf==='.'){")
# pressEN function inserted before 'function press'
EN=r'''
/* ================= English-only typing: direct text, no transliteration, no word list ================= */
var EN_ABBR=/(?:^|[\s(“"'])(?:mr|mrs|ms|dr|prof|sr|jr|st|vs|etc|e\.g|i\.e|no|fig|eq|approx|dept|est|inc|ltd|co|mt|ft|vol|pp|p|a\.m|p\.m|u\.s|u\.k)\.\s*$/i;
function enBefore(n){ return st.text.slice(Math.max(0,st.pos-n),st.pos) }
function enSentenceStart(){
  var t=st.text, p=st.pos; if(p===0) return true;
  var pre=t.slice(Math.max(0,p-60),p);
  if(/\n\s*$/.test(pre)) return true;
  var m=/([.!?…]+)["'”’)\]]*\s+$/.exec(pre);
  if(!m) return false;
  return !EN_ABBR.test(pre.slice(0,m.index+m[1].length));
}
function enOpenCtx(){ var c=st.pos===0?'\n':st.text[st.pos-1]; return /[\s(\[{—–“‘\/-]/.test(c) || c==='\n' }
function pressEN(c){
  if(selRange()) delSel();
  if(c===' '&&!selRange()&&autoFormat()){ draw(); return true }
  var out=c;
  if(ENSMART){
    if(c==='"') out=enOpenCtx()?'“':'”';
    else if(c==="'") out=enOpenCtx()?'‘':'’';
    else if(c==='-'&&enBefore(1)==='-'){ delBack(); out='—' }
    else if(c==='.'&&enBefore(2)==='..'){ delBack(); delBack(); out='…' }
  }
  if(ENCAP){
    if(/[a-z]/.test(out)&&enSentenceStart()) out=out.toUpperCase();
    else if(/[\s.,;:!?)’'"”\-—]/.test(out)){
      /* a lone i (also i'm, i'll, i've, i'd) becomes I */
      var b=enBefore(3);
      if(/(^|[\s(“"‘\n])i$/.test(b)&&!/[a-z]/i.test(out)){
        var q=out==='’'||out==="'"; var k2=st.pos-1; save(); splice(k2,1,'I',typeFid(k2)); }
    }
  }
  ins(out); draw(); return true;
}
'''
rep("function press(k,ext){",EN+"function press(k,ext){")
open(p,'w',encoding='utf-8').write(t)
print('patched')
