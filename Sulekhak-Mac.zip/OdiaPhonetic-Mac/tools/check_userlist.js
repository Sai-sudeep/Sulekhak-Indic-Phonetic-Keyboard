const E=require('../src/engine.js');E.loadBuiltin();
const D=require('./userlist.json');let miss=0,tot=0,keysMiss=0;const out=[];
for(const k in D){const c=E.candidates(k);const m=D[k].filter(x=>!c.includes(x));tot+=D[k].length;if(m.length){keysMiss++;miss+=m.length;out.push(k+' MISSING '+m.join(' ')+'   | have: '+c.slice(0,12).join(' '))}}
console.log('keys',Object.keys(D).length,'expected',tot,'missing',miss,'keys with misses',keysMiss);
console.log(out.join('\n'));
