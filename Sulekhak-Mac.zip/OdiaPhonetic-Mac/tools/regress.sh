#!/bin/bash
# runs tools/expect.tsv against the C engine and the JS twin; prints failures
cd "$(dirname "$0")/../src"
cc -O1 -o /tmp/odia_dump dump.c engine.c || exit 1
node - <<'JS'
const fs=require('fs'),cp=require('child_process');
const E=require('./engine.js');E.loadBuiltin();E.loadSkel(fs.readFileSync('skel.dat','utf8'));
const rows=fs.readFileSync('../tools/expect.tsv','utf8').split('\n').filter(l=>l&&!l.startsWith('#')).map(l=>l.split('\t'));
const input=[...new Set(rows.map(r=>r[0]))].join('\n')+'\n';
const c={};cp.execSync('/tmp/odia_dump',{input}).toString().split('\n').filter(x=>x).forEach(l=>{const a=l.split('\t');c[a[0]]=a.slice(1)});
let bad=0;
for(const [r,e,k] of rows){
  for(const [name,list] of [['js',E.candidates(r)],['c',c[r]]]){
    const i=list.indexOf(e)+1;
    if(i<1||i>+k){bad++;console.log('FAIL',name,r,'wanted',e,'<=',k,'got rank',i,list.slice(0,6).join(' '))}
  }
}
console.log(bad?('failures: '+bad):('all '+rows.length+' expectations pass on C and JS'));
process.exit(bad?1:0);
JS
