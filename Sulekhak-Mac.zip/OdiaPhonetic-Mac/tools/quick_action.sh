#!/bin/bash
# Installs the right-click / Services entry "Add to Sulekhak Dictionary" (a Quick Action) into ~/Library/Services.
# Select a word in any program, right-click > Services (or Quick Actions) > Add to Sulekhak Dictionary.
# If the entry is not in the menu: System Settings > Keyboard > Keyboard Shortcuts > Services > Text > switch "Add to Sulekhak Dictionary" on.
W="$HOME/Library/Services/Add to Sulekhak Dictionary.workflow"
rm -rf "$W"; mkdir -p "$W/Contents"
cat > "$W/Contents/Info.plist" <<'PL'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>NSServices</key>
  <array><dict>
    <key>NSMenuItem</key><dict><key>default</key><string>Add to Sulekhak Dictionary</string></dict>
    <key>NSMessage</key><string>runWorkflowAsService</string>
    <key>NSSendTypes</key><array><string>NSStringPboardType</string></array>
  </dict></array>
</dict></plist>
PL
cat > "$W/Contents/document.wflow" <<'PL'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>AMApplicationBuild</key><string>523</string>
  <key>AMApplicationVersion</key><string>2.10</string>
  <key>AMDocumentVersion</key><string>2</string>
  <key>actions</key>
  <array><dict><key>action</key><dict>
    <key>AMAccepts</key><dict><key>Container</key><string>List</string><key>Optional</key><true/><key>Types</key><array><string>com.apple.cocoa.string</string></array></dict>
    <key>AMActionVersion</key><string>2.0.3</string>
    <key>AMApplication</key><array><string>Automator</string></array>
    <key>AMParameterProperties</key><dict><key>COMMAND_STRING</key><dict/><key>CheckedForUserDefaultShell</key><dict/><key>inputMethod</key><dict/><key>shell</key><dict/><key>source</key><dict/></dict>
    <key>AMProvides</key><dict><key>Container</key><string>List</string><key>Types</key><array><string>com.apple.cocoa.string</string></array></dict>
    <key>ActionBundlePath</key><string>/System/Library/Automator/Run Shell Script.action</string>
    <key>ActionName</key><string>Run Shell Script</string>
    <key>ActionParameters</key><dict>
      <key>COMMAND_STRING</key><string>t=$(cat)
enc=$(/usr/bin/osascript -l JavaScript -e 'function run(a){return encodeURIComponent(a[0])}' "$t")
/usr/bin/open "sulekhak://add?text=$enc"</string>
      <key>CheckedForUserDefaultShell</key><true/>
      <key>inputMethod</key><integer>0</integer>
      <key>shell</key><string>/bin/bash</string>
      <key>source</key><string></string>
    </dict>
    <key>BundleIdentifier</key><string>com.apple.RunShellScript</string>
    <key>CFBundleVersion</key><string>2.0.3</string>
    <key>CanShowSelectedItemsWhenRun</key><false/>
    <key>CanShowWhenRun</key><true/>
    <key>Category</key><array><string>AMCategoryUtilities</string></array>
    <key>Class Name</key><string>RunShellScriptAction</string>
    <key>InputUUID</key><string>8C1B8F3C-4C2E-4B58-9A0F-1D6E2A7B5C01</string>
    <key>OutputUUID</key><string>3D9A6E52-7B4F-4E0B-8C21-5F0A9D1E7B02</string>
    <key>UUID</key><string>A4F2C7D1-9E3B-4A6C-B5D8-2E1F0C3A4B03</string>
    <key>UnlocalizedApplications</key><array><string>Automator</string></array>
    <key>arguments</key><dict/>
    <key>isViewVisible</key><integer>1</integer>
    <key>location</key><string>309.000000:305.000000</string>
  </dict></dict></array>
  <key>connectors</key><dict/>
  <key>workflowMetaData</key><dict>
    <key>serviceInputTypeIdentifier</key><string>com.apple.Automator.text</string>
    <key>serviceOutputTypeIdentifier</key><string>com.apple.Automator.nothing</string>
    <key>serviceProcessesInput</key><integer>0</integer>
    <key>workflowTypeIdentifier</key><string>com.apple.Automator.servicesMenu</string>
  </dict>
</dict></plist>
PL
/System/Library/CoreServices/pbs -update 2>/dev/null || true
echo "Installed the Services entry: Add to Sulekhak Dictionary"
