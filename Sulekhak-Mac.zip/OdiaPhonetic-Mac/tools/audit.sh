#!/bin/bash
# usage: tools/audit.sh   (needs the dump binary: cc -O1 -o dump src/dump.c src/engine.c)
cd "$(dirname "$0")/.."
python3 - <<'PY'
import random
random.seed(7)
C="k kh g gh ch chh j jh T Th D Dh N t th d dh n p ph b bh m y r l w sh Sh s h nk ng nch nj nT nD nt nd mp mb st sT sth str ksh gy jn tr pr kr dr".split()
V="a aa i ii u uu e o ai au ou A I U ee oo ri ru E O".split()
ws=set()
while len(ws)<4000:
    w="".join(random.choice(C)+random.choice(V) for _ in range(random.choice([1,2,2,3,3,4])))
    ws.add(w)
open('/tmp/audit_words.txt','w').write("\n".join(sorted(ws))+"\n")
PY
./dump < /tmp/audit_words.txt > /tmp/audit_out.tsv && python3 tools/audit_check.py /tmp/audit_out.tsv
