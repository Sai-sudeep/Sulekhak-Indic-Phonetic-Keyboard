import sys,collections,unicodedata
HAL='୍';ZW='‌';NUK='଼'
def cls(ch):
    o=ord(ch)
    if 0x0B15<=o<=0x0B18:return 1
    if 0x0B1A<=o<=0x0B1D:return 2
    if 0x0B1F<=o<=0x0B22 or o in(0x0B5C,0x0B5D):return 3
    if 0x0B24<=o<=0x0B27:return 4
    if 0x0B2A<=o<=0x0B2D:return 5
    return 0
NAS={'ଙ':1,'ଞ':2,'ଣ':3,'ନ':4,'ମ':5}
SIB={'ଷ':{4,2},'ସ':{3,2},'ଶ':{3,4}}
MATRA=set(chr(c) for c in range(0x0B3E,0x0B4D))|{'ୗ'}
CONS=set(chr(c) for c in list(range(0x0B15,0x0B3A))+[0x0B5C,0x0B5D,0x0B5F,0x0B71])
IND=set(chr(c) for c in list(range(0x0B05,0x0B10))+[0x0B0F,0x0B10,0x0B13,0x0B14])
def problems(w):
    p=[]
    for i,ch in enumerate(w):
        nx=w[i+1:i+3]
        if ch in NAS and len(w)>i+2 and w[i+1]==HAL:
            c2=cls(w[i+2])
            if c2:
                if NAS[ch]!=c2: p.append('nasal-class:'+('hard' if NAS[ch]<=3 else 'soft'))
        if ch in SIB and len(w)>i+2 and w[i+1]==HAL:
            c2=cls(w[i+2])
            if c2 in SIB[ch]: p.append('sibilant-class')
        if ch in MATRA:
            prev=w[i-1] if i>0 else ''
            if prev=='' or prev==HAL or prev in MATRA and not (prev==NUK): p.append('matra-misplaced')
            elif prev not in CONS and prev!=NUK and prev not in 'ଁଂଃ' : p.append('matra-after-nonconsonant')
        if ch==HAL:
            prev=w[i-1] if i>0 else ''
            if prev not in CONS and prev!=NUK: p.append('halant-misplaced')
            if len(w)>i+1 and w[i+1] in MATRA: p.append('halant-then-matra')
            if len(w)>i+1 and w[i+1]==HAL: p.append('double-halant')
        if ch=='ଁ' and (i==0 or w[i-1]==HAL): p.append('chandrabindu-misplaced')
        if ch=='଼':
            prev=w[i-1] if i>0 else ''
            if prev not in 'ଡଢ': p.append('nukta-misplaced')
        if ch=='\u200d':
            if not (i>0 and w[i-1]=='ର' and w[i+1:i+2]==HAL): p.append('zwj-misplaced')
        if ch==ZW:
            prev=w[i-1] if i>0 else ''
            if prev!=HAL and i>0: p.append('zwnj-not-after-halant')
    return p
tot=collections.Counter(); top=collections.Counter(); ex={}
for line in open(sys.argv[1],encoding='utf-8'):
    f=line.rstrip('\n').split('\t'); r=f[0]; cands=f[1:]
    for idx,c in enumerate(cands):
        if c.isascii(): continue
        for pr in set(problems(c)):
            tot[pr]+=1
            if idx<9: top[pr]+=1
            ex.setdefault(pr,[]).append((r,idx+1,c))
print('ALL candidates:',dict(tot)); print('TOP-9 (page 1):',dict(top))
for k,v in ex.items(): print(k,[x for x in v[:6]])
