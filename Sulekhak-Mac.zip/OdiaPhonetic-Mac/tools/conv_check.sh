#!/bin/bash
# the C and JS script converters must agree on every built-in and listed word
cd "$(dirname "$0")/../src"
cc -O1 -o /tmp/odia_conv ../tools/convdump.c engine.c 2>/dev/null || exit 1
node - <<'JS'
const fs=require('fs'),cp=require('child_process');
const E=require('./engine.js'),T=JSON.parse(fs.readFileSync('tables.json','utf8'));
const words=[...new Set(T.BUILTIN.map(b=>b[1]).concat(T.WORDS))];
const out=cp.execSync('/tmp/odia_conv',{input:words.join('\n')+'\n',maxBuffer:1<<28}).toString().split('\n').filter(x=>x);
let bad=0;
out.forEach((l,i)=>{const a=l.split('\t'),w=a[0];
  const js=[E.toScript(w,1,0),E.toScript(w,1,1),E.toScript(w,1,2),E.toScript(w,2,0),E.toScript(w,5,0)];
  for(let k=0;k<5;k++) if(js[k]!==a[k+1]){ if(bad++<10) console.log('DIFF',w,k,js[k],a[k+1]) }});
console.log(bad?'conversion differences: '+bad:'C and JS converters agree on '+words.length+' words x 5 modes');
process.exit(bad?1:0);
JS
