const fs=require('fs'),zlib=require('zlib');
const D=(process.argv[2]||require('path').join(__dirname,'..','sulekhak'))+'/';   // node tools/model_check.js [sulekhak folder] [word limit]
const {Sulekhak}=require(D+'sulekhak.js');
const t0=Date.now();
const rd=f=>fs.existsSync(D+f)?fs.readFileSync(D+f,'utf8'):zlib.gunzipSync(fs.readFileSync(D+f+'.gz')).toString();
const bin=f=>{const b=fs.existsSync(D+f)?fs.readFileSync(D+f):zlib.gunzipSync(fs.readFileSync(D+f+'.gz'));return b.buffer.slice(b.byteOffset,b.byteOffset+b.length)};
const SK=Sulekhak.create();
SK.load({cfg:rd('cfg.json'),lex:rd('lex.txt'),rom:rd('rom.txt'),clus:rd('clus.txt'),syl_uni:rd('syl_uni.txt'),syl_bi:rd('syl_bi.txt'),syl_chan:rd('syl_chan.txt'),ng:['ng_bi1.bin','ng_bi2.bin','ng_tri.bin'].map(bin),limit:+(process.argv[3]||250000)});
console.log('loaded',SK.size,'words in',Date.now()-t0,'ms; rss MB',Math.round(process.memoryUsage().rss/1e6));
const show=(q,prev)=>{const t=Date.now();const r=SK.suggest(q,prev||'<s>',4,2);console.log(JSON.stringify(q),prev||'', Date.now()-t+'ms',r.slice(0,7).map(x=>x[0]).join(' '))};
for(const q of ['sandha','ShaNDha','parikhya','khyati','jnana','kruShNa','prajak','namaskar','bhaasaa','odisha','sulekhak','sambad','dhanyabad','pasnd']) show(q);
SK.commit('ମୁଁ');SK.commit('ଓଡ଼ିଶା');
show('ra','ମୁଁ'); show('ja','ଓଡ଼ିଶା');
console.log('next ଓଡ଼ିଶା:',SK.next('ଓଡ଼ିଶା',8).join(' '));
console.log('next ମୁଁ:',SK.next('ମୁଁ',8).join(' '));
console.log('next <s>:',SK.next('<s>',8).join(' '));
console.log('rss MB',Math.round(process.memoryUsage().rss/1e6));
