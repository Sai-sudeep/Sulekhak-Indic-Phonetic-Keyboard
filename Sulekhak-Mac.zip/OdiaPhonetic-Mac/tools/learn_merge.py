#!/usr/bin/env python3
"""Moves what Sulekhak learned between its programs.

  learn_merge.py to-tsv  sulekhak-learn.json  OUTDIR      -> OUTDIR/history.tsv (picks, one line per use up to 20) and OUTDIR/lexicon.tsv (dictionary)
                                                              the Windows app (%LOCALAPPDATA%\\Sulekhak\\history.tsv) and the Android app read this kind of list
  learn_merge.py from-tsv history.tsv lexicon.tsv OUT.json -> a learning file from the plain lists
  learn_merge.py merge   A.json B.json OUT.json            -> the union of two learning files (counts: the larger; dates: widest; scripts: or)
Format: docs/learning-cache-format.md"""
import json, sys, time, os

def load(p):
    j = json.load(open(p, encoding='utf-8'))
    if j.get('format') != 'sulekhak-learn': raise SystemExit(p + ': not a sulekhak-learn file')
    return j

def empty(device='tool'):
    return {'format': 'sulekhak-learn', 'version': 1, 'device': device, 'app': 'learn_merge', 'updated': int(time.time()), 'picks': {}, 'dict': [], 'next': {}}

def merge(a, b):
    out = empty()
    for src in (a, b):
        for roman, lst in src.get('picks', {}).items():
            cur = out['picks'].setdefault(roman, [])
            for e in lst:
                m = next((x for x in cur if x['w'] == e['w']), None)
                if not m: cur.append(dict(e)); continue
                m['n'] = max(m['n'], e['n']); m['first'] = min(m.get('first') or e['first'], e['first']) if e.get('first') else m.get('first')
                m['last'] = max(m.get('last', 0), e.get('last', 0)); m['sc'] = m.get('sc', 0) | e.get('sc', 0)
        for e in src.get('dict', []):
            if not any(x['roman'] == e['roman'] and x['w'] == e['w'] for x in out['dict']): out['dict'].append(dict(e))
        for p, m in src.get('next', {}).items():
            cur = out['next'].setdefault(p, {})
            for w, n in m.items(): cur[w] = max(cur.get(w, 0), n)
    for lst in out['picks'].values(): lst.sort(key=lambda e: -e['n'])
    return out

def main(a):
    if len(a) >= 3 and a[0] == 'to-tsv':
        j = load(a[1]); os.makedirs(a[2], exist_ok=True)
        with open(os.path.join(a[2], 'history.tsv'), 'w', encoding='utf-8') as f:
            for roman, lst in j['picks'].items():
                for e in lst:
                    for _ in range(min(e['n'], 20)): f.write('%s\t%s\t3\n' % (roman, e['w']))
        with open(os.path.join(a[2], 'lexicon.tsv'), 'w', encoding='utf-8') as f:
            for e in j.get('dict', []): f.write('%s\t%s\t%d\n' % (e['roman'], e['w'], e.get('wt', 6)))
    elif len(a) >= 4 and a[0] == 'from-tsv':
        j = empty(); now = int(time.time())
        for line in open(a[1], encoding='utf-8') if os.path.exists(a[1]) else []:
            p = line.rstrip('\n').split('\t')
            if len(p) < 2 or not p[0] or not p[1]: continue
            lst = j['picks'].setdefault(p[0], []); e = next((x for x in lst if x['w'] == p[1]), None)
            if not e: e = {'w': p[1], 'n': 0, 'first': now, 'last': now, 'sc': 1}; lst.append(e)
            e['n'] += 1
        for line in open(a[2], encoding='utf-8') if os.path.exists(a[2]) else []:
            p = line.rstrip('\n').split('\t')
            if len(p) < 2 or not p[0] or not p[1] or p[0].startswith('#'): continue
            j['dict'].append({'w': p[1], 'roman': p[0], 'wt': int(p[2]) if len(p) > 2 and p[2].isdigit() else 6, 'added': now, 'src': 'tsv'})
        json.dump(j, open(a[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    elif len(a) >= 4 and a[0] == 'merge':
        json.dump(merge(load(a[1]), load(a[2])), open(a[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    else:
        print(__doc__)

main(sys.argv[1:])
