#include <stdio.h>
#include <string.h>
#include "../src/engine.h"
/* reads Odia words, prints each converted to the 5 Devanagari/Bangla/Assamese forms (used by tools/conv_check.sh to compare with the JS twin) */
int main(void){ char line[512], o[5][ODIA_CAND_LEN];
  while(fgets(line,sizeof line,stdin)){ size_t L=strlen(line); while(L&&(line[L-1]=='\n'||line[L-1]=='\r')) line[--L]=0;
    odia_convert(line,1,0,o[0],sizeof o[0]); odia_convert(line,1,1,o[1],sizeof o[1]); odia_convert(line,1,2,o[2],sizeof o[2]); odia_convert(line,2,0,o[3],sizeof o[3]); odia_convert(line,5,0,o[4],sizeof o[4]);
    printf("%s\t%s\t%s\t%s\t%s\t%s\n",line,o[0],o[1],o[2],o[3],o[4]); }
  return 0; }
