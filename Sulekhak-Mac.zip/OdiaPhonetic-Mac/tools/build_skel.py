# Builds src/skel.dat: one line per key, "key<TAB>word<TAB>word ...", words most frequent first (tier A only), keys sorted.
import csv,sys,collections,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from skel import odia_keys
csv.field_size_limit(10**9)
W=os.path.join(os.path.dirname(os.path.abspath(__file__)),'../../Lekhani_Wordlist/lekhani_wordlist.csv')
MAXW=150
words=[]
with open(W,encoding='utf-8-sig') as fh:
    r=csv.reader(fh); h=next(r); io=h.index('odia'); ic=h.index('count'); it=h.index('tier')
    for row in r:
        if row[it]=='A':
            try: words.append((int(row[ic]),row[io]))
            except: pass
words.sort(key=lambda x:(-x[0],len(x[1]),x[1]))
db=collections.defaultdict(list)
for cnt,w in words:
    if len(w)<2 or len(w)>40: continue
    for k in odia_keys(w):
        if len(k)>=2 and len(db[k])<MAXW and w not in db[k]: db[k].append(w)
out=os.path.join(os.path.dirname(os.path.abspath(__file__)),'../src/skel.dat')
with open(out,'w',encoding='utf-8',newline='') as f:
    for k in sorted(db): f.write(k+'\t'+'\t'.join(db[k])+'\n')
print(len(words),'words,',len(db),'keys,',os.path.getsize(out),'bytes')
