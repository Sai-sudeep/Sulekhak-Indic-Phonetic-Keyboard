"""Reference implementation of the skeleton lookup (the C engine and the JS twin must give the same results).
A word is reduced to a key of consonant symbols (ଧ and ଢ both D, ତ and ଟ both t ...). What you type is reduced the same way,
so pasnd, pasand and psnd all find ପସନ୍ଦ. The vowels you did type only decide the order."""
CONS={0x0B15:'k',0x0B16:'K',0x0B17:'g',0x0B18:'G',0x0B19:'n',0x0B1A:'c',0x0B1B:'c',0x0B1C:'j',0x0B1D:'J',0x0B1E:'n',
 0x0B1F:'t',0x0B20:'T',0x0B21:'d',0x0B22:'D',0x0B23:'n',0x0B24:'t',0x0B25:'T',0x0B26:'d',0x0B27:'D',0x0B28:'n',
 0x0B2A:'p',0x0B2B:'P',0x0B2C:'b',0x0B2D:'B',0x0B2E:'m',0x0B2F:'j',0x0B30:'r',0x0B32:'l',0x0B33:'l',0x0B35:'b',
 0x0B36:'s',0x0B37:'s',0x0B38:'s',0x0B39:'h',0x0B5C:'d',0x0B5D:'D',0x0B5F:'j',0x0B71:'b'}
RETRO=set(map(ord,'ଟଠଡଢଣଳ'))|{0x0B5C,0x0B5D}
DENT=set(map(ord,'ତଥଦଧନଲ'))
SIGN={0x0B3E:'a',0x0B3F:'i',0x0B40:'i',0x0B41:'u',0x0B42:'u',0x0B43:'ri',0x0B47:'e',0x0B48:'ai',0x0B4B:'o',0x0B4C:'au'}
IND={0x0B05:'a',0x0B06:'a',0x0B07:'i',0x0B08:'i',0x0B09:'u',0x0B0A:'u',0x0B0B:'ri',0x0B0F:'e',0x0B10:'ai',0x0B13:'o',0x0B14:'au'}
HAL=0x0B4D
def collapse(v):
    out=''
    for ch in v:
        if not out or out[-1]!=ch: out+=ch
    return out
ALTS=(None,'flap','ri','jna','ksa')
def alt_text(w,alt):
    """the word as it is typed under an alternative spelling; None when the alternative does not apply"""
    if alt is None: return w
    if alt=='flap': return w.replace('\u0B5C','\u0B30') if '\u0B5C' in w else None
    if alt=='ri': return w if '\u0B43' in w else None
    if alt=='jna': return w.replace('ଜ୍ଞ','ଗ\u0B4Dଯ') if 'ଜ୍ଞ' in w else None
    if alt=='ksa': return w.replace('କ୍ଷ','ଖ') if 'କ୍ଷ' in w else None
def odia_slots(w,alt=None):
    """-> (initial vowel, [(sym, vowel, retro 0/1/2)], final_inherent)   vowel '' = joined to the next letter by a halant"""
    w=alt_text(w,alt)
    v0=''; sl=[]; endc=False
    for ch in w:
        c=ord(ch); endc=False
        if c in CONS:
            sl.append([CONS[c],None,1 if c in RETRO else (2 if c in DENT else 0),False]); endc=True
        elif c==HAL:
            if sl: sl[-1][3]=True
        elif c==0x0B3C: endc=True
        elif c==0x0B43 and alt=='ri':
            if sl: sl[-1][1]=''; sl.append(['r','i',0,False])
        elif c in SIGN:
            if sl and not sl[-1][3]: sl[-1][1]=SIGN[c]
        elif c in IND:
            if not sl: v0+=IND[c]
            elif not sl[-1][3]: sl[-1][1]=(sl[-1][1] if sl[-1][1] is not None else 'a')+IND[c]
    fin=bool(sl) and endc and sl[-1][1] is None and not sl[-1][3]
    out=[]
    for s in sl:
        v='' if s[3] else ('a' if s[1] is None else collapse(s[1]) if len(set(s[1]))==1 else s[1])
        out.append((s[0],v,s[2]))
    return collapse(v0),out,fin
def odia_keys(w):
    out=[]
    for alt in ALTS:
        if alt_text(w,alt) is None: continue
        k=''.join(x[0] for x in odia_slots(w,alt)[1])
        if len(k)>=2 and k not in out: out.append(k)
    return out
def typed_parse(roman):
    """-> (initial vowel, [[sym, vowel, retro_typed], ...])"""
    s=''.join(c for c in roman if c.isalpha())
    if not s: return None
    def vrun(i):
        j=i
        while j<len(s) and s[j].lower() in 'aeiou': j+=1
        raw=s[i:j]; v=collapse(raw.lower().replace('ou','au'))
        return (v+'#' if ('aa' in raw.lower() or 'A' in raw) and v=='a' else v),j
    v0,i=vrun(0); toks=[]
    ASP={'kh':'K','gh':'G','jh':'J','th':'T','dh':'D','ph':'P','bh':'B'}
    ONE={'k':'k','g':'g','c':'c','j':'j','t':'t','d':'d','n':'n','p':'p','b':'b','m':'m','y':'j','r':'r','l':'l','v':'b','w':'b','s':'s','h':'h','f':'P','q':'k','z':'j'}
    while i<len(s):
        c=s[i]; lc=c.lower(); two=s[i:i+2].lower(); three=s[i:i+3].lower()
        up=c.isupper(); syms=None; n=1
        if three=='chh': syms='c'; n=3
        elif two in ASP: syms=ASP[two]; n=2
        elif two=='ch': syms='c'; n=2
        elif two=='sh': syms='s'; n=2
        elif two=='rh': syms='D'; n=2
        elif lc=='x': syms='ks'
        elif lc=='r' and up: syms='d'
        elif lc in ONE: syms=ONE[lc]
        else: i+=1; continue
        retro=1 if (up and syms[0] in 'tTdDnl') else 0
        v,j=vrun(i+n)
        if len(syms)==2: toks.append([syms[0],'',0]); toks.append([syms[1],v,0])
        else: toks.append([syms,v,retro])
        i=j
    return v0,toks
def key_of(t): return ''.join(x[0] for x in t[1])
def score(t,wslots,fin):
    v0,toks=t; w0,ws,fin=wslots
    v0=v0.replace('#','')
    sc=0
    if v0==w0: sc+=3 if v0 else 0
    elif v0=='' or w0=='': sc-=3
    else: sc-=2
    for k,(a,b) in enumerate(zip(toks,ws)):
        tv=a[1]; wv=b[1]; lg=tv.endswith('#'); tv=tv.replace('#','')
        last=(k==len(ws)-1)
        if tv=='': x=0
        elif last and fin: x=(-1 if lg else 3) if tv=='a' else -2
        elif tv==wv: x=3
        elif wv=='': x=-2
        elif tv in wv or wv in tv: x=1
        else: x=-2
        if a[2]:
            if b[2]==1: x+=1
            elif b[2]==2: x-=1
        sc+=x
    return sc
def lookup(db,roman,limit=6):
    t=typed_parse(roman)
    if not t or len(t[1])<2: return []
    tries=[(t,False)]
    for idx,tk in enumerate(t[1]):
        if tk[0] in 'nm' and 0<idx<len(t[1])-1:       # a nasal before a consonant may be an anusvara: try without it
            toks=[list(x) for x in t[1]]
            if toks[idx-1][1]=='': toks[idx-1][1]=toks[idx][1]
            del toks[idx]; tries.append(((t[0],toks),True))
    seen=set(); res=[]
    for tt,_ in tries:
        key=key_of(tt)
        for rank,w in enumerate(db.get(key,[])):
            if w in seen: continue
            best=None
            for alt in ALTS:
                if alt_text(w,alt) is None: continue
                ws=odia_slots(w,alt)
                if ''.join(x[0] for x in ws[1])!=key: continue
                sc=score(tt,ws,ws[2]); best=sc if best is None or sc>best else best
            if best is None: continue
            seen.add(w); res.append((best,rank,w))
    res.sort(key=lambda x:(-x[0],x[1]))
    return res[:limit]
