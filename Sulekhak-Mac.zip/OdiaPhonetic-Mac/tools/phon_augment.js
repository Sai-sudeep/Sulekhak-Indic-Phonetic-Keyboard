/* Adds the affricates (single-character ligature AND tie-bar forms), the release / prenasalized sequences, the ligature letters and
   every other sequence that starts with a letter that has a key, under the key their FIRST PART looks like.
   usage: node tools/phon_augment.js html/phon-data.js tools/phon-data.base.js   (reads the base database, writes the augmented one; always start from the base) */
const fs=require('fs'), crypto=require('crypto');
const file=process.argv[2]||'html/phon-data.js';
const src=fs.readFileSync(process.argv[3]||file,'utf8'); global.window={}; eval(src); const D=window.SKPH;
const cp=s=>Array.from(s).map(c=>c.codePointAt(0));
const TIEA='͡', TIEB='͜', DENT='̪';
const cat=n=>{const i=D.cats.indexOf(n); if(i<0) throw new Error('cat '+n); return i};
const bySym={}; D.entries.forEach((e,i)=>{ (bySym[e[0]]=bySym[e[0]]||[]).push(i) });
const first=s=>bySym[s]?bySym[s][0]:-1;
function addEntry(s,inv,catn,label,status,srcs,note,fonts){
  if(bySym[s]&&bySym[s].some(i=>D.entries[i][1]===inv)) return bySym[s].find(i=>D.entries[i][1]===inv);
  const i=D.entries.length; D.entries.push([s,inv,cat(catn),label,status,3,srcs,note||'',0,'',fonts||7,-1]); (bySym[s]=bySym[s]||[]).push(i); return i;
}
const keyMap=D.keyMap; const rowHas=(k,i)=>(keyMap[k]||[]).some(r=>r[0]===i);
const sym2keys=()=>{ const m={}; for(const k in keyMap) for(const r of keyMap[k]){ const s=D.entries[r[0]][0]; (m[s]=m[s]||new Set()).add(k) } return m };
let added=0, rows=0;
function row(k,i,rel,conf,score,why){
  if(!D.keys.includes(k)) return; if(rowHas(k,i)) return;
  (keyMap[k]=keyMap[k]||[]).push([i,rel,conf,score,D.entries[i][10]||7,why]); D.entries[i][5]=0; rows++;
}
const S0=sym2keys();            /* keys the single letters already have, before anything below is added */
function keysOf(base){ if(/^[\x21-\x7e]$/.test(base)) return [base]; return [...(S0[base]||[])] }
const SRC=['wp-ipa','wp-ipa-unicode','ipa-alpha-org'];

/* ---------- 1. affricates and double articulations: ligature, tie bar above, tie bar below, untied ---------- */
const AFF=[ /* [parts, label, ligature or '', first-part key(s)] ; parts are the two (or three) base characters */
 [['t','s'],'voiceless alveolar affricate','ʦ'],[['d','z'],'voiced alveolar affricate','ʣ'],
 [['t','ʃ'],'voiceless postalveolar affricate','ʧ'],[['d','ʒ'],'voiced postalveolar affricate','ʤ'],
 [['t','ɕ'],'voiceless alveolo-palatal affricate','ʨ'],[['d','ʑ'],'voiced alveolo-palatal affricate','ʥ'],
 [['ʈ','ʂ'],'voiceless retroflex affricate',''],[['ɖ','ʐ'],'voiced retroflex affricate',''],
 [['p','f'],'voiceless labiodental affricate',''],[['b','v'],'voiced labiodental affricate',''],
 [['p̪','f'],'voiceless labiodental affricate with dentolabial onset (p̪͡f)',''],[['b̪','v'],'voiced labiodental affricate with dentolabial onset (b̪͡v)',''],
 [['t','θ'],'voiceless dental affricate',''],[['d','ð'],'voiced dental affricate',''],
 [['t̪','θ'],'voiceless dental affricate, dental onset (Spanish zapato; t̪͡θ)',''],[['d̪','ð'],'voiced dental affricate, dental onset (d̪͡ð)',''],
 [['t','ɬ'],'voiceless alveolar lateral affricate',''],[['d','ɮ'],'voiced alveolar lateral affricate',''],
 [['c','ç'],'voiceless palatal affricate',''],[['ɟ','ʝ'],'voiced palatal affricate',''],
 [['k','x'],'voiceless velar affricate',''],[['ɡ','ɣ'],'voiced velar affricate',''],
 [['q','χ'],'voiceless uvular affricate',''],[['ɢ','ʁ'],'voiced uvular affricate',''],
 [['k','p'],'voiceless labial-velar plosive (double articulation)',''],[['ɡ','b'],'voiced labial-velar plosive (double articulation)',''],
 [['ŋ','m'],'labial-velar nasal (double articulation)',''],
 [['t','ɹ'],'postalveolar affricate t͡ɹ (as in English tr-)',''],[['d','ɹ'],'postalveolar affricate d͡ɹ (as in English dr-)',''],
 [['t','ɕ'],'',''],
];
const seenAff={};
for(const [parts,label,lig] of AFF){
  if(!label) continue;
  const a=parts[0], tieA=parts.join(TIEA), tieB=parts.join(TIEB), plain=parts.join('');
  if(seenAff[tieA]) continue; seenAff[tieA]=1;
  const baseKey=Array.from(a)[0];            /* the first letter, without its diacritic */
  let keys=keysOf(baseKey); if(!keys.length) continue;
  const nt=`Tie bar above (U+0361). Variants: the ligature letter where one exists, tie bar below U+035C, and the untied digraph.`;
  const iA=addEntry(tieA,0,'affricate-sequence',label,/English/.test(label)?'unresolved':'validated',SRC,nt,8);
  const iB=addEntry(tieB,0,'affricate-sequence',label+' (tie bar below)','unresolved',['wp-ipa-unicode'],'Tie bar below (U+035C): the alternative tie bar the IPA allows. Same affricate as the tie bar above form.',7);
  const iC=addEntry(plain,0,'affricate-sequence',label+' (untied digraph)','unresolved',['wp-ipa'],'The same two letters written without a tie bar; common in practice, but the tie bar says it is one segment.',8);
  const iL=lig?first(lig):-1;
  for(const k of keys){
    const why=`starts with ${baseKey}: ${label}`;
    if(iL>=0) row(k,iL,'first','medium',0.72,`ligature letter for ${tieA}; the first part (${baseKey}) looks like ${k}`);
    row(k,iA,'first','medium',0.70,`${why}; tie bar above`);
    row(k,iB,'first','low',0.66,`${why}; tie bar below`);
    row(k,iC,'first','low',0.62,`${why}; untied digraph`);
  }
}
/* the ligature letters that were left as unmatched historical letters: make sure they are on the key their first part is */
for(const [lig,k] of [['ʦ','t'],['ʧ','t'],['ʨ','t'],['ʣ','d'],['ʤ','d'],['ʥ','d']]){ const i=first(lig); if(i>=0) row(k,i,'first','medium',0.72,`ligature letter; the first part looks like ${k}`) }
{ const i=first('ƛ'); if(i>=0) row('t',i,'first','low',0.64,'Americanist barred lambda stands for t͡ɬ: the first part looks like t') }

/* ---------- 2. release / prenasalized sequences and the modifier letters they use ---------- */
const MOD=[ /* [letter, base, label] */
 ['ᵐ','m','prenasalization (superscript m)'],['ᶯ','ɳ','prenasalization (superscript retroflex n)'],['ᶮ','ɲ','prenasalization (superscript palatal n)'],['ᵑ','ŋ','prenasalization (superscript eng)'],
 ['ˀ','ʔ','glottalized (superscript glottal stop)'],['ˢ','s','sibilant release (superscript s)'],['ᶻ','z','voiced sibilant release (superscript z)'],
 ['ᵇ','b','superscript b'],['ᵈ','d','superscript d'],['ᵍ','g','superscript g'],['ᵏ','k','superscript k'],['ᵖ','p','superscript p'],['ᵗ','t','superscript t'],
 ['ᶜ','c','superscript c'],['ᶠ','f','superscript f'],['ᵛ','v','superscript v'],['ᶴ','ʃ','postalveolar release (superscript esh)'],['ᶾ','ʒ','voiced postalveolar release (superscript ezh)'],
 ['ᶝ','ɕ','alveolo-palatal release (superscript curly-tail c)'],['ᶨ','ʝ','palatal release (superscript curly-tail j)'],['ᶞ','ð','voiced dental release (superscript eth)'],
 ['ᵡ','χ','uvular release (superscript chi)'],['ᵞ','ɣ','velar release (superscript gamma)'],['ᶲ','ɸ','bilabial release (superscript phi)'],['ᵝ','β','bilabial release (superscript beta)'],
 ['ᶹ','ʋ','labiodental release (superscript v with hook)'],['ᶣ','ɥ','labial-palatalized (superscript turned h)'],
];
for(const [m,base,label] of MOD){
  const i=addEntry(m,0,'modifier-letter',label,'validated',['unicode-U02B0','wp-ipa-unicode'],'Phonetic modifier letter (Unicode U+02B0 / U+1D2C blocks); the shrunken form of its base letter.',6);
  for(const k of keysOf(base)) row(k,i,'scaled','medium',0.74,`reduced-size form of ${base}`);
}
const REL=[ /* [letters, label, base key letter] : stop + release, sequences that start with the stop */
 ['tˢ','voiceless alveolar affricate, release written as a superscript','t'],['dᶻ','voiced alveolar affricate, superscript release','d'],
 ['tᶴ','voiceless postalveolar affricate, superscript release','t'],['dᶾ','voiced postalveolar affricate, superscript release','d'],
 ['tᶝ','voiceless alveolo-palatal affricate, superscript release','t'],['dᶨ','voiced alveolo-palatal affricate (palatal release), superscript release','d'],
 ['tᶿ','voiceless dental affricate, superscript release','t'],['dᶞ','voiced dental affricate, superscript release','d'],
 ['pᶠ','voiceless labiodental affricate, superscript release','p'],['bᵛ','voiced labiodental affricate, superscript release','b'],
 ['kˣ','voiceless velar affricate, superscript release','k'],['ɡˠ','velarized voiced velar plosive','g'],['qᵡ','voiceless uvular affricate, superscript release','q'],
 ['ɡᵞ','voiced velar affricate, superscript release','g'],['pᶲ','voiceless bilabial affricate, superscript release','p'],['bᵝ','voiced bilabial affricate, superscript release','b'],
 ['ᵐb','prenasalized voiced bilabial plosive','m'],['ⁿd','prenasalized voiced alveolar plosive','n'],['ᶯɖ','prenasalized voiced retroflex plosive','n'],
 ['ᶮɟ','prenasalized voiced palatal plosive','n'],['ᵑɡ','prenasalized voiced velar plosive','n'],['ᵐp','prenasalized voiceless bilabial plosive','m'],
 ['ⁿt','prenasalized voiceless alveolar plosive','n'],['ᵑk','prenasalized voiceless velar plosive','n'],
 ['ⁿz','prenasalized voiced alveolar fricative','n'],['ⁿs','prenasalized voiceless alveolar fricative','n'],
 ['ⁿdz','prenasalized voiced alveolar affricate','n'],['ⁿdʒ','prenasalized voiced postalveolar affricate','n'],['ᵐbv','prenasalized voiced labiodental affricate','m'],
];
for(const [s,label,k] of REL){
  const i=addEntry(s,0,'affricate-sequence',label,'unresolved',['wp-ipa-unicode'],'Sequence of a stop and a superscript release or prenasalization letter; stored as typed.',6);
  row(k,i,'first','low',0.66,`starts with ${Array.from(s)[0]}: ${label}`);
}

/* ---------- 3. ligature and hook letters whose first part is a letter on a key ---------- */
const LET=[ /* [symbol, key, why, score] */
 ['æ','a','a + e ligature: the first part looks like a',0.70],['œ','o','o + e ligature: the first part looks like o',0.70],['ɶ','o','small-capital o + e ligature: the first part looks like o',0.68],
 ['ɮ','l','lezh, an l + ezh ligature: the first part looks like l',0.70],['ɧ','h','hooked heng, an h + eng ligature: the first part looks like h',0.68],
 ['ɺ','l','l joined to a fishhook r: the first part looks like l',0.68],['ʪ','l','l + s ligature: the first part looks like l',0.70],['ʫ','l','l + z ligature: the first part looks like l',0.70],
 ['ʩ','f','f + eng ligature: the first part looks like f',0.70],['𝼀','f','feng with a trill: the first part looks like f',0.66],['ꞎ','l','l with a retroflex hook and a belt',0.70],['ꬸ','l','l with a double middle tilde',0.70],
 ['𝼅','l','lezh with a retroflex hook: the first part looks like l',0.68],['𝼄','L','small capital l with a belt',0.70],['𝼁','g','reversed script g',0.68],['𝼂','G','small capital turned g',0.66],
 ['ɠ','g','g with a hook',0.76],['ʄ','j','dotless barred j with a hook',0.72],['ʛ','G','small capital g with a hook',0.74],['ʋ','v','v with a hook',0.78],['ɻ','r','turned r with a retroflex hook',0.70],
 ['ʐ','z','z with a retroflex hook',0.78],['ᶑ','d','d with a hook and a tail',0.72],['ʡ','?','glottal stop with a bar',0.72],['ɚ','e','schwa with a rhotic hook: the first part (ə) looks like e',0.70],
 ['ɝ','3','reversed epsilon with a rhotic hook: the first part (ɜ) looks like 3',0.70],['ɷ','u','closed omega (withdrawn): looks like u',0.60],
];
for(const [s,k,why,sc] of LET){ const i=first(s); if(i>=0) row(k,i,'first',sc>=0.74?'medium':'low',sc,why) }

/* ---------- 4. every other sequence that starts with a letter that has a key ---------- */
const S1=sym2keys();
D.entries.forEach((e,i)=>{
  if(!/^unmatched/.test(D.vis[e[5]])) return;
  const c=D.cats[e[2]]; if(!/^(diacritic-sequence|extipa-sequence|iast-variant|affricate-sequence)$/.test(c)) return;
  const f=Array.from(e[0])[0]; if(/^\p{M}$/u.test(f)) return;
  const ks=/^[\x21-\x7e]$/.test(f)?[f]:[...(S0[f]||[])]; if(!ks.length) return;
  for(const k of ks) row(k,i,'first','low',0.68,`starts with ${f}: ${e[3]}`);
});

/* ---------- 5. EXHAUSTIVE: every symbol gets at least one English letter / digit / punctuation key ---------- */
/* 5a. explicit look-alike table for the symbols whose shape does not start with a Latin letter (key string, strongest first) */
const EX={
 'ɸ':'fpo','β':'bB','ð':'dD','ʃ':'sfS','ʒ':'z3Z','ɣ':'gyv','χ':'xkX','ʁ':'Rr','ʕ':'?cS','ǂ':'|+!','ǁ':'|l','ʢ':'?c','ǀ':'|l','ǃ':'!|',
 'ʊ':'uUvo','ɤ':'yvx','ɛ':'e3E','ɞ':'e3','ɒ':'aop',
 '\u032C':'v^','\u0339':')c','\u031C':'(c','\u0308':'":','\u0324':'":','\u033C':'wvm','\u031D':'+t^','\u031E':'-T_','\u0318':'<(','\u0319':'>)',
 '\u032A':'umn','\u033A':'n^','\u033B':'_[o','\u031A':"'-7",'\u030B':'"\'','\u030F':'"`','\u1DC4':"'-",'\u1DC5':'`-','\u1DC8':"`'~",'\u1DC9':"'`~",'\u1DC6':'-`','\u1DC7':"-'",
 '\u0310':'~^o','\u0361':'^~(','\u035C':'_u(','ˌ':',','ˑ':':.','‖':'|l','‿':'_u','’':"'",'ʗ':'cC','ʖ':'?c','ɿ':'ir','ʅ':'is','ʮ':'uyi','ꭥ':'woW','Ɛ':'E3','Ŋ':'Nn','Ɣ':'YGy','ɀ':'zZ',
 'ʬ':'wm','ʭ':'hn','˷':'~_','˭':'=h','ˬ':'v','↗':'/^','↘':'\\v','↑':'^','↓':'v!','ꜛ':'^/','ꜜ':'v!','ʱ':'h','ˠ':'gy','ˤ':'?c','˞':'rR','ʴ':'r','ᵊ':'ea','ᶴ':'sf','ᶾ':'z3','ᶞ':'d','ᵡ':'x','ᵞ':'gy','ᶲ':'fp','ᵝ':'b','ᶹ':'v',
 '(.)':'.(','(..)':'.(','(...)':'.(','𝆑':'f','𝆏':'p','𝆑𝆑':'f','𝆏𝆏':'p','⸨':'(','⸩':')','⦇':'(','⦈':')','⸦':'([','⸧':')]','◯':'oO0',
 '˥':'5','˦':'4','˧':'3','˨':'2','˩':'1','꜒':'5','꜓':'4','꜔':'3','꜕':'2','꜖':'1',
};
for(const c of 'CFGKLNPRSTV') EX[String.fromCodePoint(0x24B6+c.charCodeAt(0)-65)]=c+c.toLowerCase();   /* circled capitals (extIPA uncertainty) */
const TONEDIG={'˥':'5','˦':'4','˧':'3','˨':'2','˩':'1'};
const NAMES=JSON.parse(fs.readFileSync(require('path').join(__dirname,'uni_names.json'),'utf8'));
const GREEK={ALPHA:'a',BETA:'b',GAMMA:'g',DELTA:'d',EPSILON:'e',IOTA:'i',THETA:'t',CHI:'x',PHI:'fp',UPSILON:'u',OMEGA:'w',OMICRON:'o',RHO:'r',SIGMA:'s',LAMDA:'l',LAMBDA:'l',ETA:'h',PSI:'y'};
const LIGK={AE:'ae',OE:'oe',AO:'ao',AU:'au',AV:'av',AY:'ay',DZ:'dz',LS:'ls',LZ:'lz',TS:'ts',TZ:'tz',FN:'fn',DB:'db',QP:'qp',TC:'tc',TH:'t',DH:'d',UE:'ue',OU:'ou',EZH:'z3',ESH:'sf',ENG:'n',ETH:'d',SCHWA:'e',YOGH:'z3gy',THORN:'tp',WYNN:'w',IOTA:'i',UPSILON:'u',OPEN:'o',GAMMA:'gy',DELTA:'d',BETA:'b',CHI:'x',PHI:'fp',THETA:'t',ALPHA:'a',EPSILON:'e',OMEGA:'w',RHO:'r',SIGMA:'s',LAMBDA:'l',LAMDA:'l'};
const DIAK=[[/TILDE/,'~'],[/ACUTE/,"'"],[/GRAVE/,'`'],[/CIRCUMFLEX/,'^'],[/CARON/,'v^'],[/MACRON|BAR|LINE|STROKE/,'-_'],[/DIAERESIS|DOUBLE DOT/,'":'],[/DOT/,'.'],[/RING|CIRCLE/,'o0'],[/BREVE|BRIDGE|ARCH/,'u'],[/HOOK|HORN|COMMA|CEDILLA|OGONEK/,",'"],[/PARENTHES|BRACKET/,'()'],[/UPWARDS/,'^'],[/DOWNWARDS/,'v'],[/LEFT/,'<'],[/RIGHT/,'>'],[/SLASH|SOLIDUS|DIAGONAL/,'/'],[/VERTICAL/,'|'],[/HORIZONTAL/,'-'],[/CROSS|PLUS/,'+'],[/ASTERISK|X ABOVE|XX/,'*x'],[/DOUBLE/,'='],[/ZIGZAG|WAVE|SQUIGGLE/,'~']];
const NAMEKEY=[[/COLON/,':'],[/EXCLAMATION/,'!'],[/EQUALS|EQUAL TO/,'='],[/PRIME|SALTILLO/,"'"],[/GLOTTAL|AIN\b|LARYNGEAL/,'?c'],[/UP ARROWHEAD|UP TACK|UPWARDS|FERMATA/,'^'],[/DOWN ARROWHEAD|DOWN TACK|DOWNWARDS/,'v'],[/MINUS/,'-'],
 [/BEGIN HIGH|END HIGH|RAISED|HIGH TONE/,'5'],[/BEGIN LOW|END LOW|LOW TONE/,'1'],[/YIN|YANG|CHINESE TONE|DEPARTING|RISING|LEVEL/,'12345'],[/SHELF/,'_'],[/LIGATURE OE/,'o'],[/\bPI\b/,'p'],[/\bEL\b/,'l'],[/CYRILLIC EN/,'n'],[/CLICK/,'!|'],
 [/DEZH/,'d'],[/LEZH/,'l'],[/TESH/,'t'],[/FENG/,'f'],[/HOMOTHETIC|ALMOST EQUAL|PERISPOMENI|SNAKE/,'~'],[/COMMA/,','],[/INFINITY/,'8'],[/GRAPHEME JOINER/,'_'],[/FLATTENED OPEN A|SMALL CAPITAL AA/,'a'],[/TRIANGULAR/,':'],[/LATERAL/,'l'],[/INVERTED EXCLAMATION/,'!']];
function keysFromName(ch){
  const nm=NAMES[ch]||''; let m, out=[];
  const L=x=>{ if(x&&/^[A-Z]$/.test(x)) out.push(x.toLowerCase(), x); };
  const word=t=>{ if(t.length===1) L(t); else if(GREEK[t]) out.push(...GREEK[t]); else if(LIGK[t]) out.push(...LIGK[t]); };
  if((m=nm.match(/(?:SMALL CAPITAL|SUBSCRIPT SMALL LETTER|SUBSCRIPT CAPITAL LETTER|MODIFIER LETTER SMALL CAPITAL|MODIFIER LETTER SMALL|MODIFIER LETTER CAPITAL|SUPERSCRIPT|SMALL GREEK|SMALL CAPITAL) ((?:[A-Z]{1,8}))\b/))) word(m[1]);
  if(!out.length&&(m=nm.match(/LETTER (?:SMALL CAPITAL |CAPITAL |SMALL GREEK |SMALL |REVERSED |TURNED |INVERTED |OPEN |CLOSED |BARRED |SCRIPT |INSULAR |DOTLESS |LONG |FLATTENED |SIDEWAYS |MIDDLE-WELSH |CON |ET |IS |US |RUM |VEND )*([A-Z]{1,8})\b/))) word(m[1]);
  if(!out.length&&(m=nm.match(/\b([A-Z])\b/))) L(m[1]);
  if(!out.length){ for(const [re,k] of NAMEKEY) if(re.test(nm)){ out.push(...k); break } }
  if(!out.length){ for(const [re,k] of DIAK) if(re.test(nm)){ out.push(...k) } }
  return [...new Set(out)];
}
/* 5b. Unicode phonetic blocks the database did not list yet */
function blockOf(c){
  if(c>=0x250&&c<=0x2af) return ['ipa-extension','other-letter'];
  if(c>=0x2b0&&c<=0x2ff) return ['spacing-modifier','modifier-letter'];
  if((c>=0x300&&c<=0x36f)||(c>=0x1ab0&&c<=0x1aff)||(c>=0x1dc0&&c<=0x1dff)) return ['combining','combining-mark'];
  if(c>=0x1d00&&c<=0x1dbf) return ['phonetic-extension','modifier-letter'];
  if(c>=0xa700&&c<=0xa71f) return ['tone-modifier','tone-letter'];
  if(c>=0x10780&&c<=0x107ba) return ['phonetic-extension-sup','modifier-letter'];
  return ['latin-extended','other-letter'];
}
const pretty=nm=>{ const t=nm.toLowerCase(); return t.charAt(0).toUpperCase()+t.slice(1) };
let tier2=0;
for(const ch of Object.keys(NAMES)){
  if(Array.from(ch).length!==1) continue; const c=ch.codePointAt(0);
  if(c<0x250||(c>=0x2c60&&c<=0x2c7f)||(c>=0x2190&&c<=0x21ff)||(c>=0xab5c&&c<=0xab6b&&c!==0xab65)) continue;
  if(bySym[ch]) continue;
  const [bk,catn]=blockOf(c); if(D.cats.indexOf(catn)<0) continue;
  addEntry(ch,5,catn,pretty(NAMES[ch]),'unresolved',['unicode-'+bk],'Unicode '+bk+' block: '+NAMES[ch].toLowerCase()+(/^\p{M}$/u.test(ch)?' (combining; typed after its base letter)':'')+'.',6); tier2++;
}
/* 5c. key every entry that still has no key */
function nfdBase(s){ const b=Array.from(Array.from(s)[0].normalize('NFD'))[0]; return /^[a-zA-Z]$/.test(b)?b:null }
function tonePair(s){ const cs=Array.from(s); if(cs.length===2&&TONEDIG[cs[0]]&&TONEDIG[cs[1]]){ const a=TONEDIG[cs[0]],b=TONEDIG[cs[1]]; return [a,b,+a<+b?'/':'\\'] } return null }
const byRule={ex:0,seq:0,tone:0,name:0,fallback:0}; let nowKeyed=0;
const REVK=new Set(); for(const k in keyMap) for(const r of keyMap[k]) REVK.add(r[0]);
D.entries.forEach((e,i)=>{
  if(REVK.has(i)) return;
  const s=e[0]; let ks=null, why='', sc=0.66, how='';
  if(EX[s]){ ks=Array.from(EX[s]); why='looks like '+ks[0]+(ks.length>1?' (also '+ks.slice(1).join(' ')+')':''); sc=0.74; how='ex'; }
  else if(tonePair(s)){ ks=tonePair(s); why='tone contour from level '+ks[0]+' to level '+ks[1]; sc=0.70; how='tone'; }
  else { const f=Array.from(s)[0], b=nfdBase(s), x=EX[f];
    if(x&&Array.from(s).length>1){ ks=Array.from(x); how='seq'; why='starts with '+f+': '+e[3]; }
    else if(b){ ks=[b]; how='seq'; why='starts with '+b+': '+e[3]; }
    else { const kn=keysFromName(f); if(kn.length){ ks=kn; how='name'; why='by its shape ('+(NAMES[f]||'').toLowerCase()+')'; } } }
  if(!ks||!ks.length){ const c=D.cats[e[2]]; const g=/tone|accent|diacritic|combining|mark/.test(c)?'~':/modifier|prosodic|suprasegmental|word/.test(c)?"'":/letter|vowel|consonant/.test(c)?'o':'.';
    ks=[g]; how='fallback'; why='generic key for '+c+': '+e[3]; }
  ks.forEach((k,j)=>row(k,i,'first',j===0?'medium':'low',Math.max(0.5,sc-0.02*j),why));
  byRule[how]++; nowKeyed++; REVK.add(i);
});
console.log('Unicode-block entries added',tier2,'| keyed now',nowKeyed,JSON.stringify(byRule));
{ const left=D.entries.filter((e,i)=>!REVK.has(i)); if(left.length) throw new Error('still without a key: '+left.map(e=>e[0]).join(' ')); }

/* ---------- 6. ARTICULATION: every IPA consonant and vowel also goes under the English letter(s) whose sound is closest
   in manner, place and voicing (consonants) or in height, backness and rounding (vowels). A symbol may sit under two or three keys, each with its reason. ---------- */
const PL={bilabial:0,linguolabial:1.5,labiodental:1,dental:2,alveolar:3,postalveolar:4,retroflex:5,'alveolo-palatal':5.5,palatal:6,velar:7,uvular:8,pharyngeal:9,epiglottal:9.5,glottal:10};
/* consonant table: symbol -> place, manner, voiced(1)/voiceless(0). Manners: stop nasal rhotic fricative sibilant lateralfric approximant lateral affricate click implosive */
const CONS={};
(function(){
 const add=(m,v,list)=>{ for(const [s,p] of list) CONS[s]={p:p.split('/'),m,v} };
 add('stop',0,[['p','bilabial'],['t','alveolar'],['t̪','dental'],['ʈ','retroflex'],['c','palatal'],['k','velar'],['q','uvular'],['ʡ','epiglottal'],['ʔ','glottal'],['ʗ','palatal'],['ǀ','dental']]);
 add('stop',1,[['b','bilabial'],['d','alveolar'],['d̪','dental'],['ɖ','retroflex'],['ɟ','palatal'],['ɡ','velar'],['g','velar'],['ɢ','uvular']]);
 add('stop',1,[['ɓ','bilabial'],['ɗ','alveolar'],['ᶑ','retroflex'],['ʄ','palatal'],['ɠ','velar'],['ʛ','uvular']]);
 add('nasal',1,[['m','bilabial'],['ɱ','labiodental'],['n','alveolar'],['n̪','dental'],['ɳ','retroflex'],['ɲ','palatal'],['ŋ','velar'],['ɴ','uvular']]);
 add('rhotic',1,[['ʙ','bilabial'],['r','alveolar'],['ʀ','uvular'],['ɾ','alveolar'],['ɽ','retroflex'],['ⱱ','labiodental'],['ɹ','alveolar'],['ɻ','retroflex'],['ɺ','alveolar']]);
 add('fricative',0,[['ɸ','bilabial'],['f','labiodental'],['θ','dental'],['ç','palatal'],['x','velar'],['χ','uvular'],['ħ','pharyngeal'],['h','glottal'],['ʜ','epiglottal'],['ʍ','bilabial/velar'],['ɧ','postalveolar/velar']]);
 add('fricative',1,[['β','bilabial'],['v','labiodental'],['ð','dental'],['ʝ','palatal'],['ɣ','velar'],['ʁ','uvular'],['ʕ','pharyngeal'],['ɦ','glottal'],['ʢ','epiglottal']]);
 add('sibilant',0,[['s','alveolar'],['ʃ','postalveolar'],['ʂ','retroflex'],['ɕ','alveolo-palatal']]);
 add('sibilant',1,[['z','alveolar'],['ʒ','postalveolar'],['ʐ','retroflex'],['ʑ','alveolo-palatal']]);
 add('lateralfric',0,[['ɬ','alveolar']]); add('lateralfric',1,[['ɮ','alveolar']]);
 add('approximant',1,[['ʋ','labiodental'],['j','palatal'],['ɰ','velar'],['w','bilabial/velar'],['ɥ','bilabial/palatal']]);
 add('lateral',1,[['l','alveolar'],['ɭ','retroflex'],['ʎ','palatal'],['ʟ','velar'],['ɫ','alveolar/velar'],['ɺ','alveolar']]);
 add('click',0,[['ʘ','bilabial'],['ǃ','alveolar'],['ǂ','palatal'],['ǁ','alveolar']]);
 add('affricate',0,[['ʦ','alveolar'],['ʧ','postalveolar'],['ʨ','alveolo-palatal']]);
 add('affricate',1,[['ʣ','alveolar'],['ʤ','postalveolar'],['ʥ','alveolo-palatal']]);
 add('fricative',0,[['ʪ','alveolar'],['ʩ','velar']]); add('fricative',1,[['ʫ','alveolar']]);
})();
/* the English letters (as keys) and the sound each stands for */
const ANC=[ ['p','stop',0,'bilabial',0],['b','stop',1,'bilabial',0],['t','stop',0,'alveolar',0],['d','stop',1,'alveolar',0],['k','stop',0,'velar',0],['g','stop',1,'velar',0],['q','stop',0,'uvular',0],
 ['T','stop',0,'retroflex',0],['D','stop',1,'retroflex',0],['m','nasal',1,'bilabial',0],['n','nasal',1,'alveolar',0],['N','nasal',1,'retroflex',0],
 ['c','affricate',0,'postalveolar',0],['j','affricate',1,'postalveolar',0],['f','fricative',0,'labiodental',0],['v','fricative',1,'labiodental',0],['x','fricative',0,'velar',0],['h','fricative',0,'glottal',0],
 ['s','sibilant',0,'alveolar',0],['z','sibilant',1,'alveolar',0],['S','sibilant',0,'postalveolar',0],['Z','sibilant',1,'postalveolar',0],
 ['r','rhotic',1,'alveolar',0],['R','rhotic',1,'retroflex',0],['l','lateral',1,'alveolar',0],['L','lateral',1,'retroflex',0],['w','approximant',1,'bilabial/velar',0],['y','approximant',1,'palatal',0] ];
const MCOMP={ // how near two manners are (0 = same)
 'stop|stop':0,'nasal|nasal':0,'rhotic|rhotic':0,'fricative|fricative':0,'sibilant|sibilant':0,'lateralfric|lateralfric':0,'approximant|approximant':0,'lateral|lateral':0,'affricate|affricate':0,'click|click':0,
 'fricative|sibilant':1.2,'sibilant|fricative':1.2,'lateralfric|sibilant':1.6,'lateralfric|fricative':1.6,'lateralfric|lateral':1.8,'lateral|lateralfric':1.8,
 'approximant|rhotic':1.5,'rhotic|approximant':1.5,'lateral|approximant':1.5,'approximant|lateral':1.5,'lateral|rhotic':1.7,'rhotic|lateral':1.7,
 'affricate|stop':1.8,'stop|affricate':1.8,'affricate|sibilant':1.6,'sibilant|affricate':1.6,'affricate|fricative':2.2,'fricative|affricate':2.2,
 'stop|fricative':2.0,'fricative|stop':2.0,'click|stop':1.5,'stop|click':1.5,'click|nasal':3,'fricative|approximant':2,'approximant|fricative':2 };
const mdist=(a,b)=>{ const k=a+'|'+b; return k in MCOMP?MCOMP[k]:9 };
const pdist=(A,B)=>{ let best=99; for(const a of A) for(const b of B) best=Math.min(best,Math.abs(PL[a]-PL[b])); return best };
function nearestAnchors(c){
  const sc=ANC.map(a=>{ const aPl=a[3].split('/'); const sonorant=/^(nasal|rhotic|approximant|lateral)$/.test(c.m);
    const d=mdist(c.m,a[1])*1.0+(sonorant?0:(c.v!==a[2]?1.3:0))+pdist(c.p,aPl)*0.55; return {k:a[0],d,a} }).sort((x,y)=>x.d-y.d||0);
  const out=[sc[0]]; for(let i=1;i<sc.length&&out.length<3;i++) if(sc[i].d<=sc[0].d+1.3&&sc[i].d<=3.4) out.push(sc[i]);
  return out;
}
/* vowel table: height (0 close .. 6 open), backness (0 front, 1 central, 2 back), rounded */
const VOW={ i:[0,0,0],y:[0,0,1],ɨ:[0,1,0],ʉ:[0,1,1],ɯ:[0,2,0],u:[0,2,1],ɪ:[1,.3,0],ʏ:[1,.3,1],ʊ:[1,1.7,1],e:[2,0,0],ø:[2,0,1],ɘ:[2,1,0],ɵ:[2,1,1],ɤ:[2,2,0],o:[2,2,1],ə:[3,1,0],ɚ:[3,1,0],
 ɛ:[4,0,0],œ:[4,0,1],ɜ:[4,1,0],ɝ:[4,1,0],ɞ:[4,1,1],ʌ:[4,2,0],ɔ:[4,2,1],æ:[5,0,0],ɐ:[5,1,0],a:[6,0,0],ɶ:[6,0,1],ɑ:[6,2,0],ɒ:[6,2,1],ʚ:[4.5,.8,1],ɷ:[1,2,1] };
const VANC=[['i',0,0,0],['I',1,.3,0],['e',2,0,0],['E',4,0,0],['a',6,1,0],['A',6,2,0],['O',4,2,1],['o',2,2,1],['U',1,1.7,1],['u',0,2,1]];
function nearestVowels(v){
  const sc=VANC.map(a=>({k:a[0],d:Math.abs(v[0]-a[1])*0.75+Math.abs(v[1]-a[2])*1.1+(v[2]!==a[3]?0.9:0)})).sort((x,y)=>x.d-y.d);
  const out=[sc[0]]; for(let i=1;i<sc.length&&out.length<3;i++) if(sc[i].d<=sc[0].d+0.9&&sc[i].d<=2.6) out.push(sc[i]); return out;
}
const VNAME=v=>['close','near-close','close-mid','mid','open-mid','near-open','open'][Math.round(Math.min(6,Math.max(0,v[0])))]+' '+(v[1]<=0.5?'front':v[1]<1.5?'central':'back')+(v[2]?' rounded':' unrounded')+' vowel';
let art=0, artSyms=0;
D.entries.forEach((e,i)=>{
  const s=e[0], cs=Array.from(s); const base=cs[0]; const single=cs.length===1;
  let c=CONS[s], v=VOW[s], seqBase=false;
  if(!c&&!v&&!single){ const nb=Array.from(base.normalize('NFD'))[0]; const b0=CONS[base]||CONS[nb]?base:null; c=CONS[base]||CONS[nb]; v=VOW[base]||VOW[nb]; if(c||v) seqBase=true; if(c&&v) v=null }
  if(!c&&!v) return;
  if(!/^(ipa|extipa|other|historical|unicode-compatible|iast)$/.test(D.inv[e[1]])) return;
  const label=seqBase?('starts with '+base):'';
  if(c){
    const na=nearestAnchors(c); const pdesc=c.p.join('/')+' '+c.m.replace('lateralfric','lateral fricative')+(c.m==='nasal'||c.m==='rhotic'||c.m==='approximant'||c.m==='lateral'?'':(c.v?' voiced':' voiceless'));
    na.forEach((a,j)=>{ const ad=a.a; const why=(label?label+': ':'')+'articulation: '+pdesc+'; nearest English '+ad[1].replace('lateralfric','lateral fricative')+' key '+a.k+' ('+ad[3]+(ad[1]==='nasal'||ad[1]==='rhotic'||ad[1]==='approximant'||ad[1]==='lateral'?'':(ad[2]?', voiced':', voiceless'))+(j===0?')':'), also near');
      row(a.k,i,'first',j===0?'medium':'low',Math.max(0.5,0.71-0.03*j-(seqBase?0.04:0)),why); art++ });
    artSyms++;
  } else if(v){
    const na=nearestVowels(v);
    na.forEach((a,j)=>{ row(a.k,i,'first',j===0?'medium':'low',Math.max(0.5,0.72-0.03*j-(seqBase?0.04:0)),(label?label+': ':'')+'articulation: '+VNAME(v)+'; nearest English vowel key '+a.k+(j?' (also near)':'')); art++ });
    artSyms++;
  }
});
/* how English (and romanised Indic) spells these sounds: th, dh, sh, zh, ng, gh, kh, ny ... -> the letter the digraph starts with / the usual vowel letter */
const SPELL={ 'θ':'t','ð':'d','ʃ':'s','ʒ':'z','ɕ':'s','ʑ':'z','ŋ':'g','ɲ':'ny','ɣ':'g','ɧ':'s','ç':'hc','ʝ':'y','ɬ':'l','ɮ':'l','ʁ':'r','ʀ':'r','ʍ':'w','ɥ':'y','ɻ':'r','ɽ':'r','ɹ':'r','χ':'k','ħ':'h','ʕ':'a',
 'ɔ':'o','ɛ':'e','ʊ':'uo','ɪ':'i','ʌ':'au','æ':'a','ɑ':'a','ɒ':'o','ə':'ae','ɐ':'a','ɜ':'e','ɤ':'o','ɘ':'e','ɵ':'o','ɞ':'e','ø':'o','œ':'oe','ʏ':'iu','ɨ':'i','ʉ':'u','ɯ':'u','ɶ':'o','ɚ':'e','ɝ':'e' };
for(const sy in SPELL){ const i=first(sy); if(i<0) continue; Array.from(SPELL[sy]).forEach((k,j)=>row(k,i,'first','low',0.64-0.02*j,'English spelling: '+sy+' is written with the letter '+k+' (sound-alike)')) }
/* function-based keys for modifiers that carry no place of articulation of their own */
const FUNC={ 'ʰ':'h','ʱ':'hH','̤':'hH','ʷ':'w','ʲ':'yj','ʲ':'yj','ˠ':'gw','ˤ':'h','ⁿ':'n','ˡ':'l','˞':'r','ː':':','ˑ':':.','̥':'h','̊':'h','̃':'n~','̰':'~','̩':'|','̩':'|','̯':'u','̆':'u','̄':'-','ʼ':"'"};
for(const k in FUNC){ const i=first(k); if(i<0) continue; Array.from(FUNC[k]).forEach((key,j)=>row(key,i,'first',j?'low':'medium',0.68-0.02*j,'function: '+(D.entries[i][3]||'modifier')+' is read like the sound of key '+key)) }
console.log('articulation rows',art,'for',artSyms,'symbols');

/* ---------- housekeeping ---------- */
D.generated=new Date().toISOString().slice(0,10); D.version='2';
const body={...D}; delete body.hash;
D.hash=crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex').slice(0,16);
fs.writeFileSync(file,'window.SKPH='+JSON.stringify(D)+';\n');
console.log('entries',D.entries.length,'rows added',rows,'hash',D.hash);
