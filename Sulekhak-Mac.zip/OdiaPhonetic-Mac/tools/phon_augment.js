/* Adds the affricates (single-character ligature AND tie-bar forms), the release / prenasalized sequences, the ligature letters and
   every other sequence that starts with a letter that has a key, under the key their FIRST PART looks like.
   usage: node tools/phon_augment.js html/phon-data.js tools/phon-data.base.js   (reads the base database, writes the augmented one; always start from the base) */
const fs=require('fs'), crypto=require('crypto');
const file=process.argv[2]||'html/phon-data.js';
const src=fs.readFileSync(process.argv[3]||file,'utf8'); global.window={}; eval(src); const D=window.SKPH;
const cp=s=>Array.from(s).map(c=>c.codePointAt(0));
const TIEA='͡', TIEB='͜', DENT='̪';
const cat=n=>{const i=D.cats.indexOf(n); if(i<0) throw new Error('cat '+n); return i};
const bySym={}; D.entries.forEach((e,i)=>{ (bySym[e[0]]=bySym[e[0]]||[]).push(i) });
const first=s=>bySym[s]?bySym[s][0]:-1;
function addEntry(s,inv,catn,label,status,srcs,note,fonts){
  if(bySym[s]&&bySym[s].some(i=>D.entries[i][1]===inv)) return bySym[s].find(i=>D.entries[i][1]===inv);
  const i=D.entries.length; D.entries.push([s,inv,cat(catn),label,status,3,srcs,note||'',0,'',fonts||7,-1]); (bySym[s]=bySym[s]||[]).push(i); return i;
}
const keyMap=D.keyMap; const rowHas=(k,i)=>(keyMap[k]||[]).some(r=>r[0]===i);
const sym2keys=()=>{ const m={}; for(const k in keyMap) for(const r of keyMap[k]){ const s=D.entries[r[0]][0]; (m[s]=m[s]||new Set()).add(k) } return m };
let added=0, rows=0;
function row(k,i,rel,conf,score,why){
  if(!D.keys.includes(k)) return; if(rowHas(k,i)) return;
  (keyMap[k]=keyMap[k]||[]).push([i,rel,conf,score,D.entries[i][10]||7,why]); D.entries[i][5]=0; rows++;
}
const S0=sym2keys();            /* keys the single letters already have, before anything below is added */
function keysOf(base){ if(/^[\x21-\x7e]$/.test(base)) return [base]; return [...(S0[base]||[])] }
const SRC=['wp-ipa','wp-ipa-unicode','ipa-alpha-org'];

/* ---------- 1. affricates and double articulations: ligature, tie bar above, tie bar below, untied ---------- */
const AFF=[ /* [parts, label, ligature or '', first-part key(s)] ; parts are the two (or three) base characters */
 [['t','s'],'voiceless alveolar affricate','ʦ'],[['d','z'],'voiced alveolar affricate','ʣ'],
 [['t','ʃ'],'voiceless postalveolar affricate','ʧ'],[['d','ʒ'],'voiced postalveolar affricate','ʤ'],
 [['t','ɕ'],'voiceless alveolo-palatal affricate','ʨ'],[['d','ʑ'],'voiced alveolo-palatal affricate','ʥ'],
 [['ʈ','ʂ'],'voiceless retroflex affricate',''],[['ɖ','ʐ'],'voiced retroflex affricate',''],
 [['p','f'],'voiceless labiodental affricate',''],[['b','v'],'voiced labiodental affricate',''],
 [['p̪','f'],'voiceless labiodental affricate with dentolabial onset (p̪͡f)',''],[['b̪','v'],'voiced labiodental affricate with dentolabial onset (b̪͡v)',''],
 [['t','θ'],'voiceless dental affricate',''],[['d','ð'],'voiced dental affricate',''],
 [['t̪','θ'],'voiceless dental affricate, dental onset (Spanish zapato; t̪͡θ)',''],[['d̪','ð'],'voiced dental affricate, dental onset (d̪͡ð)',''],
 [['t','ɬ'],'voiceless alveolar lateral affricate',''],[['d','ɮ'],'voiced alveolar lateral affricate',''],
 [['c','ç'],'voiceless palatal affricate',''],[['ɟ','ʝ'],'voiced palatal affricate',''],
 [['k','x'],'voiceless velar affricate',''],[['ɡ','ɣ'],'voiced velar affricate',''],
 [['q','χ'],'voiceless uvular affricate',''],[['ɢ','ʁ'],'voiced uvular affricate',''],
 [['k','p'],'voiceless labial-velar plosive (double articulation)',''],[['ɡ','b'],'voiced labial-velar plosive (double articulation)',''],
 [['ŋ','m'],'labial-velar nasal (double articulation)',''],
 [['t','ɹ'],'postalveolar affricate t͡ɹ (as in English tr-)',''],[['d','ɹ'],'postalveolar affricate d͡ɹ (as in English dr-)',''],
 [['t','ɕ'],'',''],
];
const seenAff={};
for(const [parts,label,lig] of AFF){
  if(!label) continue;
  const a=parts[0], tieA=parts.join(TIEA), tieB=parts.join(TIEB), plain=parts.join('');
  if(seenAff[tieA]) continue; seenAff[tieA]=1;
  const baseKey=Array.from(a)[0];            /* the first letter, without its diacritic */
  let keys=keysOf(baseKey); if(!keys.length) continue;
  const nt=`Tie bar above (U+0361). Variants: the ligature letter where one exists, tie bar below U+035C, and the untied digraph.`;
  const iA=addEntry(tieA,0,'affricate-sequence',label,/English/.test(label)?'unresolved':'validated',SRC,nt,8);
  const iB=addEntry(tieB,0,'affricate-sequence',label+' (tie bar below)','unresolved',['wp-ipa-unicode'],'Tie bar below (U+035C): the alternative tie bar the IPA allows. Same affricate as the tie bar above form.',7);
  const iC=addEntry(plain,0,'affricate-sequence',label+' (untied digraph)','unresolved',['wp-ipa'],'The same two letters written without a tie bar; common in practice, but the tie bar says it is one segment.',8);
  const iL=lig?first(lig):-1;
  for(const k of keys){
    const why=`starts with ${baseKey}: ${label}`;
    if(iL>=0) row(k,iL,'first','medium',0.72,`ligature letter for ${tieA}; the first part (${baseKey}) looks like ${k}`);
    row(k,iA,'first','medium',0.70,`${why}; tie bar above`);
    row(k,iB,'first','low',0.66,`${why}; tie bar below`);
    row(k,iC,'first','low',0.62,`${why}; untied digraph`);
  }
}
/* the ligature letters that were left as unmatched historical letters: make sure they are on the key their first part is */
for(const [lig,k] of [['ʦ','t'],['ʧ','t'],['ʨ','t'],['ʣ','d'],['ʤ','d'],['ʥ','d']]){ const i=first(lig); if(i>=0) row(k,i,'first','medium',0.72,`ligature letter; the first part looks like ${k}`) }
{ const i=first('ƛ'); if(i>=0) row('t',i,'first','low',0.64,'Americanist barred lambda stands for t͡ɬ: the first part looks like t') }

/* ---------- 2. release / prenasalized sequences and the modifier letters they use ---------- */
const MOD=[ /* [letter, base, label] */
 ['ᵐ','m','prenasalization (superscript m)'],['ᶯ','ɳ','prenasalization (superscript retroflex n)'],['ᶮ','ɲ','prenasalization (superscript palatal n)'],['ᵑ','ŋ','prenasalization (superscript eng)'],
 ['ˀ','ʔ','glottalized (superscript glottal stop)'],['ˢ','s','sibilant release (superscript s)'],['ᶻ','z','voiced sibilant release (superscript z)'],
 ['ᵇ','b','superscript b'],['ᵈ','d','superscript d'],['ᵍ','g','superscript g'],['ᵏ','k','superscript k'],['ᵖ','p','superscript p'],['ᵗ','t','superscript t'],
 ['ᶜ','c','superscript c'],['ᶠ','f','superscript f'],['ᵛ','v','superscript v'],['ᶴ','ʃ','postalveolar release (superscript esh)'],['ᶾ','ʒ','voiced postalveolar release (superscript ezh)'],
 ['ᶝ','ɕ','alveolo-palatal release (superscript curly-tail c)'],['ᶨ','ʝ','palatal release (superscript curly-tail j)'],['ᶞ','ð','voiced dental release (superscript eth)'],
 ['ᵡ','χ','uvular release (superscript chi)'],['ᵞ','ɣ','velar release (superscript gamma)'],['ᶲ','ɸ','bilabial release (superscript phi)'],['ᵝ','β','bilabial release (superscript beta)'],
 ['ᶹ','ʋ','labiodental release (superscript v with hook)'],['ᶣ','ɥ','labial-palatalized (superscript turned h)'],
];
for(const [m,base,label] of MOD){
  const i=addEntry(m,0,'modifier-letter',label,'validated',['unicode-U02B0','wp-ipa-unicode'],'Phonetic modifier letter (Unicode U+02B0 / U+1D2C blocks); the shrunken form of its base letter.',6);
  for(const k of keysOf(base)) row(k,i,'scaled','medium',0.74,`reduced-size form of ${base}`);
}
const REL=[ /* [letters, label, base key letter] : stop + release, sequences that start with the stop */
 ['tˢ','voiceless alveolar affricate, release written as a superscript','t'],['dᶻ','voiced alveolar affricate, superscript release','d'],
 ['tᶴ','voiceless postalveolar affricate, superscript release','t'],['dᶾ','voiced postalveolar affricate, superscript release','d'],
 ['tᶝ','voiceless alveolo-palatal affricate, superscript release','t'],['dᶨ','voiced alveolo-palatal affricate (palatal release), superscript release','d'],
 ['tᶿ','voiceless dental affricate, superscript release','t'],['dᶞ','voiced dental affricate, superscript release','d'],
 ['pᶠ','voiceless labiodental affricate, superscript release','p'],['bᵛ','voiced labiodental affricate, superscript release','b'],
 ['kˣ','voiceless velar affricate, superscript release','k'],['ɡˠ','velarized voiced velar plosive','g'],['qᵡ','voiceless uvular affricate, superscript release','q'],
 ['ɡᵞ','voiced velar affricate, superscript release','g'],['pᶲ','voiceless bilabial affricate, superscript release','p'],['bᵝ','voiced bilabial affricate, superscript release','b'],
 ['ᵐb','prenasalized voiced bilabial plosive','m'],['ⁿd','prenasalized voiced alveolar plosive','n'],['ᶯɖ','prenasalized voiced retroflex plosive','n'],
 ['ᶮɟ','prenasalized voiced palatal plosive','n'],['ᵑɡ','prenasalized voiced velar plosive','n'],['ᵐp','prenasalized voiceless bilabial plosive','m'],
 ['ⁿt','prenasalized voiceless alveolar plosive','n'],['ᵑk','prenasalized voiceless velar plosive','n'],
 ['ⁿz','prenasalized voiced alveolar fricative','n'],['ⁿs','prenasalized voiceless alveolar fricative','n'],
 ['ⁿdz','prenasalized voiced alveolar affricate','n'],['ⁿdʒ','prenasalized voiced postalveolar affricate','n'],['ᵐbv','prenasalized voiced labiodental affricate','m'],
];
for(const [s,label,k] of REL){
  const i=addEntry(s,0,'affricate-sequence',label,'unresolved',['wp-ipa-unicode'],'Sequence of a stop and a superscript release or prenasalization letter; stored as typed.',6);
  row(k,i,'first','low',0.66,`starts with ${Array.from(s)[0]}: ${label}`);
}

/* ---------- 3. ligature and hook letters whose first part is a letter on a key ---------- */
const LET=[ /* [symbol, key, why, score] */
 ['æ','a','a + e ligature: the first part looks like a',0.70],['œ','o','o + e ligature: the first part looks like o',0.70],['ɶ','o','small-capital o + e ligature: the first part looks like o',0.68],
 ['ɮ','l','lezh, an l + ezh ligature: the first part looks like l',0.70],['ɧ','h','hooked heng, an h + eng ligature: the first part looks like h',0.68],
 ['ɺ','l','l joined to a fishhook r: the first part looks like l',0.68],['ʪ','l','l + s ligature: the first part looks like l',0.70],['ʫ','l','l + z ligature: the first part looks like l',0.70],
 ['ʩ','f','f + eng ligature: the first part looks like f',0.70],['𝼀','f','feng with a trill: the first part looks like f',0.66],['ꞎ','l','l with a retroflex hook and a belt',0.70],['ꬸ','l','l with a double middle tilde',0.70],
 ['𝼅','l','lezh with a retroflex hook: the first part looks like l',0.68],['𝼄','L','small capital l with a belt',0.70],['𝼁','g','reversed script g',0.68],['𝼂','G','small capital turned g',0.66],
 ['ɠ','g','g with a hook',0.76],['ʄ','j','dotless barred j with a hook',0.72],['ʛ','G','small capital g with a hook',0.74],['ʋ','v','v with a hook',0.78],['ɻ','r','turned r with a retroflex hook',0.70],
 ['ʐ','z','z with a retroflex hook',0.78],['ᶑ','d','d with a hook and a tail',0.72],['ʡ','?','glottal stop with a bar',0.72],['ɚ','e','schwa with a rhotic hook: the first part (ə) looks like e',0.70],
 ['ɝ','3','reversed epsilon with a rhotic hook: the first part (ɜ) looks like 3',0.70],['ɷ','u','closed omega (withdrawn): looks like u',0.60],
];
for(const [s,k,why,sc] of LET){ const i=first(s); if(i>=0) row(k,i,'first',sc>=0.74?'medium':'low',sc,why) }

/* ---------- 4. every other sequence that starts with a letter that has a key ---------- */
const S1=sym2keys();
D.entries.forEach((e,i)=>{
  if(!/^unmatched/.test(D.vis[e[5]])) return;
  const c=D.cats[e[2]]; if(!/^(diacritic-sequence|extipa-sequence|iast-variant|affricate-sequence)$/.test(c)) return;
  const f=Array.from(e[0])[0]; if(/^\p{M}$/u.test(f)) return;
  const ks=/^[\x21-\x7e]$/.test(f)?[f]:[...(S0[f]||[])]; if(!ks.length) return;
  for(const k of ks) row(k,i,'first','low',0.68,`starts with ${f}: ${e[3]}`);
});

/* ---------- housekeeping ---------- */
D.generated=new Date().toISOString().slice(0,10); D.version='2';
const body={...D}; delete body.hash;
D.hash=crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex').slice(0,16);
fs.writeFileSync(file,'window.SKPH='+JSON.stringify(D)+';\n');
console.log('entries',D.entries.length,'rows added',rows,'hash',D.hash);
