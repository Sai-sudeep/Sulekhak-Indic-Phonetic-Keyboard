#!/bin/bash
# Double-click this file. It builds the keyboard and replaces the version you have installed.
cd "$(dirname "$0")"
if ! xcode-select -p >/dev/null 2>&1; then
  echo "The Command Line Tools are needed once. Finish the install in the window that appears, then double-click this file again."
  xcode-select --install
  read -n 1 -s -r -p "Press any key to close"; exit 0
fi
if bash build.sh; then
  echo; echo "All done."
else
  echo; echo "Something went wrong (see the lines above). Copy them and send them to the developer."
fi
read -n 1 -s -r -p "Press any key to close"
