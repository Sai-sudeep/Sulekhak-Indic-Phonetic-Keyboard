#!/bin/bash
# Double-click this file. It builds the keyboard and replaces the version you have installed (no need to remove the old one first).
cd "$(dirname "$0")"
if ! xcode-select -p >/dev/null 2>&1; then
  echo "The Command Line Tools are needed once. Finish the install in the window that appears, then double-click this file again."
  xcode-select --install
  read -n 1 -s -r -p "Press any key to close"; exit 0
fi
if [ -s google-client.json ]; then echo "Personal build: Google sign-in and learning sync are included."; else echo "Public build: English and local learning, no sign-in."; fi
if bash build.sh; then
  echo
  echo "All done. In the menu-bar input menu choose Sulekhak, then:"
  echo "  Ctrl+Option+8  English typing   (Space takes the first suggestion, Tab picks another, Esc keeps what you typed)"
  echo "  Ctrl+Option+1  Odia,  2 Devanagari,  3 Bangla,  6 Assamese,  7 IPA"
  echo "  Sign in with Google:  the input menu > 'Sign in with Google to sync what you learn…'"
else
  echo; echo "Something went wrong (see the lines above). Copy them and send them to the developer."
fi
read -n 1 -s -r -p "Press any key to close"
