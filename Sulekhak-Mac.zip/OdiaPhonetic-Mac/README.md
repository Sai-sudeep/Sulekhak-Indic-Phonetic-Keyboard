# Sulekhak (ସୁलेখk, formerly Lekhani): Phonetic Keyboard for macOS (English to Odia, Devanagari, Assamese, Bangla and IPA)

## New in 3.4: English language model
- **Next-word and in-word prediction for English** now use a language model trained on about 165 million words of ordinary text (Wikipedia, Simple English Wikipedia, web text, Tatoeba, Common Voice sentences, NLTK corpora, Wiktionary examples), with a trigram table next to the bigram table. The word list is unchanged: nothing was removed or replaced, the model only adds counts.
- On held-out text, the right next word is among the top 3 about 30.5% of the time with two words of context (was 23.0%), and after typing two letters the right word is among the top 3 about 43.7% of the time (was 33.6%).
- The engine remembers the last two committed words, so hosts that pass one word still get two-word context.

## New in 3.2 (model): the best statistical model, shipped inside this folder
- **Language model:** the weighted lexicon built from IndicCorp2 and Sangraha (cleaned spellings, ZWNJ rules applied, dotted acronyms), plus a **trigram** word-sequence model (bigram and trigram tables) instead of the old bigram table. On held-out typing tests it finds the right word in the first three choices after two typed letters 50.2% of the time against 38.8% for the old model (news test set; scoreboard v5 in Statistical_Pipeline/scoreboard).
- **Roman aliases:** what people really type is understood without changing the canonical keys: khy kkh ksy → ksh (କ୍ଷ), jny gny dny jn gn → gy (ଜ୍ଞ), s → sh (ସନ୍ଧ, ଷଣ୍ଢ), ng / n before s h → m (ଂ), y → j, ru → ri, c → ch, sr → shr.
- **Spelling rules on every word the model makes:** impossible clusters are dropped and the ZWNJ rule (halant + ବ / ଵ, ଗ୍‌ଦ) is applied (`parikhya` → ପରୀକ୍ଷା first).
- **Next-word choices** come from the trigram table (the two words before the cursor when known).
- **No download:** the data is in `sulekhak/` (the big files gzipped); `build.sh` unpacks it into the app. The first load runs in the background (about 10 to 30 seconds after login, about 600 MB of memory); until it is ready the built-in rule engine works alone, as before.
- `node tools/model_check.js` loads the same files the app loads and prints sample suggestions and load time.

## New in 3.2 (October 2026 key mappings; the symbol lists for `|` and `*` are for PC keyboards: Mac app, Windows and the web typist)
- **d / dh:** `d` gives ଦ, then ଡ, ଡ଼ (ଡ with nukta) and ଡ଼ (the single letter U+0B5C); `dh` gives ଧ, then ଢ, ଢ଼ (with nukta) and ଢ଼ (U+0B5D).
- **y / w:** `y` gives ୟ first and ଯ later (the y rule: ୟ is the y-sound, ଯ the j-sound; `j` gives ଜ first and ଯ later). `w` gives ୱ only (never ଵ).
- **v / V:** ଵ first where it is valid, then ଭ, then ବ, then ୱ. A candidate the strict word check rules out is dropped, so the order can differ per word.
- **s / S / sh / Sh:** `s` and `S` offer ସ, ଶ and ଷ; `sh` and `Sh` give ଷ first and ଶ next.
- **ksh, Ksh, x, X, khy, khya:** କ୍ଷ.
- **ru:** ରୁ, ଋ, ୠ, ◌ୃ, ◌ୄ, ରୂ (after a consonant: ୃ, ରୁ, ରୂ, ୄ).
- **Vowels:** `e` / `E` give ଏ and େ; `ai` / `Ai` give ଐ and ୈ; `o` gives ଓ and ୋ; `au` / `ou` give ଔ and ୌ.
- **`|` (shift + backslash)** opens a list: ।, |, \ . **`.`** still gives ।, `.`, ॥.
- **`*` (shift + 8) opens a symbol list** on PC keyboards (Mac app, Windows and the web typist; not on Android, iPhone or iPad, which have their own shift-number rows): `*` first, then the Odia signs that no letter key gives:

| Pick | Sign | Name |
|---|---|---|
| 1 | * | the star itself |
| 2 | ଽ | avagraha (U+0B3D) |
| 3 | ୰ | Isshar (U+0B70) |
| 4 | ୲ | fraction sign one quarter (U+0B72) |
| 5 | ୳ | fraction sign one half (U+0B73) |
| 6 | ୴ | fraction sign three quarters (U+0B74) |
| 7 | ୵ | fraction sign one sixteenth (U+0B75) |
| 8 | ୶ | fraction sign one eighth (U+0B76) |
| 9 | ୷ | fraction sign three sixteenths (U+0B77) |
| next page | ୕ | sign overline (U+0B55) |

  Press 1 to 9 to pick; Space or Enter takes the highlighted one.
- The C and JavaScript engines pass 198 expectations (`tools/regress.sh`). The Objective-C changes in `OdiaController.m` and the C# changes in the Windows `App.cs` were written but not compiled in the session that wrote them; the GitHub build compiles them.

## New in 3.1 (candidate rules, same in every app)
- **Two candidate rules, the same in every Sulekhak app** (Mac engine.c and engine.js, the phone keyboard, Windows and the web typist share them): (1) **strict ବ / ଵ rule:** a halant followed by ବ is joined only after ର, ମ or ବ (ସର୍ବ, ଅମ୍ବର, ଅବ୍ବ); a halant followed by ଵ is joined only after ର (ର୍ଵ); in every other place a ZWNJ goes between (ସ୍‌ବାଧୀନ, ଉଦ୍‌ବେଗ, ସ୍‌ଵ, ମ୍‌ଵ). The un-ZWNJ'd spelling is never a candidate: it is converted and, if that makes a duplicate, dropped. This holds for every candidate list and for the word that is typed in: rule-engine, dictionary and predicted words, z / Z words (including the "same without ZWNJ" choice), words you picked before, next-word choices and swipe words, in Odia output only (Devanagari, Bangla and Assamese are not touched). ୱ (U+0B71) is not part of this rule; (2) a ଡ or ଢ in the middle or at the end of a word is offered with the nukta first (କୁଆଡ଼େ, ବଡ଼ି), and the plain spelling follows after all the nukta ones; a word-initial ଡ/ଢ and a ଡ/ଢ in a conjunct stay plain. The text you typed and a word you picked before are never rewritten.
- **Phonetic (IPA) keyboard: affricates and every sequence listed under the key its first part looks like.** The ligature letters ʦ ʣ ʧ ʤ ʨ ʥ and the tie-bar forms t͡s d͡z t͡ʃ d͡ʒ t͡ɕ d͡ʑ ʈ͡ʂ ɖ͡ʐ p͡f b͡v t͡θ t̪͡θ d͡ð d̪͡ð t͡ɬ d͡ɮ c͡ç ɟ͡ʝ k͡x ɡ͡ɣ q͡χ ɢ͡ʁ k͡p ɡ͡b ŋ͡m (and p̪͡f, b̪͡v) are in the choice list of t, d, p, b, k, g, c, j, q, G or n: ʦ and t͡s both under t. Each affricate comes in four forms, strongest first: the ligature letter (where one exists), the tie bar above (U+0361), the tie bar below (U+035C) and the untied digraph. The same first-part rule lists the release and prenasalized sequences (tˢ dᶻ tᶴ ᵐb ⁿd ᵑɡ ...), the ligature letters (æ œ ɶ ɮ ʪ ʫ ʩ ...), and every diacritic or extIPA sequence that starts with a keyed letter (l̪ bʱ ɑ̃ r̥ t̚ ...). 174 symbols (tone letters, bare diacritics, and letters like ʃ ɛ ʒ whose shape matches no key) stay in the "No keyboard match" list and the Help inventory. The data is `html/phon-data.js`, made from `tools/phon-data.base.js` by `node tools/phon_augment.js html/phon-data.js tools/phon-data.base.js`.
- **Strict word check, the same in every Sulekhak app (Mac, Android, Windows, web, iPad/iPhone): no candidate that breaks a spelling rule is ever offered, from any source** (rule engine, dictionary, predicted, next-word, learned and swipe words). Odia output only. A spelling is dropped when: (1) the impossible-spelling filter rejects it (matra, halant, nukta, ZWNJ / ZWJ, nasal and sibilant conjunct rules); (2) it holds a conjunct on the forbidden list, a halant joining two letters that Odia never joins (ଣ୍ପ, ନ୍ବ, ସ୍ଚ, ଶ୍ଟ, ଶ୍ତ, ଷ୍ତ, ଶ୍କ, ଲ୍କ, ଟ୍କ and so on, also କ୍ଷ୍X, Y୍କ୍ଷ, ର୍‍ର with ZWJ, ଂଞ and ଁଞ; the list is `src/forbid.inc` / `strict_data.json`); a ZWNJ between the two letters makes them separate letters, so that is fine; (3) a conjunct has more than four consonants, or is not one that real words contain (the corpus table, `src/clus.inc`). The conjuncts ଳ୍ପ, ଳ୍କ, କ୍ଷ୍ମ, ଙ୍କ୍ଷ, ତ୍କ୍ଷ and ଷ୍ଫ are on the list you wrote but are left allowed because common words need them (ଅଳ୍ପ, ଶୁଳ୍କ, ଲକ୍ଷ୍ମୀ, ଆକାଙ୍କ୍ଷା, ତତ୍କ୍ଷଣ, ନିଷ୍ଫଳ). Not checked: the text you typed (it stays choice 2), a word with no consonant (a lone sign or halant key), words you added to the Sulekhak Dictionary on purpose, and the ZWNJ / ZWJ spellings of a z / Z word (they skip rule 1 only). Devanagari, Bangla and Assamese are not touched.
- **The "ru" cluster after a consonant** is listed as ୃ first, then ୍ରୁ, then ୍ରୂ (kru: କୃ, କ୍ରୁ, କ୍ରୂ; druta: ଦୃତ, ଦ୍ରୁତ, ଦ୍ରୂତ), with the ZWNJ spellings after them. It only moves candidates that are already offered, and the typed text stays choice 2.
- Not tested on a physical Mac: the C and JavaScript engines pass 198 expectations; the new Objective-C merge step in `OdiaController.m` (PostRules) was written but not compiled here.

## New in 3.0 (v17)
- **Separate keyboards and DMGs.** `bash build.sh` still builds the all-in-one. `bash build.sh odia` (also `devanagari`, `assamese`, `bangla`, `phonetic`) builds a keyboard that writes one language only, with its own name and identity, so it can sit beside the others. `bash build.sh all --dmg` or `bash build.sh everything --dmg` makes `dist/Sulekhak-<language>-<version>.dmg` (the keyboard, an Install file and an Uninstall file). GitHub also builds all six DMGs for the Releases page.
- **Hover to see on the Phonetic keyboard.** Point at a key on the 3D keyboard: a ring of bevelled tiles opens around it, one for each look-alike IPA, extIPA or IAST symbol, strongest at the top, then clockwise (green / yellow / orange light = strong / medium / weak). Click a tile to type it. The keyboard window never takes the keyboard focus, so the app now follows the pointer itself and passes it to the page.
- **sulekhak-learn.json.** Everything you pick (how often, first and last time, script), your next-word pairs and your own dictionary are kept in `~/Library/Application Support/LekhaniOdia/sulekhak-learn.json` (see `docs/learning-cache-format.md`). It is written a moment after each change, merged with outside edits every 20 seconds, and written again on quit. The old `history.tsv` is folded in the first time (kept as `history.tsv.migrated`); `lexicon.tsv` still works and each line becomes a dictionary entry. `tools/learn_merge.py` converts to and from the plain lists and merges two files. The web typist has **Import learning file** / **Export learning file**.
- **Add to Sulekhak Dictionary.** Select a word or expression (Odia, Devanagari, Bangla or Assamese; it is stored as Odia) and use any of: the small **+** beside a mouse selection (needs the Accessibility permission), **Control+Option+D**, the input-menu item, the **+ Dict** button on the 3D keyboard, or right-click → Services → *Add to Sulekhak Dictionary* (installed to `~/Library/Services` by the build; if it is missing switch it on in System Settings → Keyboard → Keyboard Shortcuts → Services). A box shows the word and a guessed Roman spelling (checked against the engine); edit it and add. An expression is typed as one block of letters (`iitdelhi`). Dictionary words are never filtered out as impossible spellings.
- Not tested on a physical Mac: the Objective-C was written and syntax-checked here, the C and JavaScript engines were run (119 expectations pass), the 3D ring and the web import were tested in a browser.

## New in 2.8
- **Z words, Mac fix.** Words with `z` (for example `baagZdebii`) now keep the ZWNJ spelling first, your typed text second, the same without ZWNJ third and the same with ZWJ fourth, even when the Sulekhak smart suggestion is on. Before, the smart suggestion pushed the order around in the candidate box. (Changed in `src/OdiaController.m`; rebuild with Build and Install.command.)
- **khy gives କ୍ଷ** (first choice), with ଖ୍ୟ as the second. Common ଖ୍ୟ words (ମୁଖ୍ୟ, ମୁଖ୍ୟମନ୍ତ୍ରୀ, ଖ୍ୟାତି, ପ୍ରଖ୍ୟାତ, ବ୍ୟାଖ୍ୟା, ଲିଖ୍ୟ, ...) are in the built-in list, so they still come out right. The same change is in the web typist and in the shared engine for Windows and Android.

## New in 2.7 (v16)
- **Stricter touch:** sliding the suggestion strip, the choice window or the keyboard never picks a word or fires a key. A tap counts only when your finger goes down and up on the same key, stays still and is quick; a drag or a flick scrolls instead, and nothing next to the key is ever pressed.
- **Better suggestion strip:** it scrolls sideways only, with a soft fade at the edge where more words wait.
- **Thin black borders** on keys and suggestion chips on the web and phone keyboards.
- The ZWNJ spelling (ବାଗ୍‌ଦେବୀ) is always listed ahead of the spelling without it.
- Not tested on a physical Mac, Windows PC or phone: the touch logic was tested in a simulated touch browser only.

## New in 2.6 (v16)
- **ZWJ on the z key** in every keyboard: `z` offers ZWNJ and ZWJ (hold `z` on the phone keyboards and the key guide), and the web, Mac and Windows on-screen keyboards show "ZWJ" on it. `Z` offers halant + ZWNJ, halant, and halant + ZWJ.
- **Choice labels that explain themselves:** halant + ZWNJ is shown as ୍ + ┊, halant + ZWJ as ୍ + [, a plain halant as just ୍.
- **Z order:** the ZWNJ spelling, what you typed, the same without ZWNJ, the same with ZWJ, then everything else.
- **New words (both spellings valid):** ବାଙ୍‌ମୟ / ବାଙ୍ମୟ, ତତ୍‌ସମ / ତତ୍ସମ, ତଦ୍‌ଭବ / ତଦ୍ଭବ.
- **The on-screen keyboard now follows the language:** its key letters change for Odia, Devanagari, Assamese, Bangla and Phonetic.
- **Assamese only:** a ৎ spelling is offered beside every ত্ (`jagat` → জগত · জগৎ); `byavahar` gives ব্যৱহাৰ.
- **Your typed letters are always choice 2** in every language.
- Not tested on a physical Mac or Windows PC: the Objective-C and C# changes were written and reviewed, and the C engine and JavaScript engine were tested here. Run Build and Install.command again to update.

## New in 2.5 (v16)
- **New name: Sulekhak.** The app, the web tool (`sulekhak.html`; the old `sulekhak.html` link redirects), the Android and Windows apps and the repository all use the name Sulekhak. The Mac app keeps the same identity, so it still installs as an update and keeps your settings and your own words.
- **Phonetic (IPA) mode on Mac, Windows and Android's shared engine.** Press **Ctrl+Option+7** on the Mac (or choose it in the input menu), **Ctrl+Alt+P** on Windows. Type a key and the symbols that look like it (IPA, extIPA, IAST) appear as choices; Tab swaps, 1-9 picks.
- **Hold and drag the space bar to move the cursor** on the web phone keyboard, left or right. Candidates are committed first, so a candidate is never changed by moving the cursor. The left and right arrow keys are gone from the phone keyboard.
- **Punctuation on long press:** hold the full stop key for ? ! , ; : " ' ( ) - and more, including the danda । and double danda ॥.
- **Symbols and emoji page:** the key at the bottom left of the web phone keyboard opens a page of punctuation, currency, maths, arrows, Odia and Indic symbols, and emoji.
- **Candidate list always on top:** nothing is drawn over the candidate window on the web tool.
- **Z choices in order:** a word typed with Z lists the ZWNJ spelling first, then what you typed, then the same word without the ZWNJ, then everything else. ବାଗ୍‌ଦେବୀ, ଦିଗ୍‌ଦର୍ଶନ, ବାକ୍‌ଶକ୍ତି, ଋଗ୍‌ବେଦ, ଜଗଦ୍‌ଜନନୀ, ଦିଗ୍‌ବିଜୟ, ଉଦ୍‌ବେଗ and ଉଦ୍‌ବିଗ୍ନ are built-in words. The hint rows now list Z, z, ` in that order.
- Not tested on physical devices: the Mac phonetic mode and the Windows phonetic mode were written and reviewed but could not be compiled and run in the build environment. Run Build and Install.command again; if it misbehaves, the build.sh output and Console.app messages are the first places to look.

## New in 2.4 (v16)
- **Suggested next words.** After you finish a word and press Space, a strip of likely next words appears (from the same word-to-word statistics as the smart candidates). Tap or click one to insert it; keep typing and the strip disappears. Where it shows:
  - **Mac with a Touch Bar:** a strip of suggested words on the Touch Bar while the Odia keyboard is active. Input menu, "Touch Bar: suggested words" switches it on or off. The Touch Bar part uses a private macOS call; on a Mac without a Touch Bar, or if macOS refuses it, it simply does nothing.
  - **3D on-screen keyboard (Mac, Windows, web):** a strip of suggestions sits at the top of the keyboard, above the keys. Tapping a word types it.
  - **Web tool (`sulekhak.html`):** the same strip above the 3D key guide and above the phone keyboard.
  - **Windows and Android:** the Windows tray keyboard and the Android keyboard show next-word suggestions after a space.
- **Rare Odia letters by typing:** `rrii` or `rrI` gives ୠ and the sign ୄ, `lrri` ଌ and ୢ, `lrrii` or `lrrI` ୡ and ୣ, two apostrophes ଽ, three apostrophes ୰, `AIL` ୖ, `AUL` ୗ.
- **Hold a key for its extras** (matras, conjuncts, rare letters) on the 3D on-screen keyboard (Mac, Windows, web), on the web phone keyboard and on Android: press and hold a letter, slide to the one you want, release.
- **Conjuncts** checked against the smart engine: ଣ୍ଣ (ବିଷଣ୍ଣ), ର୍ଲ୍ଲ, ଥ୍ର (ଥ୍ରୀ, ଥ୍ରି), ଠ୍ୟ (ପାଠ୍ୟ), ଘ୍ୟ (ଅର୍ଘ୍ୟ), ଲ୍ପ (ଗଲ୍ଫ), ଫ୍ଲ (ଫ୍ଲୋରିଷ୍ଟ). They were already accepted, so no list changes were needed.
- **Ctrl+Option+K now works in every app** (registered as a system hot key, not only while the Odia keyboard has focus). macOS may ask for **Accessibility** permission the first time you tap a key on the on-screen keyboard, because the keys are sent to the app you are typing in.
- **Zoom in / out of the on-screen keyboard** is now done by the app itself (the web view is scaled and the window resized to match) and kept inside your screen. Besides the − and + buttons you can use **Ctrl+Option+=** and **Ctrl+Option+-**, or the input menu items "3D keyboard: bigger / smaller". If it still misbehaves, Console.app lines starting "Sulekhak OSK" show whether the click reached the keyboard and what size was asked for.
- **Cleaner phone layout** (web tool and Android): the on-screen keyboard has no left Tab key any more (Tab sits in the bottom row), larger keys laid out like a normal QWERTY phone keyboard, and the toolbar, writing box, suggestion strip and keyboard each have their own space, with nothing sticking over anything else.
- Not tested on a physical Mac: the Touch Bar strip, the hot key and the zoom fix could only be written and reviewed, not run, in the build environment. If anything misbehaves, the build.sh output and Console.app messages from OdiaPhonetic are the first places to look.

## New in 2.3
- **Sulekhak smart candidates** (Mac keyboard and HTML tool). The first suggestions now come from a language model trained on the cleaned DSAL Praharaj dictionary and the news corpus (word-to-word statistics): word frequency, what usually follows the previous word, a Roman-spelling index (ee/oo, h, v/w/b, f/p, c/k and dropped-a variants), a memory of the words you pick, and a check that pushes impossible Odia consonant clusters to the bottom. Names that are not in the word list are built syllable by syllable (so `elizabeth` or `shobha` still work), using only syllables that exist in real Odia.
- **Typo tolerance:** one swapped, missing, extra or wrong letter (`birdoh`, `sarkra`, `shikhsa`) still finds the word (Damerau edit distance 1, used only when few exact matches exist).
- Slot 1 = best word, slot 2 = your typed text (unchanged), then the other smart candidates, then the original rule-based candidates.
- **Mac:** the engine runs inside JavaScriptCore, loaded in the background the first time you type (about 15 s; until then the built-in engine works alone). Files are in `sulekhak/` and are copied into the app by `build.sh`. To switch it off: `defaults write com.saisudeep.inputmethod.OdiaPhonetic.Odia SulekhakEnabled -bool NO`. Words you pick are remembered in `~/Library/Application Support/LekhaniOdia/sulekhak_commits.txt`.
- **HTML tool:** keep the `sulekhak/` folder next to `sulekhak.html`; the engine runs in a Web Worker. Add `?sk=0` to the address to switch it off.
- New files: `src/SKEngine.m/.h`, `sulekhak/*`, `html/sulekhak.js`, `html/sk_bridge.js`.

## New in 2.2
- **Assamese (অসমীয়া)** sits between Devanagari and Bangla, in the HTML tool and in the Mac input method (input-source menu, or Control+Option+6). It writes the Assamese letters ৰ (r) and ৱ (w or v), so `byavahaar` gives ব্যৱহাৰ, `prakaara` প্ৰকাৰ, `kartabya` কৰ্তব্য. `x` gives স / শ / ষ (the Assamese /x/ sound) and `ksa` gives ক্স. Conjuncts such as ন্ধ, স্ক, ঞ্চ, ঞ্জ, ন্ত্ৰ, ত্ত, ৰ্ত come out as written. Same dictionary, same learned words.
- **OMMNISKRIPT: ଯ = j.** Odia ଯ is read as j (ସଂଯମ = sanjama, ଯମୁନା = jamuna, ଜାଗା = jaga) and ୟ stays strictly y. Going the other way, every Roman j is underlined and offers ଯ or ଜ (a short word list proposes ଯ for common words; your choice is remembered for that word). The ଯ = j button turns the rule off.
- **OMMNISKRIPT:** the "Write in" pad can write Assamese too, and its buttons are bigger on touch screens.
- **Phone, tablet and web layout pass:** the writing box is full width on every screen (it was narrow on tablets and phones), the footer no longer sits over the page, the candidate list is a compact two-column card with big tap targets on touch screens (it flips above the caret when there is no room below), the phone toolbar shows every button with the formatting row behind one **Aa Format** button, and tap targets are at least 40 px on touch.
- **3D key guide drawn as the keyboard you use:** Mac (silver, ⌃ ⌥ ⌘ keys), Windows (black, Win and Alt keys), iPad / iPhone (light with blue keys) and Android (dark). It picks your device automatically; the **Keyboard style** menu in the guide overrides it and is remembered.

## New in 2.1
- **New name and logo:** ସୁलेখk (formerly Lekhani), with a 3D wordmark and a new icon. The app keeps the same identity, so it installs as an update.
- **HTML tool, `sulekhak.html`:** two new "Write in" choices next to Odia, Devanagari and Bangla.
  - **English**: plain English typing with sentence capitals, curly quotes, an automatic capital I and spell-check.
  - **Phonetic**: type a key, then pick or cycle (Tab, Shift+Tab, Esc) through the IPA, extIPA and IAST symbols that *look like* that key, judged from the rendered shapes in eight fonts, never from sound. Hover a key, or long-press it on a phone or iPad, to see everything it can give. A right-hand panel lists the symbols that look like no key (copy, insert, search, filters), and **? Help** opens the full mapping and inventory, generated from the same data. The data is `html/phon-data.js` (hash shown in Help).
- **A realistic mechanical 3D 65% keyboard** in the HTML tool: metal finish, capital letters on the keys, shifted symbols above, hover look-up of what every key types. The guide can be collapsed, detached and moved, pinned to the top or bottom, zoomed, resized from any corner, and switched to a phone layout.
- **OMMNISKRIPT** can open `sulekhak.html` as a "Write in" pad (keep both files in the same folder).
- The Mac input method itself is unchanged in 2.1: the Phonetic and English modes are in the HTML tool.

## New in 2.0
- **Halant moved from `v` to the backtick (`` ` ``).** `v` is now a letter: ବ, and ୱ right after a consonant.
- **Devanagari and Bangla output**, with the same Roman keys, the same dictionary and the same learned words (they are kept in Odia and carried over letter by letter). Choose the script from the input-source menu, or with Control+Option+1 (Odia), 2 (Devanagari), 3 (Bangla), 4 (Devanagari: Marathi ळ on/off), 5 (Devanagari: conjuncts off, anusvara ं, on/off). One Devanagari module covers all three styles: conjuncts (कुण्डल, कुञ्ज), Marathi (कुण्डळ) and conjuncts disabled (कुंडल, कुंज). Bangla: কুণ্ডল, কুঞ্জ.
- **Anusvara before s, sh, h, y, r, l, v, w** is now the second choice: `kansa` gives କନ୍ସ then କଂସ; `kaMsa` types କଂସ at once.
- HTML tool: script switch, a zoomable and collapsible 3D key guide that shows what every key types, and a button that rewrites the text already in the box in the chosen script.
- Tests: `tools/regress.sh` (110 expectations, C and JS) and `tools/conv_check.sh` (the C and JS script converters agree on every dictionary word in all four modes).

A phonetic input method in the style of Google Input Tools / Indic Input. You type Roman letters and get Odia (Unicode).

## Install (replaces the version you have now)
Double-click **Build and Install.command** in this folder. It builds the keyboard, stops the running copy, backs up your words to `~/Documents/Lekhani-backup`, removes the old app and puts the new one in `~/Library/Input Methods/OdiaPhonetic.app`. It keeps the identity `com.saisudeep.inputmethod.OdiaPhonetic` / `.Odia`, so macOS sees an update and the input source you already switched on stays on.
1. If asked, install the Xcode Command Line Tools (once) and double-click the file again.
2. When it says Done: pick another input source in the menu bar and then "ସୁलेখk" again. If it still behaves like the old one, log out and in once.
3. Only if it is missing from the list: System Settings > Keyboard > Text Input > Input Sources > Edit... > + > Odia > ସୁलेখk > Add. If macOS blocks it, allow it in System Settings > Privacy & Security.
(Terminal alternative: `./build.sh`.)

## Typing
| Type | Get |
|---|---|
| `ka kaa ki kii ku kuu ke kai ko kau` | କ କା କି କୀ କୁ କୂ କେ କୈ କୋ କୌ |
| `kh gh ch chh jh Th Dh th dh ph bh` | ଖ ଘ ଚ ଛ ଝ ଠ ଢ ଥ ଧ ଫ ଭ |
| `T D N` retroflex, `sh` / `Sh` / `s` | ଟ ଡ ଣ, ଶ / ଷ / ସ |
| `R` and `Rh` | ଡ଼ (U+0B5C) and ଢ଼ (U+0B5D), single code points |
| `kta`, `karma`, `kshetra` | conjuncts are formed automatically: କ୍ତ, କର୍ମ, କ୍ଷେତ୍ର |
| `z` | ZWNJ only |
| `Z` (Shift+z) | halant + ZWNJ |
| `` ` `` (backtick) | halant only, no ZWNJ (was `v` before v2.0). Shift+backtick is `~`, the chandrabindu |
| `v` | a letter now: ବ, and ୱ right after a consonant (`deva` ଦେବ, `svagat` ସ୍ୱାଗତ) |
| `V` (Shift+v) | ଵ (U+0B35) |
| `>` (Shift+.) | nukta U+0B3C, placed on the consonant before its matra: `baDi>` gives ବଡ଼ି |
| `M` `H` `~` | ଂ ଃ ଁ |
| `.` | opens a list: । danda, . full stop, ॥ double danda |
| `|` | । |
| `'` | separator, e.g. `n'ga` keeps n and g apart |

Only `>` acts immediately when you are not in the middle of a word. `z`, `Z` and the backtick open their own lists:
- `z`: ZWNJ, z, Z
- `Z`: halant+ZWNJ, Z, halant, ZWNJ
- `` ` ``: halant (blue), `, halant+ZWNJ
- `ru`: ରୁ, ru, ରୂ, ଋ, ୠ
- Rare Odia letters and signs (new): `rrii` or `rrI` ୠ and its sign ୄ, `lrri` ଌ and ୢ, `lrrii` or `lrrI` ୡ and ୣ, two apostrophes `''` the avagraha ଽ, three `'''` the Isshar ୰, `AIL` and `AUL` the AI and AU length marks ୖ ୗ. (One apostrophe is still the syllable separator.)

The last two rows of every English-looking list are the Title case (`Ru`) and ALL CAPS (`RU`) versions. The as-typed version stays at number 2.

## Suggestion box
While you type a word a box shows up to nine choices under the cursor:
1. best Odia spelling (a dictionary word if there is one)
2. **what you typed in English, always in position 2**
3. to 9. other spellings and dictionary words

Press the number **1 to 9** to pick that row. Space and Return both pick the highlighted row and add a space (Return with nothing being typed is a new line), Tab / Down / Up move the highlight, Delete removes a letter, Esc cancels.

Numbers: type `1` and the box offers **୧** and **1**. In a number, digits keep building the number, so choose with Tab or the arrow keys and Space (Odia digits are the default).

## More rules in this version
- A lone consonant offers the letter, the letter with halant, and halant + ZWNJ (the ZWNJ choice is shown in deep blue): `k` gives କ, କ୍, କ୍‌.
- A lone vowel also offers its matra on its own: `i` gives ଇ, ି, ୀ.
- A word ending in a vowel + `n`, `ng` or `m` also offers chandrabindu and anusvara: `ken` gives କେନ, କେଁ, କେଂ.
- `ri` also tries the vowel sign ୃ: `krishna` gives କୃଷ୍ଣ.
- After you pick a choice with a number key, a space is added before the next word (not when the choice ends in halant/ZWNJ or is a bare matra, because then the word goes on).
- ISO 15919 letters work too: ā ī ū ṭ ḍ ṇ ś ṣ ṅ ñ ṃ ḥ.

## Your own words
On first run your old words and history are copied over from the old OdiaPhonetic folder. Put lines of `roman<TAB>Odia<TAB>weight` in `~/Library/Application Support/LekhaniOdia/lexicon.tsv` (see lexicon-example.tsv). Words you pick are remembered in `history.tsv` and move up next time. The built-in list is small (about 280 words), so add your own.


## Candidate box
A raised 3D card: a preview header (what you typed, then the marked text), numbered rows, and a hint row with the special keys. Dependent signs show a dotted circle (◌) in front, a lone ZWNJ shows as "ZWNJ", and any choice with ZWNJ, and the bare halant, is in deep blue.

## Sulekhak, the web typist (HTML)
`html/sulekhak.html` (title Sulekhak, subtitle Phonetic Keyboard; the old file names sulekhk.html, odia-lekhani-typist-keyboard.html and lekhani-odia-typist.html are now redirect stubs) runs the same engine in a browser and is a rich-text writing canvas. Regenerate it after engine changes with `python3 src/gen_js.py && python3 html/make_html.py` (template `html/typist.tpl.html`). F1 opens the shortcut sheet, with a filter box; every toolbar button shows its shortcut when you hover it.

The canvas is a custom editor (not the browser's contenteditable), so the Odia cursor moves one character at a time by default (optionally whole letters), Backspace removes one character, and ZWJ, ZWNJ, virama and combining marks are never altered or normalised by copy, paste, undo, save or export.

## Abbreviations (both apps)
Type 2 to 8 English letters (`cid`, `CID`, `iit`). Four extra suggestions are added at the very end of the list: `CID`, `C.I.D.`, `ସି.ଆଇ.ଡି`, `ସିଆଇଡି`. The letter map is fixed: A ଏ, B ବି, C ସି, D ଡି, E ଇ, F ଏଫ୍‌, G ଜି, H ଏଚ୍‌, I ଆଇ, J ଜେ, K କେ, L ଏଲ୍‌, M ଏମ୍‌, N ଏନ୍‌, O ଓ, P ପି, Q କ୍ୟୁ, R ଆର୍‌, S ଏସ୍‌, T ଟି, U ୟୁ, V ଭି, W ଡବ୍ଲ୍ୟୁ, X ଏକ୍ସ, Y ୱାଇ, Z ଜେଡ୍‌. The typed text can also appear earlier in the list, so `CID` may show twice.

## Keyboard shortcuts
The 3D on-screen keyboard (the same one as the web tool, in Mac, Windows, iPad and Android styles) opens from the input menu ("3D keyboard: show / hide") or with Ctrl+Option+K. Ctrl+Option+K is a system-wide hot key: it works in every program, even when no text box is active. **Hold any letter key** to open a list of its letters, matras and common conjuncts (hold K: କ ଖ କ୍ଷ କ୍ତ କ୍ର ...; hold R: ର ଋ ୃ ୠ ୄ ର୍ମ ...; hold L: ଲ ଳ ଌ ୢ ୡ ୣ ...); slide to one and let go to type it. The + and − buttons zoom the keyboard (the window grows around its middle and stays on the screen). Clicking its keys types through the input method; the first time, macOS asks for the Accessibility permission, which it needs to accept key presses from the on-screen keyboard.

In the Mac input method, a shortcut that holds Cmd, Ctrl or Option takes the highlighted suggestion and then passes the key to the app you are typing in, so the app's own shortcuts keep working.

In the HTML app the same table is in the F1 sheet. The writing canvas (Ctrl on Windows and Linux, Cmd on Mac unless the Mac column says otherwise):

| Feature | Windows / Linux | Mac |
|---|---|---|
| Bold, Italic, Underline | Ctrl+B, Ctrl+I, Ctrl+U | Cmd+B, Cmd+I, Cmd+U |
| Strikethrough | Ctrl+Shift+X | Cmd+Shift+X |
| Superscript, Subscript | Ctrl+. , Ctrl+, | Control+. , Control+, |
| Text colour, Highlight (palette opens, arrow keys and Enter pick) | Alt+Shift+T, Alt+Shift+H | Option+Shift+T, Option+Shift+H |
| Font family (Default, Serif, Mono) | Alt+Shift+F | Option+Shift+F |
| Font size larger, smaller | Ctrl+Shift+. , Ctrl+Shift+, | Cmd+Shift+. , Cmd+Shift+, |
| Headings 1 to 3, Normal text, Quote | Ctrl+Alt+1, 2, 3, 0, 4 | Cmd+Option+1, 2, 3, 0, 4 |
| Align left, centre, right, justify | Ctrl+Shift+L, E, R, J | Cmd+Shift+L, E, R, J |
| Bulleted, numbered list, checklist | Ctrl+Shift+8, 7, 9 | Cmd+Shift+8, 7, 9 |
| Tick or untick a checklist item (or click its box) | Ctrl+Enter | Cmd+Return |
| Indent, outdent (Tab and Shift+Tab inside lists) | Ctrl+] , Ctrl+[ | Cmd+] , Cmd+[ |
| Line spacing (cycles Default, 1.5, 2.4, 3.0; the toolbar button offers a menu) | Ctrl+Alt+L | Cmd+Option+L |
| Link (Ctrl or Cmd + click opens it) | Ctrl+K | Cmd+K |
| Clear formatting | Ctrl+\ | Cmd+\ |
| Undo, redo | Ctrl+Z, Ctrl+Y or Ctrl+Shift+Z | Cmd+Z, Cmd+Shift+Z |
| Cut, copy, paste with formatting (HTML and plain text both go on the clipboard) | Ctrl+X, C, V | Cmd+X, C, V |
| Paste without formatting | Ctrl+Shift+V | Cmd+Shift+V |
| Copy as plain text, copy as HTML code | Alt+Shift+P, Alt+Shift+Y | Option+Shift+P, Option+Shift+Y |
| Select all | Ctrl+A | Cmd+A |
| Clear all text from the canvas (Undo brings it back) | Alt+Shift+Backspace | Option+Shift+Delete |
| Find and replace (replacement keeps the formatting of the text it replaces) | Ctrl+F or Ctrl+H | Cmd+F |
| Move selected text by dragging (hold Alt or Ctrl to copy) | mouse | mouse |
| New document, Documents (open, recent), Duplicate | Alt+Shift+N, Alt+Shift+O, Alt+Shift+D | Option+Shift+N, O, D |
| Revision history, save a revision now | Alt+Shift+R, Ctrl+S | Option+Shift+R, Cmd+S |
| Export menu (txt, html, PDF), Print, Open a file | Alt+Shift+E, Ctrl+P, Ctrl+O | Option+Shift+E, Cmd+P, Cmd+O |
| Full-screen writing mode | Alt+Shift+Z | Option+Shift+Z |
| Light, dark, auto theme | Alt+Shift+L | Option+Shift+L |
| Editor width narrower, wider | Alt+Shift+[ , Alt+Shift+] | Option+Shift+[ , ] |
| Editor text size | Ctrl + / - / 0, Ctrl+wheel | Cmd + / - / 0, Cmd+wheel |
| Move into the toolbar (arrows move, Esc returns) | Alt+F10 | Option+F10 |
| Shortcut sheet | F1 or Ctrl+/ | F1 or Cmd+/ |

Typing shortcuts: a line that starts with `-` or `*` and a space becomes a bullet, `#` `##` `###` and a space make headings, `[]` and a space a checklist item (Undo takes it back). Enter in an empty list item ends the list. Enter at the end of a heading starts a normal paragraph and keeps bold or colour you had on.

Cursor movement and deleting are as before:

| Action | Windows | Mac |
|---|---|---|
| Letter left/right | Left/Right | Left/Right |
| Word left/right | Ctrl+Left/Right | Option+Left/Right |
| Line start/end | Home/End | Cmd+Left/Right, Ctrl+A/E, Home/End |
| Line up/down | Up/Down | Up/Down, Ctrl+P/N |
| Paragraph start/end | Ctrl+Up/Down | Option+Up/Down |
| Document start/end | Ctrl+Home/End | Cmd+Up/Down |
| Screen up/down | Page Up/Down | Page Up/Down |
| Select | add Shift to any move | add Shift to any move |
| Delete word back/forward | Ctrl+Backspace/Delete | Option+Backspace/Delete |
| Delete to line start | | Cmd+Backspace |
| Delete to paragraph end, swap letters, open line | | Ctrl+K, Ctrl+T, Ctrl+O |
| Move paragraph up/down | Alt+Shift+Up/Down | Ctrl+Cmd+Up/Down |
| Change case (English) | Shift+F3 | Shift+F3 |
| Overwrite mode | Insert | click INS in the status line |

Double click selects a word, triple click a paragraph (Ctrl/Cmd+A selects everything). Hover or keyboard-focus any button to see what it does and its shortcut. Esc then Tab leaves the box.

### What is in the canvas
- **Formatting**: bold, italic, underline, strikethrough, superscript, subscript, text colour, highlight, font family (Default, Serif, Mono), font size, link, clear formatting. Typing right after a toggle, and Enter, carry the format on.
- **Paragraphs**: Normal, Heading 1 to 3, Quote, alignment, bullet / numbered (1. a. i.) / checklist with nesting to six levels, indent, line spacing.
- **Documents**: every document saves itself in this browser a moment after you stop typing and is a draft until you export it. The Documents window lists them with the newest first (that is the recent list), and opens, duplicates, deletes (asks twice). Revision history keeps up to 25 versions per document (yours with Save a revision, and automatic ones every few minutes), restores any of them, and Undo takes a restore back.
- **Clipboard**: copy puts formatted HTML and plain text on the clipboard; paste reads HTML from Word, Google Docs, web pages and ସୁलेখk itself (losslessly) and falls back to plain text. Pasting a web address over selected text makes a link.
- **Export**: plain text (lists keep their marks), standalone HTML, PDF through Print then Save as PDF (the print layout carries only the document). Open a .txt or .html file as a new document.
- **View**: light, dark or auto; Narrow, Medium, Wide editor; text size; full-screen writing mode (the toolbar fades until the pointer or keyboard goes near it); Documents, counts and Saved time in the status line (words, letters, characters, paragraphs, line, column, selection, INS/OVR, zoom).
- **Phone**: the toolbar scrolls sideways and stays on screen; the on-screen ସୁलेখk keyboard and the phone keyboard option work as before. Dragging selected text is mouse only.
- **Accessibility**: the box is a labelled multi-line text box, the toolbar is a real toolbar (Alt+F10, arrows, Esc), buttons report on/off state, headings are announced, the suggestion list is a listbox that announces the highlighted choice, and changes such as Bold on, Centred, Saved are announced politely.
- **Not included on purpose**: images, tables, comments, spell-check. Browsers keep a few key combinations for themselves (for example Ctrl+Shift+N, Ctrl+W); if one is taken, the toolbar button does the same thing.


## Word list for predictive text
See `../Lekhani_Wordlist/README.md` (words, Roman typing variants, index). It is not loaded into the input method, because the engine scans its lexicon linearly and a list of more than a million entries would make typing lag; a prefix index is needed first.

## Prototype 3: vowels, nasals, suffixes, pages
- **Vowel pairs.** `ai`, `au`, `ou` are read both as one vowel (ଐ ଔ) and as two (a+i, a+u, o+u). Every `a` can be ା or silent, `i` ି/ୀ, `u` ୁ/ୂ, and after a vowel the second letter is a full vowel: `khaibaku` gives ଖୈବକୁ, ଖାଇବକୁ, ଖାଇବାକୁ, ଖଈବାକୁ and so on. Cheapest combinations come first.
- **Fixed long vowels.** `aa` `A` `AA` give only ଆ. `ii` `I` `ee` `EE` give only ଈ. `uu` `U` `oo` `OO` give only ଊ.
- **Nasals follow the next consonant.** `n` before k kh g gh is ଙ, before c ch j jh ଞ, before T Th D Dh ଣ, before t th d dh ନ, and the other nasals and anusvara follow as alternatives: `anka` ଅଙ୍କ, `panchami` ପଞ୍ଚମି, `kanTa` କଣ୍ଟ, `kanta` କନ୍ତ. `m` gives ମ then anusvara. `cch` gives ଚ୍ଛ.
- **Suffix + halant + ZWNJ.** If the word ends in ଟି ଟିଏ ଟା ମାନେ କୁ ରୁ ର ରେ ଠାରୁ ପାଇଁ ଟିକୁ ମାନଙ୍କ… and the stem ends in a consonant, one more choice has stem + halant + ZWNJ + suffix: `gharaku` gives ଘରକୁ and ଘର୍‌କୁ. Stems ending in a vowel are left alone.
- **Pages.** The list can now be long. Page 1 has 7 Odia choices, then Title case and ALL CAPS English in slots 8 and 9. Left / Right arrow (or Page Up / Page Down) change page; Up / Down / Tab keep moving through everything. The number keys pick from the page you see. The header shows the page, for example 2/3.

## Prototype 4: word list, word splitting, consistent letters
- **Known words.** src/words.inc (made by tools/gen_words.py) holds about 4,000 Odia word forms: nouns with case endings, verbs with tense endings, pronouns, particles. Only the Odia spelling is stored. Every way of reading what you typed is generated, and a reading that is a known word goes first, so `khaibaku` gives ଖାଇବାକୁ and `mandirare` gives ମନ୍ଦିରରେ. Words you pick or add join the list. Please review and extend the list.
- **Word splitting.** If the whole thing is not a word but splits into known words, you get the joined form first and the spaced form third: `delenahin` gives ଦେଲେନାହିଁ, delenahin, ଦେଲେ ନାହିଁ.
- **Suffix + ZWNJ first when the suffix would glue on.** For an unknown word where the suffix's first letter would form a conjunct with the stem, the ZWNJ spelling is first: `basre` gives ବସ୍‌ରେ. The bare suffix ର is excluded because -tra and -dra words are common conjuncts. Known words such as ଚିତ୍ର keep their normal spelling first.
- **Letters must agree.** ଙ ଞ ଣ can only stand before a consonant of their own class, so `kanta` is କନ୍ତ, କନ୍ତା, କାନ୍ତ, କାନ୍ତା, କଣ୍ଟ, କଣ୍ଟା and never କାଣ୍ତା. Unusual pairs of sibilant + stop (ଷ୍ତ, ସ୍ଟ, ଶ୍ତ) are pushed down. y after a vowel is ୟ.
- **Order among equal readings.** Changes at the end of the word come before changes at the start, and t th d dh read as retroflex last.

## Prototype 5: consistency audit
- tools/audit: 4,000 random Roman words are run through the engine and every candidate on page 1 is checked for impossible Odia (ଙ ଞ ଣ before the wrong class, ନ or ମ before a wrong class, ଷ/ଶ/ସ before the wrong class, stray signs, halant or matra in the wrong place, ଣ ଙ ଞ ଳ ୟ at the start of a word). The remaining hits are loanword spellings (ସ୍ଟ) and dictionary words such as କାହିଁକି.
- Nasal letters must now match the consonant after them: `kantaa` gives କନ୍ତା, କାନ୍ତା, କଣ୍ଟା and never କାଣ୍ତା. ନ before a labial is allowed (ଅନ୍ବେଷଣ). m before k ch T t is anusvara (`samkhya` gives ସଂଖ୍ୟା).
- y is ୟ after a vowel and in a conjunct (ସତ୍ୟ ଭୟ ସଂଖ୍ୟା); ଯ only starts a word. `ny` is ନ୍ୟ first (`anyatra` ଅନ୍ୟତ୍ର), ଞ second.
- The ZWNJ-first rule for suffixes skips ordinary conjuncts (ଣ୍ଟ ନ୍ତ ଙ୍କ ସ୍କ ଷ୍ଟ ର୍କ), so `kanTaa` stays କଣ୍ଟା.
- Word splitting needs at least 6 letters and pieces of at least 3 letters, so short words are not cut into particles.

## Prototype 6: impossible spellings are never offered or learned
- A spelling check (valid_odia in engine.c, validOdia in engine.js) now runs on every Odia candidate, every learned pick, your lexicon.tsv and history.tsv lines, and the built-in lists. It rejects: ଙ ଞ ଣ before the wrong class of consonant (କାଣ୍ତା), ନ or ମ before a wrong class (ନ୍କ ମ୍ତ), ଷ before dental/palatal, ସ before palatal, ଶ before retroflex/dental, a matra or halant in the wrong place, ଣ ଙ ଞ ଳ ୟ at the start of a word.
- Why କାଣ୍ତା stayed first: a choice you once picked is stored as a learned word for that Roman spelling, and learned words go first. Old bad picks in history.tsv are now ignored on load (the lines stay in the file and do no harm).
- t th d dh are dental (ତ ଥ ଦ ଧ); T Th D Dh are retroflex (ଟ ଠ ଡ ଢ). n before a dental is ନ, before a retroflex ଣ.

## Prototype 7 notes

- **Chandrabindu inside a word**: a nasal after a vowel and before a consonant now also offers ଁ (keunthare → କେଉଁଠାରେ), besides ନ ଣ ଂ by class. Word families ଯେଉଁ/କେଉଁ/ସେଉଁ × ଠି ଠାରେ ଠାରୁ ମାନେ … are in words.inc.
- **j = ଜ and ଯ** (ଯେଉଁ, ସୂର୍ଯ୍ୟ). **Respellings** (engine `respell`): `ri`→`rri` (ୃ), `ry`/`ryy`→`rjy`, so surya / suryya / surjya → ସୂର୍ଯ୍ୟ and arya / aarya / arjya / aarjya → ଆର୍ଯ୍ୟ. Add more rules there.
- **Nukta goes to the nucleus**: the last ଡ/ଢ of the cluster (uDrai> → ଉଡ଼୍ରୈ); a nukta on any other base is treated as invalid.
- **ZWJ ya-phala**: after a plain ର, y also offers ର‍୍ୟ (U+200D before the halant) as an option; the validity filter accepts it only there.
- **Word-initial pieces**: nk → ଙ୍କ, nt → ନ୍ତ / ଣ୍ଟ, nta → ନ୍ତା / ଣ୍ଟା, ya → ଯା ୟ ୟା, Ya → ୟ ୟା, YA → ୟା (the old "never starts a word" rule is gone; only ଳ is still refused at the start).
- **Best candidate** for an unknown word is now the cheapest valid reading, not the literal first reading.
- Tools: `tools/expect.tsv` + `tools/regress.sh` (43 checks against both engines), `tools/audit.sh` (updated for ଁ, nukta and ZWJ).
- HTML app: real cursor (Left/Right/Home/End/Delete, click or tap to place), arrows move one character at a time (tick "Arrows jump a whole letter" to go by letters); Backspace always removes exactly one character, on-screen keyboard that opens on touch (Keyboard button for desktop), and a "Phone keyboard" option that uses the phone's own keyboard through a hidden input.
- Selection in the HTML app: Shift+Left/Right/Home/End, mouse drag, Shift+click, double-click (word), Ctrl/Cmd+A or the Select all button, Ctrl/Cmd+C/X, Copy text copies the selection when there is one; typing, paste, Backspace and Delete replace or remove it. Steps follow the letter / character setting. On the on-screen keyboard, Shift + ◀/▶ extends the selection.
- HTML app: Ctrl/Cmd+Z undo, Ctrl/Cmd+Y (or Shift+Ctrl/Cmd+Z) redo, and buttons. A nukta typed after a word was already picked goes straight after the last ଡ/ଢ of the letter before the cursor (ଉଡ୍ରୈ + > gives ଉଡ଼୍ରୈ). The Mac input method still only places the nukta inside the word being composed.


## Prototype 8: vowel pairs, vowel-less typing, long vowels, clusters
- **ai au ou** now give the single vowel first (ଐ ଔ), then every two-vowel reading: `ai` gives ଐ · ai · ଆଇ · ଆଈ · ଅଇ · ୈ, `au` gives ଔ · au · ଆଉ · ଆଊ · ଅଉ · ୌ, and the same pairs inside words (`khaibaku`).
- **Vowel-less typing** gives short-vowel readings of every consonant skeleton: `ktk` gives କଟକ · କତକ, `kt` gives କ୍ତ · କ୍ଟ · କଟ · କତ, `nt` keeps ଣ୍ଟ near the top. A word-initial vowel letter stays (`asr`, ଅସୁର).
- **Short and long vowels.** `a i u` give the short vowel and then the long one; `aa A ii I ee EE uu U oo OO` give only the long one, also inside words.
- **Cluster rules** from the extended list (k kh g … through dya, dya gives ଦ୍ୟ ଡ୍ୟ ଦ୍ୟା ଡ୍ୟା): extra readings were added where missing (d and dh also ଡ଼ ଢ଼, sh also ସ, ny also ଣ୍ୟ ଞ୍ୟ, v also ୱ, nian ଞ and uan ଙ first, ru also ଋ/ରୁ forms) and `skru`-like clusters give ସ୍କୃ (also ଶ୍କୃ ଷ୍କୃ ସ୍କ୍ରୁ ସ୍କ୍ରୂ). `tools/check_userlist.js` checks the whole list: 0 missing.
- **Auto space**: a choice picked with a number key or the mouse is followed by a space at once (not when the word goes on: halant, ZWNJ or a bare sign). Return and Space both pick with a space; Return when no word is being typed is a new line. Same rule in the Mac input method (not compiled here).
- `tools/expect.tsv` now holds 60 checks, run on both engines by `tools/regress.sh`.


## Word-list prediction test (HTML only, not in the main apps)

`html/predictive/odia-lekhani-typist-keyboard-predictive.html` is a separate test build. It needs the `data/` folder next to it (28 files, about 14 MB, loaded only when needed; built by `tools/build_predict.py`). After 2 or more letters a "From the word list" block shows up to 5 completions from the word list, most frequent first. Pick one with Alt+1 to Alt+5 (Option+1 to 5 on Mac) or a click; a space follows. It predicts completions of the word being typed, not the next word. The main app and the Mac input method are unchanged until you confirm.

## v1.3 changes
- **Schwa restored after a final consonant pair**: `karn` now offers କର୍ନ, karn, କର୍ଣ, କାରଣ, କରନ, କରଣ (the same for dharm, karm and similar). Words ending in a digraph (kh, sh ...) or in h, y, w, v are not touched.
- **Dictionary that forgives missing or wrong vowels**: every word of the word list is also indexed by its consonant skeleton (ଧ/ଢ, ତ/ଟ, ସ/ଶ/ଷ, ନ/ଣ ... count as the same), so `pasnd` finds ପସନ୍ଦ, `budhiani` finds ବୁଢ଼ିଆଣୀ and ବୁଢିଆଣୀ, `pustk` finds ପୁସ୍ତକ, for every vowel and consonant. The vowels you did type only decide the order. It lives in `src/skel.dat` (built by `tools/build_skel.py`; the Mac app carries it in its Resources, the HTML app embeds it compressed and loads it a moment after the page opens). Mac and HTML use the same rules (`engine.c` / `engine.tpl.js`); `tools/regress.sh` checks both.
- **Copyright footer is frozen** at the bottom of the HTML app.
- **Mouse works in the Mac candidate window**: click a choice to pick it (a space follows, like the number keys); click the page counter's left or right half to change page.
- **Apostrophe words first**: kan/kana → କ'ଣ, ta → ତା', tar/taar/tara/taara → ତା'ର, mor/mora → ମୋ'ର, tor/tora → ତୋ'ର, ma → ମା' then ମାଆ.
- **Abbreviations end with a dot**: pa / PA → … ପି.ଏ. (also ପି.ଏ and ପିଏ, and p.a. when typed in lower case).
- **y is ୟ after the first letter** (kaifiyat → କୈଫିୟତ୍ first; the ଯ spelling comes last); at the start of a word y stays ଯ (yoga → ଯୋଗ, ୟୋଗ follows).
- **Footer** now reads just © 2026 Sai Sudeep Das.
- **Missing vowels, everywhere**: `kn`, `ka'n`, `ka'na`, `k'n` all give କ'ଣ; `tr`/`t'r` → ତା'ର; `mr`/`m'r` → ମୋ'ର. Typing without vowels (or with some wrong) finds dictionary words in both apps, and words that start with a vowel you skipped now show up too.
- **Backspace removes one character only**: in the HTML app always; in the Mac input method when nothing is being composed it deletes the single Odia character before the caret (the system would remove a whole letter). While composing it already removes one Roman letter. In an app that does not accept this, Backspace falls back to the system way. The Mac input method cannot change how arrows move the caret in other apps; that is up to the app.
- **Return while typing a word** picks it and adds a space; Return with no word being typed is a new line.
- **Input menu row**: the menu icon is now a 16 pt `menu.icns` (the old 1024 px picture made the row fill the whole menu). If the row is still tall after installing, log out and in once so macOS reloads the icon.
- **Nukta after the word is already in the text (Mac)**: `>` typed right after a picked word, even with the space added by the pick, now puts the nukta on the ଡ or ଢ of the last letter (ବଡି then `>` gives ବଡ଼ି; ଡ୍ରୈ and ଢୁ work too). With no ଡ or ଢ there it inserts a plain nukta as before. Typing `>` inside the word (`baDi>`) worked already. Not compiled here.
- **Menu icon style**: macOS draws input-menu icons as one-colour masks, so a coloured picture showed as a blank black square. `menu.icns` is now a dark rounded square with the mark cut out, like the system Hindi entry.

## If typing stops or the input-method menu goes empty

This was fixed in this version: the input method no longer waits for its word engine without a time limit, an exception while handling one key cannot take it down, and a watchdog restarts it if it ever stops answering. If it still happens, `~/Library/Logs/SulekhakIME.log` records what the input method was doing (never what you typed); send that file. To restart it by hand: `killall LekhaniOdia` (macOS starts it again the next time you type).

## Choosing a word

* **1-9** pick the word with that number on the current page (the numbers are shown next to the words).
* **Tab / Shift+Tab**: Tab moves to the next word; **Shift+Tab** turns to the next page of words when there is more than one page, otherwise to the previous word.
* Odia words written with an apostrophe (ତା'ର, କ'ଣ, ମା' …) are offered next to the plain spellings (ତାର, କଣ, ମା).
