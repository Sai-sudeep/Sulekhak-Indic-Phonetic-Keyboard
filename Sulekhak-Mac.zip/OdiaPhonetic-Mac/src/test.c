#include <stdio.h>
#include <string.h>
#include "engine.h"
static int fails=0;
static void eq(const char*in,const char*want){ char o[256]; odia_transliterate(in,o,sizeof o);
  if(strcmp(o,want)){ printf("FAIL %-10s got [%s] want [%s]\n",in,o,want); fails++; } else printf("ok   %-10s %s\n",in,o); }
int main(){
  odia_load_builtin();
  eq("ka","କ");eq("kaa","କା");eq("ki","କି");eq("kii","କୀ");eq("ku","କୁ");eq("kuu","କୂ");eq("ke","କେ");eq("kai","କୈ");eq("ko","କୋ");eq("kau","କୌ");
  eq("a","ଅ");eq("aa","ଆ");eq("i","ଇ");eq("o","ଓ");eq("kaaki","କାକି");
  eq("kta","କ୍ତ");eq("karma","କର୍ମ");eq("kshetra","କ୍ଷେତ୍ର");
  eq("kvta","କ୍ତ");                 /* v = halant only */
  eq("kZta","କ୍\xE2\x80\x8C" "ତ");     /* Z = halant + ZWNJ */
  eq("kzta","କ\xE2\x80\x8C" "ତ");      /* z = ZWNJ only */
  eq("kv","କ୍");eq("kZ","କ୍\xE2\x80\x8C");
  eq("V","\xE0\xAC\xB5");            /* shift+v = U+0B35 */
  eq("R","\xE0\xAD\x9C");eq("Rh","\xE0\xAD\x9D");
  eq("ka>","କ\xE0\xAC\xBC");         /* shift+> = U+0B3C */
  eq("12","୧୨");eq("baDi>","ବଡ\xE0\xAC\xBCି");eq("baDhi>","ବଢ଼ି");eq("baDhi>","ବଢ\xE0\xAC\xBCି");eq("kaM","କଂ");eq("kaH","କଃ");eq("ka~","କଁ");
  eq("sha","ଶ");eq("Sha","ଷ");eq("sa","ସ");eq("Ta","ଟ");eq("tha","ଥ");eq("Tha","ଠ");eq("Na","ଣ");
  eq("bhala","ଭଲ");eq("ganga","ଗଙ୍ଗ");eq("n'ga","ନ୍ଗ");
  char c[ODIA_MAX_CANDS][ODIA_CAND_LEN];
  const char *tests[]={"namaskar","odia","1","k","t","i","aa","e","ken","keng","kam","baDi>",".","krishna","Z","khaibaku","anka","kanTa","panchami","gharaku","bharatara","kau","kaiyo","kanta","basre","delenahin","bhaya"};
  for(int t=0;t<24;t++){ int n=odia_candidates(tests[t],c); printf("\n%s ->",tests[t]); for(int i=0;i<n;i++) printf("  %d:%s",i+1,c[i]); }
  printf("\n\nfails=%d\n",fails); return fails!=0; }
