// The suggested-word strip: shown on the 3D on-screen keyboard and, on Macs that have one, on the Touch Bar.
// While a word is typed it lists the choices for it; after a word is finished it lists the words that usually come next.
#import <Cocoa/Cocoa.h>

@interface SuggestBar : NSObject
+ (instancetype)shared;
@property (nonatomic, copy) void (^onPick)(NSInteger index, BOOL isNext);   // a suggestion was tapped (index in the list shown last)
@property (nonatomic) BOOL touchBarEnabled;                                  // menu: "Touch Bar suggestions"
- (void)showChoices:(NSArray<NSString *> *)items selected:(NSInteger)sel;    // the word being typed
- (void)showNext:(NSArray<NSString *> *)items;                               // after a finished word
- (void)clear;                                                               // nothing to suggest (also dismisses the Touch Bar after a moment)
- (void)hideTouchBarNow;                                                     // typing moved to another program or the keyboard was switched off
- (void)pickedFromKeyboard:(NSInteger)index isNext:(BOOL)isNext;             // a chip on the 3D keyboard was clicked
@end
