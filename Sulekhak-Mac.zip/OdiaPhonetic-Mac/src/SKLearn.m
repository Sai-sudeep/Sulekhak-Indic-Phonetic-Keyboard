#import "SKLearn.h"
#import <Cocoa/Cocoa.h>
#import <ApplicationServices/ApplicationServices.h>
#import <CoreServices/CoreServices.h>
#import "OdiaController.h"
#include "engine.h"

static NSString *const kLearnFile = @"sulekhak-learn.json";
static const int kFormat = 1;

// ---------------------------------------------------------------- small helpers
static BOOL IsIndicChar(unichar c) { return (c >= 0x0900 && c <= 0x097F && c != 0x0964 && c != 0x0965) || (c >= 0x0980 && c <= 0x09FF) || (c >= 0x0B00 && c <= 0x0B7F); }
static BOOL ContainsIndic(NSString *s) { for (NSUInteger i = 0; i < s.length; i++) if (IsIndicChar([s characterAtIndex:i])) return YES; return NO; }
static NSString *Squash(NSString *s) {      // trim and make every run of white space one space
    NSArray *p = [[s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSMutableArray *k = [NSMutableArray new]; for (NSString *w in p) if (w.length) [k addObject:w];
    return [k componentsJoinedByString:@" "];
}
static NSString *ToOdia(NSString *s) {      // Devanagari / Bangla / Assamese letters carried over to the Odia the engine works in
    char out[1024]; odia_to_odia(s.UTF8String, out, sizeof out);
    return [NSString stringWithUTF8String:out] ?: s;
}
static NSNumber *Now(void) { return @((long long)[[NSDate date] timeIntervalSince1970]); }
static NSString *GuessRoman(NSString *odia) {       // a Roman spelling that types the word back, checked with the engine
    NSString *best = nil;
    for (int v = 0; v < 2; v++) {
        char r[512]; odia_reverse_roman(odia.UTF8String, v, r, sizeof r);
        NSString *rs = [NSString stringWithUTF8String:r]; if (!rs.length) continue;
        if (!best) best = rs;
        char c[ODIA_MAX_CANDS][ODIA_CAND_LEN]; int n = odia_candidates(r, c);
        for (int i = 0; i < n; i++) if (strcmp(c[i], odia.UTF8String) == 0) return rs;
    }
    return best ?: @"";
}

// ---------------------------------------------------------------- the round "+" button
@interface SKPlusView : NSView
@property (copy) void (^onClick)(void);
@end
@implementation SKPlusView
- (BOOL)acceptsFirstMouse:(NSEvent *)e { return YES; }
- (void)drawRect:(NSRect)r {
    [[NSColor colorWithCalibratedRed:0.20 green:0.42 blue:0.93 alpha:1] setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSInsetRect(self.bounds, 1, 1)] fill];
    [[NSColor whiteColor] setStroke];
    NSBezierPath *p = [NSBezierPath bezierPath]; p.lineWidth = 2.4; p.lineCapStyle = NSLineCapStyleRound;
    CGFloat c = NSMidX(self.bounds), m = NSMidY(self.bounds), k = 7;
    [p moveToPoint:NSMakePoint(c - k, m)]; [p lineToPoint:NSMakePoint(c + k, m)]; [p moveToPoint:NSMakePoint(c, m - k)]; [p lineToPoint:NSMakePoint(c, m + k)]; [p stroke];
}
- (void)mouseDown:(NSEvent *)e { if (self.onClick) self.onClick(); }
@end


// ---------------------------------------------------------------- the store
@implementation SKLearn {
    NSString *_dir, *_path;
    NSMutableDictionary *_picks;     // roman -> { word -> { n, first, last, sc } }
    NSMutableDictionary *_dict;      // "roman\tword" -> { w, roman, wt, added, src }
    NSMutableDictionary *_next;      // prev -> { word -> n }
    BOOL _dirty, _scheduled, _opened;
    NSDate *_fileDate;
    dispatch_queue_t _q;
}

+ (instancetype)shared { static SKLearn *s; static dispatch_once_t o; dispatch_once(&o, ^{ s = [SKLearn new]; }); return s; }
- (instancetype)init {
    if ((self = [super init])) {
        _picks = [NSMutableDictionary new]; _dict = [NSMutableDictionary new]; _next = [NSMutableDictionary new];
        _q = dispatch_queue_create("sulekhak.learn.write", DISPATCH_QUEUE_SERIAL);
    }
    return self;
}
- (NSUInteger)pickCount { NSUInteger n = 0; for (NSDictionary *d in _picks.allValues) n += d.count; return n; }
- (NSUInteger)dictCount { return _dict.count; }

- (NSDate *)fileMTime { return [[[NSFileManager defaultManager] attributesOfItemAtPath:_path error:nil] fileModificationDate]; }

// -------- reading (also used to merge changes another program made to the file)
- (NSArray *)mergeJSONData:(NSData *)data {       // returns what is new for the engine: [ {roman, word, n(delta), dict(BOOL), wt} ]
    NSDictionary *j = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
    if (![j isKindOfClass:[NSDictionary class]] || ![j[@"format"] isEqual:@"sulekhak-learn"]) return @[];
    NSMutableArray *fresh = [NSMutableArray new];
    NSDictionary *picks = j[@"picks"];
    if ([picks isKindOfClass:[NSDictionary class]]) for (NSString *roman in picks) {
        NSArray *list = picks[roman]; if (![list isKindOfClass:[NSArray class]]) continue;
        for (NSDictionary *e in list) {
            NSString *w = e[@"w"]; if (![w isKindOfClass:[NSString class]] || !w.length) continue;
            NSMutableDictionary *byWord = _picks[roman]; if (!byWord) { byWord = [NSMutableDictionary new]; _picks[roman] = byWord; }
            NSMutableDictionary *mine = byWord[w];
            long long n = [e[@"n"] longLongValue], first = [e[@"first"] longLongValue], last = [e[@"last"] longLongValue]; int sc = [e[@"sc"] intValue];
            if (!mine) { byWord[w] = [@{@"n": @(n), @"first": @(first), @"last": @(last), @"sc": @(sc)} mutableCopy]; [fresh addObject:@{@"roman": roman, @"word": w, @"n": @(n)}]; }
            else {
                long long mn = [mine[@"n"] longLongValue];
                if (n > mn) { mine[@"n"] = @(n); [fresh addObject:@{@"roman": roman, @"word": w, @"n": @(n - mn)}]; }
                if (first && (!([mine[@"first"] longLongValue]) || first < [mine[@"first"] longLongValue])) mine[@"first"] = @(first);
                if (last > [mine[@"last"] longLongValue]) mine[@"last"] = @(last);
                mine[@"sc"] = @([mine[@"sc"] intValue] | sc);
            }
        }
    }
    NSArray *dict = j[@"dict"];
    if ([dict isKindOfClass:[NSArray class]]) for (NSDictionary *e in dict) {
        NSString *w = e[@"w"], *r = e[@"roman"]; if (![w isKindOfClass:[NSString class]] || ![r isKindOfClass:[NSString class]] || !w.length || !r.length) continue;
        NSString *key = [NSString stringWithFormat:@"%@\t%@", r, w];
        if (_dict[key]) continue;
        int wt = [e[@"wt"] intValue]; if (wt <= 0) wt = 6;
        _dict[key] = [@{@"w": w, @"roman": r, @"wt": @(wt), @"added": e[@"added"] ?: Now(), @"src": e[@"src"] ?: @"file"} mutableCopy];
        [fresh addObject:@{@"roman": r, @"word": w, @"n": @(wt), @"dict": @YES}];
    }
    NSDictionary *nx = j[@"next"];
    if ([nx isKindOfClass:[NSDictionary class]]) for (NSString *p in nx) {
        NSDictionary *m = nx[p]; if (![m isKindOfClass:[NSDictionary class]]) continue;
        NSMutableDictionary *mine = _next[p]; if (!mine) { mine = [NSMutableDictionary new]; _next[p] = mine; }
        for (NSString *w in m) mine[w] = @(MAX([mine[w] longLongValue], [m[w] longLongValue]));
    }
    return fresh;
}

- (void)openInDirectory:(NSString *)dir {
    _dir = [dir copy]; _path = [dir stringByAppendingPathComponent:kLearnFile];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL had = [fm fileExistsAtPath:_path];
    if (had) { [self mergeJSONData:[NSData dataWithContentsOfFile:_path]]; _fileDate = [self fileMTime]; }
    // first time: fold in the old files (history.tsv: one pick per line; it is kept as history.tsv.migrated)
    NSString *hist = [dir stringByAppendingPathComponent:@"history.tsv"];
    if ([fm fileExistsAtPath:hist]) {
        NSDate *when = [[fm attributesOfItemAtPath:hist error:nil] fileModificationDate] ?: [NSDate date];
        long long t = (long long)when.timeIntervalSince1970;
        NSString *txt = [NSString stringWithContentsOfFile:hist encoding:NSUTF8StringEncoding error:nil];
        for (NSString *line in [txt componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
            NSArray *p = [line componentsSeparatedByString:@"\t"];
            if (p.count < 2 || [p[0] length] == 0 || [p[1] length] == 0) continue;
            NSMutableDictionary *byWord = _picks[p[0]]; if (!byWord) { byWord = [NSMutableDictionary new]; _picks[p[0]] = byWord; }
            NSMutableDictionary *e = byWord[p[1]];
            if (!e) { e = [@{@"n": @0, @"first": @(t), @"last": @(t), @"sc": @1} mutableCopy]; byWord[p[1]] = e; }
            e[@"n"] = @([e[@"n"] longLongValue] + 1);
        }
        NSString *back = [hist stringByAppendingString:@".migrated"];
        [fm removeItemAtPath:back error:nil]; [fm moveItemAtPath:hist toPath:back error:nil];
        _dirty = YES;
    }
    // lexicon.tsv stays where it is (you may edit it by hand): every line becomes a dictionary word of the cache
    NSString *lex = [dir stringByAppendingPathComponent:@"lexicon.tsv"];
    NSString *lt = [NSString stringWithContentsOfFile:lex encoding:NSUTF8StringEncoding error:nil];
    for (NSString *line in [lt componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
        NSArray *p = [line componentsSeparatedByString:@"\t"];
        if (p.count < 2 || [p[0] length] == 0 || [p[1] length] == 0 || [p[0] hasPrefix:@"#"]) continue;
        NSString *key = [NSString stringWithFormat:@"%@\t%@", p[0], p[1]];
        if (_dict[key]) continue;
        int wt = p.count > 2 ? [p[2] intValue] : 0; if (wt <= 0) wt = 6;
        _dict[key] = [@{@"w": p[1], @"roman": p[0], @"wt": @(wt), @"added": Now(), @"src": @"lexicon.tsv"} mutableCopy];
        _dirty = YES;
    }
    _opened = YES;
    if (!had) _dirty = YES;
    if (_dirty) [self scheduleSave:0.2];
    [NSTimer scheduledTimerWithTimeInterval:20 repeats:YES block:^(NSTimer *t) { [self checkFile]; }];
    [[NSNotificationCenter defaultCenter] addObserverForName:NSApplicationWillTerminateNotification object:nil queue:nil usingBlock:^(NSNotification *n) { [self flush]; }];
}

- (void)loadIntoEngine {
    for (NSString *roman in _picks) {
        NSDictionary *byWord = _picks[roman];
        for (NSString *w in byWord) { long long n = [byWord[w][@"n"] longLongValue]; odia_lex_add(roman.UTF8String, w.UTF8String, 3 * (int)MIN(n, 20)); }
    }
    for (NSDictionary *e in _dict.allValues) odia_lex_add_user([e[@"roman"] UTF8String], [e[@"w"] UTF8String], [e[@"wt"] intValue]);
}

// another program (the web typist's export, a sync tool, you) changed the file: take in what is new
- (void)checkFile {
    NSDate *m = [self fileMTime];
    if (!m || (_fileDate && [m isEqualToDate:_fileDate])) return;
    NSArray *fresh = [self mergeJSONData:[NSData dataWithContentsOfFile:_path]];
    _fileDate = m;
    for (NSDictionary *f in fresh) {
        if ([f[@"dict"] boolValue]) odia_lex_add_user([f[@"roman"] UTF8String], [f[@"word"] UTF8String], [f[@"n"] intValue]);
        else odia_lex_add([f[@"roman"] UTF8String], [f[@"word"] UTF8String], 3 * (int)MIN([f[@"n"] longLongValue], 20));
    }
}

// -------- writing
- (void)scheduleSave:(NSTimeInterval)delay {
    if (_scheduled) return; _scheduled = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ self->_scheduled = NO; [self save]; });
}
- (NSData *)snapshot {
    NSMutableDictionary *picks = [NSMutableDictionary new];
    NSUInteger total = 0; for (NSDictionary *d in _picks.allValues) total += d.count;
    long long cutoff = [Now() longLongValue] - 180LL * 86400;      // a huge cache forgets one-off picks older than half a year
    for (NSString *roman in _picks) {
        NSMutableArray *list = [NSMutableArray new]; NSDictionary *byWord = _picks[roman];
        for (NSString *w in byWord) {
            NSDictionary *e = byWord[w];
            if (total > 20000 && [e[@"n"] longLongValue] <= 1 && [e[@"last"] longLongValue] < cutoff) continue;
            [list addObject:@{@"w": w, @"n": e[@"n"], @"first": e[@"first"], @"last": e[@"last"], @"sc": e[@"sc"]}];
        }
        [list sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) { return [b[@"n"] compare:a[@"n"]]; }];
        if (list.count) picks[roman] = list;
    }
    NSArray *dict = [[_dict allValues] sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) { return [a[@"added"] compare:b[@"added"]]; }];
    NSDictionary *root = @{@"format": @"sulekhak-learn", @"version": @(kFormat), @"device": @"mac",
                           @"app": [[NSBundle mainBundle] infoDictionary][@"CFBundleShortVersionString"] ?: @"", @"updated": Now(),
                           @"picks": picks, @"dict": dict, @"next": _next};
    return [NSJSONSerialization dataWithJSONObject:root options:NSJSONWritingPrettyPrinted | NSJSONWritingSortedKeys error:nil];
}
- (void)save {
    if (!_opened || !_dirty) return;
    // if another program wrote the file meanwhile, merge it in first so neither side loses anything
    NSDate *m = [self fileMTime]; if (m && _fileDate && ![m isEqualToDate:_fileDate]) [self checkFile];
    _dirty = NO;
    NSData *d = [self snapshot]; NSString *p = _path;
    dispatch_async(_q, ^{
        if ([d writeToFile:p options:NSDataWritingAtomic error:nil]) {
            NSDate *nm = [[[NSFileManager defaultManager] attributesOfItemAtPath:p error:nil] fileModificationDate];
            dispatch_async(dispatch_get_main_queue(), ^{ self->_fileDate = nm; });
        }
    });
}
- (void)flush {
    if (!_opened || !_dirty) return;
    _dirty = NO;
    [[self snapshot] writeToFile:_path options:NSDataWritingAtomic error:nil];
}

// -------- what is learned
- (void)notePick:(NSString *)roman word:(NSString *)odia script:(int)script {
    if (!_opened || !roman.length || !odia.length || roman.length > 60 || odia.length > 120) return;
    NSMutableDictionary *byWord = _picks[roman]; if (!byWord) { byWord = [NSMutableDictionary new]; _picks[roman] = byWord; }
    NSNumber *now = Now();
    NSMutableDictionary *e = byWord[odia];
    if (!e) { e = [@{@"n": @0, @"first": now, @"last": now, @"sc": @0} mutableCopy]; byWord[odia] = e; }
    e[@"n"] = @([e[@"n"] longLongValue] + 1); e[@"last"] = now;
    e[@"sc"] = @([e[@"sc"] intValue] | (1 << (script & 7)));
    _dirty = YES; [self scheduleSave:2.0];
}
- (void)noteNext:(NSString *)prev word:(NSString *)word {
    if (!_opened || !prev.length || !word.length || prev.length > 120 || word.length > 120) return;
    NSMutableDictionary *m = _next[prev]; if (!m) { m = [NSMutableDictionary new]; _next[prev] = m; }
    m[word] = @([m[word] longLongValue] + 1);
    if (m.count > 12) { NSString *lo = nil; for (NSString *k in m) if (!lo || [m[k] longLongValue] < [m[lo] longLongValue]) lo = k; if (![lo isEqualToString:word]) [m removeObjectForKey:lo]; }
    if (_next.count > 4000) { NSString *k0 = _next.allKeys.firstObject; if (![k0 isEqualToString:prev]) [_next removeObjectForKey:k0]; }
    _dirty = YES; [self scheduleSave:3.0];
}

- (NSString *)addDictionaryWord:(NSString *)odia roman:(NSString *)roman {
    odia = Squash(odia ?: @""); roman = [(roman ?: @"") stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (!odia.length || !ContainsIndic(odia)) return @"Select or type an Odia, Devanagari, Bangla or Assamese word.";
    if (odia.length > 120) return @"That is too long for one dictionary entry (120 letters at most).";
    if (!roman.length) return @"Type the Roman letters you will use for it, for example kalpana.";
    if (roman.length > 60) return @"The Roman spelling is too long (60 letters at most).";
    for (NSUInteger i = 0; i < roman.length; i++) { unichar c = [roman characterAtIndex:i]; if (c <= 32 || c >= 127) return @"Use plain Roman letters without spaces for the typing, for example iitdelhi."; }
    odia = ToOdia(odia);
    NSString *key = [NSString stringWithFormat:@"%@\t%@", roman, odia];
    NSMutableDictionary *e = _dict[key];
    if (!e) { e = [@{@"w": odia, @"roman": roman, @"wt": @6, @"added": Now(), @"src": @"mac"} mutableCopy]; _dict[key] = e;
        // keep the plain word list in step, for older versions and for editing by hand
        NSString *lex = [_dir stringByAppendingPathComponent:@"lexicon.tsv"];
        NSString *line = [NSString stringWithFormat:@"%@\t%@\t6\n", roman, odia];
        NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:lex];
        if (!h) { [@"" writeToFile:lex atomically:YES encoding:NSUTF8StringEncoding error:nil]; h = [NSFileHandle fileHandleForWritingAtPath:lex]; }
        [h seekToEndOfFile]; [h writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile];
    }
    odia_lex_add_user(roman.UTF8String, odia.UTF8String, 6);
    _dirty = YES; [self scheduleSave:0.3];
    return nil;
}

// ---------------------------------------------------------------- Add to Sulekhak Dictionary: asking
static void Toast(NSString *msg) {
    static NSPanel *p; if (p) [p orderOut:nil];
    NSTextField *t = [NSTextField labelWithString:msg]; t.font = [NSFont systemFontOfSize:14 weight:NSFontWeightMedium]; t.textColor = [NSColor whiteColor]; [t sizeToFit];
    NSRect f = NSMakeRect(0, 0, t.frame.size.width + 32, t.frame.size.height + 20);
    p = [[NSPanel alloc] initWithContentRect:f styleMask:NSWindowStyleMaskBorderless | NSWindowStyleMaskNonactivatingPanel backing:NSBackingStoreBuffered defer:NO];
    p.level = NSStatusWindowLevel; p.opaque = NO; p.backgroundColor = [NSColor clearColor]; p.hasShadow = YES; p.releasedWhenClosed = NO; p.ignoresMouseEvents = YES;
    NSView *v = [[NSView alloc] initWithFrame:f]; v.wantsLayer = YES; v.layer.backgroundColor = [NSColor colorWithCalibratedWhite:0.1 alpha:0.92].CGColor; v.layer.cornerRadius = 10;
    t.frame = NSMakeRect(16, 10, t.frame.size.width, t.frame.size.height); [v addSubview:t]; p.contentView = v;
    NSRect vis = [NSScreen mainScreen].visibleFrame; [p setFrameOrigin:NSMakePoint(NSMidX(vis) - f.size.width / 2, vis.origin.y + 90)];
    [p orderFrontRegardless];
    NSPanel *mine = p; dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (p == mine) [mine orderOut:nil]; });
}

+ (void)presentAddFor:(NSString *)text {
    static BOOL busy; if (busy) return; busy = YES;
    NSRunningApplication *front = [[NSWorkspace sharedWorkspace] frontmostApplication];
    NSString *odia = Squash(text ?: @"");
    if (odia.length > 120) odia = [odia substringToIndex:120];
    NSString *err = nil, *romanText = nil;      // romanText: what you typed in the Roman box (kept if the entry is refused and asked again)
    for (;;) {
        NSAlert *a = [NSAlert new];
        a.messageText = @"Add to Sulekhak Dictionary";
        a.informativeText = err ?: @"The word or expression, and the Roman letters you will type for it. An expression is typed as one block of letters, like iitdelhi.";
        NSView *v = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 380, 106)];
        NSTextField *l1 = [NSTextField labelWithString:@"Word or expression"]; l1.frame = NSMakeRect(0, 88, 380, 16);
        NSTextField *fw = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 60, 380, 26)]; fw.stringValue = odia; fw.font = [NSFont systemFontOfSize:17];
        NSTextField *l2 = [NSTextField labelWithString:@"Type it as (Roman letters)"]; l2.frame = NSMakeRect(0, 40, 380, 16);
        NSTextField *fr = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 12, 380, 26)]; fr.font = [NSFont systemFontOfSize:15];
        fr.stringValue = romanText ?: (odia.length && ContainsIndic(odia) ? GuessRoman(ToOdia(odia)) : @"");
        for (NSView *s in @[l1, fw, l2, fr]) [v addSubview:s];
        a.accessoryView = v;
        [a addButtonWithTitle:@"Add to Dictionary"]; [a addButtonWithTitle:@"Cancel"];
        [NSApp activateIgnoringOtherApps:YES];
        a.window.initialFirstResponder = (odia.length ? fr : fw);
        NSModalResponse r = [a runModal];
        if (r != NSAlertFirstButtonReturn) break;
        odia = Squash(fw.stringValue);
        romanText = [fr.stringValue copy];
        err = [[SKLearn shared] addDictionaryWord:odia roman:fr.stringValue];
        if (!err) { Toast([NSString stringWithFormat:@"Added to Sulekhak Dictionary:  %@  =  %@", odia, [fr.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]]); break; }
    }
    busy = NO;
    if (front && ![front isEqual:[NSRunningApplication currentApplication]]) [front activateWithOptions:0];
}

// ---------------------------------------------------------------- Add to Sulekhak Dictionary: finding the selection
static NSString *AXSelectedText(void) {
    if (!AXIsProcessTrusted()) return nil;
    AXUIElementRef sys = AXUIElementCreateSystemWide(), el = NULL; NSString *s = nil;
    if (AXUIElementCopyAttributeValue(sys, kAXFocusedUIElementAttribute, (CFTypeRef *)&el) == kAXErrorSuccess && el) {
        CFTypeRef v = NULL;
        if (AXUIElementCopyAttributeValue(el, kAXSelectedTextAttribute, &v) == kAXErrorSuccess && v) {
            if (CFGetTypeID(v) == CFStringGetTypeID()) s = [(__bridge NSString *)v copy];
            CFRelease(v);
        }
        CFRelease(el);
    }
    CFRelease(sys);
    return s;
}

+ (void)addSelection {
    NSString *s = AXSelectedText();
    if (!s.length || !ContainsIndic(s)) s = [OdiaController clientSelectionOrWord];      // the typing client's own selection, else the word before the cursor
    [self presentAddFor:s];
}

// ---------------------------------------------------------------- the round "+" beside a mouse selection
static NSPanel *gPlus; static NSString *gPlusText; static NSInteger gPlusGen;
static void HidePlus(void) { gPlusGen++; [gPlus orderOut:nil]; }
static void ShowPlus(NSString *text) {
    if (!gPlus) {
        gPlus = [[NSPanel alloc] initWithContentRect:NSMakeRect(0, 0, 30, 30) styleMask:NSWindowStyleMaskBorderless | NSWindowStyleMaskNonactivatingPanel backing:NSBackingStoreBuffered defer:NO];
        gPlus.level = NSStatusWindowLevel; gPlus.opaque = NO; gPlus.backgroundColor = [NSColor clearColor]; gPlus.hasShadow = YES; gPlus.releasedWhenClosed = NO;
        SKPlusView *v = [[SKPlusView alloc] initWithFrame:NSMakeRect(0, 0, 30, 30)];
        v.toolTip = @"Add to Sulekhak Dictionary";
        v.onClick = ^{ NSString *t = gPlusText; HidePlus(); [SKLearn presentAddFor:t]; };
        gPlus.contentView = v;
    }
    gPlusText = [text copy];
    NSPoint m = [NSEvent mouseLocation]; NSRect vis = [NSScreen mainScreen].visibleFrame;
    for (NSScreen *s in [NSScreen screens]) if (NSPointInRect(m, s.frame)) vis = s.visibleFrame;
    NSPoint o = NSMakePoint(MIN(m.x + 8, NSMaxX(vis) - 36), MIN(m.y + 14, NSMaxY(vis) - 36));
    [gPlus setFrameOrigin:o]; [gPlus orderFrontRegardless];
    NSInteger gen = ++gPlusGen;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if (gen == gPlusGen) [gPlus orderOut:nil]; });
}
+ (void)startSelectionButton {
    static BOOL on; if (on) return; on = YES;
    [NSEvent addGlobalMonitorForEventsMatchingMask:NSEventMaskLeftMouseUp handler:^(NSEvent *e) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.18 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            NSString *s = AXSelectedText();
            s = Squash(s ?: @"");
            if (s.length && s.length <= 100 && ContainsIndic(s)) ShowPlus(s); else HidePlus();
        });
    }];
    [NSEvent addGlobalMonitorForEventsMatchingMask:NSEventMaskLeftMouseDown | NSEventMaskKeyDown handler:^(NSEvent *e) { HidePlus(); }];
}

// ---------------------------------------------------------------- Services menu and sulekhak://add?text=
+ (void)installServices {
    static SKLearn *provider; provider = [SKLearn shared];
    [NSApp setServicesProvider:provider];
    NSUpdateDynamicServices();
    [[NSAppleEventManager sharedAppleEventManager] setEventHandler:provider andSelector:@selector(handleURLEvent:withReplyEvent:) forEventClass:kInternetEventClass andEventID:kAEGetURL];
}
- (void)addToSulekhakDictionary:(NSPasteboard *)pb userData:(NSString *)ud error:(NSString **)error {      // the Services menu / right-click entry
    NSString *s = [pb stringForType:NSPasteboardTypeString];
    dispatch_async(dispatch_get_main_queue(), ^{ [SKLearn presentAddFor:s]; });
}
- (void)handleURLEvent:(NSAppleEventDescriptor *)event withReplyEvent:(NSAppleEventDescriptor *)reply {       // sulekhak://add?text=...  (the Quick Action)
    NSString *u = [[event paramDescriptorForKeyword:keyDirectObject] stringValue];
    NSURLComponents *c = u ? [NSURLComponents componentsWithString:u] : nil;
    if (![c.host isEqualToString:@"add"]) return;
    NSString *t = nil; for (NSURLQueryItem *q in c.queryItems) if ([q.name isEqualToString:@"text"]) t = q.value;
    dispatch_async(dispatch_get_main_queue(), ^{ [SKLearn presentAddFor:t]; });
}
@end
