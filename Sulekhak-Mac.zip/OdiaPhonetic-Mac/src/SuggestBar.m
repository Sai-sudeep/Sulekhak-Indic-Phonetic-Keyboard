#import "SuggestBar.h"
#import "OSKPanel.h"

// The Touch Bar can be taken over for the whole screen only through the system-modal call below. It is not in the public SDK headers,
// so it is declared here and only used when the running macOS answers to it. On a Mac without a Touch Bar nothing happens.
@interface NSTouchBar (SKSystemModal)
+ (void)presentSystemModalTouchBar:(NSTouchBar *)touchBar placement:(long long)placement systemTrayItemIdentifier:(NSTouchBarItemIdentifier)identifier;
+ (void)presentSystemModalFunctionBar:(NSTouchBar *)touchBar placement:(long long)placement systemTrayItemIdentifier:(NSTouchBarItemIdentifier)identifier;
+ (void)dismissSystemModalTouchBar:(NSTouchBar *)touchBar;
+ (void)dismissSystemModalFunctionBar:(NSTouchBar *)touchBar;
@end

static NSString *const kTBPref = @"SulekhkTouchBarSuggest";
static const NSInteger kMaxChips = 8;

@interface SuggestBar () <NSTouchBarDelegate>
@end

@implementation SuggestBar {
    NSArray<NSString *> *_items;
    BOOL _isNext;
    NSInteger _sel;
    NSTouchBar *_bar;
    NSMutableArray<NSButton *> *_btns;
    BOOL _barShown;
    NSUInteger _gen;
}

+ (instancetype)shared {
    static SuggestBar *s; static dispatch_once_t o;
    dispatch_once(&o, ^{ s = [SuggestBar new]; });
    return s;
}

- (instancetype)init {
    if ((self = [super init])) {
        NSNumber *v = [[NSUserDefaults standardUserDefaults] objectForKey:kTBPref];
        _touchBarEnabled = v ? [v boolValue] : YES;
        _items = @[];
    }
    return self;
}

- (void)setTouchBarEnabled:(BOOL)on {
    _touchBarEnabled = on;
    [[NSUserDefaults standardUserDefaults] setBool:on forKey:kTBPref];
    if (!on) [self hideTouchBarNow]; else [self refreshTouchBar];
}

// ---- what to show
- (void)showChoices:(NSArray<NSString *> *)items selected:(NSInteger)sel { [self setItems:items next:NO selected:sel]; }
- (void)showNext:(NSArray<NSString *> *)items { [self setItems:items next:YES selected:-1]; }
- (void)clear { [self setItems:@[] next:YES selected:-1]; }

- (void)setItems:(NSArray<NSString *> *)items next:(BOOL)next selected:(NSInteger)sel {
    dispatch_async(dispatch_get_main_queue(), ^{
        self->_gen++;
        self->_items = items ?: @[];
        self->_isNext = next;
        self->_sel = sel;
        [[OSKPanel shared] setSuggestions:self->_items next:next selected:sel];
        [self refreshTouchBar];
    });
}

- (void)pickedFromKeyboard:(NSInteger)index isNext:(BOOL)isNext {
    if (self.onPick) self.onPick(index, isNext);
}

// ---- Touch Bar
- (BOOL)canUseTouchBar { return NSClassFromString(@"NSTouchBar") != nil; }

- (NSTouchBar *)buildBar {
    NSTouchBar *b = [[NSTouchBar alloc] init];
    b.delegate = self;
    _btns = [NSMutableArray new];
    NSMutableArray *ids = [NSMutableArray new];
    for (NSInteger i = 0; i < kMaxChips; i++) [ids addObject:[NSString stringWithFormat:@"sk.sug.%ld", (long)i]];
    b.defaultItemIdentifiers = ids;
    return b;
}

- (NSTouchBarItem *)touchBar:(NSTouchBar *)touchBar makeItemForIdentifier:(NSTouchBarItemIdentifier)identifier {
    if (![identifier hasPrefix:@"sk.sug."]) return nil;
    NSInteger i = [[identifier substringFromIndex:7] integerValue];
    NSCustomTouchBarItem *it = [[NSCustomTouchBarItem alloc] initWithIdentifier:identifier];
    NSButton *btn = [NSButton buttonWithTitle:@"" target:self action:@selector(chipTapped:)];
    btn.tag = i;
    btn.font = [NSFont systemFontOfSize:16];
    btn.title = (i < (NSInteger)_items.count) ? _items[i] : @"";
    btn.bezelColor = (!_isNext && i == _sel) ? [NSColor systemBlueColor] : nil;
    [btn setContentHuggingPriority:NSLayoutPriorityDefaultLow forOrientation:NSLayoutConstraintOrientationHorizontal];
    it.view = btn;
    while ((NSInteger)_btns.count <= i) [_btns addObject:(NSButton *)[NSNull null]];
    _btns[i] = btn;
    return it;
}

- (void)chipTapped:(NSButton *)b {
    if (b.tag >= 0 && b.tag < (NSInteger)_items.count) [self pickedFromKeyboard:b.tag isNext:_isNext];
}

- (void)refreshTouchBar {
    if (![self canUseTouchBar]) return;
    if (!_touchBarEnabled) return;
    if (_items.count == 0) {                       // nothing to show: close the bar after a short pause, unless something comes in meanwhile
        NSUInteger g = _gen;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (g == self->_gen && self->_items.count == 0) [self hideTouchBarNow];
        });
        return;
    }
    if (!_bar) _bar = [self buildBar];
    NSInteger n = MIN((NSInteger)_items.count, kMaxChips);
    NSMutableArray *ids = [NSMutableArray new];
    for (NSInteger i = 0; i < n; i++) [ids addObject:[NSString stringWithFormat:@"sk.sug.%ld", (long)i]];
    _bar.defaultItemIdentifiers = ids;
    for (NSInteger i = 0; i < n; i++) {
        NSButton *btn = (i < (NSInteger)_btns.count && [_btns[i] isKindOfClass:[NSButton class]]) ? _btns[i] : nil;
        if (!btn) continue;
        btn.title = _items[i];
        btn.bezelColor = (!_isNext && i == _sel) ? [NSColor systemBlueColor] : nil;
    }
    if (!_barShown) {
        Class c = [NSTouchBar class];
        if ([c respondsToSelector:@selector(presentSystemModalTouchBar:placement:systemTrayItemIdentifier:)]) {
            [NSTouchBar presentSystemModalTouchBar:_bar placement:1 systemTrayItemIdentifier:nil];
            _barShown = YES;
        } else if ([c respondsToSelector:@selector(presentSystemModalFunctionBar:placement:systemTrayItemIdentifier:)]) {
            [NSTouchBar presentSystemModalFunctionBar:_bar placement:1 systemTrayItemIdentifier:nil];
            _barShown = YES;
        }
    }
}

- (void)hideTouchBarNow {
    if (!_barShown || !_bar) return;
    Class c = [NSTouchBar class];
    if ([c respondsToSelector:@selector(dismissSystemModalTouchBar:)]) [NSTouchBar dismissSystemModalTouchBar:_bar];
    else if ([c respondsToSelector:@selector(dismissSystemModalFunctionBar:)]) [NSTouchBar dismissSystemModalFunctionBar:_bar];
    _barShown = NO;
}

@end
