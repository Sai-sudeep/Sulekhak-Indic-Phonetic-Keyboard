"""Extracts the rule tables and the built-in word list from engine.c / lexicon.inc so the JS twin uses the same data."""
import re, json, sys
src=open('engine.c',encoding='utf-8').read()
inc=open('lexicon.inc',encoding='utf-8').read()
macros={'HAL':'"\\xE0\\xAD\\x8D"','ZWNJ':'"\\xE2\\x80\\x8C"','NUKTA':'"\\xE0\\xAC\\xBC"'}
def lit(m):
    body=m.group(1); out=bytearray(); i=0
    while i<len(body):
        if body[i]=='\\' and body[i+1]=='x': out.append(int(body[i+2:i+4],16)); i+=4
        elif body[i]=='\\': out+=body[i+1].encode(); i+=2
        else: out+=body[i].encode('utf-8'); i+=1
    return json.dumps(out.decode('utf-8'),ensure_ascii=True)
def table(name):
    m=re.search(r'static const \w+ '+name+r'\[\] = \{(.*?)\n \{NULL',src,re.S)
    t=m.group(1)
    t=re.sub(r'/\*.*?\*/','',t,flags=re.S)
    for k,v in macros.items(): t=re.sub(r'\b'+k+r'\b',lambda _m,v=v:v,t)
    t=re.sub(r'"((?:[^"\\]|\\.)*)"',lit,t)
    t=t.replace('{','[').replace('}',']')
    return eval('['+t+']')
def suffixes():
    m=re.search(r'static const char \*SUFFIX\[\] = \{(.*?)NULL\}',src,re.S)
    return [json.loads(lit(x)) for x in re.finditer(r'"((?:[^"\\]|\\.)*)"',m.group(1))]
SUFFIX=suffixes()
WORDS=[json.loads(lit(x)) for x in re.finditer(r'"((?:[^"\\]|\\.)*)"',open('words.inc',encoding='utf-8').read().split('WORDS[] = {')[1])]
CONS=table('CONS'); VOW=table('VOW'); RAW=table('RAW')
BUILTIN=[[m.group(1),m.group(2),int(m.group(3))] for m in re.finditer(r'\{"(.*?)","(.*?)","(\d+)"\}',inc)]
json.dump({'CONS':CONS,'VOW':VOW,'RAW':RAW,'BUILTIN':BUILTIN,'SUFFIX':SUFFIX,'WORDS':WORDS},open('tables.json','w',encoding='utf-8'),ensure_ascii=False)
print(len(CONS),len(VOW),len(RAW),len(BUILTIN)); print(CONS[:2],VOW[:2],RAW[:5])

tpl=open('engine.tpl.js',encoding='utf-8').read()
open('engine.js','w',encoding='utf-8').write(tpl.replace('__TABLES__',json.dumps(json.load(open('tables.json',encoding='utf-8')),ensure_ascii=False)))
