#import <InputMethodKit/InputMethodKit.h>
@interface OdiaController : IMKInputController
+ (void)oskInsert:(NSString *)text;
+ (void)suggestPick:(NSInteger)i next:(BOOL)isNext;   // a suggestion was tapped     // text chosen on the on-screen keyboard
@end
