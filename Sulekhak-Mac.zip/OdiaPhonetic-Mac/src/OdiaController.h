#import <InputMethodKit/InputMethodKit.h>
@interface OdiaController : IMKInputController
+ (void)oskInsert:(NSString *)text;
+ (NSString *)clientSelectionOrWord;                    // the selected text of the program being typed in, else the word before the cursor (Add to Sulekhak Dictionary)
+ (void)suggestPick:(NSInteger)i next:(BOOL)isNext;   // a suggestion was tapped     // text chosen on the on-screen keyboard
@end
