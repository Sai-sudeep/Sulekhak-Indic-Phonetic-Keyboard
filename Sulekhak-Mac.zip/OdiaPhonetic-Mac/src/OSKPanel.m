#import "OSKPanel.h"
#import "OdiaController.h"
#import "SuggestBar.h"
#import "SKLearn.h"
#import <WebKit/WebKit.h>
#import <ApplicationServices/ApplicationServices.h>
#import <Carbon/Carbon.h>

// A web view that reacts to the very first click, so clicking a key never needs a "first click to activate".
@interface OSKWebView : WKWebView
@end
@implementation OSKWebView
- (BOOL)acceptsFirstMouse:(NSEvent *)event { return YES; }
- (BOOL)mouseDownCanMoveWindow { return NO; }

// The window is never the key window, so WebKit gets no mouse-move events of its own and the hover-to-see (the 3D ring of look-alike
// symbols on the Phonetic keyboard) would never show. A tracking area that works while the app is in the background reports the
// pointer instead, and the page's oskHoverAt(x, y) turns it into the mouseover / mouseout events its own code listens for.
- (void)updateTrackingAreas {
    for (NSTrackingArea *a in [self.trackingAreas copy]) if (a.owner == self) [self removeTrackingArea:a];
    NSTrackingAreaOptions o = NSTrackingMouseMoved | NSTrackingMouseEnteredAndExited | NSTrackingActiveAlways | NSTrackingInVisibleRect;
    [self addTrackingArea:[[NSTrackingArea alloc] initWithRect:self.bounds options:o owner:self userInfo:nil]];
    [super updateTrackingAreas];
}
- (void)mouseMoved:(NSEvent *)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    CGFloat z = 1;
    if (@available(macOS 11.0, *)) { if (self.pageZoom > 0) z = self.pageZoom; }
    CGFloat x = p.x / z, y = (self.isFlipped ? p.y : self.bounds.size.height - p.y) / z;     // page coordinates: top left origin, in CSS pixels
    [self evaluateJavaScript:[NSString stringWithFormat:@"window.oskHoverAt&&window.oskHoverAt(%.1f,%.1f)", x, y] completionHandler:nil];
}
- (void)mouseExited:(NSEvent *)event {
    [self evaluateJavaScript:@"window.oskHoverLeave&&window.oskHoverLeave()" completionHandler:nil];
}
@end

// The window never becomes the key or main window, so the program you are typing into keeps the keyboard focus.
@interface OSKWindow : NSPanel
@end
@implementation OSKWindow
- (BOOL)canBecomeKeyWindow { return NO; }
- (BOOL)canBecomeMainWindow { return NO; }
@end

@interface OSKPanel () <WKScriptMessageHandler, WKNavigationDelegate>
@end

static NSString *const kOskPrefs = @"SulekhakOskPrefs";
static NSString *gSugJS = nil;     // the strip as last sent, so a freshly loaded page can show it

@implementation OSKPanel {
    OSKWindow *_win;
    OSKWebView *_web;
    BOOL _loaded;
    NSPoint _dragMouse, _dragOrigin;
    BOOL _dragging, _askedAccess;
    CGFloat _baseW, _baseH, _zoom;     // the page's normal size and the zoom factor it asked for
}

+ (instancetype)shared {
    static OSKPanel *p; static dispatch_once_t once;
    dispatch_once(&once, ^{ p = [OSKPanel new]; });
    return p;
}

static BOOL gHotKeyOK = NO;
static OSStatus SKHotKeyHandler(EventHandlerCallRef next, EventRef ev, void *ud) {
    EventHotKeyID hid = { 0, 0 };
    GetEventParameter(ev, kEventParamDirectObject, typeEventHotKeyID, NULL, sizeof(hid), NULL, &hid);
    if (hid.signature != 'SKOS') return eventNotHandledErr;      // the script keys (signature 'SKSC') have their own handler
    UInt32 which = hid.id;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (which == 2) [[OSKPanel shared] zoomBy:0.1];
        else if (which == 3) [[OSKPanel shared] zoomBy:-0.1];
        else if (which == 4) [SKLearn addSelection];       // Ctrl+Option+D: Add to Sulekhak Dictionary
        else [[OSKPanel shared] toggle];
    });
    return noErr;
}

// Ctrl+Option+K as a system-wide hot key: it works in every program, with no Accessibility permission and whether or not a text box has the focus.
// Ctrl+Option+= and Ctrl+Option+- make the keyboard bigger / smaller from the keyboard, as a second way to the + and - buttons.
+ (void)installHotKey {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        EventTypeSpec spec = { kEventClassKeyboard, kEventHotKeyPressed };
        OSStatus a = InstallApplicationEventHandler(&SKHotKeyHandler, 1, &spec, NULL, NULL);
        EventHotKeyRef ref = NULL;
        EventHotKeyID h1 = { 'SKOS', 1 }, h2 = { 'SKOS', 2 }, h3 = { 'SKOS', 3 };
        OSStatus b = RegisterEventHotKey(kVK_ANSI_K, controlKey | optionKey, h1, GetApplicationEventTarget(), 0, &ref);
        EventHotKeyRef r2 = NULL, r3 = NULL;
        RegisterEventHotKey(kVK_ANSI_Equal, controlKey | optionKey, h2, GetApplicationEventTarget(), 0, &r2);
        RegisterEventHotKey(kVK_ANSI_Minus, controlKey | optionKey, h3, GetApplicationEventTarget(), 0, &r3);
        EventHotKeyID h4 = { 'SKOS', 4 }; EventHotKeyRef r4 = NULL;
        RegisterEventHotKey(kVK_ANSI_D, controlKey | optionKey, h4, GetApplicationEventTarget(), 0, &r4);      // Ctrl+Option+D: Add to Sulekhak Dictionary
        gHotKeyOK = (a == noErr && b == noErr);
    });
}
+ (BOOL)hotKeyActive { return gHotKeyOK; }

// ---- Ctrl+Option+1 ... 8 as system hot keys (only while Sulekhak is the selected keyboard) ----
// Some programs type the digit even when the keyboard says it took the key. A hot key is taken by the system before any program sees
// the key, so the digit can never be typed. The keys are registered only while Sulekhak is the selected input source and are given back
// the moment another keyboard is chosen, so every other input method keeps these keys exactly as it had them.
static EventHotKeyRef gScriptHK[8];
static BOOL gScriptHKOn = NO;
static const UInt32 kScriptHKCodes[8] = { 18, 19, 20, 21, 23, 22, 26, 28 };      // the number keys 1 2 3 4 5 6 7 8
static OSStatus SKScriptHotKeyHandler(EventHandlerCallRef next, EventRef ev, void *ud) {
    EventHotKeyID hid = { 0, 0 };
    GetEventParameter(ev, kEventParamDirectObject, typeEventHotKeyID, NULL, sizeof(hid), NULL, &hid);
    if (hid.signature != 'SKSC') return eventNotHandledErr;
    UInt32 code = hid.id;
    dispatch_async(dispatch_get_main_queue(), ^{ [OdiaController hotKeyScript:(unsigned short)code]; });
    return noErr;
}
static BOOL SKMySourceIsCurrent(void) {
    BOOL mine = NO;
    TISInputSourceRef src = TISCopyCurrentKeyboardInputSource();
    if (!src) return NO;
    NSString *me = [[NSBundle mainBundle] bundleIdentifier];
    CFStringRef bid = (CFStringRef)TISGetInputSourceProperty(src, kTISPropertyBundleID);
    CFStringRef sid = (CFStringRef)TISGetInputSourceProperty(src, kTISPropertyInputSourceID);
    if (me.length) {
        if (bid && [(__bridge NSString *)bid isEqualToString:me]) mine = YES;
        else if (sid && [(__bridge NSString *)sid hasPrefix:me]) mine = YES;
    }
    CFRelease(src);
    return mine;
}
static void SKSyncScriptHotKeys(void) {
    BOOL want = SKMySourceIsCurrent();
    if (want == gScriptHKOn) return;
    if (want) {
        for (int i = 0; i < 8; i++) { EventHotKeyID h = { 'SKSC', kScriptHKCodes[i] }; gScriptHK[i] = NULL; RegisterEventHotKey(kScriptHKCodes[i], controlKey | optionKey, h, GetApplicationEventTarget(), 0, &gScriptHK[i]); }
    } else {
        for (int i = 0; i < 8; i++) { if (gScriptHK[i]) UnregisterEventHotKey(gScriptHK[i]); gScriptHK[i] = NULL; }
    }
    gScriptHKOn = want;
}
static void SKSourceChangedCB(CFNotificationCenterRef c, void *o, CFNotificationName n, const void *obj, CFDictionaryRef info) {
    dispatch_async(dispatch_get_main_queue(), ^{ SKSyncScriptHotKeys(); });
}
+ (void)syncScriptHotKeys { SKSyncScriptHotKeys(); }
+ (void)installScriptHotKeys {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        EventTypeSpec spec = { kEventClassKeyboard, kEventHotKeyPressed };
        InstallApplicationEventHandler(&SKScriptHotKeyHandler, 1, &spec, NULL, NULL);
        CFNotificationCenterAddObserver(CFNotificationCenterGetDistributedCenter(), NULL, SKSourceChangedCB, kTISNotifySelectedKeyboardInputSourceChanged, NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
        SKSyncScriptHotKeys();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ SKSyncScriptHotKeys(); });
    });
}

- (BOOL)isVisible { return _win != nil && _win.isVisible; }

- (void)build {
    if (_win) return;
    NSRect scr = [NSScreen mainScreen].visibleFrame;
    NSRect fr = NSMakeRect(NSMidX(scr) - 410, scr.origin.y + 16, 820, 376);
    _win = [[OSKWindow alloc] initWithContentRect:fr
                                        styleMask:NSWindowStyleMaskBorderless | NSWindowStyleMaskNonactivatingPanel
                                          backing:NSBackingStoreBuffered defer:NO];
    _win.level = NSFloatingWindowLevel;
    _win.opaque = YES;
    _win.backgroundColor = [NSColor colorWithCalibratedRed:29/255.0 green:35/255.0 blue:49/255.0 alpha:1];
    _win.hasShadow = YES;
    _win.hidesOnDeactivate = NO;
    _win.releasedWhenClosed = NO;
    _win.becomesKeyOnlyIfNeeded = YES;
    _win.collectionBehavior = NSWindowCollectionBehaviorCanJoinAllSpaces | NSWindowCollectionBehaviorFullScreenAuxiliary;

    WKWebViewConfiguration *cfg = [WKWebViewConfiguration new];
    [cfg.userContentController addScriptMessageHandler:self name:@"osk"];
    _web = [[OSKWebView alloc] initWithFrame:NSMakeRect(0, 0, fr.size.width, fr.size.height) configuration:cfg];
    _web.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _web.navigationDelegate = self;
    _win.contentView = _web;

    NSURL *page = [[NSBundle mainBundle] URLForResource:@"osk" withExtension:@"html"];
    if (page) [_web loadFileURL:page allowingReadAccessToURL:[page URLByDeletingLastPathComponent]];
}

- (void)toggle {
    [self build];
    if (_win.isVisible) { [_win orderOut:nil]; return; }
    [_win orderFrontRegardless];
    [self refreshScript];
    [self checkAccess];
}

// Typing from the on-screen keyboard works by sending key presses, which macOS only allows with the Accessibility permission.
- (void)checkAccess {
    if (AXIsProcessTrusted()) return;
    if (_askedAccess) return;
    _askedAccess = YES;
    NSDictionary *opts = @{(__bridge id)kAXTrustedCheckOptionPrompt: @YES};
    AXIsProcessTrustedWithOptions((__bridge CFDictionaryRef)opts);
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    _loaded = YES;
    if (gSugJS) [webView evaluateJavaScript:gSugJS completionHandler:nil];
    NSString *p = [[NSUserDefaults standardUserDefaults] stringForKey:kOskPrefs];
    if (p.length) [webView evaluateJavaScript:[NSString stringWithFormat:@"window.oskPrefs && window.oskPrefs(%@)", p] completionHandler:nil];
    [self refreshScript];
}

// The key legends follow the selected language: 0 Odia, 1 Devanagari, 2 Bangla, 4 Phonetic, 5 Assamese (+ the Devanagari options).
- (void)refreshScript {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    [d synchronize];
    NSInteger sc = [d integerForKey:@"LekhaniScript"], op = [d integerForKey:@"LekhaniDevOpts"] & 3;
    if (_web && _loaded) [_web evaluateJavaScript:[NSString stringWithFormat:@"window.oskScript && window.oskScript(%ld,%ld)", (long)sc, (long)op] completionHandler:nil];
}

// ---- suggested words (the strip above the keys)
- (void)setSuggestions:(NSArray<NSString *> *)items next:(BOOL)next selected:(NSInteger)sel {
    NSDictionary *o = @{@"kind": next ? @"n" : @"c", @"items": items ?: @[], @"sel": @(MAX(sel, 0))};
    NSData *d = [NSJSONSerialization dataWithJSONObject:o options:0 error:nil];
    if (!d) return;
    gSugJS = [NSString stringWithFormat:@"window.oskSuggest && window.oskSuggest(%@)", [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding]];
    if (_web && _loaded && _win.isVisible) [_web evaluateJavaScript:gSugJS completionHandler:nil];
}

// ---- key presses
static CGKeyCode KeyCodeFor(NSString *k) {
    static NSDictionary *map;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        map = @{@"a":@0, @"s":@1, @"d":@2, @"f":@3, @"h":@4, @"g":@5, @"z":@6, @"x":@7, @"c":@8, @"v":@9, @"b":@11, @"q":@12, @"w":@13,
                @"e":@14, @"r":@15, @"y":@16, @"t":@17, @"1":@18, @"2":@19, @"3":@20, @"4":@21, @"6":@22, @"5":@23, @"=":@24, @"9":@25,
                @"7":@26, @"-":@27, @"8":@28, @"0":@29, @"]":@30, @"o":@31, @"u":@32, @"[":@33, @"i":@34, @"p":@35, @"l":@37, @"j":@38,
                @"'":@39, @"k":@40, @";":@41, @"\\":@42, @",":@43, @"/":@44, @"n":@45, @"m":@46, @".":@47, @"`":@50, @" ":@49,
                @"Enter":@36, @"Tab":@48, @"Backspace":@51, @"Escape":@53, @"Delete":@117, @"ArrowLeft":@123, @"ArrowRight":@124,
                @"ArrowDown":@125, @"ArrowUp":@126, @"PageUp":@116, @"PageDown":@121};
    });
    NSNumber *n = map[k];
    return n ? (CGKeyCode)n.intValue : (CGKeyCode)0xFFFF;
}

static void PostKey(CGKeyCode kc, BOOL shift) {
    CGEventSourceRef src = CGEventSourceCreate(kCGEventSourceStateHIDSystemState);
    CGEventRef down = CGEventCreateKeyboardEvent(src, kc, true);
    CGEventRef up = CGEventCreateKeyboardEvent(src, kc, false);
    if (down && up) {
        if (shift) { CGEventSetFlags(down, kCGEventFlagMaskShift); CGEventSetFlags(up, kCGEventFlagMaskShift); }
        CGEventPost(kCGHIDEventTap, down);
        CGEventPost(kCGHIDEventTap, up);
    }
    if (down) CFRelease(down);
    if (up) CFRelease(up);
    if (src) CFRelease(src);
}

- (void)pressKey:(NSString *)k base:(NSString *)base {
    if (k.length == 0) return;
    if (!AXIsProcessTrusted()) { _askedAccess = NO; [self checkAccess]; return; }
    NSString *id_ = base.length ? base : k;
    CGKeyCode kc = KeyCodeFor(id_);
    if (kc == 0xFFFF) kc = KeyCodeFor(k);
    if (kc == 0xFFFF) return;                       // modifier keys and the like
    BOOL shift = (id_.length == 1 && ![id_ isEqualToString:k]);
    PostKey(kc, shift);
}

// Zoom is done here, not in the page: the page reports its normal size (w x h) and the zoom it wants. The web view is scaled with pageZoom and the window is made
// w*z by h*z, grown around its middle with the bottom edge fixed, and never larger than the screen (the zoom is reduced if it would not fit).
- (void)applyBaseW:(CGFloat)w h:(CGFloat)h zoom:(CGFloat)z {
    if (!_win || !_web) return;
    _baseW = w; _baseH = h; _zoom = z;
    NSRect f = _win.frame;
    NSRect cr = [_win contentRectForFrameRect:f];
    CGFloat dw = f.size.width - cr.size.width, dh = f.size.height - cr.size.height;
    NSScreen *scr = _win.screen ?: [NSScreen mainScreen];
    NSRect vis = scr.visibleFrame;
    CGFloat fit = MIN((vis.size.width - dw) / w, (vis.size.height - dh) / h);
    CGFloat ez = MAX(0.4, MIN(z, fit));
    if (@available(macOS 11.0, *)) _web.pageZoom = ez;
    CGFloat nw = round(w * ez + dw), nh = round(h * ez + dh);
    NSRect nf = NSMakeRect(NSMidX(f) - nw / 2, f.origin.y, nw, nh);
    nf.origin.x = MAX(NSMinX(vis), MIN(nf.origin.x, NSMaxX(vis) - nw));
    nf.origin.y = MAX(NSMinY(vis), MIN(nf.origin.y, NSMaxY(vis) - nh));
    [_win setFrame:nf display:YES animate:NO];
    NSLog(@"Sulekhak OSK: size base %.0fx%.0f zoom %.2f (used %.2f) -> window %.0fx%.0f", w, h, z, ez, nw, nh);
}

// Bigger / smaller from the menu or the hot keys.
- (void)zoomBy:(double)d {
    [self build];
    if (!_win.isVisible) { [_win orderFrontRegardless]; [self checkAccess]; }
    if (!_loaded) return;
    [_web evaluateJavaScript:[NSString stringWithFormat:@"window.oskZoomBy && window.oskZoomBy(%g)", d] completionHandler:nil];
}

// ---- messages from the page
- (void)userContentController:(WKUserContentController *)ucc didReceiveScriptMessage:(WKScriptMessage *)message {
    if (![message.body isKindOfClass:[NSString class]]) return;
    NSData *data = [(NSString *)message.body dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *m = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if (![m isKindOfClass:[NSDictionary class]]) return;
    NSString *t = m[@"t"];
    if (![t isEqualToString:@"drag"]) NSLog(@"Sulekhak OSK message: %@", t);
    if ([t isEqualToString:@"key"]) {
        [self pressKey:m[@"k"] base:m[@"id"]];
    } else if ([t isEqualToString:@"text"]) {
        NSString *tx = m[@"s"];
        if ([tx isKindOfClass:[NSString class]] && tx.length) [OdiaController oskInsert:tx];     // works without the Accessibility permission: it goes straight to the input method
    } else if ([t isEqualToString:@"size"]) {
        CGFloat w = [m[@"w"] doubleValue], h = [m[@"h"] doubleValue], z = m[@"z"] ? [m[@"z"] doubleValue] : 1;
        if (z < 0.5 || z > 2) z = 1;
        if (w > 100 && h > 60) dispatch_async(dispatch_get_main_queue(), ^{ [self applyBaseW:w h:h zoom:z]; });
    } else if ([t isEqualToString:@"sug"]) {
        [[SuggestBar shared] pickedFromKeyboard:[m[@"i"] integerValue] isNext:[m[@"kind"] isEqualToString:@"n"]];
    } else if ([t isEqualToString:@"dict"]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [SKLearn addSelection]; });        // the + button of the keyboard
    } else if ([t isEqualToString:@"hide"]) {
        [_win orderOut:nil];
    } else if ([t isEqualToString:@"drag"]) {
        int s = [m[@"s"] intValue];
        if (s == 1) { _dragging = YES; _dragMouse = [NSEvent mouseLocation]; _dragOrigin = _win.frame.origin; }
        else if (s == 2 && _dragging) {
            NSPoint c = [NSEvent mouseLocation];
            [_win setFrameOrigin:NSMakePoint(_dragOrigin.x + c.x - _dragMouse.x, _dragOrigin.y + c.y - _dragMouse.y)];
        } else _dragging = NO;
    } else if ([t isEqualToString:@"pref"]) {
        NSDictionary *p = @{@"dev": m[@"dev"] ?: @"auto", @"lay": m[@"lay"] ?: @"full", @"zoom": m[@"zoom"] ?: @1};
        NSData *pd = [NSJSONSerialization dataWithJSONObject:p options:0 error:nil];
        if (pd) [[NSUserDefaults standardUserDefaults] setObject:[[NSString alloc] initWithData:pd encoding:NSUTF8StringEncoding] forKey:kOskPrefs];
    }
}

@end
