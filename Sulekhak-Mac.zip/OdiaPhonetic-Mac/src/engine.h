// Odia phonetic engine (pure C, no platform dependencies).
#ifndef ODIA_ENGINE_H
#define ODIA_ENGINE_H
#include <stddef.h>
#define ODIA_MAX_CANDS 64   /* whole ranked list; the UI shows ODIA_PAGE at a time */
#define ODIA_PAGE 9
#define ODIA_CAND_LEN 256
// Primary transliteration of a Roman string into Odia (UTF-8).
void odia_transliterate(const char *roman, char *out, size_t cap);
// Fill cands[0..n) with up to ODIA_MAX_CANDS suggestions; returns n.
//  [0] best Odia   [1] the text exactly as typed (always position 2)   [2..] other choices
// For an all-digit input: [0] Odia digits, [1] ASCII digits.
int odia_candidates(const char *roman, char cands[][ODIA_CAND_LEN]);
// Dictionary: add or boost a word. weight>0. Used for the bundled list, the user's file, and learning.
void odia_lex_add(const char *roman, const char *odia, int weight);
void odia_lex_clear(void);
void odia_load_builtin(void);
// Consonant-skeleton dictionary (skel.dat): lets pasnd find ପସନ୍ଦ. Optional; without it the engine works as before.
void odia_load_skel(const char *data, size_t len);
// Output scripts. The engine thinks in Odia; odia_convert() carries a finished Odia string into another script.
//  script: 0 Odia (copy), 1 Devanagari, 2 Bangla, 5 Assamese.   opts: bit 1 = Marathi (ଳ -> ळ, else ल), bit 2 = anusvara (conjuncts disabled: कुण्डल -> कुंडल).
#define ODIA_SCRIPT_ODIA 0
#define ODIA_SCRIPT_DEVA 1
#define ODIA_SCRIPT_BENG 2
#define ODIA_SCRIPT_ASM 5      // Assamese: Bengali block with ৰ ৱ; the typing reads v and w as ৱ and x as s (odia_candidates_in)
#define ODIA_OPT_MARATHI 1
#define ODIA_OPT_ANUSVARA 2
void odia_convert(const char *odia, int script, int opts, char *out, size_t cap);
int odia_candidates_in(const char *roman, int script, char cands[][ODIA_CAND_LEN]);
// Any Indic string (Devanagari / Bangla / Odia) back to Odia, so a word picked in another script can be learned.
void odia_to_odia(const char *any, char *out, size_t cap);
#endif
