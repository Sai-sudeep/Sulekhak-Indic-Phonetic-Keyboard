#import "SKPersonal.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import <Cocoa/Cocoa.h>
#import <CommonCrypto/CommonDigest.h>
#import <Security/Security.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>
#include <unistd.h>
#import "SKEngine.h"
#include "engine.h"

#ifndef SK_PERSONAL
#define SK_PERSONAL 0
#endif

static void PLog(NSString *s) { NSLog(@"Sulekhak: %@", s); }
static NSString *B64Url(NSData *d) {
    NSString *s = [d base64EncodedStringWithOptions:0];
    s = [[s stringByReplacingOccurrencesOfString:@"+" withString:@"-"] stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    while ([s hasSuffix:@"="]) s = [s substringToIndex:s.length - 1];
    return s;
}
static NSData *RandomBytes(NSUInteger n) { NSMutableData *d = [NSMutableData dataWithLength:n]; SecRandomCopyBytes(kSecRandomDefault, n, d.mutableBytes); return d; }
static NSString *Enc(NSString *s) {
    NSMutableCharacterSet *ok = [NSMutableCharacterSet alphanumericCharacterSet]; [ok addCharactersInString:@"-._~"];
    return [s stringByAddingPercentEncodingWithAllowedCharacters:ok] ?: @"";
}
static NSString *Form(NSDictionary<NSString *, NSString *> *d) {
    NSMutableArray *a = [NSMutableArray new];
    for (NSString *k in d) [a addObject:[NSString stringWithFormat:@"%@=%@", Enc(k), Enc(d[k])]];
    return [a componentsJoinedByString:@"&"];
}

@implementation SKPersonal {
    dispatch_queue_t _q;
    JSContext *_js;
    BOOL _started, _enLoading, _enReady, _wantEnglish;
    int _script, _opts;
    NSString *_dir, *_did, *_state, *_detail;
    NSMutableDictionary<NSNumber *, dispatch_source_t> *_timers;
    NSMutableDictionary<NSNumber *, JSValue *> *_timerFns;
    int _timerSeq;
    // Google
    NSString *_clientId, *_clientSecret, *_refresh, *_access, *_email;
    NSArray<NSString *> *_allowed;
    NSDate *_accessExp;
    BOOL _signingIn;
}

+ (instancetype)shared { static SKPersonal *s; static dispatch_once_t o; dispatch_once(&o, ^{ s = [SKPersonal new]; }); return s; }
- (instancetype)init {
    if ((self = [super init])) {
        _q = dispatch_queue_create("sulekhak.personal", DISPATCH_QUEUE_SERIAL);
        _timers = [NSMutableDictionary new]; _timerFns = [NSMutableDictionary new];
        _script = 0; _state = @"off"; _detail = @"";
        NSString *sup = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES).firstObject;
        _dir = [sup stringByAppendingPathComponent:@"Sulekhak"];
        [[NSFileManager defaultManager] createDirectoryAtPath:[_dir stringByAppendingPathComponent:@"learning"] withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return self;
}

#pragma mark small things
- (NSString *)res:(NSString *)rel { return [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:rel]; }
- (NSString *)readRes:(NSString *)rel { return [NSString stringWithContentsOfFile:[self res:rel] encoding:NSUTF8StringEncoding error:nil]; }
- (NSString *)langFile:(NSString *)lang { return [[[_dir stringByAppendingPathComponent:@"learning"] stringByAppendingPathComponent:lang] stringByAppendingString:@".json"]; }
static BOOL GoodLang(NSString *l) { return [@[@"or", @"hi", @"mr", @"bn", @"as", @"en"] containsObject:l]; }
- (NSString *)jsonString:(id)o { NSData *d = [NSJSONSerialization dataWithJSONObject:o options:0 error:nil]; return d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : @"null"; }
- (BOOL)signInAvailable { return SK_PERSONAL && _clientId.length && _clientSecret.length; }
- (BOOL)signedIn { return _refresh.length > 0; }
- (NSString *)email { return _email; }
- (BOOL)englishReady { return _enReady; }
- (NSString *)statusLine {
    if (!SK_PERSONAL) return @"English learning: on this Mac only";
    if (!self.signInAvailable) return @"Sign-in: not set up in this build";
    if (_signingIn) return @"Sign-in: waiting for the browser…";
    if (!self.signedIn) return @"Sign-in: not signed in";
    NSString *d = _detail.length ? [@" · " stringByAppendingString:_detail] : @"";
    if ([_state isEqualToString:@"error"]) return [NSString stringWithFormat:@"Signed in as %@ · sync problem%@", _email, d];
    if ([_state isEqualToString:@"refused"]) return @"Sign-in: this account is not allowed";
    return [NSString stringWithFormat:@"Signed in as %@ · %@%@", _email, [_state isEqualToString:@"syncing"] ? @"syncing…" : [_state isEqualToString:@"synced"] ? @"synced" : @"ready", [_state isEqualToString:@"synced"] ? d : @""];
}

#pragma mark start
- (void)startIfNeeded {
    @synchronized (self) { if (_started) return; _started = YES; }
    dispatch_async(_q, ^{ [self boot]; });
}

- (void)loadConfig {
    NSString *cfg = [self readRes:@"personal-config.json"];
    if (!cfg.length) return;
    NSDictionary *c = [NSJSONSerialization JSONObjectWithData:[cfg dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
    if (![c isKindOfClass:[NSDictionary class]]) return;
    _clientId = c[@"clientId"]; _clientSecret = c[@"clientSecret"];
    NSMutableArray *al = [NSMutableArray new];
    for (NSString *e in c[@"allowed"] ?: @[]) [al addObject:[[e lowercaseString] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]];
    _allowed = al;
}
- (void)loadToken {
    NSData *d = [NSData dataWithContentsOfFile:[_dir stringByAppendingPathComponent:@"google.tok"]];
    if (!d) return;
    NSDictionary *o = [NSJSONSerialization JSONObjectWithData:d options:0 error:nil];
    if ([o isKindOfClass:[NSDictionary class]]) { _refresh = o[@"r"]; _email = o[@"e"]; }
}
- (void)saveToken {
    NSString *f = [_dir stringByAppendingPathComponent:@"google.tok"];
    if (!_refresh.length) { [[NSFileManager defaultManager] removeItemAtPath:f error:nil]; return; }
    NSData *d = [NSJSONSerialization dataWithJSONObject:@{ @"r": _refresh, @"e": _email ?: @"" } options:0 error:nil];
    [d writeToFile:f atomically:YES];
    [[NSFileManager defaultManager] setAttributes:@{ NSFilePosixPermissions: @(0600) } ofItemAtPath:f error:nil];     // you only
}

- (void)boot {
    if (SK_PERSONAL) { [self loadConfig]; [self loadToken]; }
    NSString *idf = [_dir stringByAppendingPathComponent:@"device.id"];
    _did = [[NSString stringWithContentsOfFile:idf encoding:NSUTF8StringEncoding error:nil] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (_did.length < 3) { _did = [@"m" stringByAppendingString:[[[NSUUID UUID].UUIDString stringByReplacingOccurrencesOfString:@"-" withString:@""].lowercaseString substringToIndex:8]]; [_did writeToFile:idf atomically:YES encoding:NSUTF8StringEncoding error:nil]; }

    _js = [[JSContext alloc] init];
    _js.exceptionHandler = ^(JSContext *c, JSValue *e) { PLog([NSString stringWithFormat:@"js: %@", e]); };
    __weak SKPersonal *ws = self;
    _js[@"__log"] = ^(NSString *s) { PLog(s); };
    _js[@"__timer"] = ^NSNumber *(JSValue *fn, int ms, BOOL rep) { return [ws addTimer:fn ms:ms repeat:rep]; };
    _js[@"__untimer"] = ^(NSNumber *id_) { [ws removeTimer:id_]; };
    _js[@"__fetch"] = ^(NSString *method, NSString *url, NSString *hdrs, id body, JSValue *done) { [ws fetch:method url:url headers:hdrs body:body done:done]; };
    _js[@"__post"] = ^(NSString *json) { NSString *j = [json copy]; SKPersonal *me = ws; if (!me) return; dispatch_async(me->_q, ^{ [me hostMessage:j]; }); };
    _js[@"__learnAdd"] = ^(NSString *json) { [ws learnAdd:json]; };
    for (NSString *f in @[@"personal/prelude.js", @"personal/english.js", @"personal/learning.js", @"personal/drive.js", @"personal/personal.js", @"personal/host.js"]) {
        NSString *src = [self readRes:f];
        if (!src.length) { PLog([@"missing " stringByAppendingString:f]); _js = nil; return; }
        [_js evaluateScript:src withSourceURL:[NSURL fileURLWithPath:f]];
    }
    NSString *allowed = [self jsonString:_allowed ?: @[]];
    [[_js[@"SKM"] objectForKeyedSubscript:@"init"] callWithArguments:@[_did, [NSString stringWithFormat:@"Mac (%@)", NSUserName()], allowed]];
    [self applyMode];
    if (self.signedIn && self.signInAvailable) {            // signed in earlier: get a token now, which also starts the first sync
        [self accessToken:^(NSString *a, int secs) {
            if (a) [[self->_js[@"SKM"] objectForKeyedSubscript:@"setToken"] callWithArguments:@[a, @(secs), self->_email ?: @""]];
        }];
    }
    if (_wantEnglish) [self loadEnglish];
}

- (void)applyMode {
    if (!_js) return;
    [[_js[@"SKM"] objectForKeyedSubscript:@"setMode"] callWithArguments:@[@(_script == 6 ? 0 : _script), @(_opts), @(_script == 6)]];
}
- (void)setScript:(int)script options:(int)opts {
    [self startIfNeeded];
    dispatch_async(_q, ^{
        self->_script = script; self->_opts = opts;
        if (script == 6) { self->_wantEnglish = YES; [self loadEnglish]; }
        [self applyMode];
    });
}

- (void)loadEnglish {            // on _q
    if (!_js || _enReady || _enLoading) return;
    _enLoading = YES;
    NSString *lex = [self readRes:@"sulekhak/en/en_lex.txt"], *ng = [self readRes:@"sulekhak/en/en_ng.txt"], *fix = [self readRes:@"sulekhak/en/en_fix.txt"];
    if (!lex.length || !ng.length) { PLog(@"English data missing"); _enLoading = NO; return; }
    JSValue *ok = [[_js[@"SKM"] objectForKeyedSubscript:@"enLoad"] callWithArguments:@[lex, ng, fix ?: @""]];
    _enReady = ok.toBool; _enLoading = NO;
    PLog(_enReady ? @"English ready" : @"English failed to load");
}

#pragma mark English
- (BOOL)englishQuery:(NSString *)typed previous:(NSString *)prev list:(NSArray<NSString *> **)list autoCorrected:(BOOL *)autoCorrected {
    if (!_enReady) { [self startIfNeeded]; dispatch_async(_q, ^{ self->_wantEnglish = YES; [self loadEnglish]; }); return NO; }
    __block NSString *res = nil;
    dispatch_sync(_q, ^{ res = [[self->_js[@"SKM"] objectForKeyedSubscript:@"enQuery"] callWithArguments:@[typed, prev ?: @""]].toString; });
    if (!res.length || [res isEqualToString:@"null"] || [res isEqualToString:@"undefined"]) return NO;
    NSDictionary *o = [NSJSONSerialization JSONObjectWithData:[res dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
    if (![o isKindOfClass:[NSDictionary class]] || ![o[@"list"] isKindOfClass:[NSArray class]]) return NO;
    if (list) *list = o[@"list"];
    if (autoCorrected) *autoCorrected = [o[@"auto"] boolValue];
    return YES;
}
- (void)englishCommitTyped:(NSString *)typed word:(NSString *)word previous:(NSString *)prev how:(NSString *)how passedOver:(NSString *)passed {
    if (!_started || !word.length) return;
    NSString *t = [typed copy] ?: @"", *w = [word copy], *p = [prev copy] ?: @"", *h = [how copy] ?: @"typed", *ps = [passed copy] ?: @"";
    dispatch_async(_q, ^{ [[self->_js[@"SKM"] objectForKeyedSubscript:@"enCommit"] callWithArguments:@[t, w, p, h, ps]]; });
}
- (void)noteOdiaPick:(NSString *)roman word:(NSString *)odia previous:(NSString *)prevOdia {
    if (!SK_PERSONAL || !roman.length || !odia.length) return;
    [self startIfNeeded];
    NSString *r = [roman copy], *w = [odia copy], *p = [prevOdia copy] ?: @"";
    dispatch_async(_q, ^{ [[self->_js[@"SKM"] objectForKeyedSubscript:@"pick"] callWithArguments:@[r, w, p]]; });
}
- (void)learnAdd:(NSString *)json {          // history that came from another device: [[roman, odiaWord], ...], into the engine on the main thread
    NSArray *a = [NSJSONSerialization JSONObjectWithData:[json dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
    if (![a isKindOfClass:[NSArray class]] || !a.count) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        for (NSArray *p in a) {
            if (![p isKindOfClass:[NSArray class]] || p.count < 2 || ![p[0] length] || ![p[1] length]) continue;
            odia_lex_add([p[0] UTF8String], [p[1] UTF8String], 3);
            [[SKEngine shared] commit:p[1]];
        }
    });
}

#pragma mark what the JavaScript asks for
- (NSNumber *)addTimer:(JSValue *)fn ms:(int)ms repeat:(BOOL)rep {         // on _q
    NSNumber *tid = @(++_timerSeq);
    dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, _q);
    uint64_t ns = (uint64_t)MAX(ms, 1) * NSEC_PER_MSEC;
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, ns), rep ? ns : DISPATCH_TIME_FOREVER, ns / 10);
    _timers[tid] = t; _timerFns[tid] = fn;
    __weak SKPersonal *ws = self;
    dispatch_source_set_event_handler(t, ^{
        SKPersonal *me = ws; if (!me) return;
        JSValue *f = me->_timerFns[tid];
        if (!rep) [me removeTimer:tid];
        [f callWithArguments:@[]];
    });
    dispatch_resume(t);
    return tid;
}
- (void)removeTimer:(NSNumber *)tid {
    dispatch_source_t t = _timers[tid];
    if (t) { dispatch_source_cancel(t); [_timers removeObjectForKey:tid]; }
    [_timerFns removeObjectForKey:tid];
}
- (void)fetch:(NSString *)method url:(NSString *)url headers:(NSString *)hdrs body:(id)body done:(JSValue *)done {
    NSURL *u = [NSURL URLWithString:url];
    if (!u || ![u.scheme isEqualToString:@"https"] || ![u.host hasSuffix:@"googleapis.com"]) {         // the sync code only ever talks to Google's Drive API
        dispatch_async(_q, ^{ [done callWithArguments:@[@0, @"{}", @""]]; });
        return;
    }
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:u cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:60];
    r.HTTPMethod = method;
    NSDictionary *h = [NSJSONSerialization JSONObjectWithData:[(hdrs ?: @"{}") dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
    for (NSString *k in h) [r setValue:[NSString stringWithFormat:@"%@", h[k]] forHTTPHeaderField:k];
    if ([body isKindOfClass:[NSString class]]) r.HTTPBody = [(NSString *)body dataUsingEncoding:NSUTF8StringEncoding];
    [[[NSURLSession sharedSession] dataTaskWithRequest:r completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
        NSHTTPURLResponse *hr = [resp isKindOfClass:[NSHTTPURLResponse class]] ? (NSHTTPURLResponse *)resp : nil;
        NSString *text = data ? ([[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ?: @"") : @"";
        NSMutableDictionary *hd = [NSMutableDictionary new];
        for (id k in hr.allHeaderFields) hd[[NSString stringWithFormat:@"%@", k]] = [NSString stringWithFormat:@"%@", hr.allHeaderFields[k]];
        NSString *hj = [self jsonString:hd];
        NSInteger st = hr ? hr.statusCode : 0;
        dispatch_async(self->_q, ^{ [done callWithArguments:@[@(st), hj, text]]; });
    }] resume];
}

- (void)hostMessage:(NSString *)json {         // on _q: what personal.js posts
    NSDictionary *m = [NSJSONSerialization JSONObjectWithData:[json dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
    if (![m isKindOfClass:[NSDictionary class]]) return;
    NSString *t = m[@"t"], *lang = m[@"lang"];
    if ([t isEqualToString:@"sk-need"]) {
        NSString *text = GoodLang(lang) ? ([NSString stringWithContentsOfFile:[self langFile:lang] encoding:NSUTF8StringEncoding error:nil] ?: @"") : @"";
        [[_js[@"SKM"] objectForKeyedSubscript:@"hostLoad"] callWithArguments:@[lang ?: @"", text]];
    } else if ([t isEqualToString:@"sk-save"]) {
        NSString *text = m[@"text"];
        if (!GoodLang(lang) || !text.length) return;
        NSString *f = [self langFile:lang], *tmp = [f stringByAppendingString:@".tmp"];
        if ([text writeToFile:tmp atomically:NO encoding:NSUTF8StringEncoding error:nil]) {
            NSFileManager *fm = [NSFileManager defaultManager];
            if ([fm fileExistsAtPath:f]) { [fm removeItemAtPath:[f stringByAppendingString:@".bak"] error:nil]; [fm copyItemAtPath:f toPath:[f stringByAppendingString:@".bak"] error:nil]; [fm removeItemAtPath:f error:nil]; }
            [fm moveItemAtPath:tmp toPath:f error:nil];
        }
    } else if ([t isEqualToString:@"sk-token"]) {
        [self accessToken:^(NSString *a, int secs) {
            JSValue *skm = self->_js[@"SKM"];
            if (a) [[skm objectForKeyedSubscript:@"setToken"] callWithArguments:@[a, @(secs), self->_email ?: @""]];
            else [[skm objectForKeyedSubscript:@"signedOut"] callWithArguments:@[]];
        }];
    } else if ([t isEqualToString:@"sk-state"]) {
        [self setStateOnQueue:m[@"state"] ?: @"" detail:m[@"detail"] ?: @""];
    } else if ([t isEqualToString:@"sk-signout"]) {
        [self forgetToken];
    }
}
- (void)setStateOnQueue:(NSString *)s detail:(NSString *)d { _state = s; _detail = d; }

#pragma mark Google (personal build)
- (void)tokenRequest:(NSDictionary *)form done:(void (^)(NSDictionary *tok, NSString *err))done {
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://oauth2.googleapis.com/token"] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:30];
    r.HTTPMethod = @"POST";
    [r setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    r.HTTPBody = [Form(form) dataUsingEncoding:NSUTF8StringEncoding];
    [[[NSURLSession sharedSession] dataTaskWithRequest:r completionHandler:^(NSData *d, NSURLResponse *resp, NSError *err) {
        NSInteger st = [(NSHTTPURLResponse *)resp statusCode];
        NSString *body = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : @"";
        NSDictionary *o = d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
        if (st == 200 && [o isKindOfClass:[NSDictionary class]] && o[@"access_token"]) done(o, nil);
        else done(nil, err ? err.localizedDescription : (body ?: @"no answer"));
    }] resume];
}
static NSString *EmailFromIdToken(NSString *jwt) {
    NSArray *p = [jwt componentsSeparatedByString:@"."];
    if (p.count < 2) return nil;
    NSString *s = [[p[1] stringByReplacingOccurrencesOfString:@"-" withString:@"+"] stringByReplacingOccurrencesOfString:@"_" withString:@"/"];
    while (s.length % 4) s = [s stringByAppendingString:@"="];
    NSData *d = [[NSData alloc] initWithBase64EncodedString:s options:0];
    NSDictionary *o = d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
    if (![o isKindOfClass:[NSDictionary class]]) return nil;
    if (o[@"email_verified"] && ![o[@"email_verified"] boolValue]) return nil;
    return [(NSString *)o[@"email"] lowercaseString];
}
- (BOOL)isAllowed:(NSString *)mail { return mail.length && [_allowed containsObject:mail.lowercaseString]; }

/// a valid access token (refreshing when it runs out), on _q: done(token, seconds) or done(nil, 0) when signed out
- (void)accessToken:(void (^)(NSString *tok, int secs))done {
    if (!self.signedIn || !self.signInAvailable) { done(nil, 0); return; }
    if (_access && _accessExp && [_accessExp timeIntervalSinceNow] > 120) { done(_access, (int)[_accessExp timeIntervalSinceNow]); return; }
    [self tokenRequest:@{ @"client_id": _clientId, @"client_secret": _clientSecret, @"refresh_token": _refresh, @"grant_type": @"refresh_token" } done:^(NSDictionary *t, NSString *err) {
        dispatch_async(self->_q, ^{
            if (!t) {
                if ([err containsString:@"invalid_grant"]) [self forgetToken];     // expired (Google ends test-mode tokens after 7 days) or revoked: sign in again
                done(nil, 0); return;
            }
            self->_access = t[@"access_token"]; int secs = [t[@"expires_in"] intValue] ?: 3000;
            self->_accessExp = [NSDate dateWithTimeIntervalSinceNow:secs];
            done(self->_access, secs);
        });
    }];
}
- (void)forgetToken {                        // on _q
    NSString *r = _refresh;
    _refresh = nil; _access = nil; _email = nil; _accessExp = nil;
    [self saveToken];
    if (r.length && self.signInAvailable) {
        NSMutableURLRequest *q = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://oauth2.googleapis.com/revoke"]];
        q.HTTPMethod = @"POST"; [q setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"]; q.HTTPBody = [Form(@{ @"token": r }) dataUsingEncoding:NSUTF8StringEncoding];
        [[[NSURLSession sharedSession] dataTaskWithRequest:q completionHandler:^(NSData *d, NSURLResponse *x, NSError *e) {}] resume];
    }
    if (_js) [[_js[@"SKM"] objectForKeyedSubscript:@"signedOut"] callWithArguments:@[]];
}
- (void)signOut { dispatch_async(_q, ^{ [self forgetToken]; self->_state = @"signed-out"; self->_detail = @""; }); }
- (void)syncNow { if (!SK_PERSONAL) return; [self startIfNeeded]; dispatch_async(_q, ^{ if (self.signedIn) [[self->_js[@"SKM"] objectForKeyedSubscript:@"syncNow"] callWithArguments:@[]]; }); }

- (void)tell:(NSString *)title text:(NSString *)text {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSAlert *a = [NSAlert new]; a.messageText = title; a.informativeText = text ?: @"";
        [NSApp activateIgnoringOtherApps:YES]; [a runModal];
    });
}

- (void)signIn {
    if (!SK_PERSONAL) return;
    [self startIfNeeded];
    dispatch_async(_q, ^{
        if (!self.signInAvailable) { [self tell:@"Sign-in is not set up" text:@"This build was made without the Google sign-in details. Build it again with the one-click installer from the private repository's Mac folder."]; return; }
        if (self->_signingIn) return;
        self->_signingIn = YES;
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            NSString *err = [self runSignIn];
            dispatch_async(self->_q, ^{
                self->_signingIn = NO;
                if (err) [self tell:@"Sulekhak: could not sign in" text:err];
                else if (self->_js) [[self->_js[@"SKM"] objectForKeyedSubscript:@"setToken"] callWithArguments:@[self->_access ?: [NSNull null], @(3000), self->_email ?: @""]];
            });
        });
    });
}

/// Opens the browser and waits (up to 5 minutes) for Google to answer on a loopback address of this Mac (OAuth for installed apps with PKCE). nil on success, else the reason.
- (NSString *)runSignIn {
    NSString *verifier = B64Url(RandomBytes(48)), *state = B64Url(RandomBytes(16));
    unsigned char h[CC_SHA256_DIGEST_LENGTH]; NSData *vd = [verifier dataUsingEncoding:NSASCIIStringEncoding];
    CC_SHA256(vd.bytes, (CC_LONG)vd.length, h);
    NSString *challenge = B64Url([NSData dataWithBytes:h length:sizeof h]);

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return @"Cannot open a local port.";
    int on = 1; setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_len = sizeof a; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = 0;
    if (bind(fd, (struct sockaddr *)&a, sizeof a) < 0 || listen(fd, 4) < 0) { close(fd); return @"Cannot listen on a local port."; }
    socklen_t len = sizeof a; getsockname(fd, (struct sockaddr *)&a, &len);
    int port = ntohs(a.sin_port);
    NSString *redirect = [NSString stringWithFormat:@"http://127.0.0.1:%d/", port];
    NSString *url = [NSString stringWithFormat:@"https://accounts.google.com/o/oauth2/v2/auth?client_id=%@&redirect_uri=%@&response_type=code&scope=%@&code_challenge=%@&code_challenge_method=S256&state=%@&access_type=offline&prompt=select_account%%20consent",
                     Enc(_clientId), Enc(redirect), Enc(@"openid email https://www.googleapis.com/auth/drive.appdata"), challenge, state];
    dispatch_sync(dispatch_get_main_queue(), ^{ [[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:url]]; });

    NSString *code = nil, *err = nil;
    NSDate *end = [NSDate dateWithTimeIntervalSinceNow:300];
    while (!code && !err && [end timeIntervalSinceNow] > 0) {
        struct pollfd pf = { fd, POLLIN, 0 };
        int pr = poll(&pf, 1, 1000);
        if (pr <= 0) continue;
        int c = accept(fd, NULL, NULL);
        if (c < 0) continue;
        char buf[8192]; ssize_t n = 0, total = 0;
        struct timeval tv = { 5, 0 }; setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
        while (total < (ssize_t)sizeof(buf) - 1 && (n = recv(c, buf + total, sizeof(buf) - 1 - total, 0)) > 0) { total += n; buf[total] = 0; if (strstr(buf, "\r\n\r\n")) break; }
        buf[total > 0 ? total : 0] = 0;
        NSString *req = [NSString stringWithUTF8String:buf] ?: @"";
        NSString *line = [req componentsSeparatedByString:@"\r\n"].firstObject ?: @"";
        NSArray *parts = [line componentsSeparatedByString:@" "];
        NSString *path = parts.count > 1 ? parts[1] : @"";
        NSURLComponents *uc = [NSURLComponents componentsWithString:[@"http://127.0.0.1" stringByAppendingString:path]];
        NSString *gotState = nil, *gotCode = nil, *gotErr = nil;
        for (NSURLQueryItem *qi in uc.queryItems) { if ([qi.name isEqualToString:@"state"]) gotState = qi.value; else if ([qi.name isEqualToString:@"code"]) gotCode = qi.value; else if ([qi.name isEqualToString:@"error"]) gotErr = qi.value; }
        NSString *page = nil;
        if (gotCode || gotErr) {
            if (![gotState isEqualToString:state]) err = @"The answer did not match the request.";
            else if (gotErr) err = [@"Google: " stringByAppendingString:gotErr];
            else code = gotCode;
            page = err ? @"<html><body style='font-family:sans-serif'><h3>Not signed in</h3>You can close this tab and look at Sulekhak.</body></html>"
                       : @"<html><body style='font-family:sans-serif'><h3>Signed in</h3>You can close this tab and go back to typing.</body></html>";
        } else page = @"<html><body></body></html>";           // e.g. the browser asking for the icon
        NSData *pd = [page dataUsingEncoding:NSUTF8StringEncoding];
        NSString *head = [NSString stringWithFormat:@"HTTP/1.1 %@\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %lu\r\nConnection: close\r\n\r\n", (gotCode || gotErr) ? @"200 OK" : @"404 Not Found", (unsigned long)pd.length];
        send(c, head.UTF8String, head.length, 0); send(c, pd.bytes, pd.length, 0);
        close(c);
    }
    close(fd);
    if (!code) return err ?: @"Timed out waiting for the browser.";

    __block NSDictionary *tok = nil; __block NSString *terr = nil;
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    [self tokenRequest:@{ @"code": code, @"client_id": _clientId, @"client_secret": _clientSecret, @"redirect_uri": redirect, @"grant_type": @"authorization_code", @"code_verifier": verifier }
                  done:^(NSDictionary *t, NSString *e) { tok = t; terr = e; dispatch_semaphore_signal(sem); }];
    dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 40 * NSEC_PER_SEC));
    if (!tok) return [@"Google did not accept the sign-in. " stringByAppendingString:terr ?: @""];
    NSString *mail = EmailFromIdToken(tok[@"id_token"]);
    if (![self isAllowed:mail]) {
        NSMutableURLRequest *q = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://oauth2.googleapis.com/revoke"]];
        q.HTTPMethod = @"POST"; [q setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"]; q.HTTPBody = [Form(@{ @"token": tok[@"access_token"] }) dataUsingEncoding:NSUTF8StringEncoding];
        [[[NSURLSession sharedSession] dataTaskWithRequest:q completionHandler:^(NSData *d, NSURLResponse *x, NSError *e) {}] resume];
        return [NSString stringWithFormat:@"%@ is not an authorised account for this app.", mail ?: @"That account"];
    }
    __block NSString *refresh = tok[@"refresh_token"];
    dispatch_sync(_q, ^{
        self->_email = mail; self->_access = tok[@"access_token"]; self->_accessExp = [NSDate dateWithTimeIntervalSinceNow:[tok[@"expires_in"] intValue] ?: 3000];
        if (refresh.length) self->_refresh = refresh;
        [self saveToken];
    });
    if (!self.signedIn) return @"Google did not give a long-lived sign-in. Remove Sulekhak from your Google account's third-party access and try again.";
    return nil;
}
@end
