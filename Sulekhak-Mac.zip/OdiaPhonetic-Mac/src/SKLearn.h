// SKLearn: what Sulekhak learns while you type, kept in one readable file, plus "Add to Sulekhak Dictionary".
//
//   ~/Library/Application Support/LekhaniOdia/sulekhak-learn.json     (format: docs/learning-cache-format.md)
//
// The file records the words you pick for the Roman letters you type (how often, first and last time, in which script), the next-word pairs,
// and your own dictionary (words and expressions you added). Every Sulekhak edition reads and writes the same file, and the web typist,
// Windows and Android can import it (tools/learn_merge.py turns it into history.tsv / lexicon.tsv and back).
// The file is written in the background a moment after a change, and is re-read when another program changes it, so nothing is lost.
#import <Foundation/Foundation.h>

@interface SKLearn : NSObject
+ (instancetype)shared;
/// Opens (or creates) the cache in `dir`. The first time, history.tsv and lexicon.tsv are folded in, and kept as .migrated backups.
- (void)openInDirectory:(NSString *)dir;
/// Puts everything learned into the engine: picks (weight 3 per use, at most 20 uses) and dictionary words (trusted, never filtered out).
- (void)loadIntoEngine;
/// A word was picked for these Roman letters. `odia` is the Odia form (the engine's own), `script` the script it was typed in (0 Odia, 1 Devanagari, 2 Bangla, 5 Assamese).
- (void)notePick:(NSString *)roman word:(NSString *)odia script:(int)script;
/// `word` was typed right after `prev` (both Odia).
- (void)noteNext:(NSString *)prev word:(NSString *)word;
/// Adds a word or expression to the Sulekhak Dictionary (and to the engine now). Returns an error text, or nil when it was added.
- (NSString *)addDictionaryWord:(NSString *)odia roman:(NSString *)roman;
@property (readonly) NSUInteger pickCount, dictCount;
- (void)flush;                       // write now (the app is quitting)

// ---- "Add to Sulekhak Dictionary": every way in ends here
/// Reads the selected text of the program in front (Accessibility; else the typing client), or the word before the cursor, and asks.
+ (void)addSelection;
/// Asks for this text (a word or an expression, in any Indic script); `nil` opens it empty.
+ (void)presentAddFor:(NSString *)text;
/// The small round "+" that appears beside a mouse selection (needs the Accessibility permission, like the keyboard's key posting).
+ (void)startSelectionButton;
/// Services menu / right-click entry and the sulekhak://add?text= address (used by the Quick Action).
+ (void)installServices;
@end
