#import "SKEngine.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import <JavaScriptCore/JSTypedArray.h>

// A binary data file as a JavaScript ArrayBuffer (the language-model tables are read in place by the engine, nothing is converted).
static void SKFreeBytes(void *bytes, void *info) { free(bytes); }
static JSValue *SKBufferFromFile(JSContext *c, NSString *path) {
    NSData *d = [NSData dataWithContentsOfFile:path];
    if (!d.length) return nil;
    void *p = malloc(d.length);
    if (!p) return nil;
    memcpy(p, d.bytes, d.length);
    JSValueRef ex = NULL;
    JSObjectRef o = JSObjectMakeArrayBufferWithBytesNoCopy(c.JSGlobalContextRef, p, d.length, SKFreeBytes, NULL, &ex);
    if (!o || ex) { free(p); return nil; }
    return [JSValue valueWithJSValueRef:o inContext:c];
}

@implementation SKEngine {
    dispatch_queue_t _q;
    JSContext *_ctx;
    BOOL _started, _ready, _failed, _off, _phonFailed;
    JSContext *_phon;
}
+ (instancetype)shared { static SKEngine *s; static dispatch_once_t o; dispatch_once(&o, ^{ s = [SKEngine new]; }); return s; }
- (instancetype)init {
    if ((self = [super init])) {
        _q = dispatch_queue_create("com.saisudeep.sulekhak", DISPATCH_QUEUE_SERIAL);
        NSNumber *v = [[NSUserDefaults standardUserDefaults] objectForKey:@"SulekhakEnabled"];
        _off = (v && ![v boolValue]);           // defaults write com.saisudeep.inputmethod.OdiaPhonetic.Odia SulekhakEnabled -bool NO
    }
    return self;
}
- (BOOL)ready { return _ready; }
static NSString *CommitFile(void) { return [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/LekhaniOdia/sulekhak_commits.txt"]; }

- (void)startIfNeeded {
    if (_started || _off) return;
    _started = YES;
    dispatch_async(_q, ^{
        @try {
            NSBundle *b = [NSBundle mainBundle];
            NSString *dir = [[b resourcePath] stringByAppendingPathComponent:@"sulekhak"];
            NSString *(^rd)(NSString *) = ^NSString *(NSString *f) {
                return [NSString stringWithContentsOfFile:[dir stringByAppendingPathComponent:f] encoding:NSUTF8StringEncoding error:nil];
            };
            NSString *js = rd(@"sulekhak.js");
            if (!js) { self->_failed = YES; return; }
            JSContext *c = [[JSContext alloc] init];
            c.exceptionHandler = ^(JSContext *ctx, JSValue *ex) { NSLog(@"Sulekhak JS error: %@", ex); };
            [c evaluateScript:js];
// how many dictionary words to load (defaults write com.saisudeep.inputmethod.OdiaPhonetic SulekhakWords -int 150000 loads fewer, then log out and in)
            NSInteger lim = [[NSUserDefaults standardUserDefaults] integerForKey:@"SulekhakWords"];
            if (lim < 50000 || lim > 250000) lim = 250000;
            NSDictionary *P = @{ @"cfg": rd(@"cfg.json") ?: @"", @"lex": rd(@"lex.txt") ?: @"", @"rom": rd(@"rom.txt") ?: @"",
                                 @"clus": rd(@"clus.txt") ?: @"", @"syl_uni": rd(@"syl_uni.txt") ?: @"",
                                 @"syl_bi": rd(@"syl_bi.txt") ?: @"", @"syl_chan": rd(@"syl_chan.txt") ?: @"", @"limit": @(lim) };
            c[@"__P"] = P;
            // the word-sequence (bigram + trigram) tables
            NSArray<NSString *> *ngFiles = @[@"ng_bi1.bin", @"ng_bi2.bin", @"ng_tri.bin"];
            NSMutableArray<NSString *> *ngNames = [NSMutableArray new];
            for (NSUInteger i = 0; i < ngFiles.count; i++) {
                JSValue *buf = SKBufferFromFile(c, [dir stringByAppendingPathComponent:ngFiles[i]]);
                if (!buf) { [ngNames removeAllObjects]; break; }
                NSString *name = [NSString stringWithFormat:@"__ng%lu", (unsigned long)i];
                c[name] = buf;
                [ngNames addObject:name];
            }
            if (ngNames.count == ngFiles.count) [c evaluateScript:@"__P.ng = [__ng0, __ng1, __ng2]; __ng0 = __ng1 = __ng2 = null;"];
            [c evaluateScript:@"var SK=Sulekhak.create(); SK.load(__P); __P=null; SK.suggest('ka','<s>',4,2); SK.suggest('prajak','<s>',4,2);"];     // the two queries warm the engine up
            // replay the words chosen before, so the memory cache survives restarts
            NSString *hist = [NSString stringWithContentsOfFile:CommitFile() encoding:NSUTF8StringEncoding error:nil];
            if (hist.length) {
                NSArray *ls = [hist componentsSeparatedByString:@"\n"];
                NSUInteger from = ls.count > 400 ? ls.count - 400 : 0;
                for (NSUInteger i = from; i < ls.count; i++) if ([ls[i] length]) [c[@"SK"] invokeMethod:@"commit" withArguments:@[ls[i]]];
            }
            self->_ctx = c;
            self->_ready = YES;
        } @catch (NSException *e) { self->_failed = YES; NSLog(@"Sulekhak load failed: %@", e); }
    });
}
- (NSArray<NSString *> *)suggest:(NSString *)roman prev:(NSString *)prev {
    if (!_ready || !roman.length) return nil;
    __block NSArray *out = nil;
    dispatch_sync(_q, ^{
        @try {
            JSValue *r = [self->_ctx[@"SK"] invokeMethod:@"suggest" withArguments:@[roman, prev.length ? prev : @"<s>", @4, @2]];
            NSArray *a = [r toArray], *words = nil;
            if ([a isKindOfClass:[NSArray class]]) {
                NSMutableArray *m = [NSMutableArray new];
                for (id x in a) if ([x isKindOfClass:[NSArray class]] && [x count]) [m addObject:[x firstObject]];
                words = m;
            }
            out = words;
        } @catch (NSException *e) { out = nil; }
    });
    return out;
}
- (NSArray<NSString *> *)nextAfter:(NSString *)w {
    if (!_ready || !w.length) return @[];
    __block NSArray *out = @[];
    dispatch_sync(_q, ^{
        @try {
            NSArray *a = [[self->_ctx[@"SK"] invokeMethod:@"next" withArguments:@[w, @8]] toArray];
            NSMutableArray *m = [NSMutableArray new];
            if ([a isKindOfClass:[NSArray class]]) for (id x in a) if ([x isKindOfClass:[NSString class]]) [m addObject:x];
            out = m;
        } @catch (NSException *e) { out = @[]; }
    });
    return out;
}
// Phonetic mode: phon-data.js (the web typist's database) and phon-core.js, run in their own small JavaScript context on first use.
- (NSArray<NSString *> *)phonCandidates:(NSString *)key {
    if (!key.length) return @[];
    @synchronized (self) {
        if (!_phon && !_phonFailed) {
            @try {
                NSString *dir = [[NSBundle mainBundle] resourcePath];
                NSString *d = [NSString stringWithContentsOfFile:[dir stringByAppendingPathComponent:@"phon-data.js"] encoding:NSUTF8StringEncoding error:nil];
                NSString *c = [NSString stringWithContentsOfFile:[dir stringByAppendingPathComponent:@"phon-core.js"] encoding:NSUTF8StringEncoding error:nil];
                if (d && c) {
                    JSContext *x = [[JSContext alloc] init];
                    x.exceptionHandler = ^(JSContext *ctx, JSValue *ex) { NSLog(@"Sulekhak phonetic JS error: %@", ex); };
                    [x evaluateScript:@"var window = this;"];
                    [x evaluateScript:d]; [x evaluateScript:c];
                    _phon = x;
                } else _phonFailed = YES;
            } @catch (NSException *e) { _phonFailed = YES; }
        }
        if (!_phon) return @[key];
        @try {
            NSArray *a = [[_phon[@"phCands"] callWithArguments:@[key]] toArray];
            NSMutableArray *m = [NSMutableArray new];
            if ([a isKindOfClass:[NSArray class]]) for (id x in a) if ([x isKindOfClass:[NSString class]] && [x length]) [m addObject:x];
            return m.count ? m : @[key];
        } @catch (NSException *e) { return @[key]; }
    }
}
- (void)commit:(NSString *)w {
    if (!w.length || _off) return;
    if (_ready) dispatch_async(_q, ^{ [self->_ctx[@"SK"] invokeMethod:@"commit" withArguments:@[w]]; });
    NSString *file = CommitFile();
    NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:file];
    if (!h) { [@"" writeToFile:file atomically:YES encoding:NSUTF8StringEncoding error:nil]; h = [NSFileHandle fileHandleForWritingAtPath:file]; }
    [h seekToEndOfFile]; [h writeData:[[w stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile];
}
@end
