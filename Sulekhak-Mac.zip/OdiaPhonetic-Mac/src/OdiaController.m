#import <Cocoa/Cocoa.h>
#import "OdiaController.h"
#import "SKEngine.h"
#import "OSKPanel.h"
#import "SuggestBar.h"
#include "engine.h"

extern IMKServer *gServer;

// ---------------------------------------------------------------------------
// Candidate window: a raised, bevelled card with a preview header, numbered rows and a hint row.
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Output script: Odia (default), Devanagari or Bangla. The engine thinks in Odia; every candidate is carried over by odia_convert().
// Devanagari options: bit 1 = Marathi (ळ), bit 2 = anusvara instead of nasal conjuncts (कुंडल). Kept in NSUserDefaults, shared by all apps.
// ---------------------------------------------------------------------------
static int gScript = 0, gOpts = 0;
static NSString *const kScriptKey = @"LekhaniScript", *const kOptsKey = @"LekhaniDevOpts";
static void LoadScript(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    gScript = (int)[d integerForKey:kScriptKey]; if (gScript != 0 && gScript != 1 && gScript != 2 && gScript != 4 && gScript != 5) gScript = 0;   // 0 Odia, 1 Devanagari, 2 Bangla, 4 Phonetic (IPA), 5 Assamese
    gOpts = (int)[d integerForKey:kOptsKey] & 3;
}
static void SaveScript(void) { NSUserDefaults *d = [NSUserDefaults standardUserDefaults]; [d setInteger:gScript forKey:kScriptKey]; [d setInteger:gOpts forKey:kOptsKey]; [d synchronize]; }
static NSString *Conv(NSString *odia) {
    if (gScript == 0 || gScript == 4 || !odia.length) return odia;
    char out[ODIA_CAND_LEN]; odia_convert([odia UTF8String], gScript, gOpts, out, sizeof out);
    return [NSString stringWithUTF8String:out] ?: odia;
}
static NSString *ScriptTitle(void) {
    NSString *n = gScript == 0 ? @"ଓଡ଼ିଆ Odia" : gScript == 1 ? @"देवनागरी Devanagari" : gScript == 5 ? @"অসমীয়া Assamese" : gScript == 4 ? @"Phonetic · IPA, extIPA, IAST" : @"বাংলা Bangla";
    if (gScript == 1) n = [n stringByAppendingString:[NSString stringWithFormat:@" · %@%@", (gOpts & 1) ? @"Marathi ळ" : @"ल", (gOpts & 2) ? @" · anusvara ं" : @" · conjuncts"]];
    return n;
}
// a Devanagari or Bangla letter seen as its Odia twin (the three blocks line up)
static unichar Nrm(unichar c) {
    if (c >= 0x0900 && c <= 0x097F && c != 0x0964 && c != 0x0965) return c + 0x200;
    if (c == 0x09F0) return 0x0B30;                    // Assamese ৰ
    if (c == 0x09F1) return 0x0B71;                    // Assamese ৱ
    if (c >= 0x0980 && c <= 0x09FF) return c + 0x180;
    return c;
}
static NSString *NuktaStr(void) { return [NSString stringWithFormat:@"%C", (unichar)(gScript == 1 ? 0x093C : (gScript == 2 || gScript == 5) ? 0x09BC : 0x0B3C)]; }

static NSColor *Pair(CGFloat lr, CGFloat lg, CGFloat lb, CGFloat dr, CGFloat dg, CGFloat db) {
    return [NSColor colorWithName:nil dynamicProvider:^NSColor *(NSAppearance *a) {
        BOOL dark = [[a bestMatchFromAppearancesWithNames:@[NSAppearanceNameAqua, NSAppearanceNameDarkAqua]] isEqualToString:NSAppearanceNameDarkAqua];
        return dark ? [NSColor colorWithSRGBRed:dr green:dg blue:db alpha:1] : [NSColor colorWithSRGBRed:lr green:lg blue:lb alpha:1];
    }];
}
static BOOL IsBlue(NSString *s) { return [s containsString:@"‌"] || (s.length == 1 && Nrm([s characterAtIndex:0]) == 0x0B4D); }
// Dependent signs get a dotted circle in front so they can be seen; a bare ZWNJ is spelled out.
static NSString *Show(NSString *s) {
    if (!s.length) return s;
    BOOL allZ = YES;
    for (NSUInteger i = 0; i < s.length; i++) if ([s characterAtIndex:i] != 0x200C) { allZ = NO; break; }
    if (allZ) return @"ZWNJ";
    if ([[NSCharacterSet nonBaseCharacterSet] characterIsMember:[s characterAtIndex:0]]) return [@"◌" stringByAppendingString:s];     // a combining mark (Phonetic mode)
    unichar f = Nrm([s characterAtIndex:0]);
    if ((f >= 0x0B3E && f <= 0x0B4D) || f == 0x0B3C || (f >= 0x0B01 && f <= 0x0B03)) return [@"◌" stringByAppendingString:s];
    return s;
}

@interface CandView : NSView
@property (copy) NSString *roman;
@property (copy) NSArray<NSString *> *cands;
@property NSInteger sel;
@property NSInteger page, pages;
@property (copy) void (^onPick)(NSInteger);   // mouse: absolute index of the clicked choice
@property (copy) void (^onPage)(NSInteger);   // mouse: -1 / +1 on the page counter
- (NSSize)fitSize;
@end

#define PAD 10.0
#define LIP 4.0
#define HEAD_H 26.0
#define ROW_H 32.0
#define HINT_H 26.0

@implementation CandView
- (BOOL)isFlipped { return YES; }
- (NSDictionary *)ta:(NSFont *)f color:(NSColor *)c { return @{NSFontAttributeName: f, NSForegroundColorAttributeName: c}; }
- (NSArray *)hints {
    if (gScript == 4) return @[@[@"1-9", @"pick"], @[@"Tab", @"swap"], @[@"⇧Tab", @"back"], @[@"↩", @"keep"], @[@"Esc", @"keep the letter"], @[@"⌃⌥1-7", @"script: Phonetic"]];
    NSMutableArray *h = [@[@[@"1-9", @"pick"], @[@"Space", @"accept"], @[@"↑↓", @"move"]] mutableCopy];
    if (_pages > 1) [h addObject:@[@"←→", @"page"]];
    [h addObjectsFromArray:@[@[@"Esc", @"cancel"], @[@"⌥⌫", @"clear word"], @[@"`", @"halant"], @[@"z", @"ZWNJ"], @[@"Z", @"halant+ZWNJ"], @[@">", @"nukta"], @[@"M", @"anusvara"], @[@"⌃⌥1-6", [NSString stringWithFormat:@"script: %@", gScript == 0 ? @"Odia" : gScript == 1 ? @"Devanagari" : gScript == 5 ? @"Assamese" : @"Bangla"]]]];
    return h;
}
- (CGFloat)hintWidth {
    NSFont *kf = [NSFont monospacedSystemFontOfSize:10 weight:NSFontWeightSemibold], *lf = [NSFont systemFontOfSize:10.5];
    CGFloat w = 0;
    for (NSArray *h in [self hints]) {
        w += [h[0] sizeWithAttributes:@{NSFontAttributeName: kf}].width + 10 + 4 + [h[1] sizeWithAttributes:@{NSFontAttributeName: lf}].width + 12;
    }
    return w;
}
- (NSSize)fitSize {
    NSFont *odia = [NSFont systemFontOfSize:19];
    CGFloat w = 150;
    for (NSString *c in _cands) w = MAX(w, PAD * 2 + 34 + [Show(c) sizeWithAttributes:@{NSFontAttributeName: odia}].width + 14);
    NSFont *mono = [NSFont monospacedSystemFontOfSize:12 weight:NSFontWeightMedium];
    w = MAX(w, PAD * 2 + [_roman sizeWithAttributes:@{NSFontAttributeName: mono}].width + 60);
    w = MAX(w, [self hintWidth] > 330 ? 330 : [self hintWidth]);   // hint row wraps onto two lines when long
    CGFloat hintH = [self hintWidth] > w - PAD * 2 ? HINT_H + 22 : HINT_H;
    return NSMakeSize(w, PAD + HEAD_H + _cands.count * ROW_H + hintH + PAD + LIP);
}
- (void)drawRect:(NSRect)dirty {
    NSRect b = self.bounds;
    NSRect card = NSMakeRect(1, 1, b.size.width - 2, b.size.height - LIP - 2);
    CGFloat R = 10;
    // 3D: dark lip below, then the face, then a light inner edge on top and a dark edge at the bottom
    NSBezierPath *lip = [NSBezierPath bezierPathWithRoundedRect:NSOffsetRect(card, 0, LIP) xRadius:R yRadius:R];
    [Pair(0.64, 0.69, 0.78, 0.07, 0.09, 0.14) setFill]; [lip fill];
    NSBezierPath *face = [NSBezierPath bezierPathWithRoundedRect:card xRadius:R yRadius:R];
    NSGradient *g = [[NSGradient alloc] initWithStartingColor:Pair(0.93, 0.95, 0.97, 0.20, 0.23, 0.30) endingColor:Pair(0.878, 0.898, 0.925, 0.14, 0.17, 0.23)];
    [g drawInBezierPath:face angle:90];   // flipped view: 90 = top to bottom
    [face setLineWidth:1.2]; [Pair(0.64, 0.69, 0.78, 0.32, 0.38, 0.50) setStroke]; [face stroke];
    NSBezierPath *inner = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(card, 1.6, 1.6) xRadius:R - 1.5 yRadius:R - 1.5];
    [inner setLineWidth:1]; [Pair(1, 1, 1, 0.34, 0.40, 0.52) setStroke]; [[Pair(1, 1, 1, 0.34, 0.40, 0.52) colorWithAlphaComponent:0.8] setStroke]; [inner stroke];

    // header: roman -> preview of the marked text
    NSFont *mono = [NSFont monospacedSystemFontOfSize:12 weight:NSFontWeightMedium];
    NSColor *muted = Pair(0.44, 0.50, 0.59, 0.65, 0.70, 0.80);
    NSRect head = NSMakeRect(PAD, PAD - 2, card.size.width - PAD * 2 + 2, HEAD_H);
    NSBezierPath *hp = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(head, 0, 1) xRadius:6 yRadius:6];
    [Pair(0.83, 0.87, 0.92, 0.10, 0.13, 0.19) setFill]; [hp fill];
    [Pair(0.64, 0.69, 0.78, 0.25, 0.31, 0.42) setStroke]; [hp setLineWidth:1]; [hp stroke];
    NSString *r = _roman ?: @"";
    [r drawAtPoint:NSMakePoint(head.origin.x + 8, head.origin.y + 6) withAttributes:[self ta:mono color:muted]];
    CGFloat rw = [r sizeWithAttributes:@{NSFontAttributeName: mono}].width;
    NSString *pv = (_sel >= 0 && _sel < (NSInteger)_cands.count) ? Show(_cands[_sel]) : @"";
    NSColor *pc = (_sel >= 0 && _sel < (NSInteger)_cands.count && IsBlue(_cands[_sel])) ? Pair(0.04, 0.24, 0.57, 0.43, 0.66, 1.0) : Pair(0.18, 0.22, 0.28, 0.90, 0.93, 0.97);
    [@"→" drawAtPoint:NSMakePoint(head.origin.x + 8 + rw + 6, head.origin.y + 5) withAttributes:[self ta:[NSFont systemFontOfSize:12] color:muted]];
    if (_pages > 1) {
        NSString *pg = [NSString stringWithFormat:@"%ld/%ld", (long)_page + 1, (long)_pages];
        NSFont *pf = [NSFont monospacedDigitSystemFontOfSize:10.5 weight:NSFontWeightMedium];
        NSSize ps = [pg sizeWithAttributes:@{NSFontAttributeName: pf}];
        NSRect pr = NSMakeRect(NSMaxX(head) - ps.width - 16, head.origin.y + 5, ps.width + 10, 16);
        NSBezierPath *pp = [NSBezierPath bezierPathWithRoundedRect:pr xRadius:8 yRadius:8];
        [Pair(0.93, 0.95, 0.97, 0.22, 0.26, 0.35) setFill]; [pp fill];
        [Pair(0.64, 0.69, 0.78, 0.32, 0.38, 0.50) setStroke]; [pp stroke];
        [pg drawAtPoint:NSMakePoint(pr.origin.x + 5, pr.origin.y + (16 - ps.height) / 2) withAttributes:[self ta:pf color:muted]];
    }
    [pv drawAtPoint:NSMakePoint(head.origin.x + 8 + rw + 24, head.origin.y + 3) withAttributes:[self ta:[NSFont systemFontOfSize:15 weight:NSFontWeightSemibold] color:pc]];

    // rows
    NSFont *odia = [NSFont systemFontOfSize:19], *numf = [NSFont monospacedDigitSystemFontOfSize:12 weight:NSFontWeightBold];
    CGFloat y = PAD + HEAD_H + 2;
    for (NSInteger i = 0; i < (NSInteger)_cands.count; i++, y += ROW_H) {
        BOOL on = (i == _sel), bl = IsBlue(_cands[i]);
        NSRect row = NSMakeRect(PAD - 4, y, card.size.width - PAD * 2 + 8, ROW_H - 3);
        if (on) {
            NSBezierPath *rp = [NSBezierPath bezierPathWithRoundedRect:row xRadius:7 yRadius:7];
            NSGradient *sg = [[NSGradient alloc] initWithStartingColor:Pair(0.20, 0.36, 0.70, 0.27, 0.50, 0.85) endingColor:Pair(0.03, 0.145, 0.40, 0.17, 0.36, 0.70)];
            [sg drawInBezierPath:rp angle:90];
            [Pair(0.02, 0.10, 0.30, 0.10, 0.22, 0.48) setStroke]; [rp setLineWidth:1]; [rp stroke];
            NSBezierPath *hl = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(row, 1.2, 1.2) xRadius:6 yRadius:6];
            [[NSColor colorWithWhite:1 alpha:0.35] setStroke]; [hl stroke];
        }
        NSRect badge = NSMakeRect(row.origin.x + 6, row.origin.y + (row.size.height - 20) / 2, 20, 20);
        NSBezierPath *bp = [NSBezierPath bezierPathWithRoundedRect:badge xRadius:5 yRadius:5];
        [(on ? [NSColor colorWithWhite:1 alpha:0.92] : Pair(0.84, 0.88, 0.93, 0.22, 0.27, 0.37)) setFill]; [bp fill];
        [(on ? Pair(0.03, 0.145, 0.40, 0.03, 0.145, 0.40) : Pair(0.64, 0.69, 0.78, 0.32, 0.38, 0.50)) setStroke]; [bp stroke];
        NSString *n = [NSString stringWithFormat:@"%ld", (long)i + 1];
        NSColor *nc = on ? Pair(0.03, 0.145, 0.40, 0.03, 0.145, 0.40) : Pair(0.18, 0.22, 0.28, 0.88, 0.91, 0.96);
        NSSize ns = [n sizeWithAttributes:@{NSFontAttributeName: numf}];
        [n drawAtPoint:NSMakePoint(NSMidX(badge) - ns.width / 2, NSMidY(badge) - ns.height / 2) withAttributes:[self ta:numf color:nc]];
        NSColor *tc = on ? (bl ? Pair(0.80, 0.90, 1, 0.80, 0.90, 1) : [NSColor whiteColor])
                         : (bl ? Pair(0.04, 0.24, 0.57, 0.43, 0.66, 1.0) : Pair(0.18, 0.22, 0.28, 0.90, 0.93, 0.97));
        NSString *t = Show(_cands[i]);
        NSSize ts = [t sizeWithAttributes:@{NSFontAttributeName: odia}];
        [t drawAtPoint:NSMakePoint(badge.origin.x + 30, NSMidY(row) - ts.height / 2) withAttributes:[self ta:odia color:tc]];
    }

    // hint row with keycaps
    CGFloat hy = y + 4;
    NSBezierPath *sep = [NSBezierPath bezierPath];
    [sep moveToPoint:NSMakePoint(PAD, hy - 3)]; [sep lineToPoint:NSMakePoint(card.size.width - PAD, hy - 3)];
    [Pair(0.64, 0.69, 0.78, 0.25, 0.31, 0.42) setStroke]; [sep setLineWidth:1]; [sep stroke];
    NSFont *kf = [NSFont monospacedSystemFontOfSize:10 weight:NSFontWeightSemibold], *lf = [NSFont systemFontOfSize:10.5];
    CGFloat x = PAD, ly = hy + 2, maxX = card.size.width - PAD;
    for (NSArray *h in [self hints]) {
        NSSize ks = [h[0] sizeWithAttributes:@{NSFontAttributeName: kf}], ls = [h[1] sizeWithAttributes:@{NSFontAttributeName: lf}];
        CGFloat need = ks.width + 10 + 4 + ls.width + 12;
        if (x + need > maxX + 8 && x > PAD) { x = PAD; ly += 20; }
        NSRect kr = NSMakeRect(x, ly, ks.width + 10, 16);
        NSBezierPath *under = [NSBezierPath bezierPathWithRoundedRect:NSOffsetRect(kr, 0, 1.5) xRadius:4 yRadius:4];
        [Pair(0.64, 0.69, 0.78, 0.07, 0.09, 0.14) setFill]; [under fill];
        NSBezierPath *kp = [NSBezierPath bezierPathWithRoundedRect:kr xRadius:4 yRadius:4];
        [Pair(0.93, 0.95, 0.97, 0.22, 0.26, 0.35) setFill]; [kp fill];
        [Pair(0.64, 0.69, 0.78, 0.32, 0.38, 0.50) setStroke]; [kp setLineWidth:0.8]; [kp stroke];
        [h[0] drawAtPoint:NSMakePoint(kr.origin.x + 5, kr.origin.y + (16 - ks.height) / 2) withAttributes:[self ta:kf color:Pair(0.03, 0.145, 0.40, 0.80, 0.87, 0.98)]];
        BOOL blueLbl = [h[1] hasPrefix:@"halant"] || [h[1] isEqualToString:@"ZWNJ"];
        [h[1] drawAtPoint:NSMakePoint(NSMaxX(kr) + 4, ly + (16 - ls.height) / 2) withAttributes:[self ta:lf color:blueLbl ? Pair(0.04, 0.24, 0.57, 0.43, 0.66, 1.0) : muted]];
        x += need;
    }
}
- (BOOL)acceptsFirstMouse:(NSEvent *)e { return YES; }
- (BOOL)mouseDownCanMoveWindow { return NO; }
- (void)mouseDown:(NSEvent *)e {
    NSPoint p = [self convertPoint:e.locationInWindow fromView:nil];
    CGFloat top = PAD + HEAD_H + 2;
    if (p.y >= PAD - 2 && p.y < top && _pages > 1 && self.onPage && p.x > self.bounds.size.width - 70) {   // the "1/3" counter: left half back, right half forward
        self.onPage(p.x < self.bounds.size.width - 45 ? -1 : 1); return;
    }
    if (p.y >= top && p.x >= PAD - 4 && p.x <= self.bounds.size.width - PAD + 4) {
        NSInteger row = (NSInteger)((p.y - top) / ROW_H);
        if (row >= 0 && row < (NSInteger)_cands.count && self.onPick) self.onPick(_page * ODIA_PAGE + row);
    }
}
- (void)resetCursorRects { [self addCursorRect:self.bounds cursor:[NSCursor arrowCursor]]; }
@end

@interface CandPanel : NSObject
- (void)showCandidates:(NSArray<NSString *> *)c selected:(NSInteger)sel roman:(NSString *)roman at:(NSRect)caret;
- (void)hide;
@property (copy) void (^onPick)(NSInteger);
@property (copy) void (^onPage)(NSInteger);
@end

@implementation CandPanel {
    NSPanel *_panel;
    CandView *_view;
}
- (instancetype)init {
    if ((self = [super init])) {
        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0, 0, 220, 120)
                                            styleMask:NSWindowStyleMaskBorderless | NSWindowStyleMaskNonactivatingPanel
                                              backing:NSBackingStoreBuffered defer:YES];
        _panel.level = NSPopUpMenuWindowLevel;
        _panel.opaque = NO;
        _panel.backgroundColor = [NSColor clearColor];
        _panel.hasShadow = YES;
        _panel.hidesOnDeactivate = NO;
        _view = [[CandView alloc] initWithFrame:NSMakeRect(0, 0, 220, 120)];
        _panel.contentView = _view;
    }
    return self;
}
- (void)showCandidates:(NSArray<NSString *> *)c selected:(NSInteger)sel roman:(NSString *)roman at:(NSRect)caret {
    NSInteger pageSize = ODIA_PAGE, pages = MAX(1, ((NSInteger)c.count + pageSize - 1) / pageSize), page = sel / pageSize;
    NSInteger from = page * pageSize, len = MIN(pageSize, (NSInteger)c.count - from);
    _view.cands = [c subarrayWithRange:NSMakeRange(from, MAX(len, 0))]; _view.sel = sel - from; _view.roman = roman;
    _view.page = page; _view.pages = pages;
    NSSize sz = [_view fitSize];
    NSPoint origin = NSMakePoint(caret.origin.x, caret.origin.y - sz.height - 4);
    NSScreen *scr = [NSScreen mainScreen];
    for (NSScreen *s in [NSScreen screens]) if (NSPointInRect(caret.origin, s.frame)) scr = s;
    if (origin.y < scr.visibleFrame.origin.y) origin.y = caret.origin.y + caret.size.height + 4;  // no room below: go above
    if (origin.x + sz.width > NSMaxX(scr.visibleFrame)) origin.x = NSMaxX(scr.visibleFrame) - sz.width;
    [_panel setFrame:NSMakeRect(origin.x, origin.y, sz.width, sz.height) display:NO];
    [_view setFrame:NSMakeRect(0, 0, sz.width, sz.height)];
    [_view setNeedsDisplay:YES];
    [_panel orderFrontRegardless];
}
- (void)hide { [_panel orderOut:nil]; }
- (void)setOnPick:(void (^)(NSInteger))b { _view.onPick = b; }
- (void (^)(NSInteger))onPick { return _view.onPick; }
- (void)setOnPage:(void (^)(NSInteger))b { _view.onPage = b; }
- (void (^)(NSInteger))onPage { return _view.onPage; }
@end

// ---------------------------------------------------------------------------
static __weak OdiaController *gActive;     // the controller of the program being typed in: the on-screen keyboard's popup picks go through it

@implementation OdiaController {
    NSMutableString *_buf;
    NSMutableArray<NSString *> *_cands;
    NSMutableArray<NSString *> *_odiaCands;   // the same choices in Odia (what the dictionary and learning use)
    NSInteger _sel;
    CandPanel *_panel;
    BOOL _pendingSpace;
    id _client;      // the app being typed into, kept so a mouse click on the window can finish the word
    BOOL _navd;      // the highlight was moved with Tab / arrows / Page keys: Return then picks with a space
}

- (instancetype)initWithServer:(IMKServer *)server delegate:(id)delegate client:(id)inputClient {
    if ((self = [super initWithServer:server delegate:delegate client:inputClient])) {
        _buf = [NSMutableString new];
        _cands = [NSMutableArray new];
        _odiaCands = [NSMutableArray new];
        static dispatch_once_t once; dispatch_once(&once, ^{ LoadScript(); });
        _panel = [CandPanel new];
        __weak OdiaController *ws = self;
        _panel.onPick = ^(NSInteger i){ OdiaController *me = ws; if (me && me->_client) [me commitIndex:i client:me->_client suffix:nil bySelection:YES]; };
        _panel.onPage = ^(NSInteger d){ OdiaController *me = ws; if (me && me->_client) [me movePage:d client:me->_client]; };
    }
    return self;
}

- (NSUInteger)recognizedEvents:(id)sender { return NSEventMaskKeyDown; }

- (void)activateServer:(id)sender { gActive = self; _client = sender; [super activateServer:sender]; }

/// A ready-made piece of Odia from the on-screen keyboard's long-press popup: finish the word being typed, then put the piece in.
+ (void)oskInsert:(NSString *)t {
    OdiaController *c = gActive;
    if (!c || !c->_client || t.length == 0) return;
    if (c->_buf.length) [c commitIndex:c->_sel client:c->_client suffix:nil bySelection:NO];
    [c insert:Conv(t) client:c->_client];
}

#pragma mark helpers

- (BOOL)digitMode {
    if (!_buf.length) return NO;
    for (NSUInteger i = 0; i < _buf.length; i++) { unichar c = [_buf characterAtIndex:i]; if (c < '0' || c > '9') return NO; }
    return YES;
}

- (void)insert:(NSString *)s client:(id)client {
    [client insertText:s replacementRange:NSMakeRange(NSNotFound, NSNotFound)];
}

- (void)reset { [_buf setString:@""]; [_cands removeAllObjects]; [_odiaCands removeAllObjects]; _sel = 0; _navd = NO; [_panel hide]; }

- (void)movePage:(NSInteger)d client:(id)client {
    NSInteger pages = ((NSInteger)_cands.count + ODIA_PAGE - 1) / ODIA_PAGE;
    if (pages < 2) return;
    NSInteger p = ((_sel / ODIA_PAGE) + d + pages) % pages;
    _sel = p * ODIA_PAGE; _navd = YES;
    [self refreshClient:client];
}

static BOOL SKLettersOnly(NSString *s) {
    if (!s.length) return NO;
    for (NSUInteger i = 0; i < s.length; i++) { unichar c = [s characterAtIndex:i]; if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) return NO; }
    return YES;
}
// The word just before the one being typed (as Odia), for the next-word statistics; "<s>" at the start of a sentence.
- (NSString *)skPrevWord:(id)client {
    @try {
        NSRange mr = [client markedRange], sr = [client selectedRange];
        NSUInteger end = (mr.location != NSNotFound && mr.length) ? mr.location : sr.location;
        if (end == NSNotFound || end == 0) return @"<s>";
        NSUInteger from = end > 80 ? end - 80 : 0;
        NSString *t = [[client attributedSubstringFromRange:NSMakeRange(from, end - from)] string];
        if (!t.length) return @"<s>";
        NSInteger i = (NSInteger)t.length - 1;
        while (i >= 0 && ([t characterAtIndex:i] == ' ' || [t characterAtIndex:i] == '\t')) i--;
        NSInteger e = i;
        while (i >= 0) {
            unichar c = [t characterAtIndex:i];
            BOOL odia = (c >= 0x0B00 && c <= 0x0B7F && c != 0x0B64 && c != 0x0B65);
            BOOL deva = (c >= 0x0900 && c <= 0x097F && c != 0x0964 && c != 0x0965), beng = (c >= 0x0980 && c <= 0x09FF);
            if (odia || deva || beng || c == 0x200C || c == 0x200D) i--; else break;
        }
        if (e < 0 || i == e) return @"<s>";
        NSString *w = [t substringWithRange:NSMakeRange(i + 1, e - i)];
        if ([w characterAtIndex:0] < 0x0B00 || [w characterAtIndex:0] > 0x0B7F) {
            char out[ODIA_CAND_LEN]; odia_to_odia([w UTF8String], out, sizeof out); w = [NSString stringWithUTF8String:out] ?: w;
        }
        return w.length ? w : @"<s>";
    } @catch (NSException *ex) { return @"<s>"; }
}

- (void)refreshClient:(id)client {
    _client = client;
    if (gScript == 4) { [self phShow:client]; return; }
    if (!_buf.length) { [self reset]; [[SuggestBar shared] clear]; [client setMarkedText:@"" selectionRange:NSMakeRange(0, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)]; return; }
    static char c[ODIA_MAX_CANDS][ODIA_CAND_LEN];
    int n = odia_candidates_in([_buf UTF8String], gScript, c);
    [_cands removeAllObjects]; [_odiaCands removeAllObjects];
    for (int i = 0; i < n; i++) {
        NSString *o = [NSString stringWithUTF8String:c[i]] ?: @"", *d = Conv(o);
        if (i > 1 && gScript != 0 && [_cands containsObject:d]) continue;      // two Odia spellings that look the same in this script
        [_cands addObject:d]; [_odiaCands addObject:o];
    }
    [[SKEngine shared] startIfNeeded];                       // Sulekhak smart candidates (loads once, in the background)
    if ([SKEngine shared].ready && SKLettersOnly(_buf)) {
        NSArray *sk = [[SKEngine shared] suggest:_buf prev:[self skPrevWord:client]];
        if (sk.count) {
            NSMutableArray *O = [NSMutableArray new], *D = [NSMutableArray new]; NSMutableSet *seen = [NSMutableSet new];
            void (^push)(NSString *, NSString *) = ^(NSString *o, NSString *d) {
                if ([seen containsObject:o] || (gScript != 0 && [D containsObject:d])) return;
                [seen addObject:o]; [O addObject:o]; [D addObject:d];
            };
            push(sk[0], Conv(sk[0]));
            if (_odiaCands.count > 1) { [O addObject:_odiaCands[1]]; [D addObject:_cands[1]]; [seen addObject:_odiaCands[1]]; }   // the typed text stays in slot 2
            for (NSUInteger q = 1; q < sk.count; q++) push(sk[q], Conv(sk[q]));
            for (NSUInteger q = 0; q < _odiaCands.count; q++) if (q != 1) push(_odiaCands[q], _cands[q]);
            [_cands setArray:D]; [_odiaCands setArray:O];
        }
    }
    if (_sel >= (NSInteger)_cands.count) _sel = 0;
    NSString *marked = _cands.count ? _cands[_sel] : _buf;
    NSAttributedString *m = [[NSAttributedString alloc] initWithString:marked attributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle)}];
    [client setMarkedText:m selectionRange:NSMakeRange(marked.length, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)];
    NSRect r = NSZeroRect;
    [client attributesForCharacterIndex:0 lineHeightRectangle:&r];
    [_panel showCandidates:_cands selected:_sel roman:_buf at:r];
    [[SuggestBar shared] showChoices:_cands selected:_sel];
}

// After a candidate is picked with a number key, a space is added before the next word
// (unless the choice ends in halant/ZWNJ or is a bare matra, which means the word continues).
static BOOL WordContinues(NSString *w) {
    if (!w.length) return YES;
    unichar last = Nrm([w characterAtIndex:w.length - 1]), first = Nrm([w characterAtIndex:0]);
    if (last == 0x0B4D || last == 0x200C) return YES;
    if ((first >= 0x0B3E && first <= 0x0B4C) || first == 0x0B3C || (first >= 0x0B01 && first <= 0x0B03)) return YES;
    return NO;
}
- (void)commitIndex:(NSInteger)i client:(id)client suffix:(NSString *)suffix bySelection:(BOOL)bySel {
    if (gScript == 4) { [self phCommitIndex:i client:client suffix:suffix]; return; }
    if (i < 0 || i >= (NSInteger)_cands.count) i = 0;
    NSString *word = _cands.count ? _cands[i] : _buf;
    NSString *roman = [_buf copy];
    // a choice picked with a number key or the mouse is followed by a space at once, unless the word goes on (halant, ZWNJ, bare sign)
    BOOL autoSpace = bySel && !suffix.length && !WordContinues(word);
    [self insert:suffix.length ? [word stringByAppendingString:suffix] : (autoSpace ? [word stringByAppendingString:@" "] : word) client:client];
    // remember picks so they rank higher next time (position 2 is the English text, so it is not learned)
    NSString *oword = (i < (NSInteger)_odiaCands.count) ? _odiaCands[i] : word;
    BOOL hasOdia = NO; for (NSUInteger q = 0; q < oword.length; q++) if ([oword characterAtIndex:q] > 127) { hasOdia = YES; break; }
    if (i != 1 && hasOdia && ![self digitMode] && roman.length && ![roman isEqualToString:@"."]) {
        odia_lex_add([roman UTF8String], [oword UTF8String], 3);
        [[SKEngine shared] commit:oword];
        NSString *file = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/LekhaniOdia/history.tsv"];
        NSString *line = [NSString stringWithFormat:@"%@\t%@\t3\n", roman, oword];
        NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:file];
        if (!h) { [@"" writeToFile:file atomically:YES encoding:NSUTF8StringEncoding error:nil]; h = [NSFileHandle fileHandleForWritingAtPath:file]; }
        [h seekToEndOfFile]; [h writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile];
    }
    [self reset];
    _pendingSpace = NO;
    // the words that usually come next, shown on the 3D keyboard strip and the Touch Bar
    NSArray *nx = (hasOdia && (suffix.length || autoSpace) && ![self digitMode]) ? [[SKEngine shared] nextAfter:oword] : nil;
    [self publishNext:nx];
}

// Next-word suggestions, in the current script. The Odia originals are what the engine understands, so they are kept alongside.
static NSArray *gNextOdia = nil;
- (void)publishNext:(NSArray *)odia {
    gNextOdia = odia.count ? [odia copy] : nil;
    if (!gNextOdia) { [[SuggestBar shared] clear]; return; }
    NSMutableArray *d = [NSMutableArray new];
    for (NSString *o in gNextOdia) [d addObject:Conv(o)];
    [[SuggestBar shared] showNext:d];
}

/// A suggestion was tapped on the 3D keyboard strip or the Touch Bar.
+ (void)suggestPick:(NSInteger)i next:(BOOL)isNext {
    OdiaController *c = gActive;
    if (!c || !c->_client) return;
    if (!isNext) {                                     // a choice for the word being typed: take it, with a space
        if (c->_buf.length) [c commitIndex:i client:c->_client suffix:nil bySelection:YES];
        return;
    }
    if (c->_buf.length) [c commitIndex:c->_sel client:c->_client suffix:nil bySelection:NO];
    if (i < 0 || i >= (NSInteger)gNextOdia.count) return;
    NSString *o = gNextOdia[i];
    [c insert:[Conv(o) stringByAppendingString:@" "] client:c->_client];
    [[SKEngine shared] commit:o];
    [c publishNext:[[SKEngine shared] nextAfter:o]];
}

#pragma mark events

#pragma mark Phonetic mode (IPA, extIPA, IAST)

// Phonetic mode: a key shows up as the letter itself, with every symbol that looks like it in the choice list (Tab swaps).
- (void)phShow:(id)client {
    if (!_buf.length || !_cands.count) { [self reset]; [[SuggestBar shared] clear]; [client setMarkedText:@"" selectionRange:NSMakeRange(0, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)]; return; }
    if (_sel >= (NSInteger)_cands.count || _sel < 0) _sel = 0;
    NSString *marked = _cands[_sel];
    NSAttributedString *m = [[NSAttributedString alloc] initWithString:marked attributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle)}];
    [client setMarkedText:m selectionRange:NSMakeRange(marked.length, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)];
    NSRect r = NSZeroRect;
    [client attributesForCharacterIndex:0 lineHeightRectangle:&r];
    [_panel showCandidates:_cands selected:_sel roman:_buf at:r];
    [[SuggestBar shared] showChoices:_cands selected:_sel];
}
- (void)phCommitIndex:(NSInteger)i client:(id)client suffix:(NSString *)suffix {
    if (!_cands.count) { [self reset]; return; }
    if (i < 0 || i >= (NSInteger)_cands.count) i = _sel;
    NSString *w = _cands[i];
    [self insert:suffix.length ? [w stringByAppendingString:suffix] : w client:client];
    [self reset];
    _pendingSpace = NO;
    [[SuggestBar shared] clear];
}
- (BOOL)phHandle:(NSEvent *)event client:(id)sender composing:(BOOL)composing shift:(BOOL)shf {
    unsigned short kc = event.keyCode;
    NSInteger n = (NSInteger)_cands.count;
    if (composing) {
        switch (kc) {
            case 36: case 76: [self phCommitIndex:_sel client:sender suffix:nil]; return YES;                      // return: keep it (no new line)
            case 49: [self phCommitIndex:_sel client:sender suffix:@" "]; return YES;                                // space: keep it, then a space
            case 53: [self phCommitIndex:0 client:sender suffix:nil]; return YES;                                    // esc: keep the letter you typed
            case 51: [self reset]; [[SuggestBar shared] clear]; [sender setMarkedText:@"" selectionRange:NSMakeRange(0, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)]; return YES;   // delete: drop it
            case 48: _navd = YES; _sel = shf ? (_sel + n - 1) % MAX(n, 1) : (_sel + 1) % MAX(n, 1); [self phShow:sender]; return YES;     // tab / shift+tab: the next / previous symbol
            case 125: _navd = YES; _sel = (_sel + 1) % MAX(n, 1); [self phShow:sender]; return YES;
            case 126: _navd = YES; _sel = (_sel + n - 1) % MAX(n, 1); [self phShow:sender]; return YES;
            case 116: [self movePage:-1 client:sender]; return YES;
            case 121: [self movePage:1 client:sender]; return YES;
            case 123: case 124:
                if ((n + ODIA_PAGE - 1) / ODIA_PAGE > 1) { [self movePage:(kc == 123 ? -1 : 1) client:sender]; return YES; }
                [self phCommitIndex:_sel client:sender suffix:nil]; return NO;                                       // one page only: keep it, then move the caret
        }
    }
    NSString *s = event.characters;
    unichar c = s.length == 1 ? [s characterAtIndex:0] : 0;
    if (c < 32 || c == 127 || (c >= 0xF700 && c <= 0xF8FF)) { if (composing) [self phCommitIndex:_sel client:sender suffix:nil]; return NO; }
    if (composing && c >= '1' && c <= '9' && !(_buf.length == 1 && [_buf characterAtIndex:0] >= '0' && [_buf characterAtIndex:0] <= '9')) {
        NSInteger i = (_sel / ODIA_PAGE) * ODIA_PAGE + (c - '1');
        if (i < n) { [self phCommitIndex:i client:sender suffix:nil]; return YES; }
    }
    if (s.length != 1) { if (composing) [self phCommitIndex:_sel client:sender suffix:nil]; return NO; }
    NSArray *L = [[SKEngine shared] phonCandidates:s];
    if (composing) [self phCommitIndex:_sel client:sender suffix:nil];
    if (L.count < 2) { [self insert:s client:sender]; return YES; }                                              // no symbol looks like this key: it is typed as it is
    [_buf setString:s]; [_cands setArray:L]; [_odiaCands setArray:L]; _sel = 0; _navd = NO;
    [self phShow:sender];
    return YES;
}

- (BOOL)handleEvent:(NSEvent *)event client:(id)sender {
    if (event.type != NSEventTypeKeyDown) return NO;
    gActive = self; _client = sender;
    NSEventModifierFlags f = event.modifierFlags;
    unsigned short kc = event.keyCode;
    BOOL composing = _buf.length > 0;
    if (!composing && gNextOdia) {          // typing anything but the first letter of a new word drops the old next-word list
        NSString *ch0 = event.charactersIgnoringModifiers;
        unichar u0 = ch0.length ? [ch0 characterAtIndex:0] : 0;
        BOOL letter = (u0 >= 'a' && u0 <= 'z') || (u0 >= 'A' && u0 <= 'Z');
        if (!letter || (event.modifierFlags & (NSEventModifierFlagCommand | NSEventModifierFlagControl | NSEventModifierFlagOption))) [self publishNext:nil];
    }

    if (_pendingSpace) {     // space after a number-key choice, added only if a new word really starts
        _pendingSpace = NO;
        NSString *cs = event.characters;
        unichar c0 = cs.length == 1 ? [cs characterAtIndex:0] : 0;
        BOOL wordStart = ((c0 >= 'a' && c0 <= 'z') || (c0 >= 'A' && c0 <= 'Z') || (c0 >= '0' && c0 <= '9'));
        if (wordStart && !(f & (NSEventModifierFlagCommand | NSEventModifierFlagControl | NSEventModifierFlagOption))) [self insert:@" " client:sender];
    }

    BOOL cmd = (f & NSEventModifierFlagCommand) != 0, ctl = (f & NSEventModifierFlagControl) != 0;
    BOOL opt = (f & NSEventModifierFlagOption) != 0, shf = (f & NSEventModifierFlagShift) != 0;
    // keys that move the caret or select text (arrows, Home, End, Page Up/Down, forward delete, function keys): they belong to the
    // application. While a word is being composed, take the highlighted choice first, then let the key through unchanged.
    BOOL navKey = (kc >= 123 && kc <= 126) || kc == 115 || kc == 119 || kc == 116 || kc == 121 || kc == 117;
    NSString *evc = event.characters;
    unichar fc = evc.length == 1 ? [evc characterAtIndex:0] : 0;
    BOOL fnKey = (fc >= 0xF700 && fc <= 0xF8FF);

    if (composing && kc == 51 && (opt || cmd)) {          // Option+Delete / Cmd+Delete while composing: throw the whole word away
        [self reset]; [sender setMarkedText:@"" selectionRange:NSMakeRange(0, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)]; return YES;
    }
    if (composing && ctl && !cmd && !opt && kc == 4) {    // Ctrl+H = Backspace (macOS text-field habit)
        [_buf deleteCharactersInRange:NSMakeRange(_buf.length - 1, 1)]; _sel = 0; _navd = NO; [self refreshClient:sender]; return YES;
    }
    if (composing && ctl && !cmd && !opt && (kc == 32 || kc == 13)) {   // Ctrl+U / Ctrl+W: clear the composing word
        [self reset]; [sender setMarkedText:@"" selectionRange:NSMakeRange(0, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)]; return YES;
    }
    if (ctl && opt && !cmd && kc == 40) { if (![OSKPanel hotKeyActive]) [[OSKPanel shared] toggle]; return YES; }     // Ctrl+Option+K: show or hide the 3D keyboard
    if (ctl && opt && !cmd && (kc == 18 || kc == 19 || kc == 20 || kc == 21 || kc == 22 || kc == 23 || kc == 26)) {   // Ctrl+Option+1 Odia, 2 Devanagari, 3 Bangla, 4 Marathi ळ on/off, 5 conjuncts on/off, 6 Assamese, 7 Phonetic (IPA)
        if (composing) [self commitIndex:_sel client:sender suffix:nil bySelection:NO];
        if (kc == 18) gScript = 0; else if (kc == 19) gScript = 1; else if (kc == 20) gScript = 2; else if (kc == 22) gScript = 5; else if (kc == 26) gScript = 4;
        else if (kc == 21) { gScript = 1; gOpts ^= 1; } else { gScript = 1; gOpts ^= 2; }
        SaveScript(); [self flashScript:sender]; return YES;
    }
    if (cmd || ctl || opt) {                              // every shortcut: Option+arrows (word), Cmd+arrows (line), Ctrl+A/E/F/B (Emacs keys), Cmd+C/V/Z ...
        if (composing) { [self commitIndex:_sel client:sender suffix:nil bySelection:NO]; }
        return NO;
    }
    if (shf && navKey) {                                  // Shift+arrows / Home / End: extend the selection in the application
        if (composing) { [self commitIndex:_sel client:sender suffix:nil bySelection:NO]; }
        return NO;
    }
    BOOL candKey = (kc >= 123 && kc <= 126) || kc == 116 || kc == 121;     // keys the candidate list uses while composing
    if (!candKey && (kc == 115 || kc == 119 || kc == 117 || fnKey)) {      // Home, End, forward delete, F-keys, Help ...
        if (composing) { [self commitIndex:_sel client:sender suffix:nil bySelection:NO]; }
        return NO;
    }

    if (gScript == 4) return [self phHandle:event client:sender composing:composing shift:shf];

    if (!composing && kc == 51) {                         // Delete with nothing being composed: remove exactly ONE character before the caret
        // (the system would take a whole letter such as କ୍ଷି at once). Only Odia characters are handled here; everything else is left to the app.
        id<IMKTextInput> cl = (id<IMKTextInput>)sender;
        NSRange sr = [cl selectedRange];
        if (sr.location != NSNotFound && sr.length == 0 && sr.location > 0) {
            NSAttributedString *last = [cl attributedSubstringFromRange:NSMakeRange(sr.location - 1, 1)];
            unichar lc = last.length ? [last.string characterAtIndex:0] : 0;
            if ((Nrm(lc) >= 0x0B00 && Nrm(lc) <= 0x0B7F) || lc == 0x200C || lc == 0x200D) {
                [cl insertText:@"" replacementRange:NSMakeRange(sr.location - 1, 1)];
                NSRange after = [cl selectedRange];
                if (after.location == NSNotFound || after.location != sr.location) return YES;   // it worked
                return NO;                                                                         // this app ignored the request: let it delete the usual way
            }
        }
        return NO;
    }

    if (composing) {
        switch (kc) {
            case 36: case 76: [self commitIndex:_sel client:sender suffix:nil bySelection:YES]; return YES;                 // return / enter: picks with a space (an empty buffer never reaches here, so Return is then a new line)
            case 49: [self commitIndex:_sel client:sender suffix:@" " bySelection:NO]; return YES;                         // space
            case 53: [self reset]; [sender setMarkedText:@"" selectionRange:NSMakeRange(0, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)]; return YES; // esc
            case 51: [_buf deleteCharactersInRange:NSMakeRange(_buf.length - 1, 1)]; _sel = 0; _navd = NO; [self refreshClient:sender]; return YES; // delete
            case 125: _navd = YES; _sel = (_sel + 1) % MAX((NSInteger)_cands.count, 1); [self refreshClient:sender]; return YES;                     // down
            case 48: _navd = YES; _sel = shf ? (_sel + (NSInteger)_cands.count - 1) % MAX((NSInteger)_cands.count, 1) : (_sel + 1) % MAX((NSInteger)_cands.count, 1); [self refreshClient:sender]; return YES;   // tab / shift+tab
            case 126: _navd = YES; _sel = (_sel + (NSInteger)_cands.count - 1) % MAX((NSInteger)_cands.count, 1); [self refreshClient:sender]; return YES; // up
            case 116: [self movePage:-1 client:sender]; return YES;                                          // page up: previous page
            case 121: [self movePage:1 client:sender]; return YES;                                           // page down: next page
            case 123: case 124: {                                                                             // left / right
                if (((NSInteger)_cands.count + ODIA_PAGE - 1) / ODIA_PAGE > 1) { [self movePage:(kc == 123 ? -1 : 1) client:sender]; return YES; }
                [self commitIndex:_sel client:sender suffix:nil bySelection:NO]; return NO;                   // one page only: take the choice, then move the caret
            }
        }
    }

    NSString *s = event.characters;
    if (s.length != 1) return NO;
    unichar c = [s characterAtIndex:0];

    // "." opens its own choice list: danda, full stop, double danda
    BOOL dotsOnly = composing && _buf.length && [[_buf stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"."]] length] == 0;
    if (dotsOnly && c == '.') {                  // more dots in a row stay literal dots: .. ... ....
        [_buf appendString:@"."]; _sel = 0; _navd = NO; [self refreshClient:sender]; return YES;
    }
    if (dotsOnly) {
        if (c >= '1' && c <= '9' && (c - '1') < (NSInteger)_cands.count) { [self commitIndex:c - '1' client:sender suffix:nil bySelection:YES]; return YES; }
        [self commitIndex:_sel client:sender suffix:nil bySelection:NO]; composing = NO;   // anything else: take the highlighted choice and go on
    }
    if (c == '.') {
        if (composing) [self commitIndex:_sel client:sender suffix:nil bySelection:NO];
        [_buf setString:@"."]; _sel = 0; _navd = NO; [self refreshClient:sender]; return YES;
    }

    // number keys
    if (c >= '0' && c <= '9') {
        if (composing && ![self digitMode]) {
            if (c == '0') { [self commitIndex:_sel client:sender suffix:nil bySelection:NO]; }
            else { NSInteger i = (_sel / ODIA_PAGE) * ODIA_PAGE + (c - '1'); if (i < (NSInteger)_cands.count) [self commitIndex:i client:sender suffix:nil bySelection:YES]; return YES; }
        }
        [_buf appendString:s]; _sel = 0; _navd = NO; [self refreshClient:sender]; return YES;   // digits build a number: Odia digits first, ASCII second
    }

    // letters and the special keys that belong inside a word
    BOOL letter = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '\'' || c == '~' || c == '>' || c == '`';
    if (letter) {
        if (!composing) {
            // stand-alone > acts at once (nukta); z, Z and v open their own choice lists
            if (c == '>') { if (![self nuktaBack:sender]) [self insert:NuktaStr() client:sender]; return YES; }
        }
        [_buf appendString:s]; _sel = 0; _navd = NO; [self refreshClient:sender]; return YES;
    }

    // punctuation ends the word
    if (composing) {
        NSString *suffix = s;
        if (c == '|') suffix = @"।";     // danda
        [self commitIndex:_sel client:sender suffix:suffix bySelection:NO];
        return YES;
    }
    if (c == '|') { [self insert:@"।" client:sender]; return YES; }
    return NO;
}


// ">" typed after a word was already put in the text: put the nukta on the ଡ / ଢ of the last letter before the caret
// (ବଡି> -> ବଡ଼ି, also with a space that was added after the pick). Returns NO when there is no ଡ / ଢ there.
static BOOL OdiaMark(unichar c) { c = Nrm(c); return (c >= 0x0B3E && c <= 0x0B44) || c == 0x0B47 || c == 0x0B48 || c == 0x0B4B || c == 0x0B4C || c == 0x0B56 || c == 0x0B57 || c == 0x0B62 || c == 0x0B63 || c == 0x0B3C || (c >= 0x0B01 && c <= 0x0B03) || c == 0x0B4D || c == 0x200C || c == 0x200D; }
static BOOL OdiaLet(unichar c) { c = Nrm(c); return (c >= 0x0B05 && c <= 0x0B39) || c == 0x0B5C || c == 0x0B5D || c == 0x0B5F || c == 0x0B60 || c == 0x0B61 || c == 0x0B71; }
- (BOOL)nuktaBack:(id)sender {
    id<IMKTextInput> cl = (id<IMKTextInput>)sender;
    NSRange sr = [cl selectedRange];
    if (sr.location == NSNotFound || sr.length != 0 || sr.location == 0) return NO;
    NSUInteger n = MIN((NSUInteger)14, sr.location);
    NSRange back = NSMakeRange(sr.location - n, n);
    NSString *s = [cl attributedSubstringFromRange:back].string;
    if (s.length != n) return NO;
    NSInteger end = (NSInteger)n; BOOL space = NO;
    if (end >= 2 && [s characterAtIndex:end - 1] == ' ' && (OdiaMark([s characterAtIndex:end - 2]) || OdiaLet([s characterAtIndex:end - 2]))) { space = YES; end--; }
    NSInteger i = end - 1;
    while (i > 0 && OdiaMark([s characterAtIndex:i])) i--;
    if (i < 0 || !OdiaLet([s characterAtIndex:i])) return NO;
    NSInteger cs = i;
    while (cs > 0 && Nrm([s characterAtIndex:cs - 1]) == 0x0B4D) { cs--; if (cs > 0 && OdiaLet([s characterAtIndex:cs - 1])) cs--; else break; }
    NSInteger at = -1; NSString *nuk = NuktaStr();
    for (NSInteger j = end - 1; j >= cs; j--) {
        unichar u = [s characterAtIndex:j];
        if ((Nrm(u) == 0x0B21 || Nrm(u) == 0x0B22) && !(j + 1 < end && Nrm([s characterAtIndex:j + 1]) == 0x0B3C)) { at = j + 1; nuk = [NSString stringWithFormat:@"%C", (unichar)(0x0B3C + (u - Nrm(u)))]; break; }
    }
    if (at < 0) return NO;
    NSMutableString *seg = [[s substringWithRange:NSMakeRange(cs, end - cs)] mutableCopy];
    [seg insertString:nuk atIndex:at - cs];
    if (space) [seg appendString:@" "];
    NSRange rep = NSMakeRange(sr.location - n + cs, n - cs);
    [cl insertText:seg replacementRange:rep];
    return YES;
}

// a one-row note under the cursor that names the script just chosen
- (void)flashScript:(id)sender {
    NSRect r = NSZeroRect;
    [(id<IMKTextInput>)sender attributesForCharacterIndex:0 lineHeightRectangle:&r];
    [_panel showCandidates:@[ScriptTitle()] selected:0 roman:@"script" at:r];
    __weak OdiaController *ws = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ OdiaController *me = ws; if (me && me->_buf.length == 0) [me->_panel hide]; });
}
// the input-source menu: choose the script and the Devanagari style
- (NSMenu *)menu {
    NSMenu *m = [[NSMenu alloc] initWithTitle:@"Sulekhak"];
    NSArray *rows = @[@[@"ଓଡ଼ିଆ  Odia  (⌃⌥1)", @"menuOdia:", @(gScript == 0)], @[@"देवनागरी  Devanagari  (⌃⌥2)", @"menuDeva:", @(gScript == 1)], @[@"অসমীয়া  Assamese  (⌃⌥6)", @"menuAsm:", @(gScript == 5)], @[@"বাংলা  Bangla  (⌃⌥3)", @"menuBeng:", @(gScript == 2)], @[@"IPA  Phonetic: IPA · extIPA · IAST  (⌃⌥7)", @"menuPhon:", @(gScript == 4)]];
    for (NSArray *r in rows) { NSMenuItem *it = [[NSMenuItem alloc] initWithTitle:r[0] action:NSSelectorFromString(r[1]) keyEquivalent:@""]; it.target = self; it.state = [r[2] boolValue] ? NSControlStateValueOn : NSControlStateValueOff; [m addItem:it]; }
    [m addItem:[NSMenuItem separatorItem]];
    NSMenuItem *ma = [[NSMenuItem alloc] initWithTitle:@"Devanagari: Marathi ळ  (⌃⌥4)" action:@selector(menuMarathi:) keyEquivalent:@""]; ma.target = self; ma.state = (gOpts & 1) ? NSControlStateValueOn : NSControlStateValueOff; [m addItem:ma];
    NSMenuItem *cj = [[NSMenuItem alloc] initWithTitle:@"Devanagari: conjuncts off, anusvara ं  (⌃⌥5)" action:@selector(menuAnu:) keyEquivalent:@""]; cj.target = self; cj.state = (gOpts & 2) ? NSControlStateValueOn : NSControlStateValueOff; [m addItem:cj];
    [m addItem:[NSMenuItem separatorItem]];
    NSMenuItem *kb = [[NSMenuItem alloc] initWithTitle:@"3D keyboard: show / hide  (⌃⌥K)" action:@selector(menuOSK:) keyEquivalent:@""]; kb.target = self; kb.state = [[OSKPanel shared] isVisible] ? NSControlStateValueOn : NSControlStateValueOff; [m addItem:kb];
    NSMenuItem *zb = [[NSMenuItem alloc] initWithTitle:@"3D keyboard: bigger  (⌃⌥=)" action:@selector(menuOSKBigger:) keyEquivalent:@""]; zb.target = self; [m addItem:zb];
    NSMenuItem *zs = [[NSMenuItem alloc] initWithTitle:@"3D keyboard: smaller  (⌃⌥-)" action:@selector(menuOSKSmaller:) keyEquivalent:@""]; zs.target = self; [m addItem:zs];
    NSMenuItem *tb = [[NSMenuItem alloc] initWithTitle:@"Touch Bar: suggested words" action:@selector(menuTouchBar:) keyEquivalent:@""]; tb.target = self; tb.state = [SuggestBar shared].touchBarEnabled ? NSControlStateValueOn : NSControlStateValueOff; [m addItem:tb];
    return m;
}
- (void)menuTouchBar:(id)s { [SuggestBar shared].touchBarEnabled = ![SuggestBar shared].touchBarEnabled; }
- (void)menuSet:(int)sc { if (_buf.length && _client) [self commitIndex:_sel client:_client suffix:nil bySelection:NO]; gScript = sc; SaveScript(); }
- (void)menuOSK:(id)s { [[OSKPanel shared] toggle]; }
- (void)menuOSKBigger:(id)s { [[OSKPanel shared] zoomBy:0.1]; }
- (void)menuOSKSmaller:(id)s { [[OSKPanel shared] zoomBy:-0.1]; }
- (void)menuOdia:(id)s { [self menuSet:0]; }
- (void)menuDeva:(id)s { [self menuSet:1]; }
- (void)menuBeng:(id)s { [self menuSet:2]; }
- (void)menuAsm:(id)s { [self menuSet:5]; }
- (void)menuPhon:(id)s { [self menuSet:4]; }
- (void)menuMarathi:(id)s { gOpts ^= 1; [self menuSet:1]; }
- (void)menuAnu:(id)s { gOpts ^= 2; [self menuSet:1]; }

- (void)commitComposition:(id)sender { if (_buf.length) [self commitIndex:_sel client:sender suffix:nil bySelection:NO]; }
- (void)deactivateServer:(id)sender { if (_buf.length) [self commitIndex:_sel client:sender suffix:nil bySelection:NO]; [_panel hide]; if (gActive == self) { [[SuggestBar shared] clear]; [[SuggestBar shared] hideTouchBarNow]; } [super deactivateServer:sender]; }

@end
