// SKEnglishTyper: English typing for the Mac keyboard (script 6). The typing rules are the same C++ code as the Windows text service
// (tipcore.cpp): the letters stay in the text as you type them (underlined), the list below offers spellings and completions,
// Space takes the first one (a correction is only made by Space, and Backspace right after it puts your letters back),
// Tab / arrows choose another, Esc keeps what you typed. The suggestions and the learning come from SKPersonal.
#import <Cocoa/Cocoa.h>
#import <InputMethodKit/InputMethodKit.h>

@interface SKEnglishTyper : NSObject
/// Called with the list to show (choices, the highlighted one, the letters typed) and when the list goes away.
@property (copy) void (^showList)(NSArray<NSString *> *choices, NSInteger selected, NSString *typed);
@property (copy) void (^hideList)(void);
@property (readonly) BOOL composing;
/// YES: the key was used; NO: the application gets it.
- (BOOL)handleEvent:(NSEvent *)event client:(id)client;
/// The word being typed stays as typed (focus left, the script was switched, the app asked to finish).
- (void)finishWithClient:(id)client;
/// A choice of the list was clicked with the mouse.
- (void)pickIndex:(NSInteger)i client:(id)client;
@end
