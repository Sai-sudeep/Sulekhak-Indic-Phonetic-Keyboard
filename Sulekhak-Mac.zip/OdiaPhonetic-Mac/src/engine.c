#include "engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <strings.h>

/* ---------- token tables ---------- */
#define HAL "\xE0\xAD\x8D"      /* U+0B4D virama */
#define ZWNJ "\xE2\x80\x8C"     /* U+200C */
#define NUKTA "\xE0\xAC\xBC"    /* U+0B3C */
#define ZWJ "\xE2\x80\x8D"      /* U+200D */
#define ZWJ_Y ZWJ "\xE0\xAD\x9F"  /* ZWJ + ୟ : ର‍୍ୟ shows ର with a ya-phala instead of reph + ୟ */

typedef struct { const char *r; const char *a[3]; } ConsDef;
static const ConsDef CONS[] = {
 {"k",{"କ"}},{"kh",{"ଖ"}},{"g",{"ଗ"}},{"gh",{"ଘ"}},
 {"c",{"ଚ","ଛ"}},{"ch",{"ଚ","ଛ"}},{"chh",{"ଛ"}},{"j",{"ଜ","ଯ"}},{"jh",{"ଝ"}},{"ny",{"ନ୍ୟ","ଞ"}},
 {"T",{"ଟ"}},{"Th",{"ଠ"}},{"D",{"ଡ"}},{"Dh",{"ଢ"}},{"N",{"ଣ"}},
 {"t",{"ତ","ଟ"}},{"th",{"ଥ","ଠ"}},{"d",{"ଦ","ଡ"}},{"dh",{"ଧ","ଢ"}},{"n",{"ନ","ଣ"}},
 {"p",{"ପ"}},{"ph",{"ଫ"}},{"f",{"ଫ"}},{"b",{"ବ"}},{"bh",{"ଭ"}},{"m",{"ମ"}},
 {"y",{"ଯ","ୟ"}},{"Y",{"ୟ"}},{"r",{"ର"}},{"l",{"ଲ","ଳ"}},{"L",{"ଳ"}},{"w",{"ୱ","ଵ"}},
 {"sh",{"ଶ","ଷ"}},{"Sh",{"ଷ"}},{"S",{"ଷ"}},{"s",{"ସ","ଶ","ଷ"}},{"h",{"ହ"}},
 {"R",{"\xE0\xAD\x9C"}},{"Rh",{"\xE0\xAD\x9D"}},      /* U+0B5C ଡ଼ , U+0B5D ଢ଼ (single code points) */
 {"V",{"\xE0\xAC\xB5"}},                              /* U+0B35 ଵ */
 {"v",{"ବ","\xE0\xAC\xB5","ଭ"}},                       /* v is a letter now (the halant moved to the backtick): ବ ଵ ଭ ୱ ; right after a consonant ୱ comes first (see annotate) */
 {"cch",{"ଚ୍ଛ"}},{"cchh",{"ଚ୍ଛ"}},{"ksh",{"କ୍ଷ"}},{"khy",{"କ୍ଷ","ଖ୍ୟ"}},{"x",{"କ୍ଷ"}},{"q",{"କ"}},{"gy",{"ଜ୍ଞ","ଗ୍ୟ"}},{"jn",{"ଜ୍ଞ"}},{"jny",{"ଜ୍ଞ"}},{"ck",{"କ"}},
 /* ISO 15919 / IAST letters, as used by the Microsoft Indic phonetic keyboards */
 {"ṅ",{"ଙ"}},{"ñ",{"ଞ"}},{"ṭ",{"ଟ"}},{"ṭh",{"ଠ"}},{"ḍ",{"ଡ"}},{"ḍh",{"ଢ"}},{"ṇ",{"ଣ"}},{"ś",{"ଶ"}},{"ṣ",{"ଷ"}},{"ḷ",{"ଳ"}},
 {NULL,{NULL}}};

typedef struct { const char *r; const char *ind[3]; const char *sign[3]; } VowDef;
static const VowDef VOW[] = {
 {"a",{"ଅ","ଆ"},{"","ା"}},
 {"aa",{"ଆ"},{"ା"}},{"A",{"ଆ"},{"ା"}},
 {"i",{"ଇ","ଈ"},{"ି","ୀ"}},{"ii",{"ଈ"},{"ୀ"}},{"I",{"ଈ"},{"ୀ"}},
 {"u",{"ଉ","ଊ"},{"ୁ","ୂ"}},{"uu",{"ଊ"},{"ୂ"}},{"oo",{"ଊ"},{"ୂ"}},{"U",{"ଊ"},{"ୂ"}},
 {"rri",{"ଋ"},{"ୃ"}},
 {"rrii",{"ୠ"},{"ୄ"}},{"rrI",{"ୠ"},{"ୄ"}},                       /* long vocalic R */
 {"lrri",{"ଌ"},{"ୢ"}},                                           /* vocalic L */
 {"lrrii",{"ୡ"},{"ୣ"}},{"lrrI",{"ୡ"},{"ୣ"}},                     /* long vocalic L */
 {"e",{"ଏ"},{"େ"}},{"ai",{"ଐ"},{"ୈ"}},{"o",{"ଓ"},{"ୋ"}},{"au",{"ଔ"},{"ୌ"}},{"ou",{"ଔ"},{"ୌ"}},{"ee",{"ଈ"},{"ୀ"}},
 {"AA",{"ଆ"},{"ା"}},{"II",{"ଈ"},{"ୀ"}},{"EE",{"ଈ"},{"ୀ"}},{"UU",{"ଊ"},{"ୂ"}},{"OO",{"ଊ"},{"ୂ"}},
 {"ā",{"ଆ"},{"ା"}},{"ī",{"ଈ"},{"ୀ"}},{"ū",{"ଊ"},{"ୂ"}},{"ṛ",{"ଋ"},{"ୃ"}},{"ē",{"ଏ"},{"େ"}},{"ō",{"ଓ"},{"ୋ"}},
 {NULL,{NULL},{NULL}}};

/* raw tokens: emitted as typed-in characters. keep=1: does not change consonant state (nukta) */
typedef struct { const char *r; const char *o; int kind; } RawDef; /* kind 0 reset, 1 keep, 2 vowel-like sign */
static const RawDef RAW[] = {
 {"z",ZWNJ,0},          /* z        -> ZWNJ only                 */
 {"Z",HAL ZWNJ,0},      /* shift+z  -> halant + ZWNJ             */
 {"`",HAL,0},           /* ` (backtick) -> halant only (no ZWNJ) */
 {">",NUKTA,1},         /* shift+>  -> U+0B3C ORIYA SIGN NUKTA   */
 {"M","ଂ",2},{"H","ଃ",2},{"~","ଁ",2},{"ṁ","ଂ",2},{"ṃ","ଂ",2},{"ḥ","ଃ",2},
 {"|","।",0},
 {"AIL","ୖ",2},{"AUL","ୗ",2},   /* AI / AU length marks (rare, used in decomposed ୈ ୌ) */
 {NULL,NULL,0}};

/* common Odia suffixes: a stem that ends in a consonant also gets a halant + ZWNJ version before them (ଘର୍‌କୁ) */
static const char *SUFFIX[] = {
 "ଟିଏ","ଟି","ଟା","ଟିକୁ","ଟାକୁ","ଟିର","ଟାର","ଟିରେ","ଟାରେ","ମାନେ","ମାନଙ୍କ","ମାନଙ୍କୁ","ମାନଙ୍କର","ମାନଙ୍କରେ",
 "କୁ","ରୁ","ରେ","ର","ଠାରୁ","ଠାରେ","ପାଇଁ","ଗୁ\xE0\xAD\x9Cିକ", NULL};

enum { T_K, T_V, T_RAW, T_DIGIT, T_OTHER, T_SEP };
typedef struct { int kind, n, keep; const char *a[6]; const char *s[6]; int cost[6]; char lit[8]; char r[6]; } Tok;

static int startswith(const char *s, const char *p){ size_t l=strlen(p); return l && strncmp(s,p,l)==0; }
static int is_vowel_ch(char c){ c=(char)tolower((unsigned char)c); return c=='a'||c=='e'||c=='i'||c=='o'||c=='u'; }

static int g_ndg;   /* number of splittable vowel digraphs (ai, au, ou) met by the last parse */
/* per-token alternative costs, and the homorganic nasal rule: n before k/kh/g/gh is ଙ, before ch/j is ଞ, before T/D is ଣ,
   before t/d is ନ. The class nasal comes first; the plain letters and anusvara follow. */
static int nasal_class(const char *r){
  static const char *vel[]={"k","kh","g","gh","ck","q","ksh","x",NULL}, *pal[]={"c","ch","chh","cch","cchh","j","jh",NULL},
    *ret[]={"T","Th","D","Dh","ṭ","ṭh","ḍ","ḍh","ṇ","N",NULL}, *den[]={"t","th","d","dh",NULL}, *lab[]={"p","ph","b","bh","f","m",NULL};
  const char **L[5]={vel,pal,ret,den,lab};
  for(int c=0;c<5;c++) for(int i=0;L[c][i];i++) if(strcmp(r,L[c][i])==0) return c+1;
  return 0;
}
static void set_alts(Tok *k, const char **alts, int n){
  k->n=n; for(int i=0;i<n;i++){ k->a[i]=alts[i]; k->cost[i]=i==0?0:(strcmp(alts[i],"ଂ")==0?4:1); }
}
static int is_anu(const char *x){ return strcmp(x,"ଂ")==0 || strcmp(x,"ଁ")==0; }
static void annotate(Tok *t, int nt){
  for(int i=0;i<nt;i++){
    Tok *k=&t[i];
    /* a nasal before a consonant agrees with it (ଙ୍କ ଞ୍ଚ ଣ୍ଟ ନ୍ତ); at the start of a word only n + a stop (nk nT nt nch) */
    if(k->kind==T_K && (strcmp(k->r,"n")==0||strcmp(k->r,"m")==0) && i+1<nt && t[i+1].kind==T_K
       && (i>0 || (k->r[0]=='n' && nasal_class(t[i+1].r)>=1))){
      int cl=nasal_class(t[i+1].r);
      if(strcmp(k->r,"n")==0){
        static const char *v[]={"ଙ","ନ","ଣ","ଂ"}, *p[]={"ଞ","ନ","ଣ","ଂ"}, *r[]={"ଣ","ନ","ଂ"}, *d[]={"ନ","ଣ","ଂ"}, *l[]={"ନ","ମ","ଂ"};
        if(cl==1) set_alts(k,v,4); else if(cl==2) set_alts(k,p,4); else if(cl==3) set_alts(k,r,3);
        else if(cl==5) set_alts(k,l,3); else set_alts(k,d,3);
        if(i==0) k->n--;                                               /* no anusvara at the start of a word */
        else if(t[i-1].kind==T_V){ k->a[k->n-1]="ଁ"; k->cost[k->n-1]=5; k->a[k->n]="ଂ"; k->cost[k->n]=4; k->n++; }  /* keunthare -> କେଉଁଠାରେ */
      } else if(cl>=1 && cl<=4){ static const char *m1[]={"ଂ"}; set_alts(k,m1,1); }   /* ସଂଖ୍ୟା: m before k ch T t is anusvara */
      else { static const char *m[]={"ମ","ଂ"}; set_alts(k,m,2); }
    }
    /* before s sh h y r l v w the anusvara is the usual spelling (ସଂସାର ସିଂହ ସଂଯୋଗ ସଂରକ୍ଷଣ): put it right after the first choice */
    if(k->kind==T_K && (strcmp(k->r,"n")==0||strcmp(k->r,"m")==0) && i+1<nt && t[i+1].kind==T_K && nasal_class(t[i+1].r)==0 && (i>0||k->r[0]=='n') && strchr("sSyYrlLvwh",t[i+1].r[0])){
      for(int q=0;q<k->n;q++) if(strcmp(k->a[q],"ଂ")==0) k->cost[q]=0;
    }
    /* word-final n / ng / m after a vowel: chandrabindu and anusvara are alternatives too */
    if(k->kind==T_K && i==nt-1 && i>0 && t[i-1].kind==T_V && (strcmp(k->r,"n")==0||strcmp(k->r,"ng")==0||strcmp(k->r,"m")==0) && k->n<=2){
      k->a[k->n]="ଁ"; k->cost[k->n]=3; k->n++; k->a[k->n]="ଂ"; k->cost[k->n]=3; k->n++;
    }
    /* v after a consonant is the cluster letter ୱ (ସ୍ୱ ତ୍ୱ ଦ୍ୱ); elsewhere ବ (ବେଦ ଦେବ), then ଵ, ଭ, ୱ */
    if(k->kind==T_K && strcmp(k->r,"v")==0 && k->n==3){
      if(i>0 && t[i-1].kind==T_K){ k->a[0]="ୱ"; k->a[1]="ବ"; k->a[2]="\xE0\xAC\xB5"; k->a[3]="ଭ"; }
      else { k->a[3]="ୱ"; }                                                /* ବ ଵ ଭ ୱ */
      k->n=4; k->cost[0]=0; k->cost[1]=k->cost[2]=k->cost[3]=1;
    }
    /* t th d dh: the retroflex reading is the unusual one (people type T Th D Dh for it) */
    if(k->kind==T_K && k->n>=2 && (strcmp(k->r,"t")==0||strcmp(k->r,"th")==0||strcmp(k->r,"d")==0||strcmp(k->r,"dh")==0)) k->cost[1]=3;
    /* y after a vowel is the letter ୟ (ଭୟ ଜୟ ପ୍ରିୟ); word-initially and in a conjunct it is ଯ (ଯାଇ ସତ୍ୟ) */
    if(k->kind==T_K && strcmp(k->r,"y")==0 && k->n==2){
      /* Odia writes ya as ୟ (U+0B5F) after a vowel and in a conjunct (ସତ୍ୟ ଭୟ); ଯ only starts a word (ଯାଇ) */
      if(i>0){ k->a[0]="ୟ"; k->a[1]="ଯ"; k->cost[1]=3; } else k->cost[1]=3;
    }
    /* j is ଜ, and also ଯ (ଯେଉଁ, ସୂର୍ଯ୍ୟ) */
    if(k->kind==T_K && strcmp(k->r,"j")==0 && k->n==2) k->cost[1]=2;
    /* r + y: an extra reading with ZWJ, ର\u200d୍ୟ = ର with a ya-phala (not reph + ୟ) */
    if(k->kind==T_K && (strcmp(k->r,"y")==0||strcmp(k->r,"Y")==0) && i>0 && t[i-1].kind==T_K && strcmp(t[i-1].r,"r")==0 && k->n<5){
      k->a[k->n]=ZWJ_Y; k->cost[k->n]=2; k->n++;
    }
    if(k->kind==T_K && strcmp(k->r,"ny")==0 && k->n==2) k->cost[1]=2;
    if(k->kind==T_K && strcmp(k->r,"gy")==0 && k->n==2) k->cost[1]=2;
    if(k->kind==T_V && k->n>=2 && strcmp(k->a[0],"ଅ")==0 && i+1<nt && t[i+1].kind==T_V){ k->cost[0]=1; k->cost[1]=0; }  /* a before a vowel is the kaara ା first */
  }
}

static int parse(const char *s, Tok *t, int max, int mask){
  int nt=0; g_ndg=0;
  while(*s && nt<max-1){
    Tok *k=&t[nt]; memset(k,0,sizeof *k);
    /* two apostrophes = avagraha ଽ, three = Isshar ୰ (one apostrophe stays the syllable separator) */
    if(s[0]=='\''&&s[1]=='\''){ int q=(s[2]=='\'')?3:2; k->kind=T_RAW; k->n=1; k->a[0]=(q==3)?"୰":"ଽ"; k->keep=0; nt++; s+=q; continue; }
    if(*s=='\''){ k->kind=T_SEP; nt++; s++; continue; }
    if(*s>='0'&&*s<='9'){ k->kind=T_DIGIT; k->lit[0]=*s; nt++; s++; continue; }
    /* "ng": before a vowel the usual Odia spelling is ଙ୍ଗ, otherwise ଙ */
    if(startswith(s,"ngh")){ k->kind=T_K; k->n=1; k->a[0]="ଙ୍ଘ"; nt++; s+=3; continue; }
    if(startswith(s,"ng")){
        k->kind=T_K; k->n=2; strcpy(k->r,"ng");
        if(is_vowel_ch(s[2])){ k->a[0]="ଙ୍ଗ"; k->a[1]="ଙ"; } else { k->a[0]="ଙ"; k->a[1]="ଙ୍ଗ"; }
        k->cost[1]=1;
        nt++; s+=2; continue; }
    /* longest match over vowels, consonants, raw */
    int best=0, bk=-1; const void *bp=NULL;
    for(const ConsDef *c=CONS;c->r;c++){ size_t l=strlen(c->r); if(l>(size_t)best && startswith(s,c->r)){best=(int)l;bk=T_K;bp=c;} }
    for(const VowDef  *v=VOW; v->r;v++){ size_t l=strlen(v->r); if(l>(size_t)best && startswith(s,v->r)){best=(int)l;bk=T_V;bp=v;} }
    for(const RawDef  *r=RAW; r->r;r++){ size_t l=strlen(r->r); if(l>(size_t)best && startswith(s,r->r)){best=(int)l;bk=T_RAW;bp=r;} }
    /* case-insensitive fallback for letters the tables only hold in lower case */
    if(!best && isupper((unsigned char)*s)){
      char low[2]={(char)tolower((unsigned char)*s),0};
      for(const ConsDef *c=CONS;c->r;c++) if(strcmp(c->r,low)==0){best=1;bk=T_K;bp=c;}
      if(!best) for(const VowDef *v=VOW;v->r;v++) if(strcmp(v->r,low)==0){best=1;bk=T_V;bp=v;}
    }
    if(bk==T_V){   /* ai, au, ou can also be read as two vowels: a+i, a+u, o+u (khaibaku -> ଖାଇବାକୁ) */
      const VowDef *v=bp;
      if(strcmp(v->r,"ai")==0||strcmp(v->r,"au")==0||strcmp(v->r,"ou")==0){
        int di=g_ndg++;
        if((mask>>di)&1){ const char *one=(v->r[0]=='a')?"a":"o"; for(const VowDef *w=VOW;w->r;w++) if(strcmp(w->r,one)==0){bp=w;best=1;break;} }
      }
    }
    if(!best){
      k->kind=T_OTHER; size_t l=1; unsigned char c=(unsigned char)*s;
      if(c>=0xF0) l=4; else if(c>=0xE0) l=3; else if(c>=0xC0) l=2;
      memcpy(k->lit,s,l<7?l:7); nt++; s+=l; continue;
    }
    if(bk==T_K){ const ConsDef*c=bp; k->kind=T_K; strncpy(k->r,c->r,5); for(int i=0;i<3&&c->a[i];i++){k->a[i]=c->a[i];k->n++;} k->cost[1]=k->cost[2]=1; }
    else if(bk==T_V){ const VowDef*v=bp; k->kind=T_V; for(int i=0;i<3&&v->ind[i];i++){k->a[i]=v->ind[i];k->s[i]=v->sign[i];k->n++;} k->cost[1]=k->cost[2]=1; }
    else { const RawDef*r=bp; k->kind=T_RAW; k->n=1; k->a[0]=r->o; k->keep=r->kind; }
    nt++; s+=best;
  }
  t[nt].kind=-1; annotate(t,nt); return nt;
}

/* ---------- rendering with a choice per token ---------- */
enum { S_NONE, S_CONS, S_AFTERV, S_RAW };
static int g_badnuk;   /* set by render(): a nukta landed on something other than ଡ / ଢ */
static void render(const Tok *t, const int *ch, char *out, size_t cap){
  int st=S_NONE; out[0]=0; size_t len=0; long consEnd=-1, nukAt=-1; g_badnuk=0;
  #define APP(x) do{ const char*_p=(x); size_t _l=strlen(_p); if(len+_l<cap-1){memcpy(out+len,_p,_l);len+=_l;out[len]=0;} }while(0)
  for(int i=0;t[i].kind>=0;i++){
    const Tok *k=&t[i]; int c=ch?ch[i]:0; if(c>=k->n) c=0;
    switch(k->kind){
      case T_K:
        if(is_anu(k->a[c])){ APP(k->a[c]); st=S_AFTERV; break; }   /* anusvara instead of the nasal letter */
      { const char *x=k->a[c];
        if(strncmp(x,ZWJ,3)==0){ if(st==S_CONS){ APP(ZWJ); APP(HAL); } x+=3; }
        else if(st==S_CONS) APP(HAL);     /* consonant + consonant => conjunct */
        if(st!=S_CONS) nukAt=-1;
        APP(x); st=S_CONS; consEnd=(long)len;
        if(strlen(x)==3 && (unsigned char)x[0]==0xE0 && (unsigned char)x[1]==0xAC && ((unsigned char)x[2]==0xA1||(unsigned char)x[2]==0xA2)) nukAt=(long)len;   /* ଡ ଢ */
        break; }
      case T_V:
        if(st==S_CONS){ APP(k->s[c]?k->s[c]:""); st=S_AFTERV; }
        else { APP(k->a[c]); st=S_AFTERV; }
        break;
      case T_RAW:
        if(k->keep==1){ /* nukta goes to the nucleus: the last ଡ / ଢ of the cluster (ଉଡ଼୍ରୈ), else the last consonant, before any matra: ବଡ + i + > => ବଡ଼ି */
          size_t nl=strlen(k->a[0]); long tg=nukAt>=0?nukAt:consEnd;
          if(tg>=0 && len+nl<cap-1){
            if(!(tg>=3 && (unsigned char)out[tg-3]==0xE0 && (unsigned char)out[tg-2]==0xAC && ((unsigned char)out[tg-1]==0xA1||(unsigned char)out[tg-1]==0xA2))) g_badnuk=1;
            memmove(out+tg+nl,out+tg,len-(size_t)tg+1); memcpy(out+tg,k->a[0],nl); len+=nl; consEnd+=(long)nl; if(nukAt>=0) nukAt+=(long)nl; }
          else { APP(k->a[0]); g_badnuk=1; }
        } else APP(k->a[0]);
        if(k->keep==1){ /* state unchanged */ }
        else if(k->keep==2) st=S_AFTERV; else st=S_RAW;
        break;
      case T_DIGIT: { int d=k->lit[0]-'0'; char b[4]={(char)0xE0,(char)0xAD,(char)(0xA6+d),0}; APP(b); st=S_NONE; break; }
      case T_OTHER: APP(k->lit); st=S_NONE; break;
      case T_SEP: break;
    }
  }
  #undef APP
}

void odia_transliterate(const char *roman, char *out, size_t cap){
  Tok t[128]; parse(roman,t,128,0); render(t,NULL,out,cap);
}

/* ---------- is this string possible Odia spelling? (used to drop impossible candidates and learned picks) ---------- */
static int v_stop(unsigned cp){
  if(cp>=0x0B15&&cp<=0x0B18) return 1; if(cp>=0x0B1A&&cp<=0x0B1D) return 2;
  if((cp>=0x0B1F&&cp<=0x0B22)||cp==0x0B5C||cp==0x0B5D) return 3;
  if(cp>=0x0B24&&cp<=0x0B27) return 4; if(cp>=0x0B2A&&cp<=0x0B2D) return 5; return 0; }
static int v_nasal(unsigned cp){ switch(cp){ case 0x0B19:return 1; case 0x0B1E:return 2; case 0x0B23:return 3; case 0x0B28:return 4; case 0x0B2E:return 5; } return 0; }
static int v_cons(unsigned cp){ return (cp>=0x0B15&&cp<=0x0B39)||cp==0x0B5C||cp==0x0B5D||cp==0x0B5F||cp==0x0B71; }
static int v_sign(unsigned cp){ return (cp>=0x0B3E&&cp<=0x0B44)||cp==0x0B47||cp==0x0B48||cp==0x0B4B||cp==0x0B4C||cp==0x0B56||cp==0x0B57||cp==0x0B62||cp==0x0B63; }
static int valid_word(const char *w){
  unsigned cp[256]; int n=0; const unsigned char *q=(const unsigned char*)w;
  while(*q && n<255){
    if(q[0]<0x80){ cp[n++]=q[0]; q++; }
    else if(q[0]<0xE0){ cp[n++]=((q[0]&0x1Fu)<<6)|(q[1]&0x3Fu); q+=2; }
    else if(q[0]<0xF0){ cp[n++]=((q[0]&0x0Fu)<<12)|((q[1]&0x3Fu)<<6)|(q[2]&0x3Fu); q+=3; }
    else { cp[n++]=0xFFFD; q+=4; }
  }
  if(n==0) return 1;
  for(int i=0;i<n;i++){
    unsigned c=cp[i], p=i?cp[i-1]:0, x=i+1<n?cp[i+1]:0;
    if(v_sign(c)){ if(!(v_cons(p)||p==0x0B3C)) return 0; }
    else if(c==0x0B4D){ if(!(v_cons(p)||p==0x0B3C||p==0x200D)) return 0; if(x==0x0B4D||v_sign(x)) return 0; }
    else if(c==0x0B3C){ if(!(p==0x0B21||p==0x0B22)) return 0; }   /* the nukta belongs to ଡ and ଢ only */
    else if(c==0x0B01||c==0x0B02||c==0x0B03){ if(i==0||v_sign(x)) return 0; }
    else if(c==0x200C){ if(p!=0x0B4D) return 0; }
    else if(c==0x200D){ if(!(p==0x0B30 && x==0x0B4D && i+2<n && (cp[i+2]==0x0B5F||cp[i+2]==0x0B2F))) return 0; }   /* ର\u200d୍ୟ only */
    if(v_cons(c) && x==0x0B4D && i+2<n){                       /* conjunct c + halant + next */
      unsigned nx=cp[i+2]; int fc=v_stop(nx), nl=v_nasal(c);
      if(nl && fc){ if(nl!=fc && !(nl==4&&fc==5)) return 0; }    /* ଙ୍କ ଞ୍ଚ ଣ୍ଟ ନ୍ତ ମ୍ପ; ନ୍ବ allowed */
      if(c==0x0B37 && (fc==4||fc==2)) return 0;
      if(c==0x0B38 && fc==2) return 0;
      if(c==0x0B36 && (fc==3||fc==4)) return 0;
    }
  }
  return 1;
}
/* words the person added to the Sulekhak Dictionary on purpose (names, new words): they are never rejected as "impossible spellings" */
static char **uset=NULL; static size_t ucap=0, un=0;
static size_t uhash(const char *s){ size_t h=5381; while(*s) h=h*33+(unsigned char)*s++; return h; }
static int user_has(const char *s){
  if(!ucap) return 0;
  for(size_t i=uhash(s)&(ucap-1);uset[i];i=(i+1)&(ucap-1)) if(strcmp(uset[i],s)==0) return 1;
  return 0;
}
static void user_add(const char *s){
  if(!s||!*s||user_has(s)) return;
  if((un+1)*2>ucap){
    size_t oc=ucap; char **os=uset; ucap=ucap?ucap*2:256; uset=calloc(ucap,sizeof *uset);
    for(size_t i=0;i<oc;i++) if(os[i]){ size_t j=uhash(os[i])&(ucap-1); while(uset[j]) j=(j+1)&(ucap-1); uset[j]=os[i]; }
    free(os);
  }
  size_t i=uhash(s)&(ucap-1); while(uset[i]) i=(i+1)&(ucap-1);
  uset[i]=strdup(s); un++;
}
/* a candidate or dictionary entry may hold several words separated by spaces */
static int valid_odia(const char *s){
  if(user_has(s)) return 1;
  char b[ODIA_CAND_LEN]; size_t o=0;
  for(const char *p=s;;p++){
    if(*p==' '||*p==0){ b[o]=0; if(o && !user_has(b) && !valid_word(b)) return 0; o=0; if(!*p) break; }
    else if(o<sizeof b-1) b[o++]=*p;
  }
  return 1;
}

/* ---------- dictionary ---------- */
typedef struct { char *r; char *o; int w; } Lex;
static Lex *lex=NULL; static size_t nlex=0, caplex=0;

/* set of known Odia spellings (dictionary words, word forms, and the user's own words) */
static char **kset=NULL; static size_t kcap=0, kn=0;
static size_t khash(const char *s){ size_t h=5381; while(*s) h=h*33+(unsigned char)*s++; return h; }
static void known_clear(void){ for(size_t i=0;i<kcap;i++) free(kset[i]); free(kset); kset=NULL; kcap=kn=0; }
static int known_has(const char *s){
  if(!kcap) return 0;
  for(size_t i=khash(s)&(kcap-1);kset[i];i=(i+1)&(kcap-1)) if(strcmp(kset[i],s)==0) return 1;
  return 0;
}
static void known_add(const char *s){
  if(!s||!*s||known_has(s)) return;
  if((kn+1)*2>kcap){
    size_t oc=kcap; char **os=kset; kcap=kcap?kcap*2:4096; kset=calloc(kcap,sizeof *kset);
    for(size_t i=0;i<oc;i++) if(os[i]){ size_t j=khash(os[i])&(kcap-1); while(kset[j]) j=(j+1)&(kcap-1); kset[j]=os[i]; }
    free(os);
  }
  size_t i=khash(s)&(kcap-1); while(kset[i]) i=(i+1)&(kcap-1);
  kset[i]=strdup(s); kn++;
}

void odia_lex_clear(void){ for(size_t i=0;i<nlex;i++){free(lex[i].r);free(lex[i].o);} nlex=0; known_clear(); }
void odia_lex_add(const char *roman, const char *odia, int weight){
  if(!roman||!odia||!*roman||!*odia) return;
  if(!valid_odia(odia)) return;          /* e.g. କାଣ୍ତା: never learned, never ranked */
  known_add(odia);
  for(size_t i=0;i<nlex;i++) if(strcasecmp(lex[i].r,roman)==0 && strcmp(lex[i].o,odia)==0){ lex[i].w+=weight; return; }
  if(nlex==caplex){ caplex=caplex?caplex*2:1024; lex=realloc(lex,caplex*sizeof *lex); }
  lex[nlex].r=strdup(roman); lex[nlex].o=strdup(odia); lex[nlex].w=weight; nlex++;
}
/* A word or expression added by the person (Add to Sulekhak Dictionary): it is trusted as it is, so it is never filtered out as an impossible spelling. */
void odia_lex_add_user(const char *roman, const char *odia, int weight){
  if(!roman||!odia||!*roman||!*odia) return;
  user_add(odia);
  known_add(odia);
  for(size_t i=0;i<nlex;i++) if(strcasecmp(lex[i].r,roman)==0 && strcmp(lex[i].o,odia)==0){ lex[i].w+=weight; return; }
  if(nlex==caplex){ caplex=caplex?caplex*2:1024; lex=realloc(lex,caplex*sizeof *lex); }
  lex[nlex].r=strdup(roman); lex[nlex].o=strdup(odia); lex[nlex].w=weight; nlex++;
}
#include "lexicon.inc"
#include "words.inc"
void odia_load_builtin(void){
  for(size_t i=0;i<sizeof BUILTIN/sizeof BUILTIN[0];i++) odia_lex_add(BUILTIN[i][0],BUILTIN[i][1],atoi(BUILTIN[i][2]));
  for(int i=0;WORDS[i];i++) if(valid_odia(WORDS[i])) known_add(WORDS[i]);
}

/* ---------- candidates ---------- */
static int g_limit=ODIA_MAX_CANDS;
static int g_filter=1;   /* 0 for the hand-made lists (lone letters, z v Z, digits, danda) */
static int has(char c[][ODIA_CAND_LEN], int n, const char *s){ for(int i=0;i<n;i++) if(strcmp(c[i],s)==0) return 1; return 0; }
static void put(char c[][ODIA_CAND_LEN], int *n, const char *s){ if(*n<g_limit && *s && !has(c,*n,s)){ strncpy(c[*n],s,ODIA_CAND_LEN-1); c[*n][ODIA_CAND_LEN-1]=0; (*n)++; } }

typedef struct { char s[ODIA_CAND_LEN]; int score, cost, known, idx; } Var;
static int cmpvar(const void*a,const void*b){ const Var*x=a,*y=b; return x->score!=y->score ? x->score-y->score : x->idx-y->idx; }

static void lex_exact(const char *roman, char cands[][ODIA_CAND_LEN], int *n, int rounds){
  for(int round=0;round<rounds && *n<g_limit;round++){
    int pi=-1,pw=-1;
    for(size_t i=0;i<nlex;i++) if(strcasecmp(lex[i].r,roman)==0 && !has(cands,*n,lex[i].o) && lex[i].w>pw){pw=lex[i].w;pi=(int)i;}
    if(pi<0) break;
    put(cands,n,lex[pi].o);
  }
}
static void lex_prefix(const char *roman, char cands[][ODIA_CAND_LEN], int *n, int rounds){
  for(int round=0;round<rounds && *n<g_limit;round++){
    int pi=-1,pw=-1;
    for(size_t i=0;i<nlex;i++)
      if(strncasecmp(lex[i].r,roman,strlen(roman))==0 && strlen(lex[i].r)>strlen(roman) && !has(cands,*n,lex[i].o) && lex[i].w>pw){pw=lex[i].w;pi=(int)i;}
    if(pi<0) break;
    put(cands,n,lex[pi].o);
  }
}

/* ---- consistency between neighbouring letters ---- */
static unsigned first_cp(const char *s){ const unsigned char *q=(const unsigned char*)s; if(q[0]<0x80) return q[0];
  if(q[0]<0xE0) return ((q[0]&0x1Fu)<<6)|(q[1]&0x3Fu); return ((q[0]&0x0Fu)<<12)|((q[1]&0x3Fu)<<6)|(q[2]&0x3Fu); }
/* stop class: 1 velar, 2 palatal, 3 retroflex, 4 dental, 5 labial, 0 not a stop */
static int stop_class(unsigned cp){
  if(cp>=0x0B15&&cp<=0x0B18) return 1; if(cp>=0x0B1A&&cp<=0x0B1D) return 2;
  if((cp>=0x0B1F&&cp<=0x0B22)||cp==0x0B5C||cp==0x0B5D) return 3;
  if(cp>=0x0B24&&cp<=0x0B27) return 4; if((cp>=0x0B2A&&cp<=0x0B2D)) return 5; return 0; }
/* the nasal letters: ଙ ଞ ଣ ନ ମ -> the class they belong to */
static int nasal_letter_class(const char *s){
  if(strlen(s)!=3) return 0; unsigned cp=first_cp(s);
  switch(cp){ case 0x0B19: return 1; case 0x0B1E: return 2; case 0x0B23: return 3; case 0x0B28: return 4; case 0x0B2E: return 5; }
  return 0; }
/* cost of one combination of choices, or -1 when it is not a possible Odia spelling:
   nasal letters must sit before their own class (kanta is never କାଣ୍ତା), except ନ before a labial; ଷ not before dental/palatal,
   ସ not before palatal, ଶ not before retroflex/dental; ଣ ଙ ଞ ଳ ୟ never start a word. */
static int var_cost(const Tok *u, int nu, const int *ch){
  int c=0;
  for(int i=0;i<nu;i++){
    const Tok *k=&u[i]; if(k->kind!=T_K && k->kind!=T_V) continue;
    int cc=k->n>1?k->cost[ch[i]]:0;
    if(k->kind==T_K && i==0 && ch[i]>0 && k->n>1){      /* ଳ never starts a word; ଣ ଙ ଞ only as the start of their own conjunct (ଙ୍କ ଣ୍ଟ) */
      unsigned f=first_cp(k->a[ch[i]]);
      if(f==0x0B33) return -1;
      if(f==0x0B23||f==0x0B19||f==0x0B1E){
        int nc=nasal_letter_class(k->a[ch[i]]), fc0=(i+1<nu && u[i+1].kind==T_K)?stop_class(first_cp(u[i+1].a[ch[i+1]])):0;
        if(!(nc && nc==fc0)) return -1;
      }
    }
    if(k->kind==T_K && strncmp(k->a[ch[i]],ZWJ,3)==0){      /* ZWJ ya-phala only after a plain ର */
      if(!(i>0 && u[i-1].kind==T_K && strcmp(u[i-1].a[ch[i-1]],"ର")==0)) return -1;
    }
    if(k->kind==T_K && i+1<nu && u[i+1].kind==T_K){
      const char *L=k->a[ch[i]]; const Tok *nx=&u[i+1]; int fc=stop_class(first_cp(nx->a[ch[i+1]]));
      int nl=nasal_letter_class(L);
      if(nl && fc){ if(nl==fc) cc=0; else if(nl==4 && fc==5) cc=2; else return -1; }   /* ନ before a labial is allowed (ଅନ୍ବେଷଣ) */
      else if(strlen(L)==3 && fc){
        unsigned cp=first_cp(L);
        if(cp==0x0B37 && (fc==4||fc==2)) return -1;        /* ଷ: not before dental or palatal */
        else if(cp==0x0B38 && fc==2) return -1;            /* ସ: not before palatal */
        else if(cp==0x0B38 && fc==3) cc+=3;                /* ସ୍ଟ only as a loanword spelling */
        else if(cp==0x0B36 && (fc==3||fc==4)) return -1;   /* ଶ: not before retroflex or dental */
      }
    }
    c+=cc;
  }
  return c;
}

/* every reading of a Roman string: ambiguous letters, split vowel pairs, and ri read as ୃ; cheapest first;
   known words get a big bonus */
static void enum_one(const char *roman, int offset, int variant, Var *vars, int *nv, int cap){
  Tok t[128]; parse(roman,t,128,0); int ndg=g_ndg; if(ndg>2) ndg=2;
  int nmask=1<<ndg;
  for(int mask=0;mask<nmask;mask++){
    Tok u[128]; int nu=parse(roman,u,128,mask);
    int amb[16],na=0; for(int i=0;i<nu&&na<10;i++) if((u[i].kind==T_K||u[i].kind==T_V)&&u[i].n>1) amb[na++]=i;
    long total=1; for(int j=0;j<na;j++){ total*=u[amb[j]].n; if(total>cap){ total=cap; break; } }
    int ch[128];
    for(long code=0;code<total;code++){
      memset(ch,0,sizeof ch); long x=code;
      for(int j=na-1;j>=0;j--){ int m=u[amb[j]].n; ch[amb[j]]=(int)(x%m); x/=m; }   /* last letter varies fastest */
      int cost=var_cost(u,nu,ch); if(cost<0) continue;
      for(int b=0;b<ndg;b++) if(!((mask>>b)&1)) cost+=1;     /* ai is read as a+i first; the ଐ reading costs one */
      cost+=offset;
      Var *v=&vars[*nv]; render(u,ch,v->s,ODIA_CAND_LEN);
      cost+=8*g_badnuk; v->cost=cost; v->known=known_has(v->s); v->score=cost-(v->known?20:0); v->idx=variant*1000000+mask*65536+(int)code; (*nv)++;
    }
  }
}
/* roman-level respellings people use for the same Odia: ri = ୃ (krishna), ry = ର୍ଯ୍ୟ (surya, karya), ryy (suryya) */
static int respell(const char *roman, int flags, char *out, size_t cap){
  size_t o=0; const char *p=roman;
  while(*p && o+4<cap){
    if((flags&2) && startswith(p,"ryy")){ memcpy(out+o,"rjy",3); o+=3; p+=3; }
    else if((flags&2) && startswith(p,"ry")){ memcpy(out+o,"rjy",3); o+=3; p+=2; }
    else if((flags&1) && startswith(p,"ri")){ memcpy(out+o,"rri",3); o+=3; p+=2; }
    else out[o++]=*p++;
  }
  out[o]=0; return (int)o;
}
static int enum_vars(const char *roman, Var **out, int cap){
  int a0=strstr(roman,"ri") && !strstr(roman,"rri"), a1=strstr(roman,"ry")!=NULL;
  Var *vars=malloc(sizeof(Var)*(size_t)4*(size_t)cap*4); int nv=0;
  enum_one(roman,0,0,vars,&nv,cap);
  char alt[256];
  if(a0){ respell(roman,1,alt,sizeof alt); enum_one(alt,2,1,vars,&nv,cap); }
  if(a1){ respell(roman,2,alt,sizeof alt); enum_one(alt,1,2,vars,&nv,cap); }
  if(a0&&a1){ respell(roman,3,alt,sizeof alt); enum_one(alt,3,3,vars,&nv,cap); }
  qsort(vars,(size_t)nv,sizeof(Var),cmpvar);
  *out=vars; return nv;
}

/* ---- word segmentation: delenahin -> ଦେଲେନାହିଁ / ଦେଲେ ନାହିଁ ---- */
static int piece_best(const char *piece, char *out, int *cost){
  int bw=-1,bi=-1;
  for(size_t i=0;i<nlex;i++) if(strcasecmp(lex[i].r,piece)==0 && lex[i].w>bw){bw=lex[i].w;bi=(int)i;}
  if(bi>=0){ strcpy(out,lex[bi].o); *cost=0; return 1; }
  Var *v; int nv=enum_vars(piece,&v,200); int found=0;
  for(int i=0;i<nv;i++) if(v[i].known && strlen(v[i].s)>=9){   /* a piece found by spelling must be at least 3 letters long */ strcpy(out,v[i].s); *cost=v[i].cost; found=1; break; }   /* sorted: first known = cheapest */
  free(v); return found;
}
static int segment(const char *roman, char *concat, char *spaced){
  int L=(int)strlen(roman); if(L<6||L>24) return 0;
  for(int i=0;i<L;i++) if(!isalpha((unsigned char)roman[i])) return 0;
  static char str[25][ODIA_CAND_LEN]; int nseg[25], cst[25], prev[25];
  for(int i=0;i<=L;i++){ nseg[i]=1000; cst[i]=0; prev[i]=-1; }
  nseg[0]=0;
  for(int i=0;i<L;i++){ if(nseg[i]>=1000) continue;
    for(int j=i+3;j<=L&&j-i<=14;j++){
      char piece[16]; memcpy(piece,roman+i,(size_t)(j-i)); piece[j-i]=0;
      char o[ODIA_CAND_LEN]; int c;
      if(!piece_best(piece,o,&c)) continue;
      int ns=nseg[i]+1, cs=cst[i]+c;
      if(ns<nseg[j] || (ns==nseg[j] && cs<cst[j])){ nseg[j]=ns; cst[j]=cs; prev[j]=i; strcpy(str[j],o); }
    } }
  if(nseg[L]>=1000 || nseg[L]<2) return 0;
  int pos[25],np=0; for(int j=L;j>0;j=prev[j]) pos[np++]=j;
  concat[0]=0; spaced[0]=0;
  for(int k=np-1;k>=0;k--){ if(strlen(concat)+strlen(str[pos[k]])+2>=ODIA_CAND_LEN) return 0;
    strcat(concat,str[pos[k]]); if(k<np-1) strcat(spaced," "); strcat(spaced,str[pos[k]]); }
  return 1;
}

/* a stem followed by a common suffix, with a halant + ZWNJ between them. joined=1 when the plain spelling had
   already glued the suffix's first consonant to the stem (basre -> ବସ୍ରେ), so the ZWNJ goes after that halant. */
static int cons_cp(unsigned cp){ return (cp>=0x0B15&&cp<=0x0B39)||cp==0x0B5C||cp==0x0B5D||cp==0x0B5F||cp==0x0B71; }
/* is stem-final consonant + suffix-initial consonant an ordinary conjunct (ଣ୍ଟ ନ୍ତ ଙ୍କ ସ୍କ ଷ୍ଟ ର୍କ)? then no ZWNJ is needed */
static int natural_pair(unsigned pc, unsigned sc){
  int fc=stop_class(sc); if(!fc) return 0;
  if(pc==0x0B30) return 1;                                   /* reph ର୍ */
  { char b[4]={(char)0xE0,(char)(0x80+((pc>>6)&0x3F)),(char)(0x80+(pc&0x3F)),0}; int nl=nasal_letter_class(b); if(nl) return nl==fc; }
  if(pc==0x0B37) return !(fc==4||fc==2);
  if(pc==0x0B38) return fc!=2;
  if(pc==0x0B36) return !(fc==3||fc==4);
  return 0;
}
static int suffix_zw(const char *w, char *out, int *joined, const char **suffix, int *natural){
  size_t wl=strlen(w); const char *bs=NULL; size_t bl=0;
  for(int i=0;SUFFIX[i];i++){ size_t l=strlen(SUFFIX[i]); if(l>bl && l<wl && strcmp(w+wl-l,SUFFIX[i])==0){bs=SUFFIX[i];bl=l;} }
  if(!bs) return 0;
  size_t sl=wl-bl; if(sl<6) return 0;                       /* the stem needs at least two letters */
  const unsigned char *q=(const unsigned char*)w+sl-3;
  if(q[0]!=0xE0) return 0;
  unsigned cp=((q[0]&0x0Fu)<<12)|((q[1]&0x3Fu)<<6)|(q[2]&0x3Fu);
  size_t need=sl+strlen(ZWNJ)+bl+strlen(HAL)+1; if(need>=ODIA_CAND_LEN) return 0;
  memcpy(out,w,sl); out[sl]=0;
  if(natural) *natural=0;
  if(cons_cp(cp)){ strcat(out,HAL ZWNJ); *joined=0; }
  else if(cp==0x0B4D && sl>=6){ const unsigned char *p=(const unsigned char*)w+sl-6;
    unsigned pc=((p[0]&0x0Fu)<<12)|((p[1]&0x3Fu)<<6)|(p[2]&0x3Fu);
    if(p[0]!=0xE0||!cons_cp(pc)) return 0;
    strcat(out,ZWNJ); *joined=1; if(natural) *natural=natural_pair(pc,first_cp(bs)); }
  else return 0;
  strcat(out,bs); if(suffix) *suffix=bs; return 1;
}


/* ---------- spelling an abbreviation out: cid -> CID, C.I.D., ସି.ଆଇ.ଡି, ସିଆଇଡି  (letter names fixed by the user) ---------- */
static const char *LETTER_ODIA[26] = {
  "ଏ",
  "ବି",
  "ସି",
  "ଡି",
  "ଇ",
  "ଏଫ୍" ZWNJ "",
  "ଜି",
  "ଏଚ୍" ZWNJ "",
  "ଆଇ",
  "ଜେ",
  "କେ",
  "ଏଲ୍" ZWNJ "",
  "ଏମ୍" ZWNJ "",
  "ଏନ୍" ZWNJ "",
  "ଓ",
  "ପି",
  "କ୍ୟୁ",
  "ଆର୍" ZWNJ "",
  "ଏସ୍" ZWNJ "",
  "ଟି",
  "ୟୁ",
  "ଭି",
  "ଡବ୍ଲ୍ୟୁ",
  "ଏକ୍ସ",
  "ୱାଇ",
  "ଜେଡ୍" ZWNJ "" };
#define ACRO_MAX 6
/* 2 to 8 plain English letters give extra choices that always sit at the very end of the list:
   PA, P.A., ପି.ଏ. (with the last dot), ପି.ଏ, ପିଏ, and p.a. when the letters were typed in lower case */
static int acronym(const char *roman, char out[ACRO_MAX][ODIA_CAND_LEN]){
  size_t L=strlen(roman); if(L<2||L>8) return 0;
  int low=0;
  for(size_t i=0;i<L;i++){ if(!isalpha((unsigned char)roman[i]) || (unsigned char)roman[i]>127) return 0; if(islower((unsigned char)roman[i])) low=1; }
  for(int q=0;q<ACRO_MAX;q++) out[q][0]=0;
  for(size_t i=0;i<L;i++){
    int k=toupper((unsigned char)roman[i])-'A';
    char u[2]={(char)('A'+k),0}, l[2]={(char)('a'+k),0};
    strcat(out[0],u); strcat(out[1],u); strcat(out[1],".");
    if(i) strcat(out[3],".");
    strcat(out[2],LETTER_ODIA[k]); strcat(out[2],"."); strcat(out[3],LETTER_ODIA[k]); strcat(out[4],LETTER_ODIA[k]);
    strcat(out[5],l); strcat(out[5],".");
  }
  return low?ACRO_MAX:ACRO_MAX-1;
}

/* ---------- extra rules: diphthong spellings, lone-letter extras ---------- */
typedef struct { const char *r; const char *o[3]; } Multi;
static const Multi DIPH[] = { {"ai",{"ଆଇ","ଆଈ","ଅଇ"}}, {"au",{"ଆଉ","ଆଊ","ଅଉ"}}, {"ou",{"ଓଉ","ଓଊ","ଅଉ"}}, {NULL,{NULL}} };
static const Multi SINGLE_EXTRA[] = { {"d",{"ଡ଼"}}, {"dh",{"ଢ଼"}}, {"sh",{"ସ"}}, {"ny",{"ଣ୍ୟ","ଞ୍ୟ"}}, {NULL,{NULL}} };
/* short words Odia writes with an apostrophe: କ'ଣ ତା' ତା'ର ମୋ'ର ତୋ'ର ମା'. Typed with any of their vowels left out, with or without the apostrophe:
   kn kan kana kaana ka'na ka'n k'n -> କ'ଣ ; ta taa ta' -> ତା' ; tr tar taar tara t'r ta'r -> ତା'ର ; tor tora to'r -> ତୋ'ର ; mr mor mora m'r -> ମୋ'ର ; ma maa ma' -> ମା' ମାଆ */
static int apos_match(const char *roman, const char *out[2]){
  size_t L=strlen(roman); if(L<1||L>10) return 0;
  char c[16]; int nc=0, na=0, no=0, nv=0;
  for(size_t i=0;i<L;i++){ char ch=(char)tolower((unsigned char)roman[i]);
    if(ch=='\'') continue;
    if(!isalpha((unsigned char)ch)) return 0;
    if(ch=='a'){ na++; nv++; } else if(ch=='o'){ no++; nv++; } else if(strchr("eiu",ch)) return 0; else c[nc++]=ch;
  }
  c[nc]=0; out[0]=out[1]=NULL;
  if(!strcmp(c,"kn") && no==0 && na<=3){ out[0]="କ'ଣ"; return 1; }
  if(!strcmp(c,"t") && no==0 && na>=1 && na<=2){ out[0]="ତା'"; return 1; }
  if(!strcmp(c,"tr") && na<=3 && no<=2){ out[0]= no ? "ତୋ'ର" : "ତା'ର"; return 1; }
  if(!strcmp(c,"mr") && na<=2 && (no>0 || nv==0)){ out[0]="ମୋ'ର"; return 1; }
  if(!strcmp(c,"m") && no==0 && na>=1 && na<=2){ out[0]="ମା'"; out[1]="ମାଆ"; return 2; }
  return 0;
}
static const Multi FIRST_EXTRA[] = { {"nian",{"ଞ"}}, {"uan",{"ଙ"}}, {NULL,{NULL}} };
static const Multi *multi_find(const Multi *m, const char *r){ for(;m->r;m++) if(strcmp(m->r,r)==0) return m; return NULL; }

static int gen(const char *roman, char cands[][ODIA_CAND_LEN]){
  int n=0; if(!*roman) return 0;
  g_filter=1;

  /* "." offers danda, full stop and double danda */
  if(strcmp(roman,".")==0){ g_filter=0; put(cands,&n,"।"); put(cands,&n,"."); put(cands,&n,"॥"); return n; }

  /* "ru": ରୁ ରୂ ଋ ୠ */
  if(strcasecmp(roman,"ru")==0){ g_filter=0; put(cands,&n,"ରୁ"); put(cands,&n,roman); put(cands,&n,"ରୂ"); put(cands,&n,"ଋ"); put(cands,&n,"ୠ"); return n; }
  /* stand-alone v, z, Z: the Odia meaning first, then what was typed */
  if(strcmp(roman,"`")==0){ g_filter=0; put(cands,&n,HAL); put(cands,&n,"`"); put(cands,&n,HAL ZWNJ); return n; }
  if(strcmp(roman,"z")==0){ g_filter=0; put(cands,&n,ZWNJ); put(cands,&n,"z"); return n; }
  if(strcmp(roman,"Z")==0){ g_filter=0; put(cands,&n,HAL ZWNJ); put(cands,&n,"Z"); put(cands,&n,HAL); put(cands,&n,ZWNJ); return n; }

  int alldig=1; for(const char*p=roman;*p;p++) if(!isdigit((unsigned char)*p)) alldig=0;
  char prim[ODIA_CAND_LEN]; odia_transliterate(roman,prim,sizeof prim);
  if(alldig){ g_filter=0; put(cands,&n,prim); put(cands,&n,roman); return n; }

  Tok t[128]; int nt=parse(roman,t,128,0);
  int pure=1; for(int i=0;i<nt;i++) if(t[i].kind==T_SEP) pure=0;

  int bi=-1,bw=-1;                                    /* best dictionary entry for this exact key */
  for(size_t i=0;i<nlex;i++) if(strcasecmp(lex[i].r,roman)==0 && lex[i].w>bw){bw=lex[i].w;bi=(int)i;}

  /* a lone consonant: bare letter, with halant, with halant + ZWNJ (the ZWNJ form is drawn in blue by the UI) */
  if(pure && nt==1 && t[0].kind==T_K){
    g_filter=0;
    put(cands,&n, bi>=0?lex[bi].o:prim); put(cands,&n, roman);
    put(cands,&n,prim);
    char b[ODIA_CAND_LEN];
    { const Multi *sx=multi_find(SINGLE_EXTRA,roman); if(sx){ for(int q=1;q<t[0].n;q++) put(cands,&n,t[0].a[q]); for(int q=0;q<3&&sx->o[q];q++) put(cands,&n,sx->o[q]); } }
    for(int j=0;j<t[0].n;j++){
      snprintf(b,sizeof b,"%s%s",t[0].a[j],HAL); put(cands,&n,b);
      snprintf(b,sizeof b,"%s%s%s",t[0].a[j],HAL,ZWNJ); put(cands,&n,b);
      if(j==0) for(int q=1;q<t[0].n;q++) put(cands,&n,t[0].a[q]);
    }
    return n;
  }
  /* a lone vowel: the letter, then the matra / kaara on its own */
  if(pure && nt==1 && t[0].kind==T_V){
    g_filter=0;
    put(cands,&n, bi>=0?lex[bi].o:prim); put(cands,&n, roman);
    put(cands,&n,prim);
    { const Multi *dp=multi_find(DIPH,roman); if(dp) for(int q=0;q<3&&dp->o[q];q++) put(cands,&n,dp->o[q]); }
    for(int j=0;j<t[0].n;j++) put(cands,&n,t[0].a[j]);
    for(int j=0;j<t[0].n;j++) if(t[0].s[j] && t[0].s[j][0]) put(cands,&n,t[0].s[j]);
    return n;
  }

  Var *V=NULL; int nv=enum_vars(roman,&V,4000);
  char best[ODIA_CAND_LEN], seg1[ODIA_CAND_LEN]="", seg2[ODIA_CAND_LEN]="";
  int hasseg=0, zwfirst=0;
  if(bi>=0) strcpy(best,lex[bi].o);
  else if(nv>0 && V[0].known) strcpy(best,V[0].s);
  else if(segment(roman,seg1,seg2)){ hasseg=1; strcpy(best,seg1); }
  else {
    strcpy(best, nv>0?V[0].s:prim);     /* the cheapest valid reading (equal to prim unless prim breaks a rule) */
    /* unknown word that glues a suffix to its stem: the ZWNJ spelling comes first (basre -> ବସ୍‌ରେ) */
    char z[ODIA_CAND_LEN]; int joined=0, nat=0; const char *sf=NULL;
    if(suffix_zw(best,z,&joined,&sf,&nat) && joined && !nat && strcmp(sf,"ର")!=0){ strcpy(best,z); zwfirst=1; }
  }
  put(cands,&n,best);                                 /* 1: best Odia            */
  put(cands,&n,roman);                                /* 2: as typed, always 2nd */
  if(hasseg) put(cands,&n,seg2);                      /* 3: the same words with a space */
  put(cands,&n,prim);
  lex_exact(roman,cands,&n,3);
  char late[ODIA_CAND_LEN]=""; /* the bare suffix ର is so common in words like sundara that its ZWNJ spelling waits a little */
  { char z[ODIA_CAND_LEN]; int joined, nat; const char *sf;
    if(suffix_zw(best,z,&joined,&sf,&nat)){ if(strcmp(sf,"ର")==0) strcpy(late,z); else put(cands,&n,z); }
    if(strcmp(best,prim)!=0 && suffix_zw(prim,z,&joined,&sf,&nat)){ if(strcmp(sf,"ର")==0) { if(!late[0]) strcpy(late,z); } else put(cands,&n,z); }
    (void)zwfirst; }

  /* word-final n / ng / m after a vowel: also chandrabindu and anusvara, e.g. ken -> କେନ କେଁ କେଂ */
  if(nt>=2 && t[nt-1].kind==T_K && t[nt-2].kind==T_V &&
     (strcmp(t[nt-1].r,"n")==0||strcmp(t[nt-1].r,"ng")==0||strcmp(t[nt-1].r,"m")==0)){
    const char *nas[2]={"ଁ","ଂ"};
    for(int q=0;q<2;q++){
      Tok u[128]; memcpy(u,t,sizeof(Tok)*(size_t)(nt+1));
      memset(&u[nt-1],0,sizeof(Tok)); u[nt-1].kind=T_RAW; u[nt-1].n=1; u[nt-1].a[0]=nas[q]; u[nt-1].keep=2;
      char b[ODIA_CAND_LEN]; render(u,NULL,b,sizeof b); put(cands,&n,b);
    }
  }
  lex_prefix(roman,cands,&n,3);

  /* every reading, cheapest first (known words first) */
  for(int i=0;i<nv && n<g_limit;i++){ if(i==3 && late[0]) put(cands,&n,late); put(cands,&n,V[i].s); }
  if(late[0]) put(cands,&n,late);
  free(V);
  /* a word that ends in a consonant, with a closing halant */
  if(n<g_limit && nt>=2 && t[nt-1].kind==T_K){
    char b[ODIA_CAND_LEN]; snprintf(b,sizeof b,"%s%s",prim,HAL); put(cands,&n,b);
  }
  return n;
}


/* ---------- vowel-less typing (ktk -> କଟକ କତକ) and cluster variants (nya -> ଣ୍ୟ ଞ୍ୟ, skru -> ସ୍କୃ, tva -> ତ୍ୱ ...) ---------- */
static size_t cp_len(const char *s){ size_t n=0; for(;*s;s++) if(((unsigned char)*s&0xC0)!=0x80) n++; return n; }
static int has_nonascii(const char *s){ for(;*s;s++) if((unsigned char)*s>=0x80) return 1; return 0; }
static int repl1(const char *s, const char *a, const char *b, char *out, size_t cap){
  const char *p=strstr(s,a); if(!p) return 0;
  snprintf(out,cap,"%.*s%s%s",(int)(p-s),s,b,p+strlen(a)); return 1;
}
#define EXMAX 48
static char g_ex[EXMAX][ODIA_CAND_LEN]; static int g_nex;
static char (*g_f)[ODIA_CAND_LEN]; static int g_nf; static const char *g_roman;
static void ex_push(const char *x, int force){
  if(!x||!*x||g_nex>=EXMAX||strcmp(x,g_roman)==0) return;
  for(int i=0;i<g_nf;i++) if(strcmp(g_f[i],x)==0) return;
  if(has(g_ex,g_nex,x)) return;
  if(!force && !valid_odia(x)) return;
  strncpy(g_ex[g_nex],x,ODIA_CAND_LEN-1); g_ex[g_nex][ODIA_CAND_LEN-1]=0; g_nex++;
}
/* kinds of filter for alt_list */
enum { PK_NONE, PK_SHORT, PK_SHORT_NOVA, PK_SA_ONLY, PK_VOCALIC, PK_SCHWA };
static int g_nsch;   /* how many schwa-restored spellings (karn -> କାରଣ କରନ କରଣ) sit at the front of g_ex */
static void alt_list(const char *rom, int limit, int pk){
  static char l[14][ODIA_CAND_LEN];
  int sl=g_limit, sf=g_filter; g_limit=14; int nl=gen(rom,l); g_limit=sl; g_filter=sf;
  int got=0; size_t rl=strlen(g_roman);
  for(int i=0;i<nl&&got<limit;i++){
    const char *x=l[i];
    if(strcmp(x,rom)==0||!has_nonascii(x)||!valid_odia(x)) continue;
    if((pk==PK_SHORT||pk==PK_SHORT_NOVA) && cp_len(x)>2*rl) continue;
    if(pk==PK_SHORT_NOVA && strstr(x,"\xE0\xAC\xB5")) continue;
    if(pk==PK_SA_ONLY && !(strstr(x,"ସ") && !strstr(x,"ଶ") && !strstr(x,"ଷ"))) continue;
    if(pk==PK_VOCALIC && !strstr(x,"ୃ")) continue;
    if(pk==PK_SCHWA && (strstr(x,"ଁ")||strstr(x,"ଂ")||strstr(x,"ଃ")||strstr(x,HAL ZWNJ)||(strlen(x)>=3&&strcmp(x+strlen(x)-3,HAL)==0))) continue;
    int before=g_nex; ex_push(x,0); if(g_nex>before) got++;
  }
}
static int is_cons_letter(char c){ return isalpha((unsigned char)c) && !strchr("aeiouAEIOU",c); }
static int extras(const char *roman, char f[][ODIA_CAND_LEN], int nf){
  g_nex=0; g_f=f; g_nf=nf; g_roman=roman; g_nsch=0;
  char b[ODIA_CAND_LEN];
  {   /* a word that ends in two consonants may have lost its schwa: karn -> karan -> କାରଣ କରନ କରଣ */
    size_t L=strlen(roman);
    if(L>=3 && L<ODIA_CAND_LEN-2){
      char c1=roman[L-2], c2=roman[L-1], lc1=(char)tolower((unsigned char)c1), lc2=(char)tolower((unsigned char)c2);
      int vow=0; for(size_t i=0;i+2<L;i++) if(is_vowel_ch(roman[i])) vow=1;
      int ok=vow && is_cons_letter(c1) && is_cons_letter(c2) && lc1!=lc2 && lc1!='h' && !strchr("hywv",lc2);
      for(size_t i=0;ok&&i<L;i++) if(!isalpha((unsigned char)roman[i])) ok=0;
      if(ok){ snprintf(b,sizeof b,"%.*sa%c",(int)(L-1),roman,c2); alt_list(b,4,PK_SCHWA); g_nsch=g_nex; }
    }
  }
  if(roman[0]=='v' && (roman[1]=='y'||roman[1]=='r')){
    snprintf(b,sizeof b,"b%s",roman+1); alt_list(b,2,PK_SHORT);
    snprintf(b,sizeof b,"w%s",roman+1); alt_list(b,2,PK_SHORT);
  }
  { /* consonant + v + vowel/y: v is w (tva -> twa) */
    char rv[ODIA_CAND_LEN]; size_t L=strlen(roman), o=0; int ch=0;
    for(size_t i=0;i<L&&o<sizeof rv-2;i++){
      if(roman[i]=='v' && i>0 && is_cons_letter(roman[i-1]) && strchr("aeiouy",roman[i+1]?roman[i+1]:'#')){ rv[o++]='w'; ch=1; } else rv[o++]=roman[i];
    }
    rv[o]=0; if(ch) alt_list(rv,6,PK_SHORT_NOVA);
  }
  if(strlen(roman)>2 && strstr(roman,"sh")){
    char r2[ODIA_CAND_LEN]; size_t L=strlen(roman), o=0;
    for(size_t i=0;i<L&&o<sizeof r2-2;i++){ if(roman[i]=='s'&&roman[i+1]=='h'){ r2[o++]='s'; i++; } else r2[o++]=roman[i]; }
    r2[o]=0; alt_list(r2,4,PK_SA_ONLY);
  }
  { /* consonant + ru: vocalic ୃ (skru -> ସ୍କୃ) */
    char r3[ODIA_CAND_LEN]; size_t L=strlen(roman), o=0; int ch=0;
    for(size_t i=0;i<L&&o<sizeof r3-4;i++){
      if(i>0 && roman[i]=='r' && roman[i+1]=='u' && is_cons_letter(roman[i-1]) && !strchr("rR",roman[i-1])){ r3[o++]='r'; r3[o++]='r'; r3[o++]='i'; i++; ch=1; } else r3[o++]=roman[i];
    }
    r3[o]=0; if(ch) alt_list(r3,3,PK_VOCALIC);
  }
  int hasny=strstr(roman,"ny")!=NULL, hasnr=strstr(roman,"nr")!=NULL;
  int hasvy=strstr(roman,"vy")!=NULL||strstr(roman,"wy")!=NULL;
  int total=nf+g_nex;
  for(int k=0;k<total;k++){
    const char *x = k<nf ? f[k] : g_ex[k-nf];
    if(strcmp(x,roman)==0) continue;
    char tmp[ODIA_CAND_LEN], src[ODIA_CAND_LEN]; strncpy(src,x,sizeof src-1); src[sizeof src-1]=0;
    if(hasny && strstr(src,"ନ୍ୟ")){ if(repl1(src,"ନ୍ୟ","ଣ୍ୟ",tmp,sizeof tmp)) ex_push(tmp,1); if(repl1(src,"ନ୍ୟ","ଞ୍ୟ",tmp,sizeof tmp)) ex_push(tmp,1); }
    if(hasnr && strstr(src,"ନ୍ର")){ if(repl1(src,"ନ୍ର","ଣ୍ର",tmp,sizeof tmp)) ex_push(tmp,1); }
    if(hasvy && strstr(src,"ୱ୍ୟ")){ if(repl1(src,"ୱ୍ୟ","ୱ" ZWJ "୍ୟ",tmp,sizeof tmp)) ex_push(tmp,1); }
    total=nf+g_nex;
  }
  return g_nex;
}
static int skeleton(const char *roman, char out[][ODIA_CAND_LEN], int maxout, int *ntok){
  size_t L=strlen(roman); if(L<2||L>10) return 0;
  for(size_t i=0;i<L;i++) if(!isalpha((unsigned char)roman[i])) return 0;
  if(strpbrk(roman,"aeiouzAEIOUZ")) return 0;
  const char *al[8][3]; int na[8]; int nt=0; size_t p=0;
  while(p<L){
    size_t best=0; const char *cur[3]={0,0,0}; int n=0;
    if(strncmp(roman+p,"ng",2)==0){ best=2; cur[0]="ଙ"; n=1; }
    else for(const ConsDef *e=CONS;e->r;e++){
      size_t l=strlen(e->r);
      if(l>best && strncmp(roman+p,e->r,l)==0){
        best=l; n=0; cur[0]=cur[1]=cur[2]=NULL;
        for(int q=0;q<3&&e->a[q];q++){ if(strcmp(e->r,"ny")==0 && strstr(e->a[q],HAL)) continue; cur[n++]=e->a[q]; }
      }
    }
    if(!best||!n||nt>=8) return 0;
    char r[8]; size_t cl=best<7?best:7; memcpy(r,roman+p,cl); r[cl]=0;
    if((!strcmp(r,"t")||!strcmp(r,"th")||!strcmp(r,"d")||!strcmp(r,"dh")) && n==2){ const char *sw=cur[0]; cur[0]=cur[1]; cur[1]=sw; }
    for(int q=0;q<3;q++) al[nt][q]=cur[q]; na[nt]=n; nt++; p+=best;
  }
  if(nt<2) return 0;
  static char acc[24][ODIA_CAND_LEN], nx[24][ODIA_CAND_LEN]; int nacc=1; acc[0][0]=0;
  for(int i=0;i<nt;i++){
    int nn=0;
    for(int o=0;o<nacc;o++) for(int a=0;a<na[i];a++) if(nn<24){ snprintf(nx[nn],ODIA_CAND_LEN,"%s%s",acc[o],al[i][a]); nn++; }
    for(int q=0;q<nn;q++) strcpy(acc[q],nx[q]);
    nacc=nn;
  }
  int m=0;
  for(int pass=0;pass<2;pass++) for(int i=0;i<nacc&&m<maxout;i++){
    int kn=known_has(acc[i]); if((pass==0)!=(kn!=0)) continue;
    if(!valid_odia(acc[i])) continue;
    strcpy(out[m++],acc[i]);
  }
  *ntok=nt; return m;
}

/* ---------- consonant-skeleton dictionary: pasnd -> ପସନ୍ଦ, budhiani -> ବୁଢ଼ିଆଣୀ ----------
   skel.dat holds one line per key: "key<TAB>word<TAB>word...", most frequent word first. A word is reduced to a key of consonant symbols
   (ଧ and ଢ are both D, ତ and ଟ both t, ସ ଶ ଷ all s ...); what is typed is reduced the same way, so the vowels you leave out or get wrong
   do not matter. The vowels you did type only decide the order. tools/skel.py is the reference for this block and for the JS twin. */
static char *sk_buf=NULL; static size_t *sk_off=NULL, sk_n=0;
void odia_load_skel(const char *data, size_t len){
  free(sk_buf); free(sk_off); sk_buf=NULL; sk_off=NULL; sk_n=0;
  if(!data||!len) return;
  sk_buf=(char*)malloc(len+1); if(!sk_buf) return; memcpy(sk_buf,data,len); sk_buf[len]=0;
  size_t n=0; for(size_t i=0;i<len;i++) if(sk_buf[i]=='\n') n++;
  sk_off=(size_t*)malloc((n+1)*sizeof(size_t)); if(!sk_off){ free(sk_buf); sk_buf=NULL; return; }
  size_t s=0; for(size_t i=0;i<len;i++) if(sk_buf[i]=='\n'){ sk_off[sk_n++]=s; sk_buf[i]=0; s=i+1; }
}
static int sk_cmp(size_t i, const char *key){ const char *l=sk_buf+sk_off[i]; size_t kl=strlen(key); int c=strncmp(l,key,kl); if(c) return c; return l[kl]=='\t'?0:1; }
static const char *sk_find(const char *key){
  size_t lo=0, hi=sk_n; while(lo<hi){ size_t m=(lo+hi)/2; int c=sk_cmp(m,key); if(c==0) return sk_buf+sk_off[m]; if(c<0) lo=m+1; else hi=m; }
  return NULL;
}
static int u8cps(const char *s, unsigned *o, int cap){
  int n=0; const unsigned char *p=(const unsigned char*)s;
  while(*p){ if(n>=cap) return -1; unsigned c;
    if(*p<0x80){ c=*p++; } else if((*p&0xE0)==0xC0&&p[1]){ c=((*p&0x1Fu)<<6)|(p[1]&0x3Fu); p+=2; }
    else if((*p&0xF0)==0xE0&&p[1]&&p[2]){ c=((*p&0x0Fu)<<12)|((p[1]&0x3Fu)<<6)|(p[2]&0x3Fu); p+=3; }
    else if(p[1]&&p[2]&&p[3]){ c=((*p&7u)<<18)|((p[1]&0x3Fu)<<12)|((p[2]&0x3Fu)<<6)|(p[3]&0x3Fu); p+=4; } else return -1;
    o[n++]=c; }
  return n;
}
static char sk_sym(unsigned c){
  switch(c){
    case 0x0B15:return 'k'; case 0x0B16:return 'K'; case 0x0B17:return 'g'; case 0x0B18:return 'G'; case 0x0B19:return 'n';
    case 0x0B1A:case 0x0B1B:return 'c'; case 0x0B1C:return 'j'; case 0x0B1D:return 'J'; case 0x0B1E:return 'n';
    case 0x0B1F:return 't'; case 0x0B20:return 'T'; case 0x0B21:return 'd'; case 0x0B22:return 'D'; case 0x0B23:return 'n';
    case 0x0B24:return 't'; case 0x0B25:return 'T'; case 0x0B26:return 'd'; case 0x0B27:return 'D'; case 0x0B28:return 'n';
    case 0x0B2A:return 'p'; case 0x0B2B:return 'P'; case 0x0B2C:return 'b'; case 0x0B2D:return 'B'; case 0x0B2E:return 'm';
    case 0x0B2F:return 'j'; case 0x0B30:return 'r'; case 0x0B32:case 0x0B33:return 'l'; case 0x0B35:return 'b';
    case 0x0B36:case 0x0B37:case 0x0B38:return 's'; case 0x0B39:return 'h'; case 0x0B5C:return 'd'; case 0x0B5D:return 'D';
    case 0x0B5F:return 'j'; case 0x0B71:return 'b';
  } return 0;
}
static int sk_retro(unsigned c){ switch(c){ case 0x0B1F:case 0x0B20:case 0x0B21:case 0x0B22:case 0x0B23:case 0x0B33:case 0x0B5C:case 0x0B5D:return 1;
  case 0x0B24:case 0x0B25:case 0x0B26:case 0x0B27:case 0x0B28:case 0x0B32:return 2; } return 0; }
static const char *sk_sign(unsigned c){ switch(c){ case 0x0B3E:return "a"; case 0x0B3F:case 0x0B40:return "i"; case 0x0B41:case 0x0B42:return "u";
  case 0x0B43:return "ri"; case 0x0B47:return "e"; case 0x0B48:return "ai"; case 0x0B4B:return "o"; case 0x0B4C:return "au"; } return NULL; }
static const char *sk_ind(unsigned c){ switch(c){ case 0x0B05:case 0x0B06:return "a"; case 0x0B07:case 0x0B08:return "i"; case 0x0B09:case 0x0B0A:return "u";
  case 0x0B0B:return "ri"; case 0x0B0F:return "e"; case 0x0B10:return "ai"; case 0x0B13:return "o"; case 0x0B14:return "au"; } return NULL; }
typedef struct { char sym; char v[8]; char retro; char hal; char inh; } SkSlot;
typedef struct { char v0[8]; SkSlot s[48]; int n; int fin; } SkWord;
static void sk_vapp(char *d, const char *a){ size_t l=strlen(d); while(*a && l<7) d[l++]=*a++; d[l]=0; }
static void sk_collapse(char *v){ size_t o=0; for(size_t i=0;v[i];i++) if(o==0||v[o-1]!=v[i]) v[o++]=v[i]; v[o]=0; }
static int sk_alt_cps(const unsigned *cp, int n, int alt, unsigned *out){   /* the word as typed under an alternative spelling; 0 if it does not apply */
  int m=0, hit=0;
  for(int i=0;i<n;i++){
    if(alt==1){ if(cp[i]==0x0B5C){ out[m++]=0x0B30; hit=1; } else out[m++]=cp[i]; }
    else if(alt==3 && i+2<n && cp[i]==0x0B1C && cp[i+1]==0x0B4D && cp[i+2]==0x0B1E){ out[m++]=0x0B17; out[m++]=0x0B4D; out[m++]=0x0B2F; i+=2; hit=1; }
    else if(alt==4 && i+2<n && cp[i]==0x0B15 && cp[i+1]==0x0B4D && cp[i+2]==0x0B37){ out[m++]=0x0B16; i+=2; hit=1; }
    else { if(alt==2 && cp[i]==0x0B43) hit=1; out[m++]=cp[i]; }
  }
  return hit?m:0;
}
static int sk_word(const unsigned *cp, int n, int alt, SkWord *w){
  unsigned t[80]; if(alt){ n=sk_alt_cps(cp,n,alt,t); if(!n) return 0; cp=t; }
  memset(w,0,sizeof *w); int endc=0;
  for(int i=0;i<n;i++){
    unsigned c=cp[i]; endc=0; char sy=sk_sym(c);
    if(sy){ if(w->n<48){ SkSlot *s=&w->s[w->n++]; memset(s,0,sizeof *s); s->sym=sy; s->retro=(char)sk_retro(c); s->inh=1; } endc=1; }
    else if(c==0x0B4D){ if(w->n) w->s[w->n-1].hal=1; }
    else if(c==0x0B3C){ endc=1; }
    else if(c==0x0B43 && alt==2){ if(w->n && w->n<47){ w->s[w->n-1].v[0]=0; w->s[w->n-1].inh=0; w->s[w->n-1].hal=1; SkSlot *s=&w->s[w->n++]; memset(s,0,sizeof *s); s->sym='r'; strcpy(s->v,"i"); } }
    else if(sk_sign(c)){ if(w->n && !w->s[w->n-1].hal){ SkSlot *s=&w->s[w->n-1]; s->v[0]=0; sk_vapp(s->v,sk_sign(c)); s->inh=0; } }
    else if(sk_ind(c)){
      if(!w->n) sk_vapp(w->v0,sk_ind(c));
      else if(!w->s[w->n-1].hal){ SkSlot *s=&w->s[w->n-1]; if(s->inh){ s->v[0]=0; sk_vapp(s->v,"a"); s->inh=0; } sk_vapp(s->v,sk_ind(c)); }
    }
  }
  w->fin = w->n && endc && w->s[w->n-1].inh && !w->s[w->n-1].hal;
  for(int i=0;i<w->n;i++){ SkSlot *s=&w->s[i];
    if(s->hal){ s->v[0]=0; }
    else if(s->inh){ strcpy(s->v,"a"); }
    else { int same=1; for(int k=1;s->v[k];k++) if(s->v[k]!=s->v[0]) same=0; if(same&&s->v[0]) s->v[1]=0; }
  }
  sk_collapse(w->v0);
  return 1;
}
static void sk_key(const SkWord *w, char *key){ for(int i=0;i<w->n;i++) key[i]=w->s[i].sym; key[w->n]=0; }
typedef struct { char sym; char v[8]; char retro; char lg; } SkTok;
typedef struct { char v0[8]; int lg0; SkTok t[24]; int n; } SkTyped;
static int sk_vrun(const char *s, int i, char *out, int *lg){
  int j=i; char raw[16]; int rn=0; *lg=0;
  while(s[j] && strchr("aeiouAEIOU",s[j])){ if(rn<15) raw[rn++]=(char)tolower((unsigned char)s[j]); if(s[j]=='A') *lg=1; j++; }
  raw[rn]=0;
  if(strstr(raw,"aa")) *lg=1;
  char v[16]; int o=0;
  for(int k=0;raw[k];k++){ if(raw[k]=='o' && raw[k+1]=='u'){ v[o++]='a'; v[o++]='u'; k++; } else v[o++]=raw[k]; }
  v[o]=0; sk_collapse(v);
  if(strcmp(v,"a")!=0) *lg=0;
  if(strlen(v)>7) v[7]=0;
  strcpy(out,v); return j;
}
static int sk_parse(const char *roman, SkTyped *t){
  char s[64]; int n=0; for(const char*p=roman;*p&&n<62;p++) if(isalpha((unsigned char)*p)) s[n++]=*p;
  s[n]=0; if(!n) return 0; memset(t,0,sizeof *t);
  int i=sk_vrun(s,0,t->v0,&t->lg0);
  while(s[i]){
    char c=s[i], lc=(char)tolower((unsigned char)c); int up=isupper((unsigned char)c)!=0; int adv=1; char sy[3]={0,0,0};
    char two0=lc, two1=s[i+1]?(char)tolower((unsigned char)s[i+1]):0, two2=(s[i+1]&&s[i+2])?(char)tolower((unsigned char)s[i+2]):0;
    if(two0=='c'&&two1=='h'&&two2=='h'){ sy[0]='c'; adv=3; }
    else if(two1=='h' && strchr("kgjtdpb",two0)){ sy[0]= two0=='k'?'K':two0=='g'?'G':two0=='j'?'J':two0=='t'?'T':two0=='d'?'D':two0=='p'?'P':'B'; adv=2; }
    else if(two0=='c'&&two1=='h'){ sy[0]='c'; adv=2; }
    else if(two0=='s'&&two1=='h'){ sy[0]='s'; adv=2; }
    else if(two0=='r'&&two1=='h'){ sy[0]='D'; adv=2; }
    else if(lc=='x'){ sy[0]='k'; sy[1]='s'; }
    else if(lc=='r'&&up){ sy[0]='d'; }
    else { switch(lc){ case 'k':sy[0]='k';break; case 'g':sy[0]='g';break; case 'c':sy[0]='c';break; case 'j':sy[0]='j';break; case 't':sy[0]='t';break;
      case 'd':sy[0]='d';break; case 'n':sy[0]='n';break; case 'p':sy[0]='p';break; case 'b':sy[0]='b';break; case 'm':sy[0]='m';break; case 'y':sy[0]='j';break;
      case 'r':sy[0]='r';break; case 'l':sy[0]='l';break; case 'v':case 'w':sy[0]='b';break; case 's':sy[0]='s';break; case 'h':sy[0]='h';break;
      case 'f':sy[0]='P';break; case 'q':sy[0]='k';break; case 'z':sy[0]='j';break; default: break; } }
    if(!sy[0]){ i++; continue; }
    int retro = up && strchr("tTdDnl",sy[0]) ? 1 : 0;
    char vv[8]; int lg; int j=sk_vrun(s,i+adv,vv,&lg);
    if(t->n+2>=24) break;
    if(sy[1]){ SkTok *a=&t->t[t->n++]; a->sym=sy[0]; a->v[0]=0; SkTok *b=&t->t[t->n++]; b->sym=sy[1]; strcpy(b->v,vv); b->lg=(char)lg; }
    else { SkTok *a=&t->t[t->n++]; a->sym=sy[0]; strcpy(a->v,vv); a->retro=(char)retro; a->lg=(char)lg; }
    i=j;
  }
  return 1;
}
static int sk_score(const SkTyped *t, const SkWord *w, int *neg){
  int sc=0; *neg=0;
  if(strcmp(t->v0,w->v0)==0){ if(t->v0[0]) sc+=3; }
  else if(!t->v0[0]||!w->v0[0]){ sc-=3; (*neg)++; } else { sc-=2; (*neg)++; }
  for(int k=0;k<w->n;k++){
    const char *tv=t->t[k].v, *wv=w->s[k].v; int x;
    int last=(k==w->n-1);
    if(!*tv) x=0;
    else if(last && w->fin){ x = strcmp(tv,"a")==0 ? (t->t[k].lg?-1:3) : -2; }
    else if(strcmp(tv,wv)==0) x=3;
    else if(!*wv) x=-2;
    else if(strstr(wv,tv)||strstr(tv,wv)) x=1;
    else x=-2;
    if(x<0) (*neg)++;
    if(t->t[k].retro){ if(w->s[k].retro==1) x++; else if(w->s[k].retro==2) x--; }
    sc+=x;
  }
  return sc;
}
typedef struct { int sc, neg, rank, ord; char w[ODIA_CAND_LEN]; } SkHit;
static int sk_hitcmp(const void *a, const void *b){ const SkHit *x=a,*y=b; if(x->sc!=y->sc) return y->sc-x->sc; if(x->rank!=y->rank) return x->rank-y->rank; return x->ord-y->ord; }
#define SK_MAXHITS 160
/* hits sorted best first; returns how many */
static int g_sk_ntok;
static int sk_lookup(const char *roman, SkHit *hits){
  if(!sk_n) return 0;
  SkTyped t; if(!sk_parse(roman,&t) || t.n<2) return 0;
  g_sk_ntok=t.n;
  SkTyped tries[8]; int ntry=0; tries[ntry++]=t;
  for(int i=1;i<t.n-1 && ntry<8;i++) if(t.t[i].sym=='n'||t.t[i].sym=='m'){   /* a nasal before a consonant may be an anusvara: try without it */
    SkTyped u=t; if(!u.t[i-1].v[0]) strcpy(u.t[i-1].v,u.t[i].v);
    for(int k=i;k<u.n-1;k++) u.t[k]=u.t[k+1]; u.n--; tries[ntry++]=u;
  }
  int nh=0, ord=0;
  for(int q=0;q<ntry;q++){
    char key[32]; for(int i=0;i<tries[q].n;i++) key[i]=tries[q].t[i].sym; key[tries[q].n]=0;
    const char *line=sk_find(key); if(!line) continue;
    const char *p=strchr(line,'\t'); int rank=0;
    while(p){ p++; const char *e=strchr(p,'\t'); size_t L=e?(size_t)(e-p):strlen(p);
      if(L>0 && L<ODIA_CAND_LEN){
        char wd[ODIA_CAND_LEN]; memcpy(wd,p,L); wd[L]=0;
        int dup=0; for(int i=0;i<nh;i++) if(strcmp(hits[i].w,wd)==0){ dup=1; break; }
        unsigned cp[80]; int n=u8cps(wd,cp,80);
        if(!dup && n>0 && nh<SK_MAXHITS){
          int best=0, bneg=0, got=0;
          for(int alt=0;alt<5;alt++){
            SkWord w; if(alt==0){ if(!sk_word(cp,n,0,&w)) continue; } else if(!sk_word(cp,n,alt,&w)) continue;
            char k2[64]; sk_key(&w,k2); if(strcmp(k2,key)!=0) continue;
            int ng; int sc=sk_score(&tries[q],&w,&ng); if(!got||sc>best){ best=sc; bneg=ng; got=1; }
          }
          if(got){ SkHit *h=&hits[nh++]; h->sc=best; h->neg=bneg; h->rank=rank; h->ord=ord++; strcpy(h->w,wd); }
        }
      }
      rank++; p=e;
    }
  }
  qsort(hits,(size_t)nh,sizeof(SkHit),sk_hitcmp);
  return nh;
}
static int sk_has(const char *word){   /* is the word in the dictionary */
  if(!sk_n) return 0; unsigned cp[80]; int n=u8cps(word,cp,80); if(n<2) return 0;
  for(int alt=0;alt<5;alt++){
    SkWord w; if(!sk_word(cp,n,alt,&w)) continue; char key[64]; sk_key(&w,key); if(w.n<2) continue;
    const char *line=sk_find(key); if(!line) continue; size_t L=strlen(word);
    for(const char *p=strchr(line,'\t');p;){ p++; const char *e=strchr(p,'\t'); size_t l=e?(size_t)(e-p):strlen(p); if(l==L&&memcmp(p,word,L)==0) return 1; p=e; }
  }
  return 0;
}
static int sk_u8(const unsigned *cp, int n, char *out, size_t cap){
  size_t o=0;
  for(int i=0;i<n;i++){ unsigned c=cp[i]; char t[4]; int l;
    if(c<0x80){ t[0]=(char)c; l=1; } else if(c<0x800){ t[0]=(char)(0xC0|(c>>6)); t[1]=(char)(0x80|(c&0x3F)); l=2; }
    else { t[0]=(char)(0xE0|(c>>12)); t[1]=(char)(0x80|((c>>6)&0x3F)); t[2]=(char)(0x80|(c&0x3F)); l=3; }
    if(o+(size_t)l+1>=cap) return 0; memcpy(out+o,t,(size_t)l); o+=(size_t)l; }
  out[o]=0; return 1;
}
/* A word with a medial ଡ / ଢ comes as a pair: the nukta spelling (ଡ଼ ଢ଼) first, the plain spelling second. 0 when the word has neither. */
static int sk_pair(const char *w, char *first, char *second, size_t cap){
  unsigned cp[80], a[80], b[80]; int n=u8cps(w,cp,80); if(n<2) return 0; int hn=0, hp=0;
  for(int i=0;i<n;i++){
    unsigned c=cp[i]; a[i]=c; b[i]=c;
    if(c==0x0B5C||c==0x0B5D){ hn=1; b[i]=(c==0x0B5C)?0x0B21:0x0B22; }
    else if((c==0x0B21||c==0x0B22) && i>0 && cp[i-1]!=0x0B4D && !(i+1<n && cp[i+1]==0x0B3C)){ hp=1; a[i]=(c==0x0B21)?0x0B5C:0x0B5D; }
  }
  if(!hn && !hp) return 0;
  if(hn){ strncpy(first,w,cap-1); first[cap-1]=0; return sk_u8(b,n,second,cap); }
  return sk_u8(a,n,first,cap) && (strncpy(second,w,cap-1),second[cap-1]=0,1);
}

/* typed y: the dictionary spells many words with ଯ where Odia writes ୟ (କୈଫିଯତ୍ -> କୈଫିୟତ୍). ଯ stays only at the start of the word, and the ଯ spelling follows the ୟ one. */
static int sk_ytwin(const char *w, char *yv, size_t cap){
  unsigned cp[80]; int n=u8cps(w,cp,80); if(n<2) return 0; int hit=0;
  for(int i=1;i<n;i++) if(cp[i]==0x0B2F){ cp[i]=0x0B5F; hit=1; }
  return hit && sk_u8(cp,n,yv,cap);
}
/* Odia suggestions come first, then the text as typed (always #2). The first page holds 7 Odia choices, then the
   Title-case and ALL-CAPS English in its last two slots; further Odia variants continue on the next pages. */

/* ---- universal post rules (the same two rules live in engine.tpl.js as postRules) ----
   1. ZWNJ rule: halant + ବ gets a ZWNJ in between (ସ୍‌ବ, ଉଦ୍‌ବେଗ) except after ର ମ ବ, which stay true conjuncts (ସର୍ବ, ଅମ୍ବ, ଅବ୍ବ).
   2. Nukta rule: a ଡ / ଢ in the middle or at the end of a word is written ଡ଼ / ଢ଼ (nukta spelling first, the plain spelling after all of them);
      word-initial ଡ ଢ and ଡ ଢ after a halant stay plain. */
static int u8dec(const unsigned char *s, unsigned *cp);
static size_t u8enc(unsigned cp, char *o);
static int pr_cps(const char *w, unsigned *cp, int max){ int n=0; const unsigned char *p=(const unsigned char*)w; while(*p && n<max){ unsigned c; int l=u8dec(p,&c); p+=l; cp[n++]=c; } return n; }
static int pr_str(const unsigned *cp, int n, char *out, size_t cap){ size_t o=0; char b[4]; for(int i=0;i<n;i++){ size_t l=u8enc(cp[i],b); if(o+l+1>=cap) return 0; memcpy(out+o,b,l); o+=l; } out[o]=0; return 1; }
static int g_zw=1;      /* the ZWNJ rule is for Odia output only */
/* The strict ବ / ଵ rule (same as zwnjFix in engine.js). A halant + ବ is joined only after ର ମ ବ (ର୍ବ ମ୍ବ ବ୍ବ);
   a halant + ଵ is joined only after ର (ର୍ଵ). In every other place the two are kept apart with a ZWNJ (ସ୍‌ବ, ଉଦ୍‌ବେଗ, ସ୍‌ଵ, ମ୍‌ଵ). */
static int pr_zwnj(const unsigned *cp, int n, unsigned *z){
  int m=0;
  for(int i=0;i<n;i++){
    z[m++]=cp[i];
    if(g_zw && cp[i]==0x0B4D && i>0 && i+1<n && (cp[i+1]==0x0B2C || cp[i+1]==0x0B35)){
      unsigned p=cp[i-1]; if(p==0x0B3C && i>1) p=cp[i-2];
      int cons=(p>=0x0B15&&p<=0x0B39)||p==0x0B5C||p==0x0B5D||p==0x0B5F||p==0x0B71;
      int joined=(cp[i+1]==0x0B2C) ? (p==0x0B30||p==0x0B2E||p==0x0B2C) : (p==0x0B30);
      if(cons && !joined) z[m++]=0x200C;
    }
  }
  return m;
}
/* the last stage, for every candidate list and every committed word: the ZWNJ rule on each spelling; a spelling that the rule turns into one
   that is already in the list is dropped, so no un-ZWNJ'd (out-of-rule) variant stays as a candidate */
int odia_strict_word(const char *w, int script, char *out, size_t cap){
  unsigned cp[96], z[200]; int n=pr_cps(w,cp,90), sv=g_zw;
  g_zw=(script==0); int m=pr_zwnj(cp,n,z); g_zw=sv;
  if(!pr_str(z,m,out,cap)){ snprintf(out,cap,"%s",w); return 0; }
  return 1;
}
#include "forbid.inc"
#include "clus.inc"
static int has_odia(const char *w){ for(const unsigned char *p=(const unsigned char*)w;*p;p++) if(p[0]==0xE0 && (p[1]==0xAC||p[1]==0xAD)) return 1; return 0; }
static int clus_known(const char *s){
  static int n=-1; if(n<0){ n=0; while(CLUSOK[n]) n++; }
  int lo=0, hi=n-1;
  while(lo<=hi){ int mid=(lo+hi)/2, c=strcmp(s,CLUSOK[mid]); if(!c) return 1; if(c<0) hi=mid-1; else lo=mid+1; }
  return 0;
}
/* The strict word check (same as ruleOK in engine.js): 1 the impossible-spelling filter, 2 the conjuncts that never occur (FORBID),
   3 at most four consonants in a conjunct and only conjuncts real words contain (CLUSOK). Not judged: words added to the Sulekhak Dictionary on purpose.
   zmode: the typed word had z / Z, so the ZWNJ / ZWJ spellings built for it are not judged by the spelling filter. */
static int rule_ok(const char *w, int zmode){
  if(!has_odia(w)) return 1;
  { unsigned q[256]; int qn=pr_cps(w,q,250), anyc=0; for(int i=0;i<qn;i++) if(v_cons(q[i])){ anyc=1; break; } if(!anyc) return 1; }      /* a lone sign, halant or vowel typed on its own is a key, not a word */
  if(user_has(w)) return 1;
  if(!zmode && !valid_odia(w)) return 0;
  if(!strstr(w,"\xE0\xAD\x8D")) return 1;
  for(int i=0;FORBID[i];i++) if(strstr(w,FORBID[i])) return 0;
  unsigned cp[256]; int n=pr_cps(w,cp,250);
  for(int i=0;i<n;i++){
    if(!(v_cons(cp[i]) && i+2<n && cp[i+1]==0x0B4D && v_cons(cp[i+2]))) continue;
    int j=i, k=1; while(j+2<n && cp[j+1]==0x0B4D && v_cons(cp[j+2])){ j+=2; k++; }
    if(k>4) return 0;
    char run[96]; unsigned rc[16]; int rn=0; for(int q=i;q<=j && rn<16;q++) rc[rn++]=cp[q];
    if(!pr_str(rc,rn,run,sizeof run) || !clus_known(run)) return 0;
    i=j;
  }
  return 1;
}
/* the last stage for every candidate list and every committed word: the ZWNJ rule and the strict word check on each spelling. A spelling the
   rule turns into one already in the list is dropped, and so is one that breaks the check; the typed text stays choice 2 */
int odia_strict_list(const char *roman, char (*list)[ODIA_CAND_LEN], int n, int script){
  if(script!=0) return n;
  int zm=(roman && (strchr(roman,'z')||strchr(roman,'Z'))), m=0; char f[ODIA_CAND_LEN];
  for(int i=0;i<n;i++){
    odia_strict_word(list[i],0,f,sizeof f);
    if(has_odia(f) && !(roman && strcmp(f,roman)==0) && !rule_ok(f,zm)) continue;
    int dup=0; for(int k=0;k<m;k++) if(strcmp(list[k],f)==0){ dup=1; break; }
    if(dup) continue;
    if(m!=i) snprintf(list[m],ODIA_CAND_LEN,"%s",f); else if(strcmp(list[m],f)!=0) snprintf(list[m],ODIA_CAND_LEN,"%s",f);
    m++;
  }
  if(roman && m>1 && strcmp(list[0],roman)==0){ char t[ODIA_CAND_LEN]; memcpy(t,list[0],ODIA_CAND_LEN); memcpy(list[0],list[1],ODIA_CAND_LEN); memcpy(list[1],t,ODIA_CAND_LEN); }
  return m;
}
/* writes the first spelling, and the plain spelling when it differs; returns 1 (unchanged or one spelling) or 2 */
int odia_post_word(const char *w, char *first, char *second, size_t cap){
  unsigned cp[96], z[200], a[200], b[200]; int n=pr_cps(w,cp,90), has=0, m=0, na=0, nb=0;
  first[0]=0; second[0]=0;
  for(int i=0;i<n;i++) if(cp[i]>=0x0B00 && cp[i]<=0x0B7F){ has=1; break; }
  if(!has){ snprintf(first,cap,"%s",w); return 1; }
  m=pr_zwnj(cp,n,z);                                                  /* 1: ZWNJ after a halant before ବ / ଵ unless it is a true conjunct */
  for(int i=0;i<m;i++){                                               /* 2: an existing nukta keeps its spelling; a nukta added here is the single code point ଡ଼ ଢ଼ (U+0B5C / U+0B5D) */
    unsigned c=z[i];
    if(c==0x0B21||c==0x0B22){
      if(i+1<m && z[i+1]==0x0B3C){ a[na++]=c; a[na++]=0x0B3C; b[nb++]=c; i++; }
      else { int d = i>0 && z[i-1]!=0x0B4D && z[i-1]!=0x200C && z[i-1]!=0x200D && !(i+1<m && z[i+1]==0x0B4D); a[na++]= d ? (c==0x0B21?0x0B5C:0x0B5D) : c; b[nb++]=c; }
    } else if(c==0x0B5C||c==0x0B5D){ a[na++]=c; b[nb++]=(c==0x0B5C)?0x0B21:0x0B22; }
    else { a[na++]=c; b[nb++]=c; }
  }
  if(!pr_str(a,na,first,cap)){ snprintf(first,cap,"%s",w); return 1; }
  int same = (na==nb); if(same) for(int i=0;i<na;i++) if(a[i]!=b[i]){ same=0; break; }
  if(same) return 1;
  if(!pr_str(b,nb,second,cap)){ second[0]=0; return 1; }
  return 2;
}
static void pr_key(const char *w, char *k, size_t cap){           /* both spellings of ଡ଼ ଢ଼ count as the same word */
  size_t o=0; const char *p=w;
  while(*p && o+4<cap){
    if(strncmp(p,"\xE0\xAC\xA1\xE0\xAC\xBC",6)==0){ memcpy(k+o,"\xE0\xAD\x9C",3); o+=3; p+=6; }
    else if(strncmp(p,"\xE0\xAC\xA2\xE0\xAC\xBC",6)==0){ memcpy(k+o,"\xE0\xAD\x9D",3); o+=3; p+=6; }
    else k[o++]=*p++;
  }
  k[o]=0;
}
static int pr_add(char (*L)[ODIA_CAND_LEN], int *n, int max, const char *w){
  char k1[ODIA_CAND_LEN], k2[ODIA_CAND_LEN]; pr_key(w,k1,sizeof k1);
  for(int i=0;i<*n;i++){ pr_key(L[i],k2,sizeof k2); if(strcmp(k1,k2)==0) return 0; }
  if(*n>=max) return 0;
  snprintf(L[*n],ODIA_CAND_LEN,"%s",w); (*n)++; return 1;
}

/* the cluster "ru" after a consonant: ୃ first, then ୍ରୁ, then ୍ରୂ; the ZWNJ spellings follow (same as ruRule in engine.js) */
static int ru_roman(const char *r){
  for(const char *p=r+1; *p; p++){
    if((p[0]=='r'||p[0]=='R') && (p[1]=='u'||p[1]=='U')){
      char c=p[-1]; if(c>='A'&&c<='Z') c+=32;
      if(c>='a'&&c<='z' && !strchr("aeioru",c)) return 1;
    }
  }
  return 0;
}
static int pr_repl1(const char *src, const char *from, const char *to, char *dst, size_t cap){
  const char *h=strstr(src,from); if(!h) return 0;
  size_t a=(size_t)(h-src), lf=strlen(from), lt=strlen(to);
  if(a+lt+strlen(h+lf)+1>cap) return 0;
  memcpy(dst,src,a); memcpy(dst+a,to,lt); strcpy(dst+a+lt,h+lf); return 1;
}
static int ru_rule(const char *roman, char (*L)[ODIA_CAND_LEN], int n){
  if(!ru_roman(roman)) return n;
  static const char VR[]="\xE0\xAD\x83";
  int bi=-1;
  for(int i=0;i<n;i++){
    const char *w=L[i]; if(strcmp(w,roman)==0) continue;
    const char *h=strstr(w,VR); if(!h || strstr(h+3,VR)) continue;
    bi=i; break;
  }
  if(bi<0) return n;
  char seq[5][ODIA_CAND_LEN];
  snprintf(seq[0],ODIA_CAND_LEN,"%s",L[bi]);
  if(!pr_repl1(seq[0],VR,"\xE0\xAD\x8D\xE0\xAC\xB0\xE0\xAD\x81",seq[1],ODIA_CAND_LEN)) return n;
  if(!pr_repl1(seq[0],VR,"\xE0\xAD\x8D\xE0\xAC\xB0\xE0\xAD\x82",seq[2],ODIA_CAND_LEN)) return n;
  if(!pr_repl1(seq[0],VR,"\xE0\xAD\x8D\xE2\x80\x8C\xE0\xAC\xB0\xE0\xAD\x81",seq[3],ODIA_CAND_LEN)) return n;
  if(!pr_repl1(seq[0],VR,"\xE0\xAD\x8D\xE2\x80\x8C\xE0\xAC\xB0\xE0\xAD\x82",seq[4],ODIA_CAND_LEN)) return n;
  static char rest[ODIA_MAX_CANDS*2][ODIA_CAND_LEN], res[ODIA_MAX_CANDS*2][ODIA_CAND_LEN];
  int nr=0, first=n, in[5]={0,0,0,0,0};
  for(int i=0;i<n;i++){
    int hit=-1; for(int q=0;q<5;q++) if(!strcmp(L[i],seq[q])){ hit=q; break; }
    if(hit>=0){ in[hit]=1; if(i<first) first=i; continue; }
    snprintf(rest[nr++],ODIA_CAND_LEN,"%s",L[i]);
  }
  int at=first<nr?first:nr, no=0, g=0;
  for(int i=0;i<at;i++) pr_add(res,&no,ODIA_MAX_CANDS*2,rest[i]);
  for(int q=0;q<5;q++) if(in[q]){ pr_add(res,&no,ODIA_MAX_CANDS*2,seq[q]); if(g++==0 && at<nr && strcmp(rest[at],roman)==0){ pr_add(res,&no,ODIA_MAX_CANDS*2,roman); at++; } }
  for(int i=at;i<nr;i++) pr_add(res,&no,ODIA_MAX_CANDS*2,rest[i]);
  if(no>ODIA_MAX_CANDS) no=ODIA_MAX_CANDS;
  for(int i=0;i<no;i++) memcpy(L[i],res[i],ODIA_CAND_LEN);
  return no;
}
static int post_rules(const char *roman, char all[][ODIA_CAND_LEN], int na){
  if(strchr(roman,'z')||strchr(roman,'Z')) return odia_strict_list(roman,all,na,g_zw?0:1);    /* z / Z words keep the engine's own order, but never an out-of-rule spelling */
  static char out[ODIA_MAX_CANDS*2][ODIA_CAND_LEN], later[ODIA_MAX_CANDS][ODIA_CAND_LEN];
  int no=0, nl=0; char f[ODIA_CAND_LEN], s2[ODIA_CAND_LEN];
  for(int i=0;i<na;i++){
    if(strcmp(all[i],roman)==0){ pr_add(out,&no,ODIA_MAX_CANDS*2,all[i]); continue; }
    int k=odia_post_word(all[i],f,s2,sizeof f);
    if(g_zw && has_odia(f) && !rule_ok(f,0)) continue;                 /* the strict word check: nothing that breaks it is a candidate, whichever list it came from */
    pr_add(out,&no,ODIA_MAX_CANDS*2,f); if(k==2 && !(g_zw && !rule_ok(s2,0))) pr_add(later,&nl,ODIA_MAX_CANDS,s2);
  }
  for(int i=0;i<nl;i++) pr_add(out,&no,ODIA_MAX_CANDS*2,later[i]);
  if(no>ODIA_MAX_CANDS) no=ODIA_MAX_CANDS;
  if(g_zw && *roman && no>1 && strcmp(out[0],roman)==0){ char t[ODIA_CAND_LEN]; memcpy(t,out[0],ODIA_CAND_LEN); memcpy(out[0],out[1],ODIA_CAND_LEN); memcpy(out[1],t,ODIA_CAND_LEN); }     /* the typed text stays choice 2 */
  no=ru_rule(roman,out,no);
  for(int i=0;i<no;i++) memcpy(all[i],out[i],ODIA_CAND_LEN);
  return no;
}
/* for the host app: the same rules over a finished list (the Mac smart-suggest merge) */
int odia_post_list(const char *roman, char (*list)[ODIA_CAND_LEN], int n, int script){ if(n>ODIA_MAX_CANDS) n=ODIA_MAX_CANDS; int sv=g_zw; g_zw=(script==0); n=post_rules(roman,list,n); g_zw=sv; return n; }
int odia_candidates(const char *roman, char cands[][ODIA_CAND_LEN]){
  if(!*roman) return 0;
  int alldig=1, letters=0;
  for(const char*p=roman;*p;p++){ if(!isdigit((unsigned char)*p)) alldig=0; if(isalpha((unsigned char)*p)) letters=1; }
  if(alldig || strcmp(roman,".")==0 || !letters){ g_limit=ODIA_MAX_CANDS; return gen(roman,cands); }
  static char all[ODIA_MAX_CANDS][ODIA_CAND_LEN];
  static char acr[ACRO_MAX][ODIA_CAND_LEN]; int nacr=acronym(roman,acr);
  g_limit=ODIA_MAX_CANDS-2-nacr;
  int na=gen(roman,all);
  g_limit=ODIA_MAX_CANDS;
  char t[ODIA_CAND_LEN], u[ODIA_CAND_LEN];
  size_t L=strlen(roman); if(L>ODIA_CAND_LEN-1) L=ODIA_CAND_LEN-1;
  memcpy(t,roman,L); t[L]=0; memcpy(u,roman,L); u[L]=0;
  t[0]=(char)toupper((unsigned char)t[0]);
  for(size_t i=0;i<L;i++) u[i]=(char)toupper((unsigned char)u[i]);
  if(g_filter){
    /* drop every impossible Odia spelling; the typed text stays in position 2 */
    static char ok[ODIA_MAX_CANDS][ODIA_CAND_LEN]; int nok=0;
    for(int i=0;i<na;i++){
      if(strcmp(all[i],roman)==0) continue;
      if(valid_odia(all[i])) { strcpy(ok[nok++],all[i]); }
    }
    int m=0; if(nok>0) strcpy(all[m++],ok[0]);
    strcpy(all[m++],roman);
    for(int i=1;i<nok;i++) strcpy(all[m++],ok[i]);
    na=m;
    {   /* vowel-less typing and cluster variants */
      static char f[ODIA_MAX_CANDS][ODIA_CAND_LEN], sl[16][ODIA_CAND_LEN], sk[16][ODIA_CAND_LEN], ex[EXMAX][ODIA_CAND_LEN];
      int nf=na; for(int i=0;i<nf;i++) strcpy(f[i],all[i]);
      int hb=nok>0, ntok=0, nsk=skeleton(roman,sk,16,&ntok), nsl=0, nex;
      nex=extras(roman,f,nf); for(int i=0;i<nex;i++) strcpy(ex[i],g_ex[i]);
      for(int i=0;i<nsk;i++){ int dup=0; for(int q=0;q<nf;q++) if(strcmp(f[q],sk[i])==0) dup=1; if(!dup) strcpy(sl[nsl++],sk[i]); }
      int w=0;
      #define ADD(x) do{ if(w<ODIA_MAX_CANDS && !has(all,w,(x))) strcpy(all[w++],(x)); }while(0)
      if(ntok>=3 && nsl>0){
        ADD(sl[0]); ADD(roman); for(int i=1;i<nsl;i++) ADD(sl[i]); for(int i=0;i<nex;i++) ADD(ex[i]);
        if(hb) ADD(f[0]); for(int i=hb?2:1;i<nf;i++) ADD(f[i]);
      } else {
        int r0=hb?2:1;
        int keep=nsl>0?2:(g_nsch>0?1:0);
        if(hb) ADD(f[0]); ADD(roman); for(int i=r0;i<nf&&i<r0+keep;i++) ADD(f[i]);
        for(int i=0;i<nsl;i++) ADD(sl[i]); for(int i=0;i<nex;i++) ADD(ex[i]);
        for(int i=r0+keep;i<nf;i++) ADD(f[i]);
      }
      #undef ADD
      na=w;
    }
  }
  if(g_filter && sk_n && strspn(roman,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ>~'|")==strlen(roman)){   /* the dictionary: pasnd -> ପସନ୍ଦ */
    static SkHit hits[SK_MAXHITS]; static char D[12][ODIA_CAND_LEN]; static char nl[ODIA_MAX_CANDS][ODIA_CAND_LEN];
    int nh=sk_lookup(roman,hits);
    if(nh>0){
      int top=hits[0].sc, keep=0, good0=(hits[0].neg==0);
      for(int i=0;i<nh && keep<8;i++){
        if(hits[i].sc<top-4) break;
        char vs[2][ODIA_CAND_LEN]; int nv=0, ymode=(strpbrk(roman,"yY")!=NULL);
        if(ymode && sk_ytwin(hits[i].w,vs[0],sizeof vs[0])){ strcpy(vs[1],hits[i].w); nv=2; } else { strcpy(vs[0],hits[i].w); nv=1; }
        for(int v=0;v<nv;v++){
          char p1[ODIA_CAND_LEN], p2[ODIA_CAND_LEN];
          if(sk_pair(vs[v],p1,p2,sizeof p1)){ if(keep<8 && !has(D,keep,p1)) strcpy(D[keep++],p1); if(keep<8 && !has(D,keep,p2)) strcpy(D[keep++],p2); }
          else if(keep<8 && !has(D,keep,vs[v])) strcpy(D[keep++],vs[v]);
        }
      }
      int hasbest = na>0 && strcmp(all[0],roman)!=0;
      int f0known = hasbest && (known_has(all[0]) || sk_has(all[0]));
      int m=0, lim=hasbest?7:6;
      #define NADD(x) do{ if(m<ODIA_MAX_CANDS && !has(nl,m,(x))) strcpy(nl[m++],(x)); }while(0)
      if(keep>0 && (!hasbest || (!f0known && good0 && g_sk_ntok>=3 && !strpbrk(roman,">~")))){
        /* a dictionary word that matches every vowel you typed beats a spelling the engine only guessed */
        NADD(D[0]); NADD(roman);
        if(keep>1 && sk_pair(D[0],(char*)nl[ODIA_MAX_CANDS-1],(char*)nl[ODIA_MAX_CANDS-2],ODIA_CAND_LEN)){ NADD(D[1]); }
        for(int i=0;i<na;i++) NADD(all[i]);
      } else {
        for(int i=0;i<na;i++) NADD(all[i]);
      }
      (void)lim;
      /* the other dictionary words follow the first page */
      { static char fin[ODIA_MAX_CANDS][ODIA_CAND_LEN]; int fm=0, ins=0;
        for(int i=0;i<m && i<7;i++) strcpy(fin[fm++],nl[i]);
        for(int i=0;i<keep&&ins<4;i++){ if(!has(fin,fm,D[i]) && !has(nl,m<7?m:7,D[i])){ strcpy(fin[fm++],D[i]); ins++; } }
        for(int i=7;i<m && fm<ODIA_MAX_CANDS;i++) if(!has(fin,fm,nl[i])) strcpy(fin[fm++],nl[i]);
        for(int i=0;i<fm;i++) strcpy(all[i],fin[i]); na=fm; }
      #undef NADD
    }
  }
  { const char *ap[2]; int nap=apos_match(roman,ap);
    if(nap){ int w=0; static char g3[ODIA_MAX_CANDS][ODIA_CAND_LEN];
      for(int q=0;q<nap;q++) strcpy(g3[w++],ap[q]);
      for(int i=0;i<na&&w<ODIA_MAX_CANDS;i++){ int dup=0; for(int q=0;q<nap;q++) if(strcmp(all[i],g3[q])==0) dup=1; if(!dup) strcpy(g3[w++],all[i]); }
      for(int i=0;i<w;i++) strcpy(all[i],g3[i]); na=w; } }
  { const Multi *fe=multi_find(FIRST_EXTRA,roman);
    if(fe){ int w=0; static char g2[ODIA_MAX_CANDS][ODIA_CAND_LEN]; strcpy(g2[w++],fe->o[0]);
      for(int i=0;i<na&&w<ODIA_MAX_CANDS;i++) if(strcmp(all[i],fe->o[0])!=0) strcpy(g2[w++],all[i]);
      for(int i=0;i<w;i++) strcpy(all[i],g2[i]); na=w; } }
  na=post_rules(roman,all,na);                                        /* the ZWNJ and nukta rules, before the page is laid out */
  int n=0, first=na<ODIA_PAGE-2?na:ODIA_PAGE-2;
  for(int i=0;i<first;i++) put(cands,&n,all[i]);
  put(cands,&n,t); put(cands,&n,u);
  for(int i=first;i<na;i++) put(cands,&n,all[i]);
  for(int i=0;i<nacr && n<ODIA_MAX_CANDS;i++){ strcpy(cands[n],acr[i]); n++; }   /* abbreviation spellings: always last, never de-duplicated */
  return n;
}

/* ================= output scripts (twin of toScript / toOdia in engine.tpl.js) ================= */
static int u8dec(const unsigned char *s, unsigned *cp){
  if(s[0]<0x80){ *cp=s[0]; return 1; }
  if((s[0]&0xE0)==0xC0&&s[1]){ *cp=((s[0]&0x1Fu)<<6)|(s[1]&0x3Fu); return 2; }
  if((s[0]&0xF0)==0xE0&&s[1]&&s[2]){ *cp=((s[0]&0x0Fu)<<12)|((s[1]&0x3Fu)<<6)|(s[2]&0x3Fu); return 3; }
  if((s[0]&0xF8)==0xF0&&s[1]&&s[2]&&s[3]){ *cp=((s[0]&0x07u)<<18)|((s[1]&0x3Fu)<<12)|((s[2]&0x3Fu)<<6)|(s[3]&0x3Fu); return 4; }
  *cp=s[0]; return 1;
}
static size_t u8enc(unsigned cp, char *o){
  if(cp<0x80){ o[0]=(char)cp; return 1; }
  if(cp<0x800){ o[0]=(char)(0xC0|(cp>>6)); o[1]=(char)(0x80|(cp&0x3F)); return 2; }
  if(cp<0x10000){ o[0]=(char)(0xE0|(cp>>12)); o[1]=(char)(0x80|((cp>>6)&0x3F)); o[2]=(char)(0x80|(cp&0x3F)); return 3; }
  o[0]=(char)(0xF0|(cp>>18)); o[1]=(char)(0x80|((cp>>12)&0x3F)); o[2]=(char)(0x80|((cp>>6)&0x3F)); o[3]=(char)(0x80|(cp&0x3F)); return 4;
}
/* candidates for the typing of one output script (twin of candidatesIn): Assamese reads v and w as ৱ and x as s */
/* z / Z handling, for every script. z alone: ZWNJ, z, ZWJ. A typed Z (halant + ZWNJ): 1 the ZWNJ spelling, 2 what you typed,
   3 the same with the halant but no ZWNJ, 4 with ZWJ (halant + ZWJ), then everything else. */
static void str_repl(const char *s, const char *from, const char *to, char *out, size_t cap){
  size_t fl=strlen(from), o=0; out[0]=0;
  while(*s && o+strlen(to)+2<cap){
    if(strncmp(s,from,fl)==0){ size_t tl=strlen(to); memcpy(out+o,to,tl); o+=tl; s+=fl; }
    else out[o++]=*s++;
  }
  out[o]=0;
}
static int zfix(const char *roman, const char *t, char cands[][ODIA_CAND_LEN], int n){
  int isz=(strcmp(roman,"z")==0), hasZ=(strchr(roman,'Z')!=NULL && n>1);
  if(!isz && !hasZ) return n;
  char (*lst)[ODIA_CAND_LEN]=malloc((size_t)ODIA_MAX_CANDS*ODIA_CAND_LEN); if(!lst) return n;
  int m=0;
  #define ADDC(str) do{ const char *_s=(str); int _d=0; for(int _k=0;_k<m;_k++) if(strcmp(lst[_k],_s)==0){_d=1;break;} if(!_d && m<ODIA_MAX_CANDS){ snprintf(lst[m],ODIA_CAND_LEN,"%s",_s); m++; } }while(0)
  if(isz){ ADDC("\xE2\x80\x8C"); ADDC("z"); ADDC("\xE2\x80\x8D"); }
  else {
    char zl[ODIA_CAND_LEN], zn[ODIA_CAND_LEN], zj[ODIA_CAND_LEN];
    odia_transliterate(t,zl,sizeof zl);
    str_repl(zl,"\xE0\xAD\x8D\xE2\x80\x8C","\xE0\xAD\x8D",zn,sizeof zn);
    str_repl(zl,"\xE0\xAD\x8D\xE2\x80\x8C","\xE0\xAD\x8D\xE2\x80\x8D",zj,sizeof zj);
    ADDC(zl); ADDC(roman); ADDC(zn); ADDC(zj);
  }
  for(int i=0;i<n;i++) ADDC(cands[i]);
  #undef ADDC
  for(int i=0;i<m;i++) memcpy(cands[i],lst[i],ODIA_CAND_LEN);
  free(lst); return m;
}
static int candidates_in2(const char *roman, int sc, char cands[][ODIA_CAND_LEN]);
int odia_candidates_in(const char *roman, int sc, char cands[][ODIA_CAND_LEN]){
  int sv=g_zw; g_zw=(sc==0); int n=candidates_in2(roman,sc,cands); n=odia_strict_list(roman,cands,n,sc==0?0:1); g_zw=sv; return n;
}
static int candidates_in2(const char *roman, int sc, char cands[][ODIA_CAND_LEN]){
  if(sc!=ODIA_SCRIPT_ASM){ int n=odia_candidates(roman,cands); return zfix(roman,roman,cands,n); }
  char t[256]; size_t i=0; for(;roman[i]&&i<sizeof t-1;i++) t[i]=(roman[i]=='v')?'w':(roman[i]=='x')?'s':roman[i]; t[i]=0;
  int n=odia_candidates(t,cands);
  n=zfix(roman,t,cands,n);
  if(n>1){
    snprintf(cands[1],ODIA_CAND_LEN,"%s",roman);
    if(strchr(roman,'v')||strchr(roman,'w')){                  /* the dictionary is Odia-spelled (ବ for v): a typed v / w keeps ৱ first */
      char lit[ODIA_CAND_LEN]; odia_transliterate(t,lit,sizeof lit);
      for(int i=2;i<n;i++) if(strcmp(cands[i],lit)==0){ char keep[ODIA_CAND_LEN]; memcpy(keep,cands[i],sizeof keep); for(int k=i;k>0;k--) memcpy(cands[k],cands[k-1],ODIA_CAND_LEN); memcpy(cands[0],keep,ODIA_CAND_LEN); break; }
    }
  }
  return n;
}
void odia_convert(const char *odia, int sc, int opts, char *out, size_t cap){
  if(cap==0) return;
  if(sc!=ODIA_SCRIPT_DEVA && sc!=ODIA_SCRIPT_BENG && sc!=ODIA_SCRIPT_ASM){ snprintf(out,cap,"%s",odia); return; }
  unsigned a[ODIA_CAND_LEN*2]; size_t na=0;
  int dv=(sc==ODIA_SCRIPT_DEVA), as=(sc==ODIA_SCRIPT_ASM); int d=(dv?0x0900:0x0980)-0x0B00;
  const unsigned char *p=(const unsigned char*)odia;
  while(*p && na+3<sizeof a/sizeof a[0]){
    unsigned c; int l=u8dec(p,&c); p+=l;
    if(c==0x200D){ unsigned nx; u8dec(p,&nx); if(nx==0x0B4D) continue; }
    if(c==0x0B5F && !dv && na && a[na-1]==0x09CD){ a[na++]=0x09AF; continue; }
    if((c==0x0B35||c==0x0B71) && !dv && !as && !(na && a[na-1]==0x09CD)){ a[na++]=0x0993; a[na++]=0x09AF; a[na++]=0x09BC; continue; }
    if(c<0x0B00||c>0x0B7F){ a[na++]=c; continue; }
    switch(c){
      case 0x0B5C: a[na++]=dv?0x0921:0x09A1; a[na++]=dv?0x093C:0x09BC; break;
      case 0x0B5D: a[na++]=dv?0x0922:0x09A2; a[na++]=dv?0x093C:0x09BC; break;
      case 0x0B30: a[na++]=as?0x09F0:(unsigned)((int)c+d); break;
      case 0x0B35: case 0x0B71: a[na++]=dv?0x0935:as?0x09F1:0x09AC; break;
      case 0x0B33: a[na++]=dv?((opts&ODIA_OPT_MARATHI)?0x0933:0x0932):0x09B2; break;
      case 0x0B5F: a[na++]=dv?0x092F:0x09DF; break;
      case 0x0B56: break;
      case 0x0B57: if(!dv) a[na++]=0x09D7; break;
      default: a[na++]=(unsigned)((int)c+d);
    }
  }
  if(dv && (opts&ODIA_OPT_ANUSVARA)){
    static const unsigned nas[5]={0x0919,0x091E,0x0923,0x0928,0x092E}, lo[5]={0x0915,0x091A,0x091F,0x0924,0x092A}, hi[5]={0x0918,0x091D,0x0922,0x0927,0x092D};
    size_t w=0;
    for(size_t i=0;i<na;i++){
      int hit=0;
      for(int q=0;q<5;q++) if(a[i]==nas[q] && i+2<na && a[i+1]==0x094D && a[i+2]>=lo[q] && a[i+2]<=hi[q] && (i==0||a[i-1]!=0x094D)){ hit=1; break; }
      if(hit){ a[w++]=0x0902; i++; } else a[w++]=a[i];
    }
    na=w;
  }
  size_t o=0; char b[4];
  for(size_t i=0;i<na;i++){ size_t l=u8enc(a[i],b); if(o+l+1>cap) break; memcpy(out+o,b,l); o+=l; }
  out[o]=0;
}
void odia_to_odia(const char *any, char *out, size_t cap){
  if(cap==0) return;
  const unsigned char *p=(const unsigned char*)any; size_t o=0; char b[4];
  while(*p){
    unsigned c; int l=u8dec(p,&c); p+=l;
    if(c==0x09F0) c=0x0B30; else if(c==0x09F1) c=0x0B71;
    else if(c>=0x0900&&c<=0x097F&&c!=0x0964&&c!=0x0965) c+=0x0200; else if(c>=0x0980&&c<=0x09FF) c+=0x0180;
    size_t k=u8enc(c,b); if(o+k+1>cap) break; memcpy(out+o,b,k); o+=k;
  }
  out[o]=0;
}

/* ---------- Roman guess for a word (used by "Add to Sulekhak Dictionary") ---------- */
/* Writes in `out` a Roman spelling the typing scheme would turn back into `odia` (several words keep their order, written together).
   variant 0 leaves the last bare consonant of a word without its a (kar), variant 1 writes it (kara). The caller checks the guess with odia_candidates. */
static const char *rv_cons(unsigned c){
  switch(c){
    case 0x0B15:return "k"; case 0x0B16:return "kh"; case 0x0B17:return "g"; case 0x0B18:return "gh"; case 0x0B19:return "ng";
    case 0x0B1A:return "ch"; case 0x0B1B:return "chh"; case 0x0B1C:return "j"; case 0x0B1D:return "jh"; case 0x0B1E:return "ny";
    case 0x0B1F:return "T"; case 0x0B20:return "Th"; case 0x0B21:return "D"; case 0x0B22:return "Dh"; case 0x0B23:return "N";
    case 0x0B24:return "t"; case 0x0B25:return "th"; case 0x0B26:return "d"; case 0x0B27:return "dh"; case 0x0B28:return "n";
    case 0x0B2A:return "p"; case 0x0B2B:return "ph"; case 0x0B2C:return "b"; case 0x0B2D:return "bh"; case 0x0B2E:return "m";
    case 0x0B2F:return "y"; case 0x0B30:return "r"; case 0x0B32:return "l"; case 0x0B33:return "L"; case 0x0B35:return "V";
    case 0x0B36:return "sh"; case 0x0B37:return "Sh"; case 0x0B38:return "s"; case 0x0B39:return "h";
    case 0x0B5C:return "R"; case 0x0B5D:return "Rh"; case 0x0B5F:return "Y"; case 0x0B71:return "w";
  }
  return NULL;
}
static const char *rv_vowel(unsigned c){
  switch(c){
    case 0x0B05:return "a"; case 0x0B06:return "aa"; case 0x0B07:return "i"; case 0x0B08:return "ii"; case 0x0B09:return "u"; case 0x0B0A:return "uu";
    case 0x0B0B:return "rri"; case 0x0B60:return "rrii"; case 0x0B0C:return "lrri"; case 0x0B61:return "lrrii";
    case 0x0B0F:return "e"; case 0x0B10:return "ai"; case 0x0B13:return "o"; case 0x0B14:return "au";
  }
  return NULL;
}
static const char *rv_sign(unsigned c){
  switch(c){
    case 0x0B3E:return "a"; case 0x0B3F:return "i"; case 0x0B40:return "ii"; case 0x0B41:return "u"; case 0x0B42:return "uu";
    case 0x0B43:return "rri"; case 0x0B44:return "rrii"; case 0x0B62:return "lrri"; case 0x0B63:return "lrrii";
    case 0x0B47:return "e"; case 0x0B48:return "ai"; case 0x0B4B:return "o"; case 0x0B4C:return "au";
    case 0x0B02:return "M"; case 0x0B03:return "H"; case 0x0B01:return "~";
  }
  return NULL;
}
void odia_reverse_roman(const char *odia, int variant, char *out, size_t cap){
  unsigned cp[512]; int n=0; const unsigned char *q=(const unsigned char*)odia;
  while(*q && n<511){
    if(q[0]<0x80){ cp[n++]=q[0]; q++; }
    else if(q[0]<0xE0){ cp[n++]=((q[0]&0x1Fu)<<6)|(q[1]&0x3Fu); q+=2; }
    else if(q[0]<0xF0){ cp[n++]=((q[0]&0x0Fu)<<12)|((q[1]&0x3Fu)<<6)|(q[2]&0x3Fu); q+=3; }
    else { cp[n++]=0xFFFD; q+=4; }
  }
  size_t o=0;
  #define RV_PUT(str) do{ const char *_s=(str); while(*_s && o+1<cap) out[o++]=*_s++; }while(0)
  for(int i=0;i<n;i++){
    unsigned c=cp[i]; const char *t;
    if((t=rv_cons(c))){
      RV_PUT(t);
      unsigned x=i+1<n?cp[i+1]:0;
      int wordend = (x==0||x==' '||x=='\t');
      if(x==0x0B4D||x==0x0B3C||(rv_sign(x)&&x!=0x0B02&&x!=0x0B03&&x!=0x0B01)) { /* halant, nukta or a vowel sign follows: no inherent a */ }
      else if(wordend){ if(variant&1) RV_PUT("a"); }
      else RV_PUT("a");
    }
    else if((t=rv_vowel(c))) RV_PUT(t);
    else if((t=rv_sign(c))) RV_PUT(t);
    else if(c==0x0B4D||c==0x0B3C||c==0x200C||c==0x200D) { /* halant: the consonants join; nukta is part of ଡ଼ ଢ଼ already */ }
    else if(c==0x0964) RV_PUT(".");
    else if(c==' '||c=='\t') { /* words are written together */ }
    else if(c<0x80 && o+1<cap) out[o++]=(char)c;
  }
  #undef RV_PUT
  if(cap) out[o<cap?o:cap-1]=0;
}
