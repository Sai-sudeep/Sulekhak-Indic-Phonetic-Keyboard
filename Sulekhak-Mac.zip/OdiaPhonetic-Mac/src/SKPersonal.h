// SKPersonal: English typing support and (in the personal build) Google sign-in with learning sync, for the Mac keyboard.
//
// It runs the same JavaScript as the Windows and Android apps (english.js, learning.js, drive.js, personal.js) inside JavaScriptCore on a
// queue of its own, so typing never waits for the network. Files:
//   ~/Library/Application Support/Sulekhak/learning/<lang>.json    what is learned, one file per language (or hi mr bn as en)
//   ~/Library/Application Support/Sulekhak/google.tok              the Google refresh token (only in the personal build, readable by you only)
// The public build has no sign-in: SKPersonal then only learns your English words on this Mac.
#import <Foundation/Foundation.h>

@interface SKPersonal : NSObject
+ (instancetype)shared;
@property (readonly) BOOL signInAvailable;        // this build has sign-in and the Google client details
@property (readonly) BOOL signedIn;
@property (readonly, copy) NSString *email;
@property (readonly, copy) NSString *statusLine;  // one line for the input menu
@property (readonly) BOOL englishReady;

- (void)startIfNeeded;
/// The typing script changed (0 Odia, 1 Devanagari, 2 Bangla, 4 Phonetic, 5 Assamese, 6 English) and the Devanagari options.
- (void)setScript:(int)script options:(int)opts;

// English
/// Suggestions for the word being typed. YES: `list` is filled, list[0] is what Space commits, *autoCorrected: list[1] is the text as typed. NO: not loaded yet.
- (NSArray<NSString *> *)englishNext:(NSString *)prev;      // the words that usually follow prev ("<s>" at the start of a sentence); nil when not ready
- (BOOL)englishQuery:(NSString *)typed previous:(NSString *)prev list:(NSArray<NSString *> **)list autoCorrected:(BOOL *)autoCorrected;
- (void)englishCommitTyped:(NSString *)typed word:(NSString *)word previous:(NSString *)prev how:(NSString *)how passedOver:(NSString *)passed;

// Indic (personal build): a word was picked for these Roman letters (the Odia form of the word)
- (void)noteOdiaPick:(NSString *)roman word:(NSString *)odia previous:(NSString *)prevOdia;

// Sign-in (personal build)
- (void)signIn;
- (void)signOut;
- (void)syncNow;
@end
