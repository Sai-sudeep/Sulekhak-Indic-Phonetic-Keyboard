#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "engine.h"
/* reads one Roman word per line, prints: word TAB cand1 TAB cand2 ...   (used by tools/regress.sh and tools/audit.sh) */
int main(void){
  static char c[ODIA_MAX_CANDS][ODIA_CAND_LEN]; char line[512];
  odia_load_builtin(); int sc=getenv("ODIA_SC")?atoi(getenv("ODIA_SC")):0;
  { const char *sp=getenv("ODIA_SKEL"); if(!sp) sp="skel.dat"; FILE *f=fopen(sp,"rb"); if(f){ fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET); char *b=(char*)malloc((size_t)n+1); if(b&&fread(b,1,(size_t)n,f)==(size_t)n) odia_load_skel(b,(size_t)n); free(b); fclose(f); } }
  while(fgets(line,sizeof line,stdin)){
    size_t L=strlen(line); while(L&&(line[L-1]=='\n'||line[L-1]=='\r')) line[--L]=0;
    if(!L) continue;
    int n=odia_candidates_in(line,sc,c); printf("%s",line);
    for(int i=0;i<n;i++) printf("\t%s",c[i]);
    printf("\n");
  }
  return 0;
}
