#import <Cocoa/Cocoa.h>
#import <InputMethodKit/InputMethodKit.h>
#import "OSKPanel.h"
#import "SuggestBar.h"
#import "OdiaController.h"
#include "engine.h"

IMKServer *gServer = nil;

static NSString *SupportDir(void) {
    NSString *d = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/LekhaniOdia"];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL fresh = ![fm fileExistsAtPath:d];
    [fm createDirectoryAtPath:d withIntermediateDirectories:YES attributes:nil error:nil];
    if (fresh) {    // carry over your own words and learned picks from the old "Odia Phonetic" folder
        NSString *old = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/OdiaPhonetic"];
        for (NSString *f in @[@"lexicon.tsv", @"history.tsv"])
            [fm copyItemAtPath:[old stringByAppendingPathComponent:f] toPath:[d stringByAppendingPathComponent:f] error:nil];
    }
    return d;
}
// Lines: roman <TAB> odia [<TAB> weight]
static void LoadTSV(NSString *path, int defaultWeight) {
    NSString *txt = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    if (!txt) return;
    for (NSString *line in [txt componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
        NSArray *p = [line componentsSeparatedByString:@"\t"];
        if (p.count < 2 || [p[0] length] == 0 || [p[1] length] == 0) continue;
        int w = p.count > 2 ? [p[2] intValue] : defaultWeight;
        odia_lex_add([p[0] UTF8String], [p[1] UTF8String], w > 0 ? w : defaultWeight);
    }
}

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSString *conn = [[NSBundle mainBundle] infoDictionary][@"InputMethodConnectionName"];
        gServer = [[IMKServer alloc] initWithName:conn bundleIdentifier:[[NSBundle mainBundle] bundleIdentifier]];
        odia_load_builtin();
        {   // the consonant-skeleton dictionary: pasnd -> ପସନ୍ଦ
            NSString *sp = [[NSBundle mainBundle] pathForResource:@"skel" ofType:@"dat"];
            NSData *sd = sp ? [NSData dataWithContentsOfFile:sp] : nil;
            if (sd) odia_load_skel((const char *)sd.bytes, sd.length);
        }
        NSString *dir = SupportDir();
        LoadTSV([dir stringByAppendingPathComponent:@"lexicon.tsv"], 2);   // your own word list
        LoadTSV([dir stringByAppendingPathComponent:@"history.tsv"], 3);   // words you have picked before
        [NSApplication sharedApplication];
        [SuggestBar shared].onPick = ^(NSInteger i, BOOL isNext) { [OdiaController suggestPick:i next:isNext]; };
        [OSKPanel installHotKey];     // Ctrl+Option+K shows or hides the 3D keyboard
        [[NSApplication sharedApplication] run];
    }
    return 0;
}
