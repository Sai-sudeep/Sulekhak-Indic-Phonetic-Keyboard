#import <Cocoa/Cocoa.h>
#import <InputMethodKit/InputMethodKit.h>
#import "OSKPanel.h"
#import "SuggestBar.h"
#import "OdiaController.h"
#import "SKLearn.h"
#include "engine.h"

IMKServer *gServer = nil;

static NSString *SupportDir(void) {
    NSString *d = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/LekhaniOdia"];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL fresh = ![fm fileExistsAtPath:d];
    [fm createDirectoryAtPath:d withIntermediateDirectories:YES attributes:nil error:nil];
    if (fresh) {    // carry over your own words and learned picks from the old "Odia Phonetic" folder
        NSString *old = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/OdiaPhonetic"];
        for (NSString *f in @[@"lexicon.tsv", @"history.tsv"])
            [fm copyItemAtPath:[old stringByAppendingPathComponent:f] toPath:[d stringByAppendingPathComponent:f] error:nil];
    }
    return d;
}
// Lines: roman <TAB> odia [<TAB> weight]

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSString *conn = [[NSBundle mainBundle] infoDictionary][@"InputMethodConnectionName"];
        gServer = [[IMKServer alloc] initWithName:conn bundleIdentifier:[[NSBundle mainBundle] bundleIdentifier]];
        odia_load_builtin();
        {   // the consonant-skeleton dictionary: pasnd -> ପସନ୍ଦ
            NSString *sp = [[NSBundle mainBundle] pathForResource:@"skel" ofType:@"dat"];
            NSData *sd = sp ? [NSData dataWithContentsOfFile:sp] : nil;
            if (sd) odia_load_skel((const char *)sd.bytes, sd.length);
        }
        NSString *dir = SupportDir();
        // what you have picked and your own words live in one file, sulekhak-learn.json (the old history.tsv and lexicon.tsv are folded into it the first time)
        [[SKLearn shared] openInDirectory:dir];
        [[SKLearn shared] loadIntoEngine];
        [NSApplication sharedApplication];
        [SuggestBar shared].onPick = ^(NSInteger i, BOOL isNext) { [OdiaController suggestPick:i next:isNext]; };
        [SKLearn installServices];            // Services menu / right-click: Add to Sulekhak Dictionary, and sulekhak://add
        [SKLearn startSelectionButton];       // the + beside a mouse selection
        [OSKPanel installHotKey];     // Ctrl+Option+K shows or hides the 3D keyboard
        [[NSApplication sharedApplication] run];
    }
    return 0;
}
