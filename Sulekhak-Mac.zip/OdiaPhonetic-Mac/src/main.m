#import <Cocoa/Cocoa.h>
#import <InputMethodKit/InputMethodKit.h>
#import "OSKPanel.h"
#import "SuggestBar.h"
#import "OdiaController.h"
#import "SKLearn.h"
#include "engine.h"

IMKServer *gServer = nil;

static NSString *SupportDir(void) {
    NSString *d = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/LekhaniOdia"];
    NSFileManager *fm = [NSFileManager defaultManager];
    BOOL fresh = ![fm fileExistsAtPath:d];
    [fm createDirectoryAtPath:d withIntermediateDirectories:YES attributes:nil error:nil];
    if (fresh) {    // carry over your own words and learned picks from the old "Odia Phonetic" folder
        NSString *old = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/OdiaPhonetic"];
        for (NSString *f in @[@"lexicon.tsv", @"history.tsv"])
            [fm copyItemAtPath:[old stringByAppendingPathComponent:f] toPath:[d stringByAppendingPathComponent:f] error:nil];
    }
    return d;
}
// Lines: roman <TAB> odia [<TAB> weight]

extern int SKSelfTest(void);

// ---- keeping the keyboard alive -------------------------------------------------------------------------------------------------
// A log you can send: ~/Library/Logs/SulekhakIME.log (what went wrong, with the time). An uncaught exception or a crash signal writes a line there;
// a watchdog thread notices if the main thread stops answering for 8 s (the symptom: no typing, and the Input menu items vanish) and ends the process,
// which macOS then starts again the next time you type, so the keyboard comes back by itself instead of staying dead until you log out.
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <execinfo.h>
#include <time.h>
#include <pthread.h>
static char gLogPath[1024];
static void SKLogLine(const char *msg) {
    int fd = open(gLogPath, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd < 0) return;
    char t[64]; time_t now = time(NULL); struct tm tmv; localtime_r(&now, &tmv); strftime(t, sizeof t, "%Y-%m-%d %H:%M:%S ", &tmv);
    write(fd, t, strlen(t)); write(fd, msg, strlen(msg)); write(fd, "\n", 1);
    close(fd);
}
static void SKCrashSignal(int sig) {
    char m[64]; snprintf(m, sizeof m, "crash: signal %d", sig); SKLogLine(m);
    void *bt[32]; int n = backtrace(bt, 32);
    int fd = open(gLogPath, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd >= 0) { backtrace_symbols_fd(bt, n, fd); close(fd); }
    signal(sig, SIG_DFL); raise(sig);
}
static void SKUncaught(NSException *e) {
    NSString *m = [NSString stringWithFormat:@"uncaught exception: %@ %@ %@", e.name, e.reason, [e.callStackSymbols componentsJoinedByString:@" | "]];
    SKLogLine(m.UTF8String);
}
static volatile uint64_t gBeat;
static void SKStartWatchdog(void) {
    gBeat = clock_gettime_nsec_np(CLOCK_UPTIME_RAW);          // does not tick while the Mac sleeps, so closing the lid is never mistaken for a hang
    dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), NSEC_PER_SEC, NSEC_PER_SEC / 4);
    dispatch_source_set_event_handler(t, ^{ gBeat = clock_gettime_nsec_np(CLOCK_UPTIME_RAW); });
    dispatch_resume(t);
    static dispatch_source_t keep; keep = t;
    dispatch_queue_t wq = dispatch_queue_create("sulekhak.watchdog", DISPATCH_QUEUE_SERIAL);
    dispatch_source_t w = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, wq);
    dispatch_source_set_timer(w, dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), 2 * NSEC_PER_SEC, NSEC_PER_SEC / 2);
    dispatch_source_set_event_handler(w, ^{
        uint64_t now = clock_gettime_nsec_np(CLOCK_UPTIME_RAW), last = gBeat;
        if (last && now > last && now - last > 8 * NSEC_PER_SEC) {
            SKLogLine("watchdog: the main thread stopped answering for 8 s; restarting the keyboard");
            _exit(1);
        }
    });
    dispatch_resume(w);
    static dispatch_source_t keep2; keep2 = w;
}

int main(int argc, const char *argv[]) {
    if (argc > 1 && strcmp(argv[1], "--selftest") == 0) return SKSelfTest();
    snprintf(gLogPath, sizeof gLogPath, "%s/Library/Logs/SulekhakIME.log", getenv("HOME") ?: "/tmp");
    NSSetUncaughtExceptionHandler(&SKUncaught);
    signal(SIGSEGV, SKCrashSignal); signal(SIGBUS, SKCrashSignal); signal(SIGILL, SKCrashSignal); signal(SIGABRT, SKCrashSignal); signal(SIGFPE, SKCrashSignal);
    signal(SIGPIPE, SIG_IGN);              // a closed network connection must never end the keyboard
    @autoreleasepool {
        NSString *conn = [[NSBundle mainBundle] infoDictionary][@"InputMethodConnectionName"];
        gServer = [[IMKServer alloc] initWithName:conn bundleIdentifier:[[NSBundle mainBundle] bundleIdentifier]];
        odia_load_builtin();
        {   // the consonant-skeleton dictionary: pasnd -> ପସନ୍ଦ
            NSString *sp = [[NSBundle mainBundle] pathForResource:@"skel" ofType:@"dat"];
            NSData *sd = sp ? [NSData dataWithContentsOfFile:sp] : nil;
            if (sd) odia_load_skel((const char *)sd.bytes, sd.length);
        }
        NSString *dir = SupportDir();
        // what you have picked and your own words live in one file, sulekhak-learn.json (the old history.tsv and lexicon.tsv are folded into it the first time)
        [[SKLearn shared] openInDirectory:dir];
        [[SKLearn shared] loadIntoEngine];
        [NSApplication sharedApplication];
        [SuggestBar shared].onPick = ^(NSInteger i, BOOL isNext) { [OdiaController suggestPick:i next:isNext]; };
        [SKLearn installServices];            // Services menu / right-click: Add to Sulekhak Dictionary, and sulekhak://add
        [SKLearn startSelectionButton];       // the + beside a mouse selection
        [OSKPanel installScriptHotKeys];   // Ctrl+Option+1...8 (only while Sulekhak is the selected keyboard)
        [OSKPanel installHotKey];     // Ctrl+Option+K shows or hides the 3D keyboard
        SKLogLine("started");
        SKStartWatchdog();
        [[NSApplication sharedApplication] run];
    }
    return 0;
}
