#import "SKEnglishTyper.h"
#import "SKPersonal.h"
#include "tipcore.h"
#include <memory>
#include <string>
#include <vector>

static NSString *NS16(const sk::ustr &s) { return [NSString stringWithCharacters:(const unichar *)s.data() length:s.size()]; }
static sk::ustr US16(NSString *s) {
    sk::ustr u;
    if (!s.length) return u;
    u.resize(s.length);
    [s getCharacters:(unichar *)&u[0] range:NSMakeRange(0, s.length)];
    return u;
}

// What the typing rules need from the program being typed into, over the Input Method Kit.
class MacDoc : public sk::Doc {
public:
    id client = nil;
    sk::ustr Before(int n) override {
        if (!client || n <= 0) return sk::ustr();
        NSRange sr = [client selectedRange];
        if (sr.location == NSNotFound) return sk::ustr();
        NSUInteger st = sr.location > (NSUInteger)n ? sr.location - (NSUInteger)n : 0;
        NSAttributedString *a = [client attributedSubstringFromRange:NSMakeRange(st, sr.location - st)];
        return US16(a.string);
    }
    void Compose(const sk::ustr &s) override {
        NSString *t = NS16(s);
        NSAttributedString *m = [[NSAttributedString alloc] initWithString:t attributes:@{ NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle) }];
        [client setMarkedText:m selectionRange:NSMakeRange(t.length, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)];
    }
    void Commit(const sk::ustr &s) override { [client insertText:NS16(s) replacementRange:NSMakeRange(NSNotFound, NSNotFound)]; }
    void EndEmpty() override { [client setMarkedText:@"" selectionRange:NSMakeRange(0, 0) replacementRange:NSMakeRange(NSNotFound, NSNotFound)]; }
    void ReplaceBefore(int drop, const sk::ustr &s) override {
        NSRange sr = [client selectedRange];
        NSRange r = NSMakeRange(NSNotFound, NSNotFound);
        if (drop > 0 && sr.location != NSNotFound && sr.location >= (NSUInteger)drop) r = NSMakeRange(sr.location - (NSUInteger)drop, (NSUInteger)drop);
        [client insertText:NS16(s) replacementRange:r];
    }
};

// What it needs from the engine: SKPersonal (the English word lists and what you have taught it).
class MacEngine : public sk::Engine {
public:
    __unsafe_unretained SKEnglishTyper *owner = nil;
    bool Query(int, const sk::ustr &buf, const sk::ustr &prev, std::vector<sk::ustr> &out) override {
        NSArray<NSString *> *list = nil; BOOL autoFixed = NO;
        if (![[SKPersonal shared] englishQuery:NS16(buf) previous:NS16(prev) list:&list autoCorrected:&autoFixed] || !list.count) return false;
        for (NSString *w in list) out.push_back(US16(w));
        return true;
    }
    void LearnEnglish(const sk::ustr &typed, const sk::ustr &word, const sk::ustr &prev, const std::string &how, const sk::ustr &passed) override {
        [[SKPersonal shared] englishCommitTyped:NS16(typed) word:NS16(word) previous:NS16(prev) how:[NSString stringWithUTF8String:how.c_str()] passedOver:NS16(passed)];
    }
    void ShowList(const std::vector<sk::ustr> &list, int sel, const sk::ustr &roman) override {
        NSMutableArray *a = [NSMutableArray new];
        for (const sk::ustr &w : list) [a addObject:NS16(w)];
        shown = a; shownSel = sel;
        if (owner.showList) owner.showList(a, sel, NS16(roman));
    }
    void HideList() override { shown = nil; if (owner.hideList) owner.hideList(); }
    NSArray<NSString *> *shown = nil;
    int shownSel = 0;
};

static uint32_t VirtualKey(unsigned short kc) {          // the Windows virtual-key numbers that the typing rules know
    switch (kc) {
        case 49: return 0x20;                // space
        case 36: case 76: return 0x0D;       // return, enter
        case 53: return 0x1B;                // escape
        case 51: return 0x08;                // delete (backspace)
        case 48: return 0x09;                // tab
        case 123: return 0x25; case 126: return 0x26; case 124: return 0x27; case 125: return 0x28;   // left, up, right, down
        case 116: return 0x21; case 121: return 0x22;                                                  // page up, page down
        case 119: return 0x23; case 115: return 0x24;                                                  // end, home
        case 117: return 0x2E;               // forward delete
        case 82: return 0x60; case 83: return 0x61; case 84: return 0x62; case 85: return 0x63; case 86: return 0x64;     // the numeric keypad (it always types digits)
        case 87: return 0x65; case 88: return 0x66; case 89: return 0x67; case 91: return 0x68; case 92: return 0x69;
        default: return 0x41;                // a letter or a mark: the character decides
    }
}

@implementation SKEnglishTyper {
    MacDoc _doc;
    MacEngine _eng;
    std::unique_ptr<sk::Core> _core;
}
- (instancetype)init {
    if ((self = [super init])) {
        _eng.owner = self;
        _core.reset(new sk::Core(&_doc, &_eng));
        _core->SetScript(6);
    }
    return self;
}
- (BOOL)composing { return _core->Composing(); }

static BOOL SKOn(NSString *key) { id v = [[NSUserDefaults standardUserDefaults] objectForKey:key]; return v ? [v boolValue] : YES; }      // the English polish switches are on until turned off in the menu
- (BOOL)handleEvent:(NSEvent *)e client:(id)client {
    _core->SetEnglishOptions(SKOn(@"SulekhakEnCap"), SKOn(@"SulekhakEnSmart"));
    _doc.client = client;
    NSEventModifierFlags f = e.modifierFlags;
    sk::Key k;
    k.vk = VirtualKey(e.keyCode);
    NSString *c = e.characters;
    unichar ch = c.length == 1 ? [c characterAtIndex:0] : 0;
    k.ch = (ch >= 32 && ch != 127 && !(ch >= 0xF700 && ch <= 0xF8FF)) ? (char16_t)ch : 0;
    k.shift = (f & NSEventModifierFlagShift) != 0;
    k.ctrl = (f & NSEventModifierFlagControl) != 0;
    k.alt = (f & NSEventModifierFlagOption) != 0;
    k.win = (f & NSEventModifierFlagCommand) != 0;
    // a key that is neither a named key nor a character (an F key, Caps Lock ...): the word is finished and the key goes on
    if (k.vk == 0x41 && k.ch == 0) k.vk = 0x70;
    return _core->OnKey(k) ? YES : NO;
}
- (void)finishWithClient:(id)client {
    if (!_core->Composing()) return;
    _doc.client = client;
    _core->Reset();
}
- (void)pageBy:(NSInteger)d client:(id)client {
    if (!_core->Composing() || _eng.shown.count < 2) return;
    _doc.client = client;
    sk::Key k = { d < 0 ? 0x21u : 0x22u, 0, false, false, false, false };
    _core->OnKey(k);
}
- (void)pickIndex:(NSInteger)i client:(id)client {
    if (!_core->Composing() || !_eng.shown.count) return;
    _doc.client = client;
    NSInteger n = (NSInteger)_eng.shown.count;
    if (i < 0 || i >= n) return;
    NSInteger tabs = (i - _eng.shownSel + n) % n;                  // the list has no "choose number i" call: Tab goes there, then Space takes it
    sk::Key tab = { 0x09, 0, false, false, false, false }, space = { 0x20, 0, false, false, false, false };
    for (NSInteger t = 0; t < tabs; t++) _core->OnKey(tab);
    if (i == 0 && tabs == 0) { sk::Key dn = { 0x28, 0, false, false, false, false }; _core->OnKey(dn); sk::Key up = { 0x26, 0, false, false, false, false }; _core->OnKey(up); }   // a click on the first one counts as chosen by hand
    _core->OnKey(space);
}
@end


// ------------------------------------------------------------------------------------------------------------------------------------------------
// A check that runs the real English typing (the C++ rules, the JavaScript engine in JavaScriptCore, the learning files) against a text kept in a string:
//     LekhaniOdia --selftest          (the build in CI does this; prints one line per check and returns 0 only when all pass)
class StringDoc : public sk::Doc {
public:
    sk::ustr done, comp;
    sk::ustr Before(int n) override { return done.size() > (size_t)n ? done.substr(done.size() - (size_t)n) : done; }
    void Compose(const sk::ustr &s) override { comp = s; }
    void Commit(const sk::ustr &s) override { done += s; comp.clear(); }
    void EndEmpty() override { comp.clear(); }
    void ReplaceBefore(int drop, const sk::ustr &s) override { done = done.size() >= (size_t)drop ? done.substr(0, done.size() - (size_t)drop) : sk::ustr(); done += s; }
    NSString *text() { return NS16(done + comp); }
};

static void SKType(sk::Core &core, StringDoc &d, NSString *letters) {
    for (NSUInteger i = 0; i < letters.length; i++) {
        char16_t c = (char16_t)[letters characterAtIndex:i];
        sk::Key k = { c == u' ' ? 0x20u : 0x41u, c, false, false, false, false };
        if (!core.OnKey(k)) d.done += c;                    // a key that the rules hand on goes to the text as it is
    }
}
static void SKPress(sk::Core &core, StringDoc &d, uint32_t vk) { sk::Key k = { vk, 0, false, false, false, false }; core.OnKey(k); (void)d; }

extern "C" BOOL gSKNoTimeouts;
extern "C" int SKSelfTest(void) {
    gSKNoTimeouts = YES;
    @autoreleasepool {
        [[SKPersonal shared] setScript:6 options:0];
        for (int i = 0; i < 240 && ![[SKPersonal shared] englishReady]; i++) [NSThread sleepForTimeInterval:0.5];
        if (![[SKPersonal shared] englishReady]) { printf("FAIL  English data did not load in 120 s\n"); return 1; }
        printf("ok    English data loaded\n");
        StringDoc doc; MacEngine eng; sk::Core core(&doc, &eng); core.SetScript(6);
        int bad = 0;
        auto check = [&](const char *what, NSString *got, NSString *want) {
            BOOL ok = [got isEqualToString:want];
            printf("%s  %s  [%s]%s\n", ok ? "ok  " : "FAIL", what, got.UTF8String, ok ? "" : [NSString stringWithFormat:@"  expected [%@]", want].UTF8String);
            if (!ok) bad++;
        };
        SKType(core, doc, @"teh ");                  check("teh + space is corrected", doc.text(), @"the ");
        SKType(core, doc, @"recieve ");              check("recieve + space is corrected", doc.text(), @"the receive ");
        SKPress(core, doc, 0x08);                    check("backspace right after a correction puts the typed letters back", doc.text(), @"the recieve ");
        SKType(core, doc, @"hello");                 SKPress(core, doc, 0x1B); check("esc keeps what was typed", doc.text(), @"the recieve hello");
        SKType(core, doc, @" dont ");                check("dont becomes don't", doc.text(), @"the recieve hello don't ");
        SKType(core, doc, @"thnak ");                check("thnak becomes thank", doc.text(), @"the recieve hello don't thank ");
        // what was learned is written to the language file a couple of seconds later
        for (int i = 0; i < 3; i++) [[SKPersonal shared] englishCommitTyped:@"zorbatrix" word:@"zorbatrix" previous:@"<s>" how:@"typed" passedOver:@""];
        NSString *f = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/Sulekhak/learning/en.json"];
        BOOL saved = NO;
        for (int i = 0; i < 20 && !saved; i++) { [NSThread sleepForTimeInterval:0.5]; saved = [[NSFileManager defaultManager] fileExistsAtPath:f]; }
        printf("%s  the learning file en.json was written\n", saved ? "ok  " : "FAIL"); if (!saved) bad++;
        NSArray *l = nil; BOOL a = NO;
        BOOL q = [[SKPersonal shared] englishQuery:@"zorbatrix" previous:@"<s>" list:&l autoCorrected:&a];
        check("a word typed three times is kept as the person's own", (q && l.count) ? l.firstObject : @"(none)", @"zorbatrix");
        printf(bad ? "SELFTEST FAILED (%d)\n" : "SELFTEST PASSED\n", bad);
        return bad ? 1 : 0;
    }
}
