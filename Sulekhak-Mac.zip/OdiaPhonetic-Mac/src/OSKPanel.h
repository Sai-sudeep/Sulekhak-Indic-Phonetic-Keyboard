// The 3D on-screen keyboard for the Mac input method: the same keyboard as the web tool, with Mac / Windows / iPad / Android styles.
#import <Cocoa/Cocoa.h>

@interface OSKPanel : NSObject
+ (instancetype)shared;
+ (void)installScriptHotKeys;   // Ctrl+Option+1...8 as system hot keys, only while Sulekhak is the selected keyboard
+ (void)syncScriptHotKeys;
+ (void)installHotKey;          // Ctrl+Option+K from anywhere, even when no text box is active
+ (BOOL)hotKeyActive;
- (void)toggle;
- (void)zoomBy:(double)d;             // +0.1 / -0.1: the keyboard bigger / smaller
- (void)setSuggestions:(NSArray<NSString *> *)items next:(BOOL)next selected:(NSInteger)sel;   // the suggested-word strip on the keyboard
- (void)refreshScript;                 // tell the keyboard which script is selected, so the key legends follow it
- (BOOL)isVisible;
@end
