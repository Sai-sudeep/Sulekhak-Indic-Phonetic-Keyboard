/* JS twin of engine.c (same rules, same tables). Generated tables are injected at __TABLES__. */
var OdiaEngine=(function(){
var T=__TABLES__;
var HAL='୍', ZWNJ='‌', ZWJ='\u200D', ZWJ_Y='\u200D\u0B5F', MAXC=64, PAGE=9;
var gBadNuk=0;
var SUFFIX=T.SUFFIX;
var T_K=0,T_V=1,T_RAW=2,T_DIGIT=3,T_OTHER=4,T_SEP=5;
var CONS=T.CONS, VOW=T.VOW, RAW=T.RAW;
function lower(s){return s.replace(/[A-Z]/g,function(c){return c.toLowerCase()})}
function isVowelCh(c){c=(c||'').toLowerCase();return c==='a'||c==='e'||c==='i'||c==='o'||c==='u'}
var gNdg=0;
function nasalClass(r){
  var L=[['k','kh','g','gh','ck','q','ksh','x'],['c','ch','chh','cch','cchh','j','jh'],['T','Th','D','Dh','ṭ','ṭh','ḍ','ḍh','ṇ','N'],['t','th','d','dh'],['p','ph','b','bh','f','m']];
  for(var c=0;c<5;c++) if(L[c].indexOf(r)>=0) return c+1;
  return 0;
}
function setAlts(k,alts){k.n=alts.length;k.a=alts.slice();k.cost=alts.map(function(x,i){return i===0?0:(x==='ଂ'?4:1)}).concat([0,0,0,0,0,0]).slice(0,6)}
function isAnu(x){return x==='ଂ'||x==='ଁ'}
function annotate(t){
  var nt=t.length;
  for(var i=0;i<nt;i++){
    var k=t[i];
    if(k.kind===T_K&&(k.r==='n'||k.r==='m')&&i+1<nt&&t[i+1].kind===T_K&&(i>0||(k.r==='n'&&nasalClass(t[i+1].r)>=1))){
      var cl=nasalClass(t[i+1].r);
      if(k.r==='n'){
        if(cl===1) setAlts(k,['ଙ','ନ','ଣ','ଂ']); else if(cl===2) setAlts(k,['ଞ','ନ','ଣ','ଂ']); else if(cl===3) setAlts(k,['ଣ','ନ','ଂ']);
        else if(cl===5) setAlts(k,['ନ','ମ','ଂ']); else setAlts(k,['ନ','ଣ','ଂ']);
        if(i===0){ k.n--; k.a.pop() }
        else if(t[i-1].kind===T_V){ k.a[k.n-1]='ଁ'; k.cost[k.n-1]=5; k.a[k.n]='ଂ'; k.cost[k.n]=4; k.n++ }
      } else if(cl>=1&&cl<=4) setAlts(k,['ଂ']); else setAlts(k,['ମ','ଂ']);
    }
    if(k.kind===T_K&&(k.r==='n'||k.r==='m')&&i+1<nt&&t[i+1].kind===T_K&&nasalClass(t[i+1].r)===0&&(i>0||k.r==='n')&&'sSyYrlLvwh'.indexOf(t[i+1].r.charAt(0))>=0){   /* before s sh h y r l v w the anusvara is the usual spelling */
      for(var qq=0;qq<k.n;qq++) if(k.a[qq]==='ଂ') k.cost[qq]=0;
    }
    if(k.kind===T_K&&i===nt-1&&i>0&&t[i-1].kind===T_V&&(k.r==='n'||k.r==='ng'||k.r==='m')&&k.n<=2){
      k.a=k.a.concat(['ଁ','ଂ']); k.cost[k.n]=3; k.cost[k.n+1]=3; k.n+=2;
    }
    if(k.kind===T_K&&k.r==='v'&&k.n===3){   /* v: ବ ଵ ଭ ୱ ; right after a consonant ୱ comes first (ସ୍ୱ ତ୍ୱ ଦ୍ୱ) */
      k.a=(i>0&&t[i-1].kind===T_K)?['ୱ','ବ','ଵ','ଭ']:['ବ','ଵ','ଭ','ୱ']; k.n=4; k.cost=[0,1,1,1,0,0];
    }
    if(k.kind===T_K&&k.n>=2&&(k.r==='t'||k.r==='th'||k.r==='d'||k.r==='dh')) k.cost[1]=3;
    if(k.kind===T_K&&k.r==='y'&&k.n===2){
      if(i>0){k.a=['ୟ','ଯ'];k.cost[1]=3} else k.cost[1]=3;
    }
    if(k.kind===T_K&&k.r==='j'&&k.n===2) k.cost[1]=2;
    if(k.kind===T_K&&(k.r==='y'||k.r==='Y')&&i>0&&t[i-1].kind===T_K&&t[i-1].r==='r'&&k.n<5){ k.a[k.n]=ZWJ_Y; k.cost[k.n]=2; k.n++ }
    if(k.kind===T_K&&k.r==='ny'&&k.n===2) k.cost[1]=2;
    if(k.kind===T_K&&k.r==='gy'&&k.n===2) k.cost[1]=2;
    if(k.kind===T_V&&k.n>=2&&k.a[0]==='ଅ'&&i+1<nt&&t[i+1].kind===T_V){k.cost[0]=1;k.cost[1]=0}
  }
}
function parse(s,mask){
  var t=[],i=0; gNdg=0; mask=mask||0;
  while(i<s.length && t.length<127){
    var k={kind:0,n:0,keep:0,a:[],s:[],cost:[0,0,0,0,0,0],lit:'',r:''};
    var ch=s[i];
    if(ch==="'"&&s[i+1]==="'"){var q3=(s[i+2]==="'");k.kind=T_RAW;k.n=1;k.a=[q3?'୰':'ଽ'];k.keep=0;t.push(k);i+=q3?3:2;continue}
    if(ch==="'"){k.kind=T_SEP;t.push(k);i++;continue}
    if(ch>='0'&&ch<='9'){k.kind=T_DIGIT;k.lit=ch;t.push(k);i++;continue}
    if(s.startsWith('ngh',i)){k.kind=T_K;k.n=1;k.a=['ଙ୍ଘ'];t.push(k);i+=3;continue}
    if(s.startsWith('ng',i)){
      k.kind=T_K;k.n=2;k.r='ng';
      if(isVowelCh(s[i+2])) k.a=['ଙ୍ଗ','ଙ']; else k.a=['ଙ','ଙ୍ଗ'];
      k.cost[1]=1;
      t.push(k);i+=2;continue}
    var best=0,bk=-1,bp=null,j,e;
    for(j=0;j<CONS.length;j++){e=CONS[j];if(e[0].length>best&&s.startsWith(e[0],i)){best=e[0].length;bk=T_K;bp=e}}
    for(j=0;j<VOW.length;j++){e=VOW[j];if(e[0].length>best&&s.startsWith(e[0],i)){best=e[0].length;bk=T_V;bp=e}}
    for(j=0;j<RAW.length;j++){e=RAW[j];if(e[0].length>best&&s.startsWith(e[0],i)){best=e[0].length;bk=T_RAW;bp=e}}
    if(!best && ch>='A'&&ch<='Z'){
      var low=ch.toLowerCase();
      for(j=0;j<CONS.length;j++) if(CONS[j][0]===low){best=1;bk=T_K;bp=CONS[j]}
      if(!best) for(j=0;j<VOW.length;j++) if(VOW[j][0]===low){best=1;bk=T_V;bp=VOW[j]}
    }
    if(bk===T_V&&(bp[0]==='ai'||bp[0]==='au'||bp[0]==='ou')){
      var di=gNdg++;
      if((mask>>di)&1){var one=bp[0][0]==='a'?'a':'o';for(j=0;j<VOW.length;j++) if(VOW[j][0]===one){bp=VOW[j];best=1;break}}
    }
    if(!best){
      var cp=s.codePointAt(i), l=cp>0xFFFF?2:1;
      k.kind=T_OTHER;k.lit=s.substr(i,l);t.push(k);i+=l;continue}
    if(bk===T_K){k.kind=T_K;k.r=bp[0].slice(0,5);k.a=bp[1].slice(0,3);k.n=k.a.length;k.cost[1]=k.cost[2]=1}
    else if(bk===T_V){k.kind=T_V;k.a=bp[1].slice(0,3);k.s=bp[2].slice(0,3);k.n=k.a.length;k.cost[1]=k.cost[2]=1}
    else{k.kind=T_RAW;k.n=1;k.a=[bp[1]];k.keep=bp[2]}
    t.push(k);i+=best;
  }
  annotate(t);
  return t;
}
var S_NONE=0,S_CONS=1,S_AFTERV=2,S_RAW=3;
function render(t,ch){
  var st=S_NONE,out='',consEnd=-1,nukAt=-1; gBadNuk=0;
  for(var i=0;i<t.length;i++){
    var k=t[i],c=ch?ch[i]:0; if(!c||c>=k.n) c=(c>=k.n)?0:c;
    switch(k.kind){
      case T_K: if(isAnu(k.a[c])){out+=k.a[c];st=S_AFTERV;break}
        var x=k.a[c];
        if(x.charAt(0)===ZWJ){ if(st===S_CONS) out+=ZWJ+HAL; x=x.slice(1) }
        else if(st===S_CONS) out+=HAL;
        if(st!==S_CONS) nukAt=-1;
        out+=x; st=S_CONS; consEnd=out.length;
        if(x.length===1&&(x.charCodeAt(0)===0x0B21||x.charCodeAt(0)===0x0B22)) nukAt=out.length;
        break;
      case T_V:
        if(st===S_CONS){ out+=(k.s[c]!==undefined?k.s[c]:''); st=S_AFTERV; }
        else{ out+=k.a[c]; st=S_AFTERV; }
        break;
      case T_RAW:
        if(k.keep===1){
          var tg=nukAt>=0?nukAt:consEnd;
          if(tg>=0){
            var bc=tg>=1?out.charCodeAt(tg-1):0; if(!(bc===0x0B21||bc===0x0B22)) gBadNuk=1;
            out=out.slice(0,tg)+k.a[0]+out.slice(tg); consEnd+=k.a[0].length; if(nukAt>=0) nukAt+=k.a[0].length;
          } else { out+=k.a[0]; gBadNuk=1 }
        } else out+=k.a[0];
        if(k.keep===1){} else if(k.keep===2) st=S_AFTERV; else st=S_RAW;
        break;
      case T_DIGIT: out+=String.fromCharCode(0x0B66+(k.lit.charCodeAt(0)-48)); st=S_NONE; break;
      case T_OTHER: out+=k.lit; st=S_NONE; break;
    }
  }
  return out;
}
function transliterate(r){return render(parse(r,0),null)}

/* is this string a possible Odia spelling? (drops impossible candidates and learned picks) */
function vStop(cp){
  if(cp>=0x0B15&&cp<=0x0B18) return 1; if(cp>=0x0B1A&&cp<=0x0B1D) return 2;
  if((cp>=0x0B1F&&cp<=0x0B22)||cp===0x0B5C||cp===0x0B5D) return 3;
  if(cp>=0x0B24&&cp<=0x0B27) return 4; if(cp>=0x0B2A&&cp<=0x0B2D) return 5; return 0;
}
function vNasal(cp){switch(cp){case 0x0B19:return 1;case 0x0B1E:return 2;case 0x0B23:return 3;case 0x0B28:return 4;case 0x0B2E:return 5}return 0}
function vCons(cp){return (cp>=0x0B15&&cp<=0x0B39)||cp===0x0B5C||cp===0x0B5D||cp===0x0B5F||cp===0x0B71}
function vSign(cp){return (cp>=0x0B3E&&cp<=0x0B44)||cp===0x0B47||cp===0x0B48||cp===0x0B4B||cp===0x0B4C||cp===0x0B56||cp===0x0B57||cp===0x0B62||cp===0x0B63}
function validWord(w){
  var cp=[],i; for(i=0;i<w.length&&cp.length<255;i++) cp.push(w.charCodeAt(i));
  var n=cp.length; if(n===0) return true;
  for(i=0;i<n;i++){
    var c=cp[i], p=i?cp[i-1]:0, x=i+1<n?cp[i+1]:0;
    if(vSign(c)){ if(!(vCons(p)||p===0x0B3C)) return false }
    else if(c===0x0B4D){ if(!(vCons(p)||p===0x0B3C||p===0x200D)) return false; if(x===0x0B4D||vSign(x)) return false }
    else if(c===0x0B3C){ if(!(p===0x0B21||p===0x0B22)) return false }
    else if(c===0x0B01||c===0x0B02||c===0x0B03){ if(i===0||vSign(x)) return false }
    else if(c===0x200C){ if(p!==0x0B4D) return false }
    else if(c===0x200D){ if(!(p===0x0B30&&x===0x0B4D&&i+2<n&&(cp[i+2]===0x0B5F||cp[i+2]===0x0B2F))) return false }
    if(vCons(c)&&x===0x0B4D&&i+2<n){
      var nx=cp[i+2], fc=vStop(nx), nl=vNasal(c);
      if(nl&&fc){ if(nl!==fc&&!(nl===4&&fc===5)) return false }
      if(c===0x0B37&&(fc===4||fc===2)) return false;
      if(c===0x0B38&&fc===2) return false;
      if(c===0x0B36&&(fc===3||fc===4)) return false;
    }
  }
  return true;
}
function validOdia(s){ return s.split(' ').every(function(p){return p===''||validWord(p)}) }

/* dictionary */
var lex=[], known=new Set();
function lexClear(){lex=[];known=new Set()}
function lexAdd(r,o,w){
  if(!r||!o) return;
  if(!validOdia(o)) return;
  known.add(o);
  var lr=lower(r);
  for(var i=0;i<lex.length;i++) if(lower(lex[i].r)===lr&&lex[i].o===o){lex[i].w+=w;return}
  lex.push({r:r,o:o,w:w});
}
function loadBuiltin(){T.BUILTIN.forEach(function(b){lexAdd(b[0],b[1],b[2])});T.WORDS.forEach(function(w){if(validOdia(w)) known.add(w)})}

/* candidates */
var gLimit=MAXC, gFilter=true;
function has(c,x){return c.indexOf(x)>=0}
function put(c,x){if(c.length<gLimit&&x&&!has(c,x)) c.push(x)}
function lexExact(roman,c,rounds){
  var lr=lower(roman);
  for(var round=0;round<rounds&&c.length<gLimit;round++){
    var pi=-1,pw=-1;
    for(var i=0;i<lex.length;i++) if(lower(lex[i].r)===lr&&!has(c,lex[i].o)&&lex[i].w>pw){pw=lex[i].w;pi=i}
    if(pi<0)break; put(c,lex[pi].o);
  }
}
function lexPrefix(roman,c,rounds){
  var lr=lower(roman);
  for(var round=0;round<rounds&&c.length<gLimit;round++){
    var pi=-1,pw=-1;
    for(var i=0;i<lex.length;i++){
      var r=lower(lex[i].r);
      if(r.length>lr.length&&r.startsWith(lr)&&!has(c,lex[i].o)&&lex[i].w>pw){pw=lex[i].w;pi=i}
    }
    if(pi<0)break; put(c,lex[pi].o);
  }
}
function stopClass(cp){
  if(cp>=0x0B15&&cp<=0x0B18) return 1; if(cp>=0x0B1A&&cp<=0x0B1D) return 2;
  if((cp>=0x0B1F&&cp<=0x0B22)||cp===0x0B5C||cp===0x0B5D) return 3;
  if(cp>=0x0B24&&cp<=0x0B27) return 4; if(cp>=0x0B2A&&cp<=0x0B2D) return 5; return 0;
}
function nasalLetterClass(s){
  if(s.length!==1) return 0; var cp=s.charCodeAt(0);
  switch(cp){case 0x0B19:return 1;case 0x0B1E:return 2;case 0x0B23:return 3;case 0x0B28:return 4;case 0x0B2E:return 5}
  return 0;
}
function varCost(u,ch){
  var c=0,nu=u.length;
  for(var i=0;i<nu;i++){
    var k=u[i]; if(k.kind!==T_K&&k.kind!==T_V) continue;
    var cc=k.n>1?k.cost[ch[i]]:0;
    if(k.kind===T_K&&i===0&&ch[i]>0&&k.n>1){
      var f=k.a[ch[i]].codePointAt(0);
      if(f===0x0B33) return -1;
      if(f===0x0B23||f===0x0B19||f===0x0B1E){
        var nc=nasalLetterClass(k.a[ch[i]]), fc0=(i+1<nu&&u[i+1].kind===T_K)?stopClass(u[i+1].a[ch[i+1]].codePointAt(0)):0;
        if(!(nc&&nc===fc0)) return -1;
      }
    }
    if(k.kind===T_K&&k.a[ch[i]].charAt(0)===ZWJ){
      if(!(i>0&&u[i-1].kind===T_K&&u[i-1].a[ch[i-1]]==='ର')) return -1;
    }
    if(k.kind===T_K&&i+1<nu&&u[i+1].kind===T_K){
      var L=k.a[ch[i]], nx=u[i+1], fc=stopClass(nx.a[ch[i+1]].codePointAt(0));
      var nl=nasalLetterClass(L);
      if(nl&&fc){ if(nl===fc) cc=0; else if(nl===4&&fc===5) cc=2; else return -1; }
      else if(L.length===1&&fc){
        var cp=L.charCodeAt(0);
        if(cp===0x0B37&&(fc===4||fc===2)) return -1;
        else if(cp===0x0B38&&fc===2) return -1;
        else if(cp===0x0B38&&fc===3) cc+=3;
        else if(cp===0x0B36&&(fc===3||fc===4)) return -1;
      }
    }
    c+=cc;
  }
  return c;
}
function enumOne(roman,offset,variant,vars,cap){
  var t=parse(roman,0), ndg=gNdg; if(ndg>2) ndg=2;
  var nmask=1<<ndg;
  for(var mask=0;mask<nmask;mask++){
    var u=parse(roman,mask), nu=u.length, amb=[], i;
    for(i=0;i<nu&&amb.length<10;i++) if((u[i].kind===T_K||u[i].kind===T_V)&&u[i].n>1) amb.push(i);
    var total=1; for(var j=0;j<amb.length;j++){total*=u[amb[j]].n; if(total>cap){total=cap;break}}
    for(var code=0;code<total;code++){
      var ch=new Array(nu).fill(0), x=code;
      for(j=amb.length-1;j>=0;j--){var m=u[amb[j]].n; ch[amb[j]]=x%m; x=Math.floor(x/m)}
      var cost=varCost(u,ch); if(cost<0) continue;
      for(var b=0;b<ndg;b++) if(!((mask>>b)&1)) cost+=1;
      cost+=offset;
      var s=render(u,ch), kn=known.has(s); cost+=8*gBadNuk;
      vars.push({s:s,cost:cost,known:kn,score:cost-(kn?20:0),idx:variant*1000000+mask*65536+code});
    }
  }
}
function respell(roman,flags){
  var o='',p=0;
  while(p<roman.length){
    if((flags&2)&&roman.startsWith('ryy',p)){o+='rjy';p+=3}
    else if((flags&2)&&roman.startsWith('ry',p)){o+='rjy';p+=2}
    else if((flags&1)&&roman.startsWith('ri',p)){o+='rri';p+=2}
    else o+=roman[p++];
  }
  return o;
}
function enumVars(roman,cap){
  var vars=[];
  var a0=roman.indexOf('ri')>=0&&roman.indexOf('rri')<0, a1=roman.indexOf('ry')>=0;
  enumOne(roman,0,0,vars,cap);
  if(a0) enumOne(respell(roman,1),2,1,vars,cap);
  if(a1) enumOne(respell(roman,2),1,2,vars,cap);
  if(a0&&a1) enumOne(respell(roman,3),3,3,vars,cap);
  vars.sort(function(a,b){return a.score-b.score||a.idx-b.idx});
  return vars;
}
function pieceBest(piece){
  var lp=lower(piece), bw=-1, bi=-1;
  for(var i=0;i<lex.length;i++) if(lower(lex[i].r)===lp&&lex[i].w>bw){bw=lex[i].w;bi=i}
  if(bi>=0) return {o:lex[bi].o,c:0};
  var v=enumVars(piece,200);
  for(i=0;i<v.length;i++) if(v[i].known&&v[i].s.length>=3) return {o:v[i].s,c:v[i].cost};
  return null;
}
function segment(roman){
  var L=roman.length; if(L<6||L>24) return null;
  if(!/^[A-Za-z]+$/.test(roman)) return null;
  var nseg=[],cst=[],prev=[],str=[],i,j;
  for(i=0;i<=L;i++){nseg[i]=1000;cst[i]=0;prev[i]=-1;str[i]=''}
  nseg[0]=0;
  for(i=0;i<L;i++){ if(nseg[i]>=1000) continue;
    for(j=i+3;j<=L&&j-i<=14;j++){
      var pb=pieceBest(roman.slice(i,j)); if(!pb) continue;
      var ns=nseg[i]+1, cs=cst[i]+pb.c;
      if(ns<nseg[j]||(ns===nseg[j]&&cs<cst[j])){nseg[j]=ns;cst[j]=cs;prev[j]=i;str[j]=pb.o}
    } }
  if(nseg[L]>=1000||nseg[L]<2) return null;
  var pos=[]; for(j=L;j>0;j=prev[j]) pos.push(j);
  var concat='',spaced='';
  for(var k=pos.length-1;k>=0;k--){ concat+=str[pos[k]]; if(k<pos.length-1) spaced+=' '; spaced+=str[pos[k]] }
  if(concat.length+2>=255) return null;
  return {concat:concat,spaced:spaced};
}
function consCp(cp){return (cp>=0x0B15&&cp<=0x0B39)||cp===0x0B5C||cp===0x0B5D||cp===0x0B5F||cp===0x0B71}
function naturalPair(pc,sc){
  var fc=stopClass(sc); if(!fc) return false;
  if(pc===0x0B30) return true;
  var nl=nasalLetterClass(String.fromCharCode(pc)); if(nl) return nl===fc;
  if(pc===0x0B37) return !(fc===4||fc===2);
  if(pc===0x0B38) return fc!==2;
  if(pc===0x0B36) return !(fc===3||fc===4);
  return false;
}
function suffixZw(w){
  var bs=null,bl=0;
  for(var i=0;i<SUFFIX.length;i++){var l=SUFFIX[i].length;if(l>bl&&l<w.length&&w.slice(w.length-l)===SUFFIX[i]){bs=SUFFIX[i];bl=l}}
  if(!bs) return null;
  var stem=w.slice(0,w.length-bl); if(stem.length<2) return null;
  var cp=stem.charCodeAt(stem.length-1), out, joined, nat=false;
  if(consCp(cp)){out=stem+HAL+ZWNJ;joined=false}
  else if(cp===0x0B4D){ var pc=stem.charCodeAt(stem.length-2); if(!consCp(pc)) return null; out=stem+ZWNJ; joined=true; nat=naturalPair(pc,bs.charCodeAt(0)) }
  else return null;
  return {w:out+bs,joined:joined,suffix:bs,natural:nat};
}

/* ---- extra rules: diphthong spellings, lone-letter extras, vowel-less typing, cluster variants ---- */
var DIPH={ai:['ଆଇ','ଆଈ','ଅଇ'],au:['ଆଉ','ଆଊ','ଅଉ'],ou:['ଓଉ','ଓଊ','ଅଉ']};
var SINGLE_EXTRA={d:['ଡ଼'],dh:['ଢ଼'],sh:['ସ'],ny:['ଣ୍ୟ','ଞ୍ୟ']};
var FIRST_EXTRA={nian:'ଞ',uan:'ଙ'};
function repl1(s,a,b){var i=s.indexOf(a);return i<0?null:s.slice(0,i)+b+s.slice(i+a.length)}
function altList(rom,limit,pred){
  var sg=gLimit,sf=gFilter; gLimit=14; var l=gen(rom); gLimit=sg; gFilter=sf;
  var out=[]; for(var i=0;i<l.length&&out.length<limit;i++){ var x=l[i]; if(x!==rom&&/[^\x00-\x7f]/.test(x)&&validOdia(x)&&(!pred||pred(x))) out.push(x) }
  return out;
}
function skeleton(roman){          /* ktk -> କଟକ କତକ : every consonant gets its inherent a */
  if(!/^[A-Za-z]{2,10}$/.test(roman)||/[aeiouzAEIOUZ]/.test(roman)) return [];
  var toks=[],p=0,j;
  while(p<roman.length){
    var best=0,alts=null;
    if(roman.startsWith('ng',p)){best=2;alts=['ଙ']}
    else for(j=0;j<CONS.length;j++){ var e=CONS[j]; if(e[0].length>best&&roman.startsWith(e[0],p)){best=e[0].length;alts=e[1].filter(function(x){return x.indexOf(HAL)<0||e[0]!=='ny'}).slice()} }
    if(!best||!alts.length) return [];
    if(/^(t|th|d|dh)$/.test(roman.substr(p,best))&&alts.length===2) alts=[alts[1],alts[0]];
    toks.push(alts); p+=best;
  }
  if(toks.length<2||toks.length>8) return [];
  var out=[''];
  toks.forEach(function(al){ var nx=[]; out.forEach(function(o){ al.forEach(function(a){ if(nx.length<24) nx.push(o+a) }) }); out=nx });
  out=out.filter(function(x){return validOdia(x)});
  var kn=out.filter(function(x){return known.has(x)}), rest=out.filter(function(x){return !known.has(x)});
  return {list:kn.concat(rest).slice(0,16),ntok:toks.length};
}
var gNsch=0;
function extras(roman,f){
  var ex=[]; gNsch=0;
  function push(x,force){ if(x&&x!==roman&&f.indexOf(x)<0&&ex.indexOf(x)<0&&(force||validOdia(x))) ex.push(x) }
  var short=function(x){return x.length<=2*roman.length};
  /* a word that ends in two consonants may have lost its schwa: karn -> karan -> କାରଣ କରନ କରଣ */
  if(roman.length>=3&&/^[A-Za-z]+$/.test(roman)&&/[aeiouAEIOU]/.test(roman.slice(0,-2))){
    var c1=roman.charAt(roman.length-2).toLowerCase(), c2=roman.charAt(roman.length-1).toLowerCase();
    if(!/[aeiou]/.test(c1)&&!/[aeiou]/.test(c2)&&c1!==c2&&c1!=='h'&&!/[hywv]/.test(c2)){
      altList(roman.slice(0,-1)+'a'+roman.slice(-1),4,function(x){return !/[ଁଂଃ]/.test(x)&&x.indexOf(HAL+ZWNJ)<0&&x.slice(-1)!==HAL}).forEach(function(x){push(x)});
      gNsch=ex.length;
    }
  }
  if(/^v[yr]/.test(roman)) ['b','w'].forEach(function(ch){ altList(ch+roman.slice(1),2,short).forEach(function(x){push(x)}) });
  var rv=roman.replace(/([bcdfghjklmnpqrstxyzBCDFGHJKLMNPQRSTXYZ])v(?=[aeiouy])/g,'$1w');
  if(rv!==roman) altList(rv,6,function(x){return x.indexOf('ଵ')<0&&short(x)}).forEach(function(x){push(x)});
  if(roman.length>2&&roman.indexOf('sh')>=0) altList(roman.replace(/sh/g,'s'),4,function(x){return x.indexOf('ସ')>=0&&x.indexOf('ଶ')<0&&x.indexOf('ଷ')<0}).forEach(function(x){push(x)});
  var rr=roman.replace(/([bcdfghjklmnpqstvwxyzBCDFGHJKLMNPQSTVWXYZ])ru/g,'$1rri');
  if(rr!==roman) altList(rr,3,function(x){return x.indexOf('ୃ')>=0}).forEach(function(x){push(x)});
  f.concat(ex).forEach(function(x){
    if(x===roman) return;
    if(roman.indexOf('ny')>=0&&x.indexOf('ନ୍ୟ')>=0){ push(repl1(x,'ନ୍ୟ','ଣ୍ୟ'),1); push(repl1(x,'ନ୍ୟ','ଞ୍ୟ'),1) }
    if(roman.indexOf('nr')>=0&&x.indexOf('ନ୍ର')>=0) push(repl1(x,'ନ୍ର','ଣ୍ର'),1);
    if(/[wv]y/.test(roman)&&x.indexOf('ୱ୍ୟ')>=0) push(repl1(x,'ୱ୍ୟ','ୱ'+ZWJ+'୍ୟ'),1);
  });
  return ex;
}
function gen(roman){
  var c=[]; if(!roman) return c;
  gFilter=true;
  if(roman==='.'){gFilter=false;put(c,'।');put(c,'.');put(c,'॥');return c}
  if(roman.toLowerCase()==='ru'){gFilter=false;put(c,'ରୁ');put(c,roman);put(c,'ରୂ');put(c,'ଋ');put(c,'ୠ');return c}
  if(roman==='`'){gFilter=false;put(c,HAL);put(c,'`');put(c,HAL+ZWNJ);return c}
  if(roman==='z'){gFilter=false;put(c,ZWNJ);put(c,'z');return c}
  if(roman==='Z'){gFilter=false;put(c,HAL+ZWNJ);put(c,'Z');put(c,HAL);put(c,ZWNJ);return c}
  var alldig=/^[0-9]+$/.test(roman);
  var prim=transliterate(roman);
  if(alldig){gFilter=false;put(c,prim);put(c,roman);return c}
  var t=parse(roman,0),nt=t.length,pure=true,i;
  for(i=0;i<nt;i++) if(t[i].kind===T_SEP) pure=false;
  var bi=-1,bw=-1,lr=lower(roman);
  for(i=0;i<lex.length;i++) if(lower(lex[i].r)===lr&&lex[i].w>bw){bw=lex[i].w;bi=i}
  if(pure&&nt===1&&t[0].kind===T_K){
    gFilter=false;
    put(c,bi>=0?lex[bi].o:prim); put(c,roman);
    put(c,prim);
    var sx=SINGLE_EXTRA[roman]; if(sx){ for(var q0=1;q0<t[0].n;q0++) put(c,t[0].a[q0]); for(var xq=0;xq<sx.length;xq++) put(c,sx[xq]) }
    for(var j=0;j<t[0].n;j++){
      put(c,t[0].a[j]+HAL); put(c,t[0].a[j]+HAL+ZWNJ);
      if(j===0) for(var q=1;q<t[0].n;q++) put(c,t[0].a[q]);
    }
    return c;
  }
  if(pure&&nt===1&&t[0].kind===T_V){
    gFilter=false;
    put(c,bi>=0?lex[bi].o:prim); put(c,roman);
    put(c,prim);
    var dp=DIPH[roman]; if(dp) for(j=0;j<dp.length;j++) put(c,dp[j]);
    for(j=0;j<t[0].n;j++) put(c,t[0].a[j]);
    for(j=0;j<t[0].n;j++) if(t[0].s[j]) put(c,t[0].s[j]);
    return c;
  }
  var V=enumVars(roman,4000), best, seg=null, z;
  if(bi>=0) best=lex[bi].o;
  else if(V.length>0&&V[0].known) best=V[0].s;
  else if((seg=segment(roman))) best=seg.concat;
  else{
    best=V.length>0?V[0].s:prim;
    z=suffixZw(best);
    if(z&&z.joined&&!z.natural&&z.suffix!=='ର') best=z.w;
  }
  put(c,best);
  put(c,roman);
  if(seg) put(c,seg.spaced);
  put(c,prim);
  lexExact(roman,c,3);
  var late='';
  z=suffixZw(best); if(z){ if(z.suffix==='ର') late=z.w; else put(c,z.w) }
  if(best!==prim){ z=suffixZw(prim); if(z){ if(z.suffix==='ର'){ if(!late) late=z.w } else put(c,z.w) } }
  if(nt>=2&&t[nt-1].kind===T_K&&t[nt-2].kind===T_V&&(t[nt-1].r==='n'||t[nt-1].r==='ng'||t[nt-1].r==='m')){
    var nas=['ଁ','ଂ'];
    for(var q2=0;q2<2;q2++){
      var u=t.slice(); u[nt-1]={kind:T_RAW,n:1,keep:2,a:[nas[q2]],s:[],cost:[0],lit:'',r:''};
      put(c,render(u,null));
    }
  }
  lexPrefix(roman,c,3);
  for(i=0;i<V.length&&c.length<gLimit;i++){ if(i===3&&late) put(c,late); put(c,V[i].s) }
  if(late) put(c,late);
  if(c.length<gLimit&&nt>=2&&t[nt-1].kind===T_K) put(c,prim+HAL);
  return c;
}

var LETTER_ODIA=["\u0b0f", "\u0b2c\u0b3f", "\u0b38\u0b3f", "\u0b21\u0b3f", "\u0b07", "\u0b0f\u0b2b\u0b4d\u200c", "\u0b1c\u0b3f", "\u0b0f\u0b1a\u0b4d\u200c", "\u0b06\u0b07", "\u0b1c\u0b47", "\u0b15\u0b47", "\u0b0f\u0b32\u0b4d\u200c", "\u0b0f\u0b2e\u0b4d\u200c", "\u0b0f\u0b28\u0b4d\u200c", "\u0b13", "\u0b2a\u0b3f", "\u0b15\u0b4d\u0b5f\u0b41", "\u0b06\u0b30\u0b4d\u200c", "\u0b0f\u0b38\u0b4d\u200c", "\u0b1f\u0b3f", "\u0b5f\u0b41", "\u0b2d\u0b3f", "\u0b21\u0b2c\u0b4d\u0b32\u0b4d\u0b5f\u0b41", "\u0b0f\u0b15\u0b4d\u0b38", "\u0b71\u0b3e\u0b07", "\u0b1c\u0b47\u0b21\u0b4d\u200c"];
function acronym(roman){
  if(!/^[A-Za-z]{2,8}$/.test(roman)) return [];
  var up=roman.toUpperCase(), a='', b='', c='', d='', e='', f='', i, o;
  for(i=0;i<up.length;i++){ o=LETTER_ODIA[up.charCodeAt(i)-65]; a+=up[i]; b+=up[i]+'.'; c+=o+'.'; d+=(i?'.':'')+o; e+=o; f+=up[i].toLowerCase()+'.' }
  var r=[a,b,c,d,e];
  if(/[a-z]/.test(roman)) r.push(f);
  return r;
}
function aposMatch(roman){
  if(roman.length<1||roman.length>10) return null;
  var c='', na=0, no=0, nv=0, i, ch;
  for(i=0;i<roman.length;i++){ ch=roman.charAt(i).toLowerCase();
    if(ch==="'") continue;
    if(!/[a-z]/.test(ch)) return null;
    if(ch==='a'){ na++; nv++ } else if(ch==='o'){ no++; nv++ } else if('eiu'.indexOf(ch)>=0) return null; else c+=ch;
  }
  if(c==='kn'&&no===0&&na<=3) return ["କ'ଣ"];
  if(c==='t'&&no===0&&na>=1&&na<=2) return ["ତା'"];
  if(c==='tr'&&na<=3&&no<=2) return [no?"ତୋ'ର":"ତା'ର"];
  if(c==='mr'&&na<=2&&(no>0||nv===0)) return ["ମୋ'ର"];
  if(c==='m'&&no===0&&na>=1&&na<=2) return ["ମା'","ମାଆ"];
  return null;
}
/* ---------- consonant-skeleton dictionary (twin of the block in engine.c): pasnd -> ପସନ୍ଦ ---------- */
var skMap=null, gSkNtok=0;
function loadSkel(text){
  skMap=null; if(!text) return;
  var m=new Map(), ls=text.split('\n'), i, p;
  for(i=0;i<ls.length;i++){ p=ls[i].indexOf('\t'); if(p>0) m.set(ls[i].slice(0,p),ls[i].slice(p+1)) }
  skMap=m;
}
function skWords(key){ var l=skMap.get(key); return l===undefined?null:l.split('\t') }
var SK_SYM={0x0B15:'k',0x0B16:'K',0x0B17:'g',0x0B18:'G',0x0B19:'n',0x0B1A:'c',0x0B1B:'c',0x0B1C:'j',0x0B1D:'J',0x0B1E:'n',0x0B1F:'t',0x0B20:'T',0x0B21:'d',0x0B22:'D',0x0B23:'n',0x0B24:'t',0x0B25:'T',0x0B26:'d',0x0B27:'D',0x0B28:'n',0x0B2A:'p',0x0B2B:'P',0x0B2C:'b',0x0B2D:'B',0x0B2E:'m',0x0B2F:'j',0x0B30:'r',0x0B32:'l',0x0B33:'l',0x0B35:'b',0x0B36:'s',0x0B37:'s',0x0B38:'s',0x0B39:'h',0x0B5C:'d',0x0B5D:'D',0x0B5F:'j',0x0B71:'b'};
var SK_RETRO={0x0B1F:1,0x0B20:1,0x0B21:1,0x0B22:1,0x0B23:1,0x0B33:1,0x0B5C:1,0x0B5D:1,0x0B24:2,0x0B25:2,0x0B26:2,0x0B27:2,0x0B28:2,0x0B32:2};
var SK_SIGN={0x0B3E:'a',0x0B3F:'i',0x0B40:'i',0x0B41:'u',0x0B42:'u',0x0B43:'ri',0x0B47:'e',0x0B48:'ai',0x0B4B:'o',0x0B4C:'au'};
var SK_IND={0x0B05:'a',0x0B06:'a',0x0B07:'i',0x0B08:'i',0x0B09:'u',0x0B0A:'u',0x0B0B:'ri',0x0B0F:'e',0x0B10:'ai',0x0B13:'o',0x0B14:'au'};
function skVapp(d,a){ var i=0; while(i<a.length&&d.length<7) d+=a.charAt(i++); return d }
function skCollapse(v){ var o=''; for(var i=0;i<v.length;i++) if(!o||o.charAt(o.length-1)!==v.charAt(i)) o+=v.charAt(i); return o }
function skAlt(cp,alt){
  var out=[], hit=0, n=cp.length;
  for(var i=0;i<n;i++){
    if(alt===1){ if(cp[i]===0x0B5C){ out.push(0x0B30); hit=1 } else out.push(cp[i]) }
    else if(alt===3&&i+2<n&&cp[i]===0x0B1C&&cp[i+1]===0x0B4D&&cp[i+2]===0x0B1E){ out.push(0x0B17,0x0B4D,0x0B2F); i+=2; hit=1 }
    else if(alt===4&&i+2<n&&cp[i]===0x0B15&&cp[i+1]===0x0B4D&&cp[i+2]===0x0B37){ out.push(0x0B16); i+=2; hit=1 }
    else { if(alt===2&&cp[i]===0x0B43) hit=1; out.push(cp[i]) }
  }
  return hit?out:null;
}
function skWord(cp,alt){
  if(alt){ cp=skAlt(cp,alt); if(!cp) return null }
  var w={v0:'',s:[],fin:0}, endc=0, i, c, sy, s, last;
  for(i=0;i<cp.length;i++){
    c=cp[i]; endc=0; sy=SK_SYM[c]; last=w.s.length?w.s[w.s.length-1]:null;
    if(sy){ if(w.s.length<48) w.s.push({sym:sy,v:'',retro:SK_RETRO[c]||0,hal:0,inh:1}); endc=1 }
    else if(c===0x0B4D){ if(last) last.hal=1 }
    else if(c===0x0B3C){ endc=1 }
    else if(c===0x0B43&&alt===2){ if(last&&w.s.length<47){ last.v=''; last.inh=0; last.hal=1; w.s.push({sym:'r',v:'i',retro:0,hal:0,inh:0}) } }
    else if(SK_SIGN[c]){ if(last&&!last.hal){ last.v=skVapp('',SK_SIGN[c]); last.inh=0 } }
    else if(SK_IND[c]){
      if(!last) w.v0=skVapp(w.v0,SK_IND[c]);
      else if(!last.hal){ if(last.inh){ last.v=skVapp('','a'); last.inh=0 } last.v=skVapp(last.v,SK_IND[c]) }
    }
  }
  last=w.s.length?w.s[w.s.length-1]:null;
  w.fin=(last&&endc&&last.inh&&!last.hal)?1:0;
  for(i=0;i<w.s.length;i++){ s=w.s[i];
    if(s.hal) s.v='';
    else if(s.inh) s.v='a';
    else { var same=true; for(var k=1;k<s.v.length;k++) if(s.v.charAt(k)!==s.v.charAt(0)) same=false; if(same&&s.v) s.v=s.v.charAt(0) }
  }
  w.v0=skCollapse(w.v0);
  return w;
}
function skKey(w){ var k=''; for(var i=0;i<w.s.length;i++) k+=w.s[i].sym; return k }
function skVrun(s,i){
  var j=i, raw='', lg=0;
  while(j<s.length&&'aeiouAEIOU'.indexOf(s.charAt(j))>=0){ if(raw.length<15) raw+=s.charAt(j).toLowerCase(); if(s.charAt(j)==='A') lg=1; j++ }
  if(raw.indexOf('aa')>=0) lg=1;
  var v='';
  for(var k=0;k<raw.length;k++){ if(raw.charAt(k)==='o'&&raw.charAt(k+1)==='u'){ v+='au'; k++ } else v+=raw.charAt(k) }
  v=skCollapse(v);
  if(v!=='a') lg=0;
  if(v.length>7) v=v.slice(0,7);
  return {v:v,lg:lg,j:j};
}
function skParse(roman){
  var s=roman.replace(/[^A-Za-z]/g,'').slice(0,62);
  if(!s) return null;
  var t={v0:'',lg0:0,t:[]}, r=skVrun(s,0), i=r.j, lc, up, adv, sy, a0, a1, a2, retro, vr;
  t.v0=r.v; t.lg0=r.lg;
  while(i<s.length){
    var c=s.charAt(i); lc=c.toLowerCase(); up=(c!==lc); adv=1; sy=['',''];
    a0=lc; a1=i+1<s.length?s.charAt(i+1).toLowerCase():''; a2=i+2<s.length?s.charAt(i+2).toLowerCase():'';
    if(a0==='c'&&a1==='h'&&a2==='h'){ sy[0]='c'; adv=3 }
    else if(a1==='h'&&'kgjtdpb'.indexOf(a0)>=0){ sy[0]={k:'K',g:'G',j:'J',t:'T',d:'D',p:'P',b:'B'}[a0]; adv=2 }
    else if(a0==='c'&&a1==='h'){ sy[0]='c'; adv=2 }
    else if(a0==='s'&&a1==='h'){ sy[0]='s'; adv=2 }
    else if(a0==='r'&&a1==='h'){ sy[0]='D'; adv=2 }
    else if(lc==='x'){ sy[0]='k'; sy[1]='s' }
    else if(lc==='r'&&up){ sy[0]='d' }
    else { sy[0]={k:'k',g:'g',c:'c',j:'j',t:'t',d:'d',n:'n',p:'p',b:'b',m:'m',y:'j',r:'r',l:'l',v:'b',w:'b',s:'s',h:'h',f:'P',q:'k',z:'j'}[lc]||'' }
    if(!sy[0]){ i++; continue }
    retro=(up&&'tTdDnl'.indexOf(sy[0])>=0)?1:0;
    vr=skVrun(s,i+adv);
    if(t.t.length+2>=24) break;
    if(sy[1]){ t.t.push({sym:sy[0],v:'',retro:0,lg:0}); t.t.push({sym:sy[1],v:vr.v,retro:0,lg:vr.lg}) }
    else t.t.push({sym:sy[0],v:vr.v,retro:retro,lg:vr.lg});
    i=vr.j;
  }
  return t;
}
function skScore(t,w){
  var sc=0, neg=0, k, tv, wv, x, last;
  if(t.v0===w.v0){ if(t.v0) sc+=3 }
  else if(!t.v0||!w.v0){ sc-=3; neg++ } else { sc-=2; neg++ }
  for(k=0;k<w.s.length;k++){
    tv=t.t[k].v; wv=w.s[k].v; last=(k===w.s.length-1);
    if(!tv) x=0;
    else if(last&&w.fin){ x=(tv==='a')?(t.t[k].lg?-1:3):-2 }
    else if(tv===wv) x=3;
    else if(!wv) x=-2;
    else if(wv.indexOf(tv)>=0||tv.indexOf(wv)>=0) x=1;
    else x=-2;
    if(x<0) neg++;
    if(t.t[k].retro){ if(w.s[k].retro===1) x++; else if(w.s[k].retro===2) x-- }
    sc+=x;
  }
  return {sc:sc,neg:neg};
}
function skCps(s){ var a=[]; for(var i=0;i<s.length;i++) a.push(s.charCodeAt(i)); return a }
function skLookup(roman){
  if(!skMap) return [];
  var t=skParse(roman); if(!t||t.t.length<2) return [];
  gSkNtok=t.t.length;
  var tries=[t], i, k;
  function clone(x){ return {v0:x.v0,lg0:x.lg0,t:x.t.map(function(y){return {sym:y.sym,v:y.v,retro:y.retro,lg:y.lg}})} }
  for(i=1;i<t.t.length-1&&tries.length<8;i++) if(t.t[i].sym==='n'||t.t[i].sym==='m'){
    var u=clone(t); if(!u.t[i-1].v) u.t[i-1].v=u.t[i].v;
    u.t.splice(i,1); tries.push(u);
  }
  var hits=[], seen={}, ord=0;
  for(var q=0;q<tries.length;q++){
    var key=tries[q].t.map(function(y){return y.sym}).join(''), ws=skWords(key); if(!ws) continue;
    for(var rank=0;rank<ws.length;rank++){
      var wd=ws[rank]; if(!wd||wd.length>=256) continue;
      if(seen[wd]||hits.length>=160) continue;
      var cp=skCps(wd), best=0, bneg=0, got=0;
      for(var alt=0;alt<5;alt++){
        var w=skWord(cp,alt); if(!w) continue;
        if(skKey(w)!==key) continue;
        var r=skScore(tries[q],w); if(!got||r.sc>best){ best=r.sc; bneg=r.neg; got=1 }
      }
      if(got){ seen[wd]=1; hits.push({sc:best,neg:bneg,rank:rank,ord:ord++,w:wd}) }
    }
  }
  hits.sort(function(a,b){ return a.sc!==b.sc?b.sc-a.sc:(a.rank!==b.rank?a.rank-b.rank:a.ord-b.ord) });
  return hits;
}
function skHas(word){
  if(!skMap) return false; var cp=skCps(word); if(cp.length<2) return false;
  for(var alt=0;alt<5;alt++){
    var w=skWord(cp,alt); if(!w||w.s.length<2) continue;
    var ws=skWords(skKey(w)); if(ws&&ws.indexOf(word)>=0) return true;
  }
  return false;
}
function skPair(w){
  var cp=skCps(w); if(cp.length<2) return null;
  var a=cp.slice(), b=cp.slice(), hn=0, hp=0, n=cp.length, i, c;
  for(i=0;i<n;i++){ c=cp[i];
    if(c===0x0B5C||c===0x0B5D){ hn=1; b[i]=(c===0x0B5C)?0x0B21:0x0B22 }
    else if((c===0x0B21||c===0x0B22)&&i>0&&cp[i-1]!==0x0B4D&&!(i+1<n&&cp[i+1]===0x0B3C)){ hp=1; a[i]=(c===0x0B21)?0x0B5C:0x0B5D }
  }
  if(!hn&&!hp) return null;
  var S=function(x){return String.fromCharCode.apply(null,x)};
  return hn?[w,S(b)]:[S(a),w];
}
function skMerge(roman,all){
  var hits=skLookup(roman); if(!hits.length) return all;
  var top=hits[0].sc, good0=(hits[0].neg===0), D=[], i, p;
  for(i=0;i<hits.length&&D.length<8;i++){
    if(hits[i].sc<top-4) break;
    var vs=[hits[i].w], yv;
    if(/[yY]/.test(roman)){ yv=hits[i].w.charAt(0)+hits[i].w.slice(1).replace(/\u0B2F/g,'\u0B5F'); if(yv!==hits[i].w) vs=[yv,hits[i].w] }
    for(var v=0;v<vs.length;v++){
      p=skPair(vs[v]);
      if(p){ if(D.length<8&&D.indexOf(p[0])<0) D.push(p[0]); if(D.length<8&&D.indexOf(p[1])<0) D.push(p[1]) }
      else if(D.length<8&&D.indexOf(vs[v])<0) D.push(vs[v]);
    }
  }
  var hasbest=all.length>0&&all[0]!==roman, f0known=hasbest&&(known.has(all[0])||skHas(all[0]));
  var nl=[]; function NADD(x){ if(nl.length<MAXC&&nl.indexOf(x)<0) nl.push(x) }
  if(D.length>0&&(!hasbest||(!f0known&&good0&&gSkNtok>=3&&!/[>~]/.test(roman)))){
    NADD(D[0]); NADD(roman);
    if(D.length>1&&skPair(D[0])) NADD(D[1]);
    for(i=0;i<all.length;i++) NADD(all[i]);
  } else for(i=0;i<all.length;i++) NADD(all[i]);
  var fin=nl.slice(0,7), ins=0, head=nl.slice(0,Math.min(nl.length,7));
  for(i=0;i<D.length&&ins<4;i++) if(fin.indexOf(D[i])<0&&head.indexOf(D[i])<0){ fin.push(D[i]); ins++ }
  for(i=7;i<nl.length&&fin.length<MAXC;i++) if(fin.indexOf(nl[i])<0) fin.push(nl[i]);
  return fin;
}

/* ================= universal post rules (the same two rules live in engine.c as odia_post_word) =================
   1. ZWNJ rule: a halant + ବ or ଵ keeps the two letters apart with a ZWNJ (ସ୍‌ବ, ଉଦ୍‌ବେଗ), except where the pair is a true conjunct: ବ after ର ମ ବ (ସର୍ବ, ଅମ୍ବ, ଅବ୍ବ), ଵ after ର only (ର୍ଵ). Everything else is ZWNJ-spelled (ସ୍‌ବ, ସ୍‌ଵ, ମ୍‌ଵ), and the un-ZWNJ'd spelling is never a candidate.
   2. Nukta rule: a ଡ or ଢ in the middle or at the end of a word is written ଡ଼ / ଢ଼ (nukta first); the plain spelling follows after all of them.
      Word-initial ଡ ଢ and ଡ ଢ after a halant stay plain. The typed text and the user's own earlier pick are never rewritten. */
function zwnjFix(w){            /* strict: ବ joins a halant only after ର ମ ବ; ଵ joins a halant only after ର; every other halant + ବ / ଵ gets a ZWNJ between */
  if(!w||!/\u0B4D[\u0B2C\u0B35]/.test(w)) return w;
  var o='', i, p, c;
  for(i=0;i<w.length;i++){
    o+=w.charAt(i);
    c=w.charCodeAt(i+1);
    if(w.charCodeAt(i)===0x0B4D&&(c===0x0B2C||c===0x0B35)&&i>0){
      p=w.charCodeAt(i-1);
      if(p===0x0B3C&&i>1) p=w.charCodeAt(i-2);                                    /* ଡ଼ + halant */
      if(((p>=0x0B15&&p<=0x0B39)||p===0x0B5C||p===0x0B5D||p===0x0B5F||p===0x0B71)&&!(c===0x0B2C?(p===0x0B30||p===0x0B2E||p===0x0B2C):p===0x0B30)) o+='\u200C';
    }
  }
  return o;
}
/* ---- strict word check (the same rules in engine.c as rule_ok): no candidate that breaks them is ever offered, from any source ----
   1. the impossible-spelling filter (validWord): matras, halants, nukta, ZWNJ / ZWJ, nasal and sibilant conjuncts;
   2. the list of conjuncts that never occur (SR.FORBID: a halant between the two letters, nothing in between; ZWNJ-separated letters are fine);
   3. at most four consonants in one conjunct, and only conjuncts that real words contain (SR.CLUS, from clus.txt).
   Not checked: the text you typed, and words you added to the Sulekhak Dictionary on purpose. */
var SR=__STRICT__;
var SR_RE=null, SR_CL=null, SR_C='[\\u0B15-\\u0B39\\u0B5C\\u0B5D\\u0B5F\\u0B71]', SR_RUN=null;
function ruleOK(w,zmode){        /* zmode: the typed word had z / Z, so the ZWNJ / ZWJ spellings the engine builds for it are not judged by the spelling filter */
  var i, m, c;
  if(!w||!/[\u0B00-\u0B7F]/.test(w)) return true;
  if(!/[\u0B15-\u0B39\u0B5C\u0B5D\u0B5F\u0B71]/.test(w)) return true;       /* a lone sign, halant or vowel typed on its own is a key, not a word */
  if(typeof userSet!=='undefined'&&userSet.has(w)) return true;
  if(!SR_RE){ SR_RE=new RegExp(SR.FORBID.join('|')); SR_CL=new Set(SR.CLUS); SR_RUN=new RegExp(SR_C+'(?:\\u0B4D'+SR_C+')+','g') }
  if(!zmode&&!validOdia(w)) return false;
  if(w.indexOf('\u0B4D')<0) return true;
  if(SR_RE.test(w)) return false;
  m=w.match(SR_RUN);
  if(m) for(i=0;i<m.length;i++){ c=m[i]; if(c.split('\u0B4D').length>4||!SR_CL.has(c)) return false }
  return true;
}
function pinRoman(list,roman){   /* the typed text stays choice 2: if the first choice was dropped, the next one takes its place */
  if(roman&&list.length>1&&list[0]===roman){ var t=list[0]; list[0]=list[1]; list[1]=t }
  return list;
}
function strictList(list, scr, roman){   /* the last stage for every list: the ZWNJ rule and the strict word check on each spelling; a spelling the rule turns into one already in the list is dropped too */
  if(scr>0) return list;
  var out=[], seen={}, zm=/[zZ]/.test(roman||''), i, w;
  for(i=0;i<list.length;i++){
    w=list[i];
    if(w&&/[\u0B00-\u0B7F]/.test(w)){ w=zwnjFix(w); if(w!==roman&&!ruleOK(w,zm)) continue }
    if(seen[w]) continue; seen[w]=1; out.push(w);
  }
  return pinRoman(out,roman);
}
function nuktaPair(w){                            /* an existing nukta keeps the spelling it has; a nukta added here is the single code point ଡ଼ ଢ଼ (U+0B5C / U+0B5D), as typed with R / Rh */
  if(!w||w.length<2||!/[\u0B21\u0B22\u0B5C\u0B5D]/.test(w)) return null;
  var a='', b='', i, c, d, n=w.length, nx;
  for(i=0;i<n;i++){
    c=w.charCodeAt(i); nx=w.charCodeAt(i+1);
    if(c===0x0B21||c===0x0B22){
      if(nx===0x0B3C){ a+=w.charAt(i)+'\u0B3C'; b+=w.charAt(i); i++; }                       /* already ଡ + nukta */
      else {
        d=i>0&&w.charCodeAt(i-1)!==0x0B4D&&w.charCodeAt(i-1)!==0x200C&&w.charCodeAt(i-1)!==0x200D&&nx!==0x0B4D;
        a+=d?(c===0x0B21?'\u0B5C':'\u0B5D'):w.charAt(i); b+=w.charAt(i);
      }
    } else if(c===0x0B5C||c===0x0B5D){ a+=w.charAt(i); b+=(c===0x0B5C?'\u0B21':'\u0B22'); }
    else { a+=w.charAt(i); b+=w.charAt(i); }
  }
  return a===b?[a]:[a,b];
}
function nkKey(w){ return w.replace(/\u0B21\u0B3C/g,'\u0B5C').replace(/\u0B22\u0B3C/g,'\u0B5D'); }      /* both spellings of ଡ଼ ଢ଼ count as the same word */
function ruRule(list, roman, keep){               /* the cluster "ru" after a consonant: ୃ first, then ୍ରୁ, then ୍ରୂ (kru: କୃ, କ୍ରୁ, କ୍ରୂ); the ZWNJ spellings ୍‌ରୁ ୍‌ରୂ follow them. Only candidates that are already in the list are moved, none is invented. */
  if(!roman||!/[b-df-hj-np-qs-tv-z]ru/i.test(roman)) return list;
  var VR='\u0B43', i, w, base=null;
  for(i=0;i<list.length;i++){ w=list[i]; if(w!==keep&&w!==roman&&/[\u0B00-\u0B7F]/.test(w)&&w.split(VR).length===2){ base=w; break; } }
  if(base===null) return list;
  var seq=[base, base.replace(VR,'\u0B4D\u0B30\u0B41'), base.replace(VR,'\u0B4D\u0B30\u0B42'), base.replace(VR,'\u0B4D\u200C\u0B30\u0B41'), base.replace(VR,'\u0B4D\u200C\u0B30\u0B42')];
  var grp=[], rest=[], first=list.length;
  for(i=0;i<seq.length;i++) if(list.indexOf(seq[i])>=0) grp.push(seq[i]);
  for(i=0;i<list.length;i++){ if(seq.indexOf(list[i])>=0){ if(i<first) first=i; } else rest.push(list[i]); }
  var at=Math.min(first,rest.length);
  if(list[0]===keep&&keep!==roman) at=Math.max(at,1);                                   /* the user's own earlier pick stays first */
  var out=rest.slice(0,at).concat(grp.slice(0,1));
  if(rest[at]===roman){ out.push(roman); at++; }                                           /* the typed text stays in slot 2 */
  return out.concat(grp.slice(1),rest.slice(at));
}
function postRules(list, keep, skipIdx, roman, scr){          /* keep: a spelling to leave exactly as it is (typed text, user's pick); skipIdx: a slot that is never rewritten */
  var out=[], later=[], seen={}, i, w, p, zw=!(scr>0);                    /* scr: the output script; the ZWNJ rule is for Odia only (Devanagari, Bangla and Assamese keep their conjuncts) */
  function put(a,x){ var k=x&&nkKey(x); if(x&&!seen[k]){ seen[k]=1; a.push(x); } }
  for(i=0;i<list.length;i++){
    w=list[i];
    if(!/[\u0B00-\u0B7F]/.test(w)){ put(out,w); continue; }
    if(w===keep||i===skipIdx){ w=zw?zwnjFix(w):w; if(!zw||w===roman||ruleOK(w,false)) put(out,w); continue; }    /* the ZWNJ rule and the strict check hold even for a word the user picked before */
    if(zw){ w=zwnjFix(w); if(w!==roman&&!ruleOK(w,false)) continue; }
    p=nuktaPair(w);
    if(p){ put(out,p[0]); if(p[1]&&(!zw||ruleOK(p[1],false))) put(later,p[1]); } else put(out,w);
  }
  for(i=0;i<later.length;i++) put(out,later[i]);
  if(zw) out=pinRoman(out,roman);
  return roman?ruRule(out,roman,keep):out;
}
function candidates(roman){
  if(!roman) return [];
  var alldig=/^[0-9]+$/.test(roman), letters=/[A-Za-z]/.test(roman);
  if(alldig||roman==='.'||!letters){gLimit=MAXC;return gen(roman)}
  var acr=acronym(roman);
  gLimit=MAXC-2-acr.length;
  var all=gen(roman); gLimit=MAXC;
  if(gFilter){
    var ok=all.filter(function(x){return x!==roman&&validOdia(x)}), f=[];
    if(ok.length) f.push(ok[0]);
    f.push(roman);
    for(var q=1;q<ok.length;q++) f.push(ok[q]);
    var hasBest=ok.length>0, head=hasBest?[f[0]]:[], rest=f.slice(hasBest?2:1);
    var sk=skeleton(roman), ex=extras(roman,f), sl=[];
    if(sk&&sk.list) sl=sk.list.filter(function(x){return f.indexOf(x)<0});
    if(sk&&sk.ntok>=3&&sl.length) f=[sl[0],roman].concat(sl.slice(1),ex,head,rest);
    else { var keep=sl.length?2:(gNsch>0?1:0); f=head.concat([roman],rest.slice(0,keep),sl,ex,rest.slice(keep)) }
    all=f;
    if(skMap&&/^[A-Za-z>~'|]+$/.test(roman)) all=skMerge(roman,all);
  }
  var up=function(x){return x.replace(/[a-z]/g,function(ch){return ch.toUpperCase()})};
  var ap=aposMatch(roman); if(ap) all=ap.concat(all.filter(function(x){return ap.indexOf(x)<0}));
  if(FIRST_EXTRA[roman]) all=[FIRST_EXTRA[roman]].concat(all.filter(function(x){return x!==FIRST_EXTRA[roman]}));
  if(!/[zZ]/.test(roman)) all=postRules(all,roman,all.indexOf(roman),roman,gScr); else all=strictList(all,gScr,roman);     /* the ZWNJ and nukta rules, before the page is laid out (z / Z words keep the engine's own order) */
  var out=[], first=Math.min(all.length,PAGE-2), i;
  for(i=0;i<first;i++) put(out,all[i]);
  put(out,up(roman.charAt(0))+roman.slice(1)); put(out,up(roman));
  for(i=first;i<all.length;i++) put(out,all[i]);
  for(i=0;i<acr.length&&out.length<MAXC;i++) out.push(acr[i]);      /* abbreviation spellings: always last, never de-duplicated */
  return out;
}

/* ================= output scripts: Odia (default), Devanagari, Bangla =================
   The engine always thinks in Odia (rules, dictionary, learning). A finished candidate is carried over letter by letter
   into the Unicode block of the chosen script - the Indic blocks line up, so most letters move by a fixed offset.
   Devanagari options: OPT_MARATHI writes ଳ as ळ (otherwise ल); OPT_ANUSVARA turns nasal + halant + a stop of the same
   class into the anusvara (conjuncts disabled): कुण्डल -> कुंडल, कुञ्ज -> कुंज. */
var SC_OR=0, SC_HI=1, SC_BN=2, SC_AS=5, OPT_MARATHI=1, OPT_ANUSVARA=2;   /* Assamese is 5 so that it matches the page's script number (3 English and 4 Phonetic never reach the engine) */
function scBase(sc){return sc===SC_HI?0x0900:(sc===SC_BN||sc===SC_AS)?0x0980:0x0B00}
function mapCp(c,sc,opt){
  if(sc===SC_OR||c<0x0B00||c>0x0B7F) return [c];
  var d=scBase(sc)-0x0B00;
  switch(c){
    case 0x0B5C: return [sc===SC_HI?0x0921:0x09A1, sc===SC_HI?0x093C:0x09BC];          /* ଡ଼ -> ड + nukta (the stable spelling of ड़ ড়) */
    case 0x0B5D: return [sc===SC_HI?0x0922:0x09A2, sc===SC_HI?0x093C:0x09BC];          /* ଢ଼ -> ढ + nukta */
    case 0x0B30: return sc===SC_AS?[0x09F0]:[c+d];                                          /* ର -> Assamese ৰ (Bangla র) */
    case 0x0B35: case 0x0B71: return [sc===SC_HI?0x0935:sc===SC_AS?0x09F1:0x09AC];        /* ଵ ୱ -> व ; Assamese ৱ ; Bangla: ব after a halant (স্ব), ওয় on its own (see toScript) */                          /* ଵ ୱ -> व ; Bangla: ব after a halant (স্ব), ওয় on its own (see toScript) */
    case 0x0B33: return [sc===SC_HI?((opt&OPT_MARATHI)?0x0933:0x0932):0x09B2];            /* ଳ -> ळ (Marathi) / ल ; Bangla ল */
    case 0x0B5F: return [sc===SC_HI?0x092F:0x09DF];                                       /* ୟ -> य ; য় */
    case 0x0B56: return [];
    case 0x0B57: return (sc===SC_BN||sc===SC_AS)?[0x09D7]:[];
  }
  return [c+d];
}
var NAS_STOPS={0x0919:[0x0915,0x0918],0x091E:[0x091A,0x091D],0x0923:[0x091F,0x0922],0x0928:[0x0924,0x0927],0x092E:[0x092A,0x092D]};
function toScript(s,sc,opt){
  if(!s||sc===SC_OR) return s;
  opt=opt||0; var a=[],i,m,j;
  for(i=0;i<s.length;i++){
    var c=s.charCodeAt(i);
    if(c===0x200D&&s.charCodeAt(i+1)===0x0B4D) continue;                                  /* the Odia-only ZWJ trick for a ya-phala after ର */
    if(c===0x0B5F&&(sc===SC_BN||sc===SC_AS)&&a.length&&a[a.length-1]===0x09CD){ a.push(0x09AF); continue }   /* Bangla ya-phala is য, য় is only the vowel-side letter */
    if((c===0x0B35||c===0x0B71)&&sc===SC_BN&&!(a.length&&a[a.length-1]===0x09CD)){ a.push(0x0993,0x09AF,0x09BC); continue }   /* Bangla wa: ওয় */
    m=mapCp(c,sc,opt); for(j=0;j<m.length;j++) a.push(m[j]);
  }
  if(sc===SC_HI&&(opt&OPT_ANUSVARA)){
    var b=[];
    for(i=0;i<a.length;i++){
      var r=NAS_STOPS[a[i]];
      if(r&&a[i+1]===0x094D&&a[i+2]>=r[0]&&a[i+2]<=r[1]&&(i===0||a[i-1]!==0x094D)){ b.push(0x0902); i++; continue }
      b.push(a[i]);
    }
    a=b;
  }
  var o=''; for(i=0;i<a.length;i++) o+=String.fromCharCode(a[i]); return o;
}
/* any Indic text -> Odia (to re-convert a document, or to learn a word that was picked in another script) */
function toOdia(s){
  var o='';
  for(var i=0;i<s.length;i++){
    var c=s.charCodeAt(i);
    if(c===0x09F0) c=0x0B30; else if(c===0x09F1) c=0x0B71;                                   /* Assamese ৰ ৱ */
    else if(c>=0x0900&&c<=0x097F&&c!==0x0964&&c!==0x0965) c+=0x0200; else if(c>=0x0980&&c<=0x09FF) c+=0x0180;
    o+=String.fromCharCode(c);
  }
  return o;
}
/* candidates in the chosen script: [display[], odia[]] ; duplicates that appear after the conversion are dropped (position 2 stays the typed text) */
/* Assamese typing: v and w are both ৱ, x is the Assamese /x/ sound (স / শ / ষ; ক্স for ksa) */
function asRoman(r){return r.replace(/v/g,'w').replace(/x/g,'s')}
/* Assamese only: typed v / w gives ৱ, and ত্ also gets its ৎ (khanda ta) spelling right beside it; the typed text always stays in slot 2 */
function asWRepl(c,toks){
  var n=0,k; for(k=0;k<c.length;k++) if(c.charCodeAt(k)===0x09AC) n++;
  if(!n||n!==toks.length) return null;
  var out='',q=0; for(k=0;k<c.length;k++){ if(c.charCodeAt(k)===0x09AC){ out+=toks[q]==='b'?'ব':'ৱ'; q++ } else out+=c[k] }
  return out;
}
function asTVar(c){
  if(!/[ঀ-৿]/.test(c)) return c;
  return c.replace(/ত্(?=$|[‌‍\s]|[কখগঘচছজঝটঠডঢথদধপফভশষসহ])/g,'ৎ').replace(/ত$/,'ৎ');
}
function asRefine(roman,disp,odia){
  var toks=roman.match(/b(?!h)|v|w/g)||[], vw=toks.some(function(t){return t!=='b'});
  var D=[],O=[],i,have={};
  function add(d,o){ if(have[d]) return; have[d]=1; D.push(d); O.push(o) }
  for(i=0;i<disp.length;i++){
    var c=disp[i];
    if(c===roman){ add(c,odia[i]); continue }
    if(vw){ var w=asWRepl(c,toks); if(w&&w!==c) add(w,odia[i]) }
    add(c,odia[i]);
  }
  var D2=[],O2=[],h2={},cnt=0;
  for(i=0;i<D.length;i++){
    var d=D[i];
    if(!h2[d]){ h2[d]=1; D2.push(d); O2.push(O[i]) }
    if(d!==roman&&cnt<10){ cnt++; var t=asTVar(d); if(t!==d&&!h2[t]&&!have[t]){ h2[t]=1; D2.push(t); O2.push(O[i]) } }
  }
  var k=D2.indexOf(roman); if(k>=0){ var oo=O2[k]; D2.splice(k,1); O2.splice(k,1); D2.splice(Math.min(1,D2.length),0,roman); O2.splice(Math.min(1,O2.length),0,oo) }
  return {disp:D2,odia:O2};
}
var gScr=0;
function candidatesIn(roman,sc,opt){
  var od; gScr=sc|0; try{ od=candidates(sc===SC_AS?asRoman(roman):roman) } finally{ gScr=0 }
  if(roman==='z'){ var zz=['‌','z','‍']; for(var q=0;q<od.length;q++) if(zz.indexOf(od[q])<0) zz.push(od[q]); od=zz }
  else if(/Z/.test(roman)&&od.length>1){        /* a typed Z (halant + ZWNJ): 1 the ZWNJ spelling, 2 what you typed, 3 the same with the halant but no ZWNJ, 4 with ZWJ, then the rest */
    var zl=transliterate(sc===SC_AS?asRoman(roman):roman), zn=zl.replace(/୍‌/g,'୍'), zj=zl.replace(/୍‌/g,'୍‍'), zr=[zl,roman];
    if(zn!==zl) zr.push(zn);
    if(zj!==zl&&zj!==zn) zr.push(zj);
    for(var zi=0;zi<od.length;zi++) if(zr.indexOf(od[zi])<0) zr.push(od[zi]);
    od=zr;
  }
  if(sc===SC_AS&&od.length>1){
    od[1]=roman;
    if(/[vw]/.test(roman)){                                   /* the dictionary is Odia-spelled (ବ for v): a typed v / w keeps ৱ first */
      var lit=transliterate(asRoman(roman)), li=od.indexOf(lit);
      if(li>1){ od.splice(li,1); od.unshift(lit) }
    }
  }
  od=strictList(od,sc|0,roman);                                     /* the strict rules over the final list, z / Z words included */
  if(sc===SC_OR) return {disp:od.slice(),odia:od};
  var disp=[],src=[];
  for(var i=0;i<od.length;i++){
    var d=toScript(od[i],sc,opt);
    if(i>1&&disp.indexOf(d)>=0) continue;
    disp.push(d); src.push(od[i]);
  }
  if(sc===SC_AS) return asRefine(roman,disp,src);
  return {disp:disp,odia:src};
}
return {postRules:postRules,zwnjFix:zwnjFix,strictList:strictList,ruleOK:ruleOK,nuktaPair:nuktaPair,tables:T,PAGE:PAGE,valid:validOdia,candidates:candidates,toScript:toScript,toOdia:toOdia,candidatesIn:candidatesIn,asRefine:asRefine,SC_OR:SC_OR,SC_HI:SC_HI,SC_BN:SC_BN,SC_AS:SC_AS,OPT_MARATHI:OPT_MARATHI,OPT_ANUSVARA:OPT_ANUSVARA,transliterate:transliterate,lexAdd:lexAdd,lexClear:lexClear,loadBuiltin:loadBuiltin,loadSkel:loadSkel};
})();
if(typeof module!=='undefined') module.exports=OdiaEngine;
