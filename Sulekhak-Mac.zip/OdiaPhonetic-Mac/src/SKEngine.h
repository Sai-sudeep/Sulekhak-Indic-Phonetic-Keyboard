// Sulekhak smart candidates for the Mac keyboard: the JavaScript engine (sulekhak.js) run inside JavaScriptCore.
// Loads lazily on a background queue the first time you type; until it is ready the built-in C engine works alone.
#import <Foundation/Foundation.h>
@interface SKEngine : NSObject
+ (instancetype)shared;
@property (readonly) BOOL ready;
- (void)startIfNeeded;                                        // call on every keystroke; starts the load once
- (NSArray<NSString *> *)suggest:(NSString *)roman prev:(NSString *)prevOdiaWord;   // Odia words, best first (nil until ready)
- (NSArray<NSString *> *)nextAfter:(NSString *)odiaWord;       // words that usually follow this one (empty when unknown or not ready)
- (NSArray<NSString *> *)phonCandidates:(NSString *)key;        // Phonetic mode: the key itself, then every IPA / extIPA / IAST symbol that looks like it
- (void)commit:(NSString *)odiaWord;                          // tell the memory cache what was chosen
@end
