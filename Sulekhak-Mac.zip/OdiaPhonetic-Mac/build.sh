#!/bin/bash
# Builds "Sulekhak Keyboard" and installs it over the version you already have.
# It keeps the same identity (com.saisudeep.inputmethod.OdiaPhonetic / .Odia), so macOS treats it as an update:
# the input source you already switched on stays on, and your own words and learned picks are kept.
# Needs only the Xcode Command Line Tools:  xcode-select --install
set -e
cd "$(dirname "$0")"
NAME="OdiaPhonetic"                       # installed app name (same as the old one, so it is replaced in place)
BUILD="build/$NAME.app"
USERIM="$HOME/Library/Input Methods"
say() { printf '\n== %s\n' "$1"; }

# The big word lists are not inside the download (they would make it 28 MB). They are fetched once from the project site.
need=""; for f in lex rom big clus syl_uni syl_bi syl_chan; do [ -s "sulekhak/$f.txt" ] || need=1; done
[ -s "sulekhak/cfg.json" ] || need=1
if [ -n "$need" ]; then
  say "0/5  Fetching the language data (about 8 MB, once)"
  mkdir -p sulekhak
  for f in cfg lex rom big clus syl_uni syl_bi syl_chan; do
    out="sulekhak/$f.txt"; [ "$f" = cfg ] && out="sulekhak/cfg.json"
    curl -fsSL "https://sai-sudeep.github.io/assets/tools/sulekhak/$f.gz" | gunzip > "$out.part" && mv "$out.part" "$out" || { echo "Could not download $f. Check the internet connection and run this again."; exit 1; }
  done
fi

say "1/5  Compiling"
rm -rf build && mkdir -p "$BUILD/Contents/MacOS" "$BUILD/Contents/Resources/en.lproj"
clang -fobjc-arc -O2 -arch arm64 -arch x86_64 -mmacosx-version-min=11.0 \
      -Isrc src/main.m src/OdiaController.m src/SKEngine.m src/OSKPanel.m src/SuggestBar.m src/engine.c \
      -framework Cocoa -framework InputMethodKit -framework JavaScriptCore -framework WebKit -framework ApplicationServices -framework Carbon \
      -o "$BUILD/Contents/MacOS/LekhaniOdia"
cp Info.plist "$BUILD/Contents/Info.plist"
mkdir -p "$BUILD/Contents/Resources/sulekhak"; cp sulekhak/* "$BUILD/Contents/Resources/sulekhak/"   # Sulekhak smart-candidate engine + data (about 28 MB)
cp html/osk.html html/kb3d.js src/engine.js html/phon-data.js html/phon-core.js "$BUILD/Contents/Resources/"        # the 3D on-screen keyboard (osk.html, kb3d.js) and the engine that labels its keys
cp src/skel.dat "$BUILD/Contents/Resources/skel.dat"       # consonant-skeleton dictionary (pasnd -> ପସନ୍ଦ)
cp menu.icns "$BUILD/Contents/Resources/menu.icns"      # 16 pt icon: a big picture here makes the input-menu row huge
cp en.lproj/InfoPlist.strings "$BUILD/Contents/Resources/en.lproj/"
codesign --force --deep -s - "$BUILD"
xattr -dr com.apple.quarantine "$BUILD" 2>/dev/null || true

say "2/5  Stopping the running copy"
for p in LekhaniOdia OdiaPhonetic; do killall "$p" 2>/dev/null || true; done
sleep 1

say "3/5  Backing up your words (Application Support)"
SUP="$HOME/Library/Application Support"
if [ -d "$SUP/LekhaniOdia" ] || [ -d "$SUP/OdiaPhonetic" ]; then
  mkdir -p "$HOME/Documents/Lekhani-backup"
  for d in LekhaniOdia OdiaPhonetic; do [ -d "$SUP/$d" ] && cp -R "$SUP/$d" "$HOME/Documents/Lekhani-backup/$d-$(date +%Y%m%d-%H%M%S)" || true; done
  echo "   copied to ~/Documents/Lekhani-backup"
fi

say "4/5  Replacing the installed version"
mkdir -p "$USERIM"
for old in OdiaPhonetic LekhaniOdia; do rm -rf "$USERIM/$old.app"; done
for old in OdiaPhonetic LekhaniOdia; do                                    # an older all-users install, if any
  if [ -d "/Library/Input Methods/$old.app" ]; then
    echo "   removing /Library/Input Methods/$old.app (your Mac password may be asked)"
    sudo rm -rf "/Library/Input Methods/$old.app" || echo "   could not remove it; delete it by hand in Finder"
  fi
done
cp -R "$BUILD" "$USERIM/$NAME.app"
LSR=/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister
[ -x "$LSR" ] && "$LSR" -f "$USERIM/$NAME.app" >/dev/null 2>&1 || true
touch "$USERIM"
killall TextInputMenuAgent 2>/dev/null || true          # refresh the input menu so the new small icon is picked up

say "5/5  Done"
echo "Installed: $USERIM/$NAME.app   (com.saisudeep.inputmethod.OdiaPhonetic.Odia)"
echo
echo "To start using it:"
echo "  1. Click the input-source icon in the menu bar, pick another keyboard, then pick 'Sulekhak Keyboard' again."
echo "  2. If it does not show up or still behaves like the old one: log out and log in once."
echo "  3. If it is not in the list at all: System Settings > Keyboard > Text Input > Input Sources > Edit... > + > Odia > Sulekhak Keyboard > Add."
