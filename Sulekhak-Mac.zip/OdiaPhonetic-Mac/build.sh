#!/bin/bash
# Builds Sulekhak and installs it (all-in-one, or one language), or packs it into a DMG.
#
#   bash build.sh                  all-in-one: Odia, Devanagari, Assamese, Bangla and Phonetic in one app; replaces the version you have
#   bash build.sh odia             Odia only         (also: devanagari, assamese, bangla, phonetic, english)
#   bash build.sh all --dmg        build and make dist/Sulekhak-<edition>-<version>.dmg instead of installing
#   bash build.sh everything --dmg all six DMGs in one go
#
# The all-in-one keeps the identity com.saisudeep.inputmethod.OdiaPhonetic, so macOS treats it as an update (your input source stays on).
# A language edition is a separate input method with its own name and identity, so it can sit beside the all-in-one or beside another edition
# (install only the ones you use: the editions share the Ctrl+Option+K hot key and the first one that starts owns it).
# Your words and learned picks are shared by all of them (Application Support/LekhaniOdia).
# Needs only the Xcode Command Line Tools:  xcode-select --install
set -e
cd "$(dirname "$0")"
ED="all"; DMG=""; FLAGS=""
for a in "$@"; do case "$a" in --dmg) DMG=1; FLAGS="$FLAGS --dmg" ;; *) ED="$a" ;; esac; done
if [ "$ED" = "everything" ]; then for e in all odia devanagari assamese bangla phonetic english; do bash "$0" "$e" $FLAGS || exit 1; done; exit 0; fi

# edition table: script number, app name, bundle id suffix, language, character repertoire, shown name
case "$ED" in
  all)        N=""; APP="OdiaPhonetic"; BID="com.saisudeep.inputmethod.OdiaPhonetic"; MODE="$BID.Odia"; CONN="OdiaPhonetic_Connection"; LANG_="or"; REP="Orya"; SHOWN="ସୁलेখk"; LABEL="All-in-one" ;;
  odia)       N=0; APP="SulekhakOdia"; LANG_="or";  REP="Orya"; SHOWN="ସୁଲେଖକ  Odia";        LABEL="Odia" ;;
  devanagari) N=1; APP="SulekhakDevanagari"; LANG_="hi"; REP="Deva"; SHOWN="सुलेखक  Devanagari"; LABEL="Devanagari" ;;
  assamese)   N=5; APP="SulekhakAssamese"; LANG_="as"; REP="Beng"; SHOWN="সুলেখক  Assamese";  LABEL="Assamese" ;;
  bangla)     N=2; APP="SulekhakBangla"; LANG_="bn"; REP="Beng"; SHOWN="সুলেখক  Bangla";      LABEL="Bangla" ;;
  phonetic)   N=4; APP="SulekhakPhonetic"; LANG_="und"; REP="Latn"; SHOWN="Sulekhak  IPA";      LABEL="Phonetic-IPA" ;;
  english)    N=6; APP="SulekhakEnglish"; LANG_="en"; REP="Latn"; SHOWN="Sulekhak  English";   LABEL="English" ;;
  *) echo "Unknown edition '$ED'. Use: all, odia, devanagari, assamese, bangla, phonetic, english."; exit 1 ;;
esac
if [ "$ED" != "all" ]; then BID="com.saisudeep.inputmethod.$APP"; MODE="$BID.Mode"; CONN="${APP}_Connection"; fi
EXE="LekhaniOdia"; [ "$ED" != "all" ] && EXE="$APP"      # own process name, so installing one edition never stops another
VER=$(sed -n 's/.*CFBundleShortVersionString<\/key><string>\(.*\)<\/string>.*/\1/p' Info.plist)
BUILD="build/$APP.app"
USERIM="$HOME/Library/Input Methods"
say() { printf '\n== %s\n' "$1"; }

# The personal build (Google sign-in and learning sync) is made when google-client.json sits next to this script;
# without it this is the public build: English and local learning, no sign-in.
PFLAG=""; [ -s google-client.json ] && PFLAG="-DSK_PERSONAL=1"

# The language data (dictionary, converter, word-sequence model) is inside this folder, the big files gzipped. Nothing is downloaded.
DATA="build/data-sk"; rm -rf "$DATA"; mkdir -p "$DATA"
for f in sulekhak/*; do
  case "$f" in
    *.gz) gunzip -c "$f" > "$DATA/$(basename "${f%.gz}")" ;;
    *)    cp "$f" "$DATA/" ;;
  esac
done
for f in sulekhak.js cfg.json lex.txt rom.txt clus.txt syl_uni.txt syl_bi.txt syl_chan.txt ng_bi1.bin ng_bi2.bin ng_tri.bin; do
  [ -s "$DATA/$f" ] || { echo "Missing language data: sulekhak/$f"; exit 1; }
done

say "1/5  Compiling  ($LABEL)${PFLAG:+, personal build}"
rm -rf "$BUILD" && mkdir -p "$BUILD/Contents/MacOS" "$BUILD/Contents/Resources/en.lproj"
EDFLAG=""; [ -n "$N" ] && EDFLAG="-DSK_EDITION=$N"
OBJ="build/obj-$ED"; rm -rf "$OBJ"; mkdir -p "$OBJ"
FRAMEWORKS="-framework Cocoa -framework InputMethodKit -framework JavaScriptCore -framework WebKit -framework ApplicationServices -framework Carbon -framework Security"
for ARCH in arm64 x86_64; do
  COMMON="-O2 -arch $ARCH -mmacosx-version-min=11.0 $EDFLAG $PFLAG -Isrc"
  OBJS=""
  for f in main OdiaController SKEngine OSKPanel SuggestBar SKLearn SKPersonal; do
    clang -fobjc-arc $COMMON -c "src/$f.m" -o "$OBJ/$f-$ARCH.o" || exit 1; OBJS="$OBJS $OBJ/$f-$ARCH.o"
  done
  clang $COMMON -c src/engine.c -o "$OBJ/engine-$ARCH.o" || exit 1; OBJS="$OBJS $OBJ/engine-$ARCH.o"
  clang++ -std=c++17 -fobjc-arc $COMMON -c src/SKEnglishTyper.mm -o "$OBJ/ent-$ARCH.o" || exit 1; OBJS="$OBJS $OBJ/ent-$ARCH.o"
  clang++ -std=c++17 $COMMON -c src/tipcore.cpp -o "$OBJ/core-$ARCH.o" || exit 1; OBJS="$OBJS $OBJ/core-$ARCH.o"
  clang++ -arch $ARCH -mmacosx-version-min=11.0 $OBJS $FRAMEWORKS -o "$OBJ/$EXE-$ARCH" || exit 1
done
lipo -create "$OBJ/$EXE-arm64" "$OBJ/$EXE-x86_64" -output "$BUILD/Contents/MacOS/$EXE" || exit 1
if [ "$ED" = "all" ]; then
  cp Info.plist "$BUILD/Contents/Info.plist"
else
  # the same property list with this edition's identity, name, language and character set
  sed -e "s#com.saisudeep.inputmethod.OdiaPhonetic.Odia#$MODE#g" -e "s#com.saisudeep.inputmethod.OdiaPhonetic#$BID#g" \
      -e "s#OdiaPhonetic_Connection#$CONN#g" -e "s#<string>LekhaniOdia</string>#<string>$EXE</string>#g" -e "s#<string>ସୁलेখk</string>#<string>$SHOWN</string>#g" \
      -e "s#<string>or</string>#<string>$LANG_</string>#" -e "s#<string>Orya</string>#<string>$REP</string>#" \
      Info.plist > "$BUILD/Contents/Info.plist"
fi
printf '"CFBundleName" = "%s";\n"CFBundleDisplayName" = "%s";\n"%s" = "%s";\n' "$SHOWN" "$SHOWN" "$MODE" "$SHOWN" > "$BUILD/Contents/Resources/en.lproj/InfoPlist.strings"
mkdir -p "$BUILD/Contents/Resources/sulekhak"; cp "$DATA"/* "$BUILD/Contents/Resources/sulekhak/"
# English: the word list, the word-pair model and the common misspellings (about 390,000 forms), and the learning / sync scripts that run inside the app
mkdir -p "$BUILD/Contents/Resources/sulekhak/en" "$BUILD/Contents/Resources/personal"
for f in english/*.gz; do gunzip -c "$f" > "$BUILD/Contents/Resources/sulekhak/en/$(basename "${f%.gz}")"; done
for f in en_lex.txt en_ng.txt en_fix.txt; do [ -s "$BUILD/Contents/Resources/sulekhak/en/$f" ] || { echo "Missing English data: $f"; exit 1; }; done
cp src/personal/*.js "$BUILD/Contents/Resources/personal/"
if [ -n "$PFLAG" ]; then cp google-client.json "$BUILD/Contents/Resources/personal-config.json"; fi   # Sulekhak smart-candidate engine, dictionary and word-sequence model (about 150 MB unpacked)
cp html/osk.html html/kb3d.js src/engine.js html/phon-data.js html/phon-core.js "$BUILD/Contents/Resources/"        # the 3D on-screen keyboard (osk.html, kb3d.js) and the engine that labels its keys
cp src/skel.dat "$BUILD/Contents/Resources/skel.dat"       # consonant-skeleton dictionary (pasnd -> ପସନ୍ଦ)
cp menu.icns "$BUILD/Contents/Resources/menu.icns"      # 16 pt icon: a big picture here makes the input-menu row huge
codesign --force --deep -s - "$BUILD"
xattr -dr com.apple.quarantine "$BUILD" 2>/dev/null || true

if [ -n "$DMG" ]; then
  say "2/5  Making the DMG"
  STAGE="build/dmg-$ED"; rm -rf "$STAGE"; mkdir -p "$STAGE" dist
  cp -R "$BUILD" "$STAGE/$APP.app"
  mkdir -p "$STAGE/.extras"; cp tools/quick_action.sh "$STAGE/.extras/quick_action.sh"
  cat > "$STAGE/Install Sulekhak $LABEL.command" <<INST
#!/bin/bash
# Double-click (first time: right-click > Open, because the file came from the internet). Installs Sulekhak $LABEL for you only.
cd "\$(dirname "\$0")"
UIM="\$HOME/Library/Input Methods"
mkdir -p "\$UIM"
killall $EXE 2>/dev/null; sleep 1
rm -rf "\$UIM/$APP.app"
$( [ "$ED" = all ] && echo 'for old in LekhaniOdia; do rm -rf "$UIM/$old.app"; done' )
cp -R "$APP.app" "\$UIM/$APP.app"
xattr -dr com.apple.quarantine "\$UIM/$APP.app" 2>/dev/null
LSR=/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister
[ -x "\$LSR" ] && "\$LSR" -f "\$UIM/$APP.app" >/dev/null 2>&1
touch "\$UIM"; killall TextInputMenuAgent 2>/dev/null
[ -f .extras/quick_action.sh ] && bash .extras/quick_action.sh
echo
echo "Installed Sulekhak $LABEL $VER."
echo "Next: System Settings > Keyboard > Text Input > Input Sources > Edit... > + > search \"Sulekhak\" or the language > Add."
echo "If it does not appear, log out and log in once."
read -n 1 -s -r -p "Press any key to close"
INST
  chmod +x "$STAGE/Install Sulekhak $LABEL.command"
  cat > "$STAGE/Uninstall.command" <<UNI
#!/bin/bash
killall $EXE 2>/dev/null; sleep 1
rm -rf "\$HOME/Library/Input Methods/$APP.app"
echo "Sulekhak $LABEL is removed. Your words stay in ~/Library/Application Support/LekhaniOdia."
read -n 1 -s -r -p "Press any key to close"
UNI
  chmod +x "$STAGE/Uninstall.command"
  printf 'Sulekhak %s %s\n\n1. Double-click "Install Sulekhak %s.command" (the first time: right-click it, choose Open, then Open again).\n2. System Settings > Keyboard > Text Input > Input Sources > Edit... > + and add it.\n3. Log out and in once if it does not show up.\n\nThe app is not notarised by Apple, so macOS asks once. Your own words and learned picks are kept in ~/Library/Application Support/LekhaniOdia and shared by every Sulekhak edition.\n' "$LABEL" "$VER" "$LABEL" > "$STAGE/README.txt"
  OUT="dist/Sulekhak-$LABEL-$VER.dmg"; rm -f "$OUT"
  # hdiutil sometimes answers "Resource busy" (a leftover mount, Spotlight): wait and try again
  n=0
  until hdiutil create -volname "Sulekhak $LABEL $VER" -srcfolder "$STAGE" -ov -format UDZO "$OUT" >/dev/null 2>&1; do
    n=$((n+1))
    [ "$n" -ge 6 ] && { echo "hdiutil failed 6 times"; hdiutil create -volname "Sulekhak $LABEL $VER" -srcfolder "$STAGE" -ov -format UDZO "$OUT"; exit 1; }
    for v in /Volumes/Sulekhak*; do [ -d "$v" ] && hdiutil detach "$v" -force >/dev/null 2>&1 || true; done
    sync; sleep $((n*4))
  done
  say "Done"; echo "Made: $OUT"; exit 0
fi

say "2/5  Stopping the running copy"
if [ "$ED" = all ]; then for p in LekhaniOdia OdiaPhonetic; do killall "$p" 2>/dev/null || true; done; else killall "$EXE" 2>/dev/null || true; fi
sleep 1

say "3/5  Backing up your words (Application Support)"
SUP="$HOME/Library/Application Support"
if [ -d "$SUP/LekhaniOdia" ] || [ -d "$SUP/OdiaPhonetic" ]; then
  mkdir -p "$HOME/Documents/Lekhani-backup"
  for d in LekhaniOdia OdiaPhonetic; do [ -d "$SUP/$d" ] && cp -R "$SUP/$d" "$HOME/Documents/Lekhani-backup/$d-$(date +%Y%m%d-%H%M%S)" || true; done
  echo "   copied to ~/Documents/Lekhani-backup"
fi

say "4/5  Replacing the installed version"
mkdir -p "$USERIM"
if [ "$ED" = "all" ]; then
  for old in OdiaPhonetic LekhaniOdia; do rm -rf "$USERIM/$old.app"; done
  for old in OdiaPhonetic LekhaniOdia; do                                    # an older all-users install, if any
    if [ -d "/Library/Input Methods/$old.app" ]; then
      echo "   removing /Library/Input Methods/$old.app (your Mac password may be asked)"
      sudo rm -rf "/Library/Input Methods/$old.app" || echo "   could not remove it; delete it by hand in Finder"
    fi
  done
else
  rm -rf "$USERIM/$APP.app"
fi
cp -R "$BUILD" "$USERIM/$APP.app"
LSR=/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister
[ -x "$LSR" ] && "$LSR" -f "$USERIM/$APP.app" >/dev/null 2>&1 || true
touch "$USERIM"
killall TextInputMenuAgent 2>/dev/null || true          # refresh the input menu so the new small icon is picked up
bash tools/quick_action.sh || true                      # right-click > Services > Add to Sulekhak Dictionary

say "5/5  Done"
echo "Installed: $USERIM/$APP.app   ($MODE)   Sulekhak $LABEL $VER"
echo
echo "To start using it:"
echo "  1. Click the input-source icon in the menu bar, pick another keyboard, then pick '$SHOWN' again."
echo "  2. If it does not show up or still behaves like the old one: log out and log in once."
echo "  3. If it is not in the list at all: System Settings > Keyboard > Text Input > Input Sources > Edit... > + > search 'Sulekhak' > Add."
